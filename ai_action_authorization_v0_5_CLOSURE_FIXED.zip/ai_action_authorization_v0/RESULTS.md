# Current V0.5 closure-fix results

Final recommendation: **CLOSE_WITH_EXPLICIT_LIMITATIONS**.

The initial V0.5 acceptance claim and consistency ordering are superseded. Exact original documents and archive remain in `historical/`, with independent review findings unchanged. The complete current matrix, nonpassing historical assertions, commands, mutation results and limits are in [CLOSURE_FIX_RESULTS.md](CLOSURE_FIX_RESULTS.md). The architecture assessment is in [CLOSURE_FIX_REVIEW.md](CLOSURE_FIX_REVIEW.md).

New closure-fix run: 39 tests; OK. Legacy through V0.4: 311 tests; OK. Full discovery: 409 tests; FAILED (failures=15, errors=3); this is not a clean full-suite result. Required plus provider-validation mutants: 9/9 detected. Preserved mutation definitions: 89/89 detected on passing selected suites, with explicit rebase records.

Contract requirements control requiredness. Consistency properties are independent explicit sets. Strong assertions need authenticated, capability-scoped sources and complete deterministic security-use binding. Ordinary multi-state predecessor projection both executes and independently verifies. Duplicate/conflicting identity, malformed state and unknown critical semantics fail closed. Receipts retain property sets.

Strong projected multi-state composite contexts remain unsupported and are denied. The protocol still depends on honest complete contracts, truthful authoritative infrastructure and real isolation for Mode B. The combined GC finding failure and isolated success are both recorded, not erased or reclassified as a new state-binding regression.
