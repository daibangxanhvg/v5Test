# V0.5 closure-fix StateBinding semantics

This document supersedes the earlier V0.5 consistency ordering. The exact closure-review documents, findings, original archive and implementation brief are retained under `historical/` and in the original review files. This is a V0.5 repair, not V0.6.

## Authority and identity

The contract declares dependency IDs, subject references and requiredness. An offered binding contains opaque `(dependency_id, issuer, subject_ref, binding_type, binding_value, required)` entries. Contract-required dependencies must be present and cannot be offered as optional. Contract-optional dependencies may be made required; then their coverage, issuer authority and conditional execution are also required. Offered IDs must be declared. Duplicate IDs, including exact duplicates and duplicates on different subjects, are rejected. Contradictory tokens for the same issuer/subject are rejected. No token interpretation or provider dependency inference occurs.

## Independent properties

`required_consistency` and `observed_consistency` accept one known property name or a nonempty list/tuple of distinct property names:

* `INDIVIDUALLY_CHECKED`: the declared required dependencies were individually validated.
* `SNAPSHOT_CONSISTENT`: the declared dependency set was observed in a common coherent context.
* `ATOMIC_PRECONDITION`: the declared predicates are enforced at the protected effect boundary.

No property implies another. All required properties must be explicitly observed. Snapshot-only cannot satisfy atomic-only; atomic-only cannot satisfy snapshot-only. Requiring both requires both. Receipts report property lists. The exported historical name `STATE_CONSISTENCY_LEVELS` is now an unordered frozenset of supported names, not an ordering.

## Authenticated context scope

Every observed strong property requires a consistency context with nonempty `value` and `source`, exact required `covers`, and `scope`: a list of deterministic security-use digests. A digest includes contract security identity, security intent digest, delegation/authorization lineage, execution ID, request plan, observed properties, and full effective-required dependency entries including issuer, subject, representation and opaque token.

The delegation + security intent + contract + request identify authorization lineage before constructing the grant. This avoids signing a grant containing its own consistency context; subsequent execution still reauthorizes and compares the exact issued grant. A mismatched scope is rejected. Immutable contexts may authenticate several exact scopes, permitting reuse for explicitly covered actions without imposing single-use snapshot semantics. There is no wildcard replay permission.

The existing evidence-source registry gains deployer-only `register_consistency(address, source, properties, issuers, validator)`. A source must already have registered authoritative provenance. Its capabilities must cover the observed strong properties and every effective-required issuer. The callback must authenticate the complete opaque assertion and return the literal Boolean `True`; exceptions and unavailable authority fail closed. Merely naming a registered source is insufficient. The test fixture authenticates exact context bytes against a separately held digest; production infrastructure must supply its own authoritative authentication and property enforcement.

`cross_issuer_scope_proven=True` has no accepted proof semantics. Independent local contexts cannot be combined into a global claim. A common source must be explicitly registered to establish the property for all covered issuers; it is an authority interface, not a transaction coordinator.

## Composite predecessor projection

Existing execution-unit content adds `state_dependencies` and `establishes`, lists of contract-declared IDs. Required dependencies must be covered by required conditional units. `establishes` cannot exceed the predecessor's declared precondition scope. These are fields inside ExecutionBinding, not new objects or binding categories.

U1 declares dependencies A+B and establishes B. U2 declares dependencies B+C and `state: {from_unit: U1}`. U1 must return a complete established-state envelope for exactly B, including `execution_id`, `from_unit`, dependency identity and opaque B2 token. U1 success alone produces no state authority. The boundary requires successful predecessor status and matching execution/predecessor lineage, retains issuer/subject/representation/requiredness, rejects changed guarantees, and merges the established B2 into U2's original bound C. U2's trusted effector validates B2+C against authoritative state before any effect. Missing, stale, substituted or false tokens do not execute U2.

Earlier legitimate tokens in the predecessor's boundary-recorded applied state survive later handoffs. Independent receipt evidence is compared using the same projection/merge semantics, rather than equating a B-only established envelope to a B+C applied precondition. Contradictory evidence yields VIOLATION. No rollback is promised: an unsuccessful U2 leaves U1's effect in place.

## Closed semantics and limits

Unknown fields and nonempty unknown `critical` extensions in state dependencies, StateBinding or strong contexts fail closed. `noncritical` dictionaries are inert annotations and cannot drive core execution or authority. Malformed structures, `covers=None`, invalid guarantee sequences, missing fields and empty sources produce DENY. Legacy single-state serialization remains supported; critical extensions are checked on that path too.

Strong contexts for projected multi-state composite units are explicitly unsupported and denied before execution. An aggregate snapshot cannot silently become a snapshot for projected or newly established state. Supported multi-state composition currently uses explicit individual guarantees and trusted conditional provider enforcement. No generic global snapshot, cross-provider atomic infrastructure, provider token parser, ontology, transaction coordinator, compensation, Saga or 2PC is implemented.

Guarantees remain conditional on complete honest contracts and honest authoritative validators/effectors. Registered authorities can be compromised; the protocol cannot manufacture truth. Mode B's same-process Python model is not actual process isolation.
