# V0.5 Closure Fix --- Codex Implementation Brief

## Mission

Repair the concrete defects found by the independent V0.5 adversarial
closure review, then rerun the complete baseline + adversarial suite.

This is **NOT V0.6**. Do not add features for their own sake. Do not
optimize for a green verdict. Make the minimum coherent architectural
corrections needed to restore the intended invariants.

The supplied ZIP is the closure-review archive and contains the
preserved baseline, adversarial tests, review findings, mutation tools,
logs, and documents. Treat `CLOSURE_REVIEW.md` and
`ADVERSARIAL_RESULTS.md` as the authoritative defect report.

## Non-negotiable protocol invariants

Preserve:

``` text
EXECUTION AUTHORITY
    ⊆ AUTHORIZATION GRANT
    ⊆ ACTION INTENT
    ⊆ USER DELEGATION
    ⊆ CAPABILITY CONTRACT
```

and:

``` text
NO AUTHORITY BYPASS
```

For state requirements specifically:

``` text
OFFERED / DERIVED STATE REQUIREMENTS MUST NOT WEAKEN
CONTRACT-DECLARED SECURITY-CRITICAL STATE REQUIREMENTS.
```

Unknown security-critical semantics fail closed.

Do not infer undisclosed provider dependencies/effects. A
lying/incomplete contract and a lying authoritative validator remain
explicit trust boundaries.

## Architectural constraint

Prefer repairing existing `StateBinding`, `ExecutionBinding`, and
handoff semantics.

Do NOT introduce a sixth top-level lifecycle object or a new top-level
binding category unless the existing model is demonstrably incapable of
expressing a common case. If you believe one is unavoidable, stop and
document the proof instead of silently adding it.

Forbidden scope creep: - universal ontology; - provider/domain branches
in generic core; - parsing ETag/MVCC/CAS/provider token semantics; -
Saga/2PC/rollback/compensation engine; - distributed transaction
coordinator; - workflow engine; - LLM inference of missing
dependencies; - fake backward compatibility requirements for unreleased
V0.x prototypes.

## Fix set

### F1 --- Contract authority over dependency criticality (D1)

The contract is authoritative for whether a declared dependency is
required.

An offered `StateBinding` MUST NOT weaken:

``` text
contract dependency required=true
```

into:

``` text
offered dependency required=false
```

The core must normalize/derive effective requiredness from the contract
or require exact compatible metadata. Provider-supplied `required` must
never be able to reduce contract requirements.

Security test: - contract requires B; - offered binding marks B
optional; - B changes before execution; - no protected effect may occur.

Also test: - contract optional + offered required is allowed only if it
safely narrows execution and does not create inconsistent coverage
semantics; - required coverage/issuer aggregation is computed from
contract-effective requiredness, not attacker-controlled offered flags.

### F2 --- Multi-state predecessor handoff / projection (D2)

Support the ordinary composite case:

``` text
initial:
A@a1
B@b1
C@c1

U1 requires A+B
U2 requires B+C

U1 executes and establishes B@b2

U2 must execute only with:
B@b2 + current/authorized C@c1
```

Do not infer B@b2 merely from U1 success.

The handoff must explicitly derive the U2 precondition from: 1.
authoritative established state produced by the predecessor for the
dependencies it legitimately updates; and 2. unchanged dependencies
already bound/validated for U2.

The resulting precondition must preserve exact dependency identity: -
dependency ID; - issuer; - subject; - binding representation/type; -
opaque value; - lineage/scope required by the protocol.

Do not use the legacy single-subject `_as_binding` shape as the only
decoder for multi-state handoff.

Required attacks: - stale B@b1; - substituted subject; - wrong issuer; -
wrong predecessor/execution lineage; - predecessor
failed/partial/unknown; - predecessor claims B@b2 but authoritative
established state disagrees; - missing B2; - U2 before U1; - injected
U3; - U1 changes B but U2 attempts to reuse original aggregate binding
unchanged.

A valid positive control MUST execute U2 successfully. Attack tests are
not meaningful if all are rejected by an unsupported decoder.

### F3 --- Replace the false consistency total order (D3)

Remove the assumption:

``` text
INDIVIDUALLY_CHECKED < SNAPSHOT_CONSISTENT < ATOMIC_PRECONDITION
```

as a universal total order.

Model the guarantees as independent properties/claims.

At minimum distinguish:

``` text
individual validation:
    required dependencies were individually validated

snapshot consistency:
    a declared dependency set was observed under a common coherent
    snapshot/consistency context

atomic precondition:
    declared predicates/preconditions were checked atomically with
    the protected effect/commit boundary
```

A contract may require one or more properties.

Examples: - snapshot required + atomic only =\> DENY; - atomic
required + snapshot only =\> DENY; - both required + only one
established =\> DENY; - both established =\> ALLOW; - only individual
required =\> stronger additional properties may be present but must not
be inferred from each other.

Do not invent domain token semantics.

If a compact enum cannot represent this honestly, change the internals
of existing StateBinding to a small explicit guarantee set/structured
claims. This is a change inside the existing binding, not automatically
a new protocol primitive.

Update receipt/reporting so it does not collapse orthogonal guarantees
back into a false single level.

### F4 --- Consistency-context scope and lineage (D4)

A strong consistency context must be explicitly scoped/bound.

At minimum bind/validate the context against the security-relevant
dimensions needed to prevent demonstrated replay: - dependency set with
issuer + subject identity, not only local dependency IDs; -
contract/security identity; - ActionIntent or its security digest; -
AuthorizationGrant or authorization lineage where applicable; -
execution identity when the context is execution-specific; -
guarantee/property being asserted; - authoritative issuer/source of the
context.

Do not impose single-use semantics on a provider snapshot merely because
it is reusable. Reuse is allowed only when the context's declared scope
legitimately covers the new use. The core must be able to distinguish
safe reusable immutable context from mismatched replay.

Use deterministic opaque digests/bindings; do not parse provider
snapshot internals.

### F5 --- Cross-provider strong consistency needs authenticated authority (D5)

Delete `cross_issuer_scope_proven=True` as a sufficient proof.

A Boolean assertion from the adapter/provider is not evidence.

For a strong context spanning multiple issuers/providers, require an
authoritative source/capability that is trusted to establish that
cross-provider property, and bind its assertion to the exact dependency
scope.

Reuse existing authority/evidence registration mechanisms if they can
express this honestly. Do not create a transaction coordinator.

If no trusted cross-provider authority/infrastructure exists: -
individual local checks may still be valid; - local snapshots may still
be valid locally; - global snapshot/atomic claims must be
unsupported/fail closed.

Two independent local snapshots MUST NOT become one global snapshot by
aggregation.

### F6 --- Dependency identity and conflicts (D6)

Make dependency identity unambiguous.

Requirements: - duplicate `dependency_id` in the same StateBinding must
fail closed, even if subjects differ; - exact duplicate dependency
entries fail closed; - conflicting bindings for the same
security-relevant subject/role must not be silently accepted; - context
coverage must reference an unambiguous canonical dependency identity.

Do not solve by introducing domain meaning.

### F7 --- Malformed input must DENY, not crash (D7)

Malformed state/consistency structures must produce deterministic DENY /
unavailable results.

Specifically cover: - `covers=None`; - wrong types; - missing required
fields; - empty authoritative issuer/source; - malformed guarantee
set; - malformed dependency scope.

No uncaught TypeError/KeyError/ValueError from untrusted protocol
structures.

### F8 --- Unknown critical extensions fail closed (D8)

Define a closed handling rule for critical StateBinding /
consistency-context extensions.

If an unknown extension is marked security-critical: - DENY /
unsupported.

Unknown noncritical extensions may be ignored only if they cannot
influence execution, authority, state validation, evidence, or
consistency guarantees.

Preserve the V9 fail-closed rule. Do not silently accept unknown
critical semantics.

## Trust boundary --- do not "fix" the impossible

The following are NOT reasons to add ontology or global coordination:

1.  Provider contract omits a real hidden dependency/effect.
    -   Document: guarantee is conditional on honest/complete
        security-relevant declaration.
2.  Authoritative state validator lies.
    -   Document: protocol cannot manufacture truth.
    -   Strong claims require trusted/registered authority but cannot
        survive compromise of that authority.
3.  Infrastructure cannot establish global snapshot or atomic
    precondition.
    -   Fail closed for actions requiring that property.
    -   Do not emulate it by sequential checks.
4.  Mode B same-process isolation.
    -   Preserve prior limitation; do not redesign it in this task.

## Required end-to-end tests

Do not satisfy this brief with object/list assertions where a verifier +
execution boundary test is possible.

### Positive controls

P1. Single-state legacy path still works. P2. Multi-state A+B
authorization works. P3. U1(A+B) -\> establishes B2 -\> U2(B2+C)
executes successfully. P4. Snapshot-only requirement succeeds with
authoritative correctly scoped snapshot context. P5. Atomic-only
requirement succeeds with authoritative atomic enforcement. P6. Both
snapshot+atomic required succeeds only when both are established. P7.
Safe reusable snapshot context succeeds for a second action only when
its declared scope covers that reuse.

### Negative controls

N1. required=true downgraded to false. N2. stale B1 after U1. N3. wrong
B2 subject. N4. wrong B2 issuer. N5. B2 from another
execution/predecessor. N6. U1 failed/partial/unknown then U2. N7.
snapshot requirement satisfied only by atomic. N8. atomic requirement
satisfied only by snapshot. N9. two local snapshots asserted as global.
N10. bare cross-provider Boolean. N11. context replay across changed
dependency subject. N12. context replay across changed issuer. N13.
context replay across changed intent/security digest. N14. context
replay across incompatible grant/execution scope. N15. duplicate
dependency_id. N16. conflicting same-subject binding. N17. malformed
`covers`. N18. unknown critical context extension. N19. missing trusted
authority for a strong context. N20. provider cannot validate one
required dependency.

## Mutation requirements

At minimum prove that tests detect these regressions:

1.  allow offered `required=false` to weaken required dependency;
2.  skip post-U1 B2 handoff validation;
3.  restore atomic=\>snapshot implication;
4.  remove context dependency-scope binding;
5.  remove context intent/grant/execution lineage check;
6.  accept bare cross-provider Boolean;
7.  ignore duplicate dependency ID;
8.  ignore unknown critical extension.

Each mutation must make a relevant previously passing security test
fail.

## Regression requirements

Run: - all preserved V0/V0.1/V0.2/V0.3/V0.4/V0.5 tests; - all closure
adversarial tests; - all new closure-fix tests; - mutation suite.

Do not hide the legacy runtime-sensitive Mode B GC finding. Classify it
separately exactly as evidence supports.

## Core audit after fixes

Report: - new top-level lifecycle objects: expected 0; - new binding
categories: expected 0; - provider-specific generic-core branches:
expected 0; - transaction coordinator: expected 0; - ontology/domain
semantics: expected 0; - generic-core LOC delta from supplied
closure-review base; - StateBinding schema/field growth; - complexity of
state/consistency validation; - whether existing object count is hiding
an overgrown "god binding."

If the repair makes StateBinding incoherent or excessively overloaded,
report that as an architecture finding rather than celebrating
object-count stability.

## Documentation updates

Update: - `ARCHITECTURE.md` - `RESULTS.md` - `MULTI_STATE_BINDING.md`

Add: - `CLOSURE_FIX_RESULTS.md` - `CLOSURE_FIX_REVIEW.md`

Explain the corrected consistency semantics explicitly. Remove or
supersede any documentation that still claims a universal three-level
total order.

Keep prior closure-review findings as historical evidence; do not erase
them.

## Final decision

Return exactly one:

### `CLOSE_V0_EXPERIMENTAL_ARCHITECTURE`

Only if all core counterexamples are repaired, positive composition
works, strong consistency claims are honest and scoped, no new primitive
is needed, and remaining limitations are explicit trust/infrastructure
boundaries.

### `CLOSE_WITH_EXPLICIT_LIMITATIONS`

Use if no known core security counterexample remains and the
architecture is stable enough to stop V0.x, but important
supported-envelope limitations must be carried into specification work.

### `DO_NOT_CLOSE_V0`

Use if a core defect still permits unauthorized execution, false strong
state/consistency claims, stale execution under claimed guarantees,
ordinary A+B -\> B+C composition still lacks a valid positive path, or
the repair reveals that another architectural primitive is genuinely
necessary.

A green test count alone is not sufficient.

## Deliverable

Return one complete ZIP containing: - full implementation; - preserved
old tests; - adversarial closure tests; - closure-fix tests; - mutation
tools/results; - updated docs; - exact commands/logs; -
`CLOSURE_FIX_RESULTS.md`; - `CLOSURE_FIX_REVIEW.md`.

Suggested filename:

`ai_action_authorization_v0_5_CLOSURE_FIXED.zip`

Do not start V0.6. Do not perform standards comparison. Do not
productize.
