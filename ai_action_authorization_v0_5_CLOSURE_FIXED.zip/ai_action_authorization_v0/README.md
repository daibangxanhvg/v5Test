> **V0.5 closure-fix status:** See [CLOSURE_FIX_RESULTS.md](CLOSURE_FIX_RESULTS.md) and [CLOSURE_FIX_REVIEW.md](CLOSURE_FIX_REVIEW.md). Initial V0.5 guarantee ordering and unscoped strong-context assumptions are superseded. All old tests and original mutation tools are preserved; some old assertions intentionally remain incompatible with corrected semantics. Reproduce final runs with `PYTHONPATH=src:. python tools/run_closure_fix.py`. This is not V0.6.

# AI Action Authorization Protocol — V0.4 Prototype

An experiment testing one hypothesis:

> Can application-specific semantics vary across very different domains while the AI action authorization/enforcement core stays unchanged?

The core is tested against three very different domains: Matrix messaging, calendar rescheduling, and an irreversible FakePay money transfer.

**V0 result: SURVIVED, with recorded deficiencies.** See [RESULTS_V0.md](RESULTS_V0.md).

V0.1 hardens two V0 findings without redesigning the protocol:

- **F6 (evidence trust):** an adapter's claims about its own work can no longer produce `VERIFIED`.
- **F7 (state binding / TOCTOU):** authorization over mutable provider state is carried into execution as an opaque precondition, and the provider enforces it atomically.

**V0.1 result: PARTIALLY_SURVIVED.** The core stayed generic, but the guarantees depend on provider cooperation. See [RESULTS_V01.md](RESULTS_V01.md).

V0.2 targets finding **V01-A**: an executor holding provider credentials could perform the authorized effect X **and** an unauthorized extra effect Y. V0.2 adds:

- **ExecutionCredential:** a single-use credential attenuated from an `AuthorizationGrant`. It can never be broader than the grant.
- **Enforcement boundary:** every provider effect requested by the untrusted executor is checked against the credential before provider code runs.
- **Confinement reporting:** Mode A, B or C. An executor that can reach a broad provider credential is reported `NOT_CONFINED` and is refused by default.
- **V01-B:** evaluators declare the state they relied on. Gaps are classified and block attenuation.

**V0.2 result: PARTIALLY_SURVIVED.** Y is prevented generically in all three domains, but only in Mode B (a trusted gateway holds the broad credential), and only if the executor is isolated from the gateway's process. The in-memory model cannot enforce that isolation. See [RESULTS_V02.md](RESULTS_V02.md).

V0.3 attacks the **protocol boundary itself** with the V9 failure wall (W1–W10) and two synthetic newcomers:

- **N1 Folio** `rename_document`: reversible, with a deliberately different wire format.
- **N2 PubHub** `publish_and_notify`: a high-risk composite that the provider performs as two calls.

Lower-layer infrastructure is assumed and only modeled as declared inputs.

**V0.3 result: BOUNDARY_PARTIALLY_SURVIVED.**

- Kept: 0 new protocol objects, 0 new binding categories, 0 provider-specific core branches, 0 existing-provider changes. Unknown critical semantics fail closed.
- The cost: composite actions needed about 12 new fields inside existing bindings. Sound verification of composites depends on new provider and deployer declarations.
- The wall found two V0.2 deficiencies, both fixed generically: silently ignored unknown structure, and a contract-namespace collision.

See [RESULTS_V03.md](RESULTS_V03.md).

V0.4 asks one narrow question: can the composite-action failures found in V0.3 be solved by opaque, effect-bound **execution units** structured inside the existing ExecutionBinding? The failures are V03-A (must-happen effects), V03-B (evidence scope) and V03-H (inter-step state). The constraints: no sixth object, no new binding category, no effect ontology, and no provider logic in the core.

- **Contract.** A provider may declare `execution_units`: opaque ids that partition the contract's effects. Each unit has an explicit `required` flag, the request fields it carries, an explicit order (`after`) and an explicit state precondition (`authorization`, `unbound`, or `from_unit` = the state a predecessor's effect established).
- **Grant and credential.** The exact unit table is bound into the grant. A credential may be narrowed to a subset of units.
- **Enforcement boundary.** It issues one permit per unit. Each unit is single-use and must follow its declared predecessors. The boundary itself computes the precondition from the predecessor's established state, and the provider applies it atomically.
- **Evidence.** Evidence must name the units it covers, carry the grant lineage, and come from a source the deployer scoped to those units. Joint coverage of two units only counts when the contract declares it.
- **Required units** are always read from the contract. A partial composite is never VERIFIED.

**V0.4 result: COMPOSITE_BINDING_PARTIALLY_SURVIVED.**

- Kept: 0 new objects, 0 new binding categories, 0 provider-specific core branches, 0 existing-provider changes. V03-A/B/H (and V03-C) are closed for contracts that declare units, and inter-step state is now *prevented* rather than detected. Opaque renaming changes nothing, and a meaningless three-unit domain works.
- The cost:
  - +650 core lines and 11 new fields;
  - materially stronger provider declarations: a unit table, exposed version tokens, and lineage recorded with every write;
  - the fix is opt-in, because making it the default would force existing multi-effect providers (FakePay V2, Calendar V2) to migrate;
  - one common case is not expressible: per-resource state binding for units on different mutable resources. It fails closed.
  - A lying contract remains a stated trust boundary.

See [RESULTS.md](RESULTS.md), [COMPOSITE_EXECUTION.md](COMPOSITE_EXECUTION.md), [PROTOCOL_BOUNDARY.md](PROTOCOL_BOUNDARY.md) and [V9_FAILURE_WALL.md](V9_FAILURE_WALL.md).

## Run

Requires Python ≥ 3.9 and no third-party packages.

```sh
cd ai_action_authorization_v0
python3 -m unittest discover -t . -s tests -v
```

Expected output: `Ran 311 tests ... OK`. That is 152 V0–V0.2 tests, 73 V0.3 tests (all byte-identical to the V0.3 zip) and 86 V0.4 tests.

Optional checks (not part of the suite):

```sh
python3 tools/mutate_v04.py      # disables 55 V0.4 protections one at a time (55/55 detected)
python3 tools/mutate_v03.py      # the 29 V0.3 mutations, re-run on the V0.4 core (28/29; 1 equivalent)
python3 tools/v04_probe.py [<V0.3 project>/src]   # how a core treats the V3 unit contract
```

Tests named `test_FINDING_*` assert that a weakness **exists**. They document known problems and do not fix them. The V0 F6/F7 finding tests now assert that the weakness is **closed** (same scenario, inverted expectation).

## Layout

```
src/aaap/               domain-agnostic core (the thing under test)
  objects.py            the five protocol objects (+ Confirmation record), intent digest;
                        V0.1: StateBinding, AuthorizationGrant, ExecutionEvidence, provenance classes
  verifier.py           the single shared AuthorizationVerifier (steps 1–16; V0.1: 8b state binding,
                        grant checks, evidence judging)
  evaluators.py         ConstraintEvaluatorRegistry + generic core.* evaluators
  gateway.py            ActionGateway: the only path from an intent to an effect
                        (V0.1: grant-bound conditional execution, evidence-source registration)
  stores.py             ContractRegistry, DelegationStore, ExecutionLedger, GrantStore,
                        EvidenceSourceRegistry (in-memory)
  adapter.py            ProviderAdapter interface, ExecutionResult (= ExecutionReport), ProviderTimeout;
                        V0.1: state_binding/execute_conditional, PreconditionFailed, EvidenceSource
  canonical.py          V0 canonical JSON + sha256 digest
  authority.py          V0.2: ExecutionCredential, attenuation, enforcement boundary (ExecutionPort),
                        ProviderEffector interface, Mode A/B/C confinement assessment
fixtures/
  matrix/               contract, fake homeserver (txnId semantics, /sync transaction_id), adapter,
                        observer.py (V0.1 evidence source), wiring
  calendar/             contracts v1/v2, fake calendar (etag + If-Match CAS, request records),
                        adapter (+ buggy adapter for C3), observer.py, wiring
  fakepay/              contracts v1/v2/quantum/no-minimum, fake payment provider (account revision CAS),
                        adapter, observer.py, wiring
  */effector.py         V0.2: trusted Mode B gateway effector (holds the broad provider credential)
  */world.py            V0.2: build_confined() wiring
tests/
  harness.py            generic wiring of one core instance
  test_matrix.py        M1–M4 (+ variants)
  test_calendar.py      C1–C4 (+ variants)
  test_fakepay.py       P1–P7
  test_cross_domain.py  X1 revocation, run across all three domains
  test_knowledge_evolution.py  K1–K5 (FakePay V1 -> V2)
  test_adversarial.py   core-guard probes + FINDING tests
  test_v01_f6_f7.py     V0.1: E1–E6, S1–S6, X1–X4, U1–U5, G18–G19, FINDING_V01_A–F
  test_v02_execution_authority.py
                        V0.2: A1–A12, R1–R3, B1–B3b, T1–T7, H1–H4, D1–D5, G20–G21, FINDING_V02_A–D
  test_v03_protocol_boundary.py
                        V0.3: P1–P10, T1–T6, E1–E4, W9a–b, G22–G24, FINDING_V03_A–E
  v02_baseline_manifest.json  SHA-256 of every V0.2 provider/test file (checked by P6a)
fixtures/folio/         V0.3 N1 newcomer: fake Folio store (FD-refs, nested body, integer revision),
                        mapping.py (the only code knowing both vocabularies), adapter, effector, observer
fixtures/pubhub/        V0.3 N2 newcomer: fake PubHub (publish + notify, provider-side chaining), mapping.py
                        (audience <-> list, refuses ambiguity), effector (performs the split, reports PARTIAL),
                        two effect-scoped observers, policy.py (provider-supplied path-policy evaluator)
fixtures/pubhub_units/  V0.4: PubHub publish_and_notify V3 with two execution units (sequential state). Reuses the
                        V0.3 PubHub provider/adapter/mapping unchanged; adds a conditional-notify subclass, a unit
                        effector (provider-side unit-id role table, lineage metadata), per-unit and activity observers
fixtures/triad/         V0.4 B2: synthetic domain with three opaque units (a1, b2, c3)
tests/test_v04_composite_execution.py
                        V0.4: C1–C16, S1–S6, A1–A5, E1–E5, B1–B5, CT1–CT4, G25–G28, FINDING_V04_A–E
tests/v03_baseline_manifest.json  SHA-256 of every V0.3 fixture/test file (checked by B5a)
tools/                  mutate_v03.py, mutate_v04.py (mutation checks), w7_probe.py, v04_probe.py (previous-core probes)
```

## Scope

V0.3 and V0.4 implement none of the following either; it models them as declared inputs (`authenticated_issuer`, `declare_infrastructure`). See PROTOCOL_BOUNDARY.md §2.


This prototype has **no** UI, database, OAuth, JWT, Macaroons/Biscuit, DPoP, cryptographic signatures, key management, network proxy or networking. These were excluded by the brief.

V0.2 confined execution in brief:

```python
core, provider, contract, effector = world.build_confined(executor=MyExecutor("agent-1"))
decision = core.gateway.request_authorization(intent, delegation_id)       # (+ confirmation if required)
outcome = core.gateway.execute_confined(intent, delegation_id, confirmation, decision.grant)
outcome.confinement.status   # CONFINED / NOT_CONFINED, with mode, TCB and assumptions
outcome.credential           # the ExecutionCredential that was minted
outcome.boundary_events      # every allowed / blocked call the executor made
outcome.receipt.units        # V0.4: per execution unit {unit_id, required, execution, verified, evidence, problems}
```

The legacy V0.1 `gateway.execute()` path is unchanged and is reported `NOT_CONFINED`.

No Matrix homeserver was available locally. The only Matrix code on the machine was an iOS client SDK. The Matrix fixture is therefore an in-memory homeserver that reproduces the two protocol properties under test:

- `txnId` idempotency
- event read-back that may be unavailable

## V0.5 experiment

V0.5 tests whether the existing `StateBinding` can carry multiple opaque mutable-state dependencies while preserving V0–V0.4. It distinguishes individually checked, snapshot-consistent, and atomic-precondition guarantees; weaker guarantees are never upgraded. See `MULTI_STATE_BINDING.md` and `RESULTS.md`.
