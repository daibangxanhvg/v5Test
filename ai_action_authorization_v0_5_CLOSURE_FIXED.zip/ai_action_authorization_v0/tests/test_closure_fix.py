"""End-to-end closure controls; all original test modules remain untouched."""
import copy, dataclasses as dc, unittest, threading
from aaap import ALLOW, DENY, ConfinedExecutor, PROVIDER_AUTHORITY, canonical, EvidenceSource, ExecutionEvidence, VERIFIED, VIOLATION
from aaap.adapter import ExecutionResult, PreconditionFailed
from aaap.authority import ProviderEffector, MODE_B
from aaap.objects import context_scope
from fixtures.multistate import world as ms
from tests.test_closure_adversarial import setup as baseline_setup, alter, execute
from fixtures.multistate.adapter import MultiAdapter
from tests.test_v05_multi_state_binding import variant
from tests.test_v04_composite_execution import uop


class LockedAdapter(MultiAdapter):
    """Test infrastructure: snapshot reads and predicate/effect boundary share a lock.
    All infrastructure-owned concurrent writes must honor this lock; bypassing that
    trusted storage boundary is outside the protocol's ability to manufacture truth.
    """
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); self.lock=threading.RLock()
    def resolve(self,intent):
        with self.lock: return super().resolve(intent)
    def execute_conditional(self,intent,plan,precondition):
        with self.lock: return super().execute_conditional(intent,plan,precondition)


def setup(req='INDIVIDUALLY_CHECKED',obs='INDIVIDUALLY_CHECKED',ctx=None):
    core,st,c,unused=baseline_setup(req,obs,ctx)
    a=LockedAdapter(st,guarantee=obs,context=ctx); original=a.state_binding
    a.state_binding=lambda i,f:dc.replace(original(i,f),required_consistency=req)
    core.gateway.register_adapter(ms.ADDRESS,a)
    return core,st,c,a


def publish(core,c):
    core.contracts.publish(c,authenticated_issuer=ms.ISSUER)
    core.delegations._d[ms.DID]=dc.replace(core.delegations.get(ms.DID),allowed_capabilities=[{'contract_id':ms.ADDRESS,'capability':c.capability,'contract_version':c.version,'contract_digest':c.binding_digest()}])


def trust(core,c,a,intents=None):
    intents=intents or [ms.intent()]
    b=a.state_binding(intents[0],a.resolve(intents[0]))
    scopes=[context_scope(c,core.delegations.get(ms.DID),i,a.state_binding(i,a.resolve(i)),a.plan(i,a.resolve(i))) for i in intents]
    cc={'source':'authority','value':'opaque','covers':[d['dependency_id'] for d in b.dependencies if d.get('required',True)],'scope':scopes}
    signed=canonical.digest(cc)
    sources=core.verifier.evidence_sources
    sources.register(ms.ADDRESS,'authority',PROVIDER_AUTHORITY)
    sources.register_consistency(ms.ADDRESS,'authority',b.observed_consistency,sorted({d['issuer'] for d in b.dependencies}),lambda cc,*args:canonical.digest(cc)==signed)
    a.context=copy.deepcopy(cc)
    return cc


class Requirements(unittest.TestCase):
    def test_downgrade(self):
        core,st,c,a=setup(); alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,required=False) if d['dependency_id']=='d2' else d for d in b.dependencies)))
        old=a.execute_conditional
        def race(i,p,b): st['r42']='v8'; return old(i,p,b)
        a.execute_conditional=race
        self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_optional_narrows(self):
        core,st,c,a=setup(); c=variant(c,lambda x:x['verification']['state_binding']['dependencies'][1].update(required=False)); publish(core,c)
        old=a.execute_conditional
        def race(i,p,b): st['r42']='v8'; return old(i,p,b)
        a.execute_conditional=race
        d,o=execute(core); self.assertEqual(d.decision,ALLOW); self.assertEqual(a.effects,[]); self.assertEqual(o.receipt.execution_result['status'],'PRECONDITION_FAILED')
    def test_individual_positive(self):
        core,st,c,a=setup(); d,o=execute(core); self.assertEqual(d.decision,ALLOW); self.assertEqual(a.effects,['exec-ms'])


class Guarantees(unittest.TestCase):
    def positive(self,req,obs):
        core,st,c,a=setup(req,obs); trust(core,c,a); d,o=execute(core)
        self.assertEqual(d.decision,ALLOW,d.reasons); self.assertEqual(a.effects,['exec-ms'])
        self.assertEqual(o.receipt.state_consistency['observed'],sorted(set([obs] if isinstance(obs,str) else obs)))
    def test_snapshot(self): self.positive('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT')
    def test_atomic(self): self.positive('ATOMIC_PRECONDITION','ATOMIC_PRECONDITION')
    def test_both(self): self.positive(['SNAPSHOT_CONSISTENT','ATOMIC_PRECONDITION'],['SNAPSHOT_CONSISTENT','ATOMIC_PRECONDITION'])
    def test_additional(self): self.positive('INDIVIDUALLY_CHECKED',['INDIVIDUALLY_CHECKED','SNAPSHOT_CONSISTENT','ATOMIC_PRECONDITION'])
    def deny(self,req,obs):
        core,st,c,a=setup(req,obs); trust(core,c,a); self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_atomic_not_snapshot(self): self.deny('SNAPSHOT_CONSISTENT','ATOMIC_PRECONDITION')
    def test_snapshot_not_atomic(self): self.deny('ATOMIC_PRECONDITION','SNAPSHOT_CONSISTENT')
    def test_both_needs_both(self):
        for obs in ('SNAPSHOT_CONSISTENT','ATOMIC_PRECONDITION'):
            with self.subTest(obs=obs): self.deny(['SNAPSHOT_CONSISTENT','ATOMIC_PRECONDITION'],obs)


class Contexts(unittest.TestCase):
    def test_reusable(self):
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT'); i=ms.intent(); j=dc.replace(i,intent_id='second',execution_id='second')
        trust(core,c,a,[i,j]); self.assertEqual(execute(core,i)[0].decision,ALLOW); self.assertEqual(execute(core,j)[0].decision,ALLOW); self.assertEqual(a.effects,['exec-ms','second'])
    def test_dependency_scope(self):
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT'); trust(core,c,a)
        alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,issuer='other') for d in b.dependencies)))
        reg=core.verifier.evidence_sources._consistency; key=(ms.ADDRESS,'authority'); e=reg[key]; reg[key]=(e[0],e[1]|{'other'},e[2])
        self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_lineage(self):
        for kind in ('intent','execution','grant'):
            with self.subTest(kind=kind):
                core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT'); trust(core,c,a); i=ms.intent()
                if kind=='intent': i=dc.replace(i,intent_id='other')
                if kind=='execution': i=dc.replace(i,execution_id='other')
                if kind=='grant': core.delegations._d[ms.DID]=dc.replace(core.delegations.get(ms.DID),valid_until='2026-10-30T00:00:00+07:00')
                self.assertEqual(execute(core,i)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_subject(self):
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT'); trust(core,c,a); self.assertEqual(execute(core,ms.intent(a='r42'))[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_bare_boolean(self):
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT',{'value':'S1+S2','covers':['d1','d2','d3'],'cross_issuer_scope_proven':True})
        alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,issuer='other') if d['dependency_id']=='d3' else d for d in b.dependencies)))
        self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_cross_authority(self):
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT'); alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,issuer='other') if d['dependency_id']=='d3' else d for d in b.dependencies)))
        trust(core,c,a); d,o=execute(core); self.assertEqual(d.decision,ALLOW); self.assertEqual(a.effects,['exec-ms'])
    def test_local_not_global(self):
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT'); alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,issuer='other') if d['dependency_id']=='d3' else d for d in b.dependencies)))
        trust(core,c,a); reg=core.verifier.evidence_sources._consistency; key=(ms.ADDRESS,'authority'); e=reg[key]; reg[key]=(e[0],frozenset([ms.ISSUER]),e[2])
        self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_authority_failures(self):
        for kind in ('missing','forged','capability','exception'):
            with self.subTest(kind=kind):
                core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT'); trust(core,c,a); reg=core.verifier.evidence_sources._consistency; key=(ms.ADDRESS,'authority'); e=reg[key]
                if kind=='missing': reg.pop(key)
                if kind=='forged': a.context['value']='forged'
                if kind=='capability': reg[key]=(frozenset(['INDIVIDUALLY_CHECKED']),e[1],e[2])
                if kind=='exception': reg[key]=(e[0],e[1],lambda *args: (_ for _ in ()).throw(ValueError()))
                self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_critical(self):
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT'); trust(core,c,a); a.context['critical']={'future':True}
        reg=core.verifier.evidence_sources._consistency; key=(ms.ADDRESS,'authority'); e=reg[key]; reg[key]=(e[0],e[1],lambda *args:True)
        self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])


class Malformed(unittest.TestCase):
    def test_duplicate(self):
        core,st,c,a=setup(); alter(a,lambda b:dc.replace(b,dependencies=b.dependencies+(dict(b.dependencies[0]),)))
        self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_duplicate_subject(self):
        core,st,c,a=setup(); alter(a,lambda b:dc.replace(b,dependencies=b.dependencies+(dict(b.dependencies[0],subject_ref='other'),)))
        self.assertEqual(execute(core)[0].decision,DENY)
    def test_conflict(self):
        core,st,c,a=setup(); c=variant(c,lambda x:x['verification']['state_binding']['dependencies'][1].update(subject='plan:a')); publish(core,c)
        alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,subject_ref='r17',binding_value='conflict') if d['dependency_id']=='d2' else d for d in b.dependencies)))
        self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_bad_dependency(self):
        transforms=[lambda b:dc.replace(b,dependencies=(None,)),lambda b:dc.replace(b,dependencies='wrong'),lambda b:dc.replace(b,dependencies=tuple(dict(d,required=1) for d in b.dependencies)),lambda b:dc.replace(b,observed_consistency={}),lambda b:dc.replace(b,observed_consistency=[]),lambda b:dc.replace(b,critical={'future':True}),lambda b:dc.replace(b,dependencies=tuple({k:v for k,v in d.items() if k!='issuer'} for d in b.dependencies)),lambda b:dc.replace(b,dependencies=tuple(dict(d,binding_value='') for d in b.dependencies))]
        for fn in transforms:
            with self.subTest(fn=fn):
                core,st,c,a=setup(); alter(a,fn); self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_bad_context(self):
        for key,values in {'covers':[None,{},1,['d1',None]],'source':['',None,{}],'scope':[None,{},[{}]],'critical':[None,True,{'future':True}]}.items():
            for value in values:
                with self.subTest(key=key,value=value):
                    core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT'); trust(core,c,a); a.context[key]=value
                    self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])


class Effector(ProviderEffector):
    mode=MODE_B
    def __init__(self,st,attack='valid'): self.st=st; self.attack=attack; self.calls=[]; self.validations=[]; self.audit={}
    def authority_handles(self): return [self.st]
    def perform_unit(self,cred,op,pre):
        for d in pre.dependencies:
            if d['binding_value'] != self.st.get(d['subject_ref']): raise PreconditionFailed('authoritative disagreement')
            self.validations.append((op.unit,d['dependency_id'],d['binding_value']))
        self.calls.append(op.unit)
        if op.unit=='U1':
            self.st['r42']='v8'; b=next(d for d in pre.dependencies if d['dependency_id']=='d2')
            est={'dependencies':[dict(b,binding_value='v8')],'required_consistency':pre.required_consistency,'observed_consistency':pre.observed_consistency,'execution_id':cred.execution_id,'from_unit':'U1'}
            if self.attack=='stale': est['dependencies'][0]['binding_value']='v7'
            if self.attack=='subject': est['dependencies'][0].update(subject_ref='r17',binding_value='v1')
            if self.attack=='issuer': est['dependencies'][0]['issuer']='other'
            if self.attack=='representation': est['dependencies'][0]['binding_type']='other'
            if self.attack=='execution': est['execution_id']='other'
            if self.attack=='predecessor': est['from_unit']='U3'
            if self.attack=='false': est['dependencies'][0]['binding_value']='v999'
            if self.attack=='missing': est['dependencies']=[]
            if self.attack=='aggregate': est=pre.to_dict()
            if self.attack=='changed_C': self.st['r99']='changed'
            status={'failed':'FAILED','partial':'PARTIAL','unknown':'UNKNOWN'}.get(self.attack,'SUCCESS')
            self.audit['U1']={'applied':pre.to_dict(),'established':copy.deepcopy(est)}
            return ExecutionResult(status,cred.execution_id,'U1',op.request,['r.u1'],established_state=est)
        self.audit['U2']={'applied':pre.to_dict(),'established':None}
        return ExecutionResult('SUCCESS',cred.execution_id,'U2',op.request,['r.u2'])


def composite(attack='valid'):
    core,st,c,a=setup(); c=variant(c,lambda d:d.update(effects=['r.u1','r.u2'],execution_units=[
        {'unit_id':'U1','required':True,'effects':['r.u1'],'request_fields':['a','b'],'state':'authorization','state_dependencies':['d1','d2'],'establishes':['d2']},
        {'unit_id':'U2','required':True,'effects':['r.u2'],'request_fields':['b','c'],'after':['U1'],'state':{'from_unit':'U1'},'state_dependencies':['d2','d3']}]))
    publish(core,c); eff=Effector(st,attack); core.gateway.authority.register_effector(ms.ADDRESS,eff); core.gateway.register_executor(ms.ADDRESS,ConfinedExecutor('agent-1')); return core,st,eff


class Handoffs(unittest.TestCase):
    def test_positive(self):
        core,st,eff=composite(); d=core.gateway.request_authorization(ms.intent(),ms.DID); self.assertEqual(d.decision,ALLOW,d.reasons)
        o=core.gateway.execute_confined(ms.intent(),ms.DID,grant=d.grant)
        self.assertEqual(eff.calls,['U1','U2']); self.assertEqual(eff.validations,[('U1','d1','v1'),('U1','d2','v7'),('U2','d2','v8'),('U2','d3','v3')]); self.assertEqual(o.receipt.execution_result['status'],'SUCCESS')
    def attack(self,attack):
        core,st,eff=composite(attack); d=core.gateway.request_authorization(ms.intent(),ms.DID); self.assertEqual(d.decision,ALLOW,d.reasons)
        o=core.gateway.execute_confined(ms.intent(),ms.DID,grant=d.grant); self.assertEqual(eff.calls,['U1']); self.assertEqual(st['r42'],'v8'); self.assertNotEqual(o.receipt.execution_result['status'],'SUCCESS')
    def test_subject(self): self.attack('subject')
    def test_attacks(self):
        for attack in ('stale','issuer','representation','execution','predecessor','false','missing','aggregate','failed','partial','unknown','changed_C'):
            with self.subTest(attack=attack): self.attack(attack)
    def test_port(self):
        core,st,eff=composite(); d=core.gateway.request_authorization(ms.intent(),ms.DID); cred=core.gateway.authority.attenuate_exact(d.grant,'agent-1').credential; port=core.gateway.authority.port('agent-1')
        for op in (uop(cred,'U2'),uop(cred,'U3'),uop(cred,'U1',execution_id='other')): self.assertFalse(port.invoke(cred,op).allowed)
        self.assertEqual(eff.calls,[])


class Observer(EvidenceSource):
    def __init__(self,audit,unit,mismatch=False):
        self.audit=audit; self.unit=unit; self.identity='observer-'+unit; self.mismatch=mismatch
    def observe(self,intent,grant):
        if self.unit not in self.audit: return None
        states={self.unit:copy.deepcopy(self.audit[self.unit])}
        if self.mismatch and self.unit=='U1': states['U1']['established']['dependencies'][0]['binding_value']='different'
        return ExecutionEvidence('ev-'+self.unit,intent.execution_id,intent.intent_id,self.identity,PROVIDER_AUTHORITY,
            'r17',{'a':'r17','b':'r42','c':'r99'},('r.u1' if self.unit=='U1' else 'r.u2',),covers_units=(self.unit,),grant_id=grant.grant_id,unit_states=states)


class Receipts(unittest.TestCase):
    def run_observed(self,mismatch=False):
        core,st,eff=composite()
        for unit in ('U1','U2'):
            core.gateway.register_evidence_source(ms.ADDRESS,Observer(eff.audit,unit,mismatch),PROVIDER_AUTHORITY,units=(unit,))
        d=core.gateway.request_authorization(ms.intent(),ms.DID)
        return core.gateway.execute_confined(ms.intent(),ms.DID,grant=d.grant)
    def test_verified_composition(self): self.assertEqual(self.run_observed().receipt.verification_status,VERIFIED)
    def test_authoritative_established_disagreement(self): self.assertEqual(self.run_observed(True).receipt.verification_status,VIOLATION)


class AdditionalControls(unittest.TestCase):
    def test_AB_authorization_execution(self):
        core,st,c,a=setup(); c=variant(c,lambda x:x['verification']['state_binding']['dependencies'].pop()); publish(core,c)
        alter(a,lambda b:dc.replace(b,dependencies=b.dependencies[:2]))
        d,o=execute(core); self.assertEqual(d.decision,ALLOW); self.assertEqual(a.effects,['exec-ms'])
    def test_optional_required_context_coverage(self):
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT')
        c=variant(c,lambda x:x['verification']['state_binding']['dependencies'][1].update(required=False)); publish(core,c)
        trust(core,c,a); a.context['covers'].remove('d2')
        reg=core.verifier.evidence_sources._consistency; key=(ms.ADDRESS,'authority'); e=reg[key]; reg[key]=(e[0],e[1],lambda *args:True)
        self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_unknown_noncritical_is_inert(self):
        core,st,c,a=setup(); alter(a,lambda b:dc.replace(b,noncritical={'display':'opaque note'}))
        self.assertEqual(execute(core)[0].decision,ALLOW); self.assertEqual(a.effects,['exec-ms'])


class ChainEffector(Effector):
    def perform_unit(self,cred,op,pre):
        if op.unit=='U1': return super().perform_unit(cred,op,pre)
        for d in pre.dependencies:
            if d['binding_value'] != self.st.get(d['subject_ref']): raise PreconditionFailed('authoritative disagreement')
            self.validations.append((op.unit,d['dependency_id'],d['binding_value']))
        self.calls.append(op.unit)
        est=None
        if op.unit=='U2':
            self.st['r99']='v4'; old=next(d for d in pre.dependencies if d['dependency_id']=='d3')
            est={'dependencies':[dict(old,binding_value='v4')],'required_consistency':pre.required_consistency,'observed_consistency':pre.observed_consistency,'execution_id':cred.execution_id,'from_unit':'U2'}
        return ExecutionResult('SUCCESS',cred.execution_id,op.unit,op.request,['r.u2' if op.unit=='U2' else 'r.u3'],established_state=est)


class ArchitectureControls(unittest.TestCase):
    def test_prior_update_survives_another_handoff(self):
        core,st,unused=composite(); c=core.contracts.current(ms.ADDRESS)
        def chain(d):
            d['effects'].append('r.u3'); d['execution_units'][1]['establishes']=['d3']
            d['execution_units'].append({'unit_id':'U3','required':True,'effects':['r.u3'],'request_fields':['b','c'],'after':['U2'],'state':{'from_unit':'U2'},'state_dependencies':['d2','d3']})
        publish(core,variant(c,chain,'chain')); eff=ChainEffector(st); core.gateway.authority.register_effector(ms.ADDRESS,eff)
        d=core.gateway.request_authorization(ms.intent(),ms.DID); self.assertEqual(d.decision,ALLOW)
        o=core.gateway.execute_confined(ms.intent(),ms.DID,grant=d.grant)
        self.assertEqual(eff.calls,['U1','U2','U3']); self.assertIn(('U3','d2','v8'),eff.validations); self.assertIn(('U3','d3','v4'),eff.validations); self.assertEqual(o.receipt.execution_result['status'],'SUCCESS')
    def test_individual_not_inferred(self):
        for obs in ('SNAPSHOT_CONSISTENT','ATOMIC_PRECONDITION'):
            with self.subTest(obs=obs):
                core,st,c,a=setup('INDIVIDUALLY_CHECKED',obs); trust(core,c,a)
                self.assertEqual(execute(core)[0].decision,DENY); self.assertEqual(a.effects,[])
    def test_contract_required_dep_cannot_be_uncovered_by_units(self):
        core,st,eff=composite(); c=core.contracts.current(ms.ADDRESS)
        publish(core,variant(c,lambda d:d['execution_units'][1].update(state_dependencies=['d2']),'uncovered'))
        self.assertEqual(core.gateway.request_authorization(ms.intent(),ms.DID).decision,DENY); self.assertEqual(eff.calls,[])
    def test_strong_projected_composite_is_explicitly_unsupported(self):
        from fixtures.multistate.adapter import MultiAdapter
        core,st,eff=composite(); c=core.contracts.current(ms.ADDRESS)
        c=variant(c,lambda d:d['verification']['state_binding'].update(required_consistency='SNAPSHOT_CONSISTENT'),'strong-units'); publish(core,c)
        a=MultiAdapter(st,guarantee='SNAPSHOT_CONSISTENT'); orig=a.state_binding
        a.state_binding=lambda i,f:dc.replace(orig(i,f),required_consistency='SNAPSHOT_CONSISTENT')
        core.gateway.register_adapter(ms.ADDRESS,a); trust(core,c,a)
        d=core.gateway.request_authorization(ms.intent(),ms.DID); self.assertEqual(d.decision,DENY); self.assertEqual(eff.calls,[])


class ResultsTransition(unittest.TestCase):
    def test_partial_is_settled_without_lookup(self):
        core,st,eff=composite('false'); d=core.gateway.request_authorization(ms.intent(),ms.DID)
        first=core.gateway.execute_confined(ms.intent(),ms.DID,grant=d.grant)
        self.assertEqual(first.receipt.execution_result['status'],'PARTIAL')
        looked=[]; a=core.gateway._adapters[ms.ADDRESS]
        def lookup(i):
            looked.append(i.execution_id)
            return ExecutionResult('SUCCESS',i.execution_id,'forged',a.plan(i,a.resolve(i)),['r.u1','r.u2'])
        a.lookup=lookup
        second=core.gateway.execute_confined(ms.intent(),ms.DID)
        self.assertEqual(looked,[]); self.assertIs(second.receipt,first.receipt); self.assertEqual(eff.calls,['U1']); self.assertTrue(second.replayed)


class TrustBoundaries(unittest.TestCase):
    def test_compromised_trusted_enforcement_does_not_manufacture_truth(self):
        core,st,c,a=setup('ATOMIC_PRECONDITION','ATOMIC_PRECONDITION'); trust(core,c,a)
        def lie(i,p,b):
            st['r42']='changed'; a.effects.append(i.execution_id)
            return ExecutionResult('SUCCESS',i.execution_id,'lying-boundary',p,['r.effect'])
        a.execute_conditional=lie
        d,o=execute(core); self.assertEqual(d.decision,ALLOW); self.assertEqual(a.effects,['exec-ms']); self.assertEqual(st['r42'],'changed')
        self.assertEqual(o.receipt.state_consistency['observed'],['ATOMIC_PRECONDITION']); self.assertNotEqual(o.receipt.verification_status,VERIFIED)
