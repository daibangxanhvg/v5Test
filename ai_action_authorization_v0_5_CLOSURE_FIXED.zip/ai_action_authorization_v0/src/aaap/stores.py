"""Authoritative in-memory stores. The verifier reads contracts and delegations
from here, never from objects handed to it by the agent."""
from __future__ import annotations

import copy
import dataclasses
from typing import Any, Dict, Optional, Tuple

from .objects import (
    PROVENANCES, QUALIFIER, AuthorizationGrant, CapabilityContract, Delegation, qualified_contract_id,
)


class ContractRegistry:
    """Provider-published contracts. `current` is what the provider serves now;
    every published version stays addressable by digest (artifact digest and
    V0.3 security-identity digest).

    V0.3 namespace: a contract is identified by (issuer, local contract_id).
    - Qualified address `issuer::contract_id` (objects.qualified_contract_id): never
      collides; resolves only if that issuer is trusted for that local id.
    - Bare address `contract_id` (V0-V0.2): resolves to the latest contract published
      under that local id; if more than one issuer is trusted for it, the address is
      ambiguous and the verifier fails closed.
    Authenticating who published a contract is infrastructure: `publish` accepts the
    authenticated publisher identity as an input and refuses a contract naming anyone else."""

    def __init__(self) -> None:
        self._trusted: Dict[str, set] = {}
        self._current: Dict[str, CapabilityContract] = {}
        self._current_q: Dict[str, CapabilityContract] = {}
        self._by_digest: Dict[str, CapabilityContract] = {}

    def trust_issuer(self, contract_id: str, issuer: str) -> None:
        if QUALIFIER in contract_id or QUALIFIER in issuer:
            raise ValueError("trust is granted per (local contract_id, issuer)")
        self._trusted.setdefault(contract_id, set()).add(issuer)

    def trusted_issuer(self, address: str) -> Optional[str]:
        if not isinstance(address, str):
            return None
        if QUALIFIER in address:
            issuer, _, local = address.partition(QUALIFIER)
            return issuer if issuer in self._trusted.get(local, ()) else None
        issuers = self._trusted.get(address, set())
        return next(iter(issuers)) if len(issuers) == 1 else None

    def ambiguous(self, address: Any) -> bool:
        """A bare address that more than one trusted issuer uses."""
        return isinstance(address, str) and QUALIFIER not in address and len(self._trusted.get(address, ())) > 1

    def publish(self, contract: CapabilityContract, authenticated_issuer: Optional[str] = None) -> str:
        if authenticated_issuer is not None and authenticated_issuer != contract.issuer:
            raise PermissionError(f"authenticated issuer {authenticated_issuer!r} cannot register a contract of {contract.issuer!r}")
        d = contract.digest()
        self._current[contract.contract_id] = contract
        self._current_q[qualified_contract_id(contract.issuer, contract.contract_id)] = contract
        self._by_digest[d] = contract
        self._by_digest[contract.binding_digest()] = contract
        return d

    def current(self, address: str) -> Optional[CapabilityContract]:
        if isinstance(address, str) and QUALIFIER in address:
            return self._current_q.get(address)
        return self._current.get(address)

    def by_digest(self, digest: Optional[str]) -> Optional[CapabilityContract]:
        return self._by_digest.get(digest) if digest else None


class DelegationStore:
    """Only the principal issues/revokes. There is no update API: an agent
    cannot modify a delegation, it can only be handed copies."""

    def __init__(self) -> None:
        self._d: Dict[str, Delegation] = {}
        self._revoked: set = set()

    def issue(self, delegation: Delegation) -> None:
        if delegation.delegation_id in self._d:
            raise ValueError("delegation_id already issued")
        self._d[delegation.delegation_id] = copy.deepcopy(delegation)

    def revoke(self, delegation_id: str, by_principal: str) -> None:
        d = self._d.get(delegation_id)
        if d is None:
            raise KeyError(delegation_id)
        if d.principal != by_principal:
            raise PermissionError("only the delegating principal may revoke")
        self._revoked.add(delegation_id)

    def get(self, delegation_id: Any) -> Optional[Delegation]:
        d = self._d.get(delegation_id) if isinstance(delegation_id, str) else None
        if d is None:
            return None
        return dataclasses.replace(copy.deepcopy(d), revoked=delegation_id in self._revoked)


IN_FLIGHT = "IN_FLIGHT"
IN_DOUBT = "IN_DOUBT"
COMPLETED = "COMPLETED"
FAILED = "FAILED"


class ExecutionLedger:
    """execution_id -> execution record. An execution_id is single-use.

    V0: in-memory only. Not durable, not shared between gateway instances
    (see RESULTS.md finding F-3)."""

    def __init__(self) -> None:
        self._e: Dict[str, Dict[str, Any]] = {}

    def get(self, execution_id: str) -> Optional[Dict[str, Any]]:
        e = self._e.get(execution_id)
        return dict(e) if e is not None else None

    def claim(self, execution_id: str, intent_digest: str, decision: Any, facts: Any, plan: Any) -> None:
        if execution_id in self._e:
            raise RuntimeError("execution_id already claimed")
        self._e[execution_id] = {
            "intent_digest": intent_digest, "contract_digest": decision.contract_digest,
            "state": IN_FLIGHT, "attempts": 0, "decision": decision,
            "facts": copy.deepcopy(facts), "plan": copy.deepcopy(plan), "receipt": None,
        }

    def record_attempt(self, execution_id: str) -> None:
        self._e[execution_id]["attempts"] += 1

    def attempts(self, execution_id: str) -> int:
        e = self._e.get(execution_id)
        return e["attempts"] if e else 0

    def settle(self, execution_id: str, state: str, receipt: Any) -> None:
        self._e[execution_id]["state"] = state
        self._e[execution_id]["receipt"] = receipt


class GrantStore:
    """Grants the verifier issued (V0.1). No signatures in scope: a presented
    grant is honoured only if this store holds an identical one under its id."""

    def __init__(self) -> None:
        self._g: Dict[str, str] = {}
        self._grants: Dict[str, AuthorizationGrant] = {}
        self._attenuated: set = set()   # V0.2: grants already turned into an ExecutionCredential

    def record(self, grant: AuthorizationGrant) -> None:
        self._g[grant.grant_id] = grant.digest()
        self._grants.setdefault(grant.grant_id, copy.deepcopy(grant))

    def get(self, grant_id: Any) -> Optional[AuthorizationGrant]:
        g = self._grants.get(grant_id) if isinstance(grant_id, str) else None
        return copy.deepcopy(g) if g is not None else None

    def claim_attenuation(self, grant_id: str) -> bool:
        """V0.2: a grant can be attenuated into at most one ExecutionCredential."""
        if grant_id in self._attenuated:
            return False
        self._attenuated.add(grant_id)
        return True

    def is_issued(self, grant: Any) -> bool:
        if not isinstance(grant, AuthorizationGrant):
            return False
        try:
            return self._g.get(grant.grant_id) == grant.digest()
        except Exception:
            return False


class EvidenceSourceRegistry:
    """(contract_id, source identity) -> provenance class, set by the deployer (V0.1).
    Evidence whose source is unregistered, or that claims a different class, is rejected.

    V0.3: optionally also the EFFECTS the source is in a position to observe (its scope).
    Evidence from a scoped source claiming any effect outside its scope is rejected, so an
    observation of one sub-effect cannot be relabelled as another. None = unscoped (V0.1).

    V0.4: optionally also the opaque execution UNITS the source is authoritative for. For a
    contract that declares units, a source with no unit scope can attest to no unit at all
    (unscoped is never read as "everything")."""

    def __init__(self) -> None:
        self._p: Dict[tuple, str] = {}
        self._scope: Dict[tuple, Optional[Tuple[str, ...]]] = {}
        self._units: Dict[tuple, Optional[Tuple[str, ...]]] = {}
        self._consistency = {}

    def register(self, contract_id: str, identity: str, provenance: str,
                 effects: Optional[Tuple[str, ...]] = None, units: Optional[Tuple[str, ...]] = None) -> None:
        if provenance not in PROVENANCES:
            raise ValueError(f"unknown provenance {provenance!r}")
        if not isinstance(identity, str) or not identity:
            raise ValueError("evidence source needs a non-empty identity")
        if effects is not None and (not effects or not all(isinstance(e, str) and e for e in effects)):
            raise ValueError("an effect scope must be a non-empty list of effect labels")
        key = (contract_id, identity)
        if key in self._p and self._p[key] != provenance:
            raise ValueError(f"{identity} already registered as {self._p[key]}")
        if units is not None and (not units or not all(isinstance(u, str) and u for u in units)):
            raise ValueError("a unit scope must be a non-empty list of unit ids")
        scope = tuple(effects) if effects is not None else None
        if key in self._scope and self._scope[key] != scope:
            raise ValueError(f"{identity} already registered with effect scope {self._scope[key]}")
        uscope = tuple(units) if units is not None else None
        if key in self._units and self._units[key] != uscope:
            raise ValueError(f"{identity} already registered with unit scope {self._units[key]}")
        self._p[key] = provenance
        self._scope[key] = scope
        self._units[key] = uscope

    def provenance_of(self, contract_id: str, identity: Any) -> Optional[str]:
        return self._p.get((contract_id, identity)) if isinstance(identity, str) else None

    def scope_of(self, contract_id: str, identity: Any) -> Optional[Tuple[str, ...]]:
        return self._scope.get((contract_id, identity)) if isinstance(identity, str) else None

    def units_of(self, contract_id: str, identity: Any) -> Optional[Tuple[str, ...]]:
        """V0.4: the units this source may attest to (None = no unit authority)."""
        return self._units.get((contract_id, identity)) if isinstance(identity, str) else None


    def register_consistency(self, contract_id, identity, properties, issuers, validator):
        """Deployer registration, never protocol input. Callback authenticates opaque context.
        This extends evidence-source capability scope; it does not coordinate providers.
        """
        from .objects import guarantees
        props = guarantees(properties)
        if (self.provenance_of(contract_id, identity) in (None, "SELF_REPORTED") or
                props is None or not callable(validator) or not isinstance(issuers, (list, tuple)) or
                not issuers or any(not isinstance(i, str) or not i for i in issuers)):
            raise ValueError("invalid consistency authority registration")
        key = (contract_id, identity)
        if key in self._consistency:
            raise ValueError("consistency authority already registered")
        self._consistency[key] = (props, frozenset(issuers), validator)

    def validate_consistency(self, contract, context, scope, properties, binding):
        from .objects import qualified_contract_id
        key = (qualified_contract_id(contract.issuer, contract.contract_id), context["source"])
        authority = self._consistency.get(key)
        if authority is None:
            return False
        props, issuers, validate = authority
        needed = {d["issuer"] for d in binding.dependencies if d.get("required", True)}
        if not properties <= props or not needed <= issuers:
            return False
        try:
            import copy
            return validate(copy.deepcopy(context), scope, properties) is True
        except Exception:
            return False
