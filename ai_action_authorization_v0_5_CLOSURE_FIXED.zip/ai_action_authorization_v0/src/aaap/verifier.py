"""The single shared AuthorizationVerifier.

Deterministic. Contains NO provider- or capability-specific branches. All
domain policy reaches it as data (contracts, delegations) and is evaluated by
registered evaluators. Any condition it cannot establish => DENY (pre) or
non-VERIFIED (post).

V0.3 (protocol boundary): closed-world contract schema (unknown security-relevant
structure fails closed; extensions are critical unless declared noncritical),
security identity vs artifact identity, issuer-qualified contract addresses,
the authorized effect set in the grant, partial execution, effect-scoped evidence
and declared required effects. None of it interprets any effect, field or value.

V0.4 (composite execution binding): a contract may declare `execution_units`. The verifier
validates the unit structure (closed world, explicit required flag, explicit order, explicit
state precondition, effects partitioned over units), binds the exact unit table into the
grant, and verifies each unit separately: required units come from the CONTRACT, never from
the grant or the execution path; evidence must name the units it covers, come from a source
the deployer scoped to those units, carry the grant lineage, and attest each unit's state
precondition. Unit ids and effect labels are compared as opaque strings only.
"""
from __future__ import annotations

import copy
import dataclasses
import itertools
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from . import canonical
from .objects import guarantees, validate_dependencies, context_scope, project_binding, handoff_binding
from .adapter import ExecutionResult
from .evaluators import (
    FAIL, PASS, UNVERIFIABLE, ConstraintEvaluatorRegistry, EvalContext, RefError, parse_instant, resolve_ref,
)
from .objects import (
    ALLOW, DEFAULT_AUTHORITATIVE, DENY, EXEC_PRECONDITION_FAILED, EXEC_SUCCESS, EXEC_UNKNOWN, PROVENANCES,
    REQUIRE_CONFIRMATION, SELF_REPORTED, UNVERIFIED, VERIFIED, VIOLATION,
    ActionIntent, ActionReceipt, AuthorizationDecision, AuthorizationGrant, CapabilityContract, Confirmation,
    Delegation, ExecutionEvidence, StateBinding, confirmation_digest, intent_digest,
    CONTRACT_FIELDS, EXEC_PARTIAL, NON_SECURITY_ELIGIBLE, OPTIONAL_CONTRACT_FIELDS,
    UNIT_STATE_AUTHORIZATION, UNIT_STATE_FROM, UNIT_STATE_UNBOUND,
)
from .stores import ContractRegistry, DelegationStore, EvidenceSourceRegistry, ExecutionLedger, GrantStore


class R:
    """Machine-readable reason codes."""
    MALFORMED_INTENT = "malformed_intent"
    UNKNOWN_CONTRACT = "unknown_contract"
    MALFORMED_CONTRACT = "malformed_contract"
    UNTRUSTED_ISSUER = "untrusted_contract_issuer"
    CAPABILITY_MISMATCH = "intent_capability_mismatch"
    NON_CANONICAL = "non_canonical_intent"
    UNKNOWN_DELEGATION = "unknown_delegation"
    PRINCIPAL_MISMATCH = "principal_mismatch"
    AGENT_NOT_DELEGATED = "agent_not_delegated"
    MALFORMED_DELEGATION = "malformed_delegation"
    DELEGATION_REVOKED = "delegation_revoked"
    DELEGATION_NOT_YET_VALID = "delegation_not_yet_valid"
    DELEGATION_EXPIRED = "delegation_expired"
    CAPABILITY_NOT_DELEGATED = "capability_not_delegated"
    CONTRACT_CHANGED = "contract_changed_reauthorization_required"
    AUTHORITY_NOT_DELEGATED = "authority_not_delegated"
    INVALID_ARGUMENT = "invalid_argument"
    EVIDENCE_UNAVAILABLE = "evidence_unavailable"
    EXECUTION_ID_USED = "execution_id_already_used"
    UNSUPPORTED_CONSTRAINT = "unsupported_security_constraint"
    UNSUPPORTED_INVARIANT = "unsupported_security_invariant"
    CONSTRAINT_UNBOUND = "constraint_unbound"
    CONSTRAINT_VIOLATED = "constraint_violated"
    INVARIANT_VIOLATED = "invariant_violated"
    EVALUATOR_ERROR = "evaluator_error"
    PLAN_EXCEEDS_INTENT = "execution_plan_exceeds_intent"
    CONFIRMATION_REQUIRED = "confirmation_required"
    CONFIRMATION_MISMATCH = "confirmation_mismatch"
    # warnings (non-blocking)
    SKIPPED_NONCRITICAL = "unsupported_noncritical_constraint_skipped"
    # post-execution
    NOT_AUTHORIZED = "execution_without_allow"
    IDENTITY_MISMATCH = "execution_identity_mismatch"
    INTENT_MUTATED = "intent_mutated_after_authorization"
    CONTRACT_UNAVAILABLE = "bound_contract_unavailable"
    EXEC_NOT_SUCCESSFUL = "execution_not_successful"
    OUTCOME_UNKNOWN = "execution_outcome_unknown"
    UNDECLARED_EFFECT = "undeclared_effect_observed"
    REQUEST_DIFFERS = "executed_request_differs_from_plan"
    READ_BACK_UNAVAILABLE = "read_back_unavailable"
    POSTCONDITION_FAILED = "postcondition_failed"
    POSTCONDITION_UNOBSERVABLE = "postcondition_unobservable"
    INVARIANT_UNVERIFIABLE = "invariant_unverifiable"
    # V0.1 — F7 state binding / grant (pre-execution)
    STATE_BINDING_UNDECLARED = "state_dependent_authorization_without_declared_binding"
    STATE_BINDING_UNAVAILABLE = "state_binding_unavailable"
    STATE_BINDING_SUBJECT_MISMATCH = "state_binding_subject_mismatch"
    STATE_CHANGED = "state_changed_reauthorization_required"
    GRANT_INVALID = "grant_not_issued_or_altered"
    GRANT_MISMATCH = "grant_mismatch"
    # V0.1 — F7 (post-execution)
    STATE_PRECONDITION_FAILED = "state_precondition_failed_reauthorization_required"
    STATE_PRECONDITION_UNATTESTED = "state_precondition_unattested"
    STATE_PRECONDITION_NOT_ENFORCED = "state_precondition_not_enforced"
    STATE_PRECONDITION_MISMATCH = "state_precondition_mismatch"
    # V0.1 — F6 evidence (post-execution)
    NO_AUTHORITATIVE_EVIDENCE = "no_authoritative_evidence"
    EVIDENCE_REJECTED = "evidence_rejected"
    EVIDENCE_SUBJECT_MISMATCH = "evidence_subject_mismatch"
    EVIDENCE_SUBJECT_UNDECLARED = "evidence_subject_undeclared"
    EFFECT_DESPITE_FAILURE = "effect_observed_despite_reported_failure"
    # V0.2 — state dependencies (warnings on the decision; block attenuation)
    STATE_DEPENDENCY_UNBOUND = "state_dependency_without_state_binding"
    STATE_READ_UNDECLARED = "undeclared_state_read_by_evaluator"
    # V0.2 — grant standing (re-checked by the enforcement boundary)
    GRANT_UNKNOWN = "grant_unknown"
    # V0.2 — post-execution
    OUT_OF_SCOPE_ATTEMPT = "out_of_scope_attempt_blocked"
    # V0.3 — protocol boundary
    UNSUPPORTED_EXTENSION = "unsupported_critical_extension"
    AMBIGUOUS_CONTRACT = "contract_identity_ambiguous"
    UNSUPPORTED_MODIFIER = "unsupported_constraint_modifier"
    EXECUTION_PARTIAL = "execution_partial_no_rollback"
    REQUIRED_EFFECT_UNVERIFIED = "required_effect_unverified"
    # V0.4 — composite execution binding
    COMPOSITION_UNDECLARED = "composite_structure_undeclared"          # deployer strict policy (pre)
    UNIT_REQUEST_UNAVAILABLE = "unit_request_unavailable"              # pre
    EXECUTION_BINDING_MISMATCH = "execution_binding_mismatch"          # grant unit table != contract's
    UNIT_EXECUTION_UNOBSERVED = "unit_execution_unobserved"            # no boundary record of the units
    REQUIRED_UNIT_NOT_EXECUTED = "required_unit_not_executed"
    REQUIRED_UNIT_UNVERIFIED = "required_unit_unverified"
    EXECUTED_UNIT_UNVERIFIED = "executed_optional_unit_unverified"
    UNIT_EFFECT_WITHOUT_PERMIT = "unit_effect_observed_without_permit"
    UNIT_STATE_UNATTESTED = "unit_state_unattested"
    UNIT_STATE_MISMATCH = "unit_state_continuity_violated"


CONFIRMATION_MODES = {"always": True, "never": False}
# grant fields that must be identical between a presented grant and a fresh authorization
GRANT_BOUND_FIELDS = ("intent_id", "intent_digest", "contract_id", "contract_digest", "delegation_id",
                      "delegation_digest", "confirmation_digest", "plan_digest", "execution_id",
                      "principal", "agent", "capability", "resource", "state_dependencies", "effects",
                      "execution_units")
READ_BACK_MODES = ("required",)
INPUT_TYPES = ("string", "integer", "datetime")
# V0.3 closed-world schema: keys this protocol version interprets. Anything else inside these
# structures is a semantic the verifier would otherwise silently ignore => malformed (DENY).
INPUT_KEYS = ("type", "required", "security_relevant", "maps_to", "minimum")
VERIFICATION_KEYS = ("read_back", "subject", "evidence_provenance", "state_binding", "required_effects")
STATE_BINDING_KEYS = ("subject", "dependencies", "required_consistency", "observed_consistency", "consistency_context")
STATE_CONSISTENCY_LEVELS = frozenset(("INDIVIDUALLY_CHECKED", "SNAPSHOT_CONSISTENT", "ATOMIC_PRECONDITION"))
SECURITY_IDENTITY_KEYS = ("exclude",)
# spec keys the protocol itself interprets; evaluators declare any further modifiers they read
BASE_SPEC_KEYS = ("id", "evaluator", "target", "targets", "security_critical", "params", "params_from", "phase")
REF_KINDS = ("arg:", "fact:", "plan:", "post:")
# V0.4 execution units (closed world). Keys a unit MUST state explicitly: nothing about a unit's
# criticality or state is ever defaulted.
UNIT_KEYS = ("unit_id", "required", "effects", "request_fields", "after", "state", "evidence", "post_invariants",
             "subject", "state_dependencies", "establishes")
UNIT_MANDATORY_KEYS = ("unit_id", "required", "effects", "request_fields", "state")
UNIT_EVIDENCE_KEYS = ("provenance", "joint_with")


def _unit_state_problem(uid: str, state: Any, after: List[str]) -> Optional[str]:
    if isinstance(state, str):
        return None if state in (UNIT_STATE_AUTHORIZATION, UNIT_STATE_UNBOUND) else f"unit {uid}: unknown state {state!r}"
    if not isinstance(state, dict) or set(state) != {UNIT_STATE_FROM}:
        return f"unit {uid}: unknown state structure"
    if state[UNIT_STATE_FROM] not in after:
        # continuity implies order: a unit can only start from state a declared predecessor established
        return f"unit {uid}: state from {state[UNIT_STATE_FROM]!r} which is not a declared predecessor"
    return None


def _units_problem(c: CapabilityContract) -> Optional[str]:
    """V0.4: structural validity of `execution_units`. Malformed => DENY."""
    units = c.extensions.get("execution_units")
    if not isinstance(units, list) or not units:
        return "execution_units must be a non-empty list"
    fields = {s["maps_to"] for s in c.inputs.values() if isinstance(s, dict) and isinstance(s.get("maps_to"), str)}
    invariants = {s.get("id"): s for s in c.invariants if isinstance(s, dict)}
    seen: Dict[str, Dict[str, Any]] = {}
    for u in units:
        if not isinstance(u, dict):
            return "execution_units: each unit must be an object"
        unknown = sorted(set(u) - set(UNIT_KEYS))
        if unknown:
            return f"execution_units: unknown key(s) {unknown}"
        missing = [k for k in UNIT_MANDATORY_KEYS if k not in u]
        if missing:
            return f"execution_units: unit must state {missing} explicitly"
        uid = u["unit_id"]
        if not isinstance(uid, str) or not uid or uid in seen:
            return f"execution_units: unit_id must be a unique non-empty string ({uid!r})"
        if not isinstance(u["required"], bool):
            return f"unit {uid}: required must be bool"
        eff = u["effects"]
        if not isinstance(eff, list) or not eff or any(not isinstance(e, str) or e not in c.effects for e in eff):
            return f"unit {uid}: effects must be a non-empty list of declared effects"
        rf = u["request_fields"]
        if not isinstance(rf, list) or len(set(map(str, rf))) != len(rf) or any(f not in fields for f in rf):
            return f"unit {uid}: request_fields must be distinct provider request fields (maps_to)"
        after = u.get("after", [])
        if not isinstance(after, list) or len(set(map(str, after))) != len(after) or any(a not in seen for a in after):
            # declared order is a topological order: a unit may only follow units listed before it
            return f"unit {uid}: after must name distinct units declared earlier"
        problem = _unit_state_problem(uid, u["state"], after)
        if problem:
            return problem
        if u["state"] != UNIT_STATE_UNBOUND and "state_binding" not in c.verification:
            return f"unit {uid}: a state precondition needs verification.state_binding"
        if "dependencies" in c.verification.get("state_binding", {}):
            declared = {d["dependency_id"] for d in c.verification["state_binding"]["dependencies"]}
            for key in ("state_dependencies", "establishes"):
                value = u.get(key, [])
                if not isinstance(value, list) or any(not isinstance(x, str) or x not in declared for x in value) or len(set(value)) != len(value):
                    return f"unit {uid}: invalid {key}"
            if u["state"] != UNIT_STATE_UNBOUND and not u.get("state_dependencies"):
                return f"unit {uid}: multi-state dependency scope required"
            if set(u.get("establishes", [])) - set(u.get("state_dependencies", [])):
                return f"unit {uid}: updates outside precondition scope"
        ev = u.get("evidence", {})
        if not isinstance(ev, dict) or set(ev) - set(UNIT_EVIDENCE_KEYS):
            return f"unit {uid}: unknown evidence requirement structure"
        if "provenance" in ev:
            pv = ev["provenance"]
            if not isinstance(pv, list) or not pv or any(p not in PROVENANCES or p == SELF_REPORTED for p in pv):
                return f"unit {uid}: evidence.provenance must list authoritative provenances"
        if not isinstance(ev.get("joint_with", []), list):
            return f"unit {uid}: evidence.joint_with must be a list"
        if "subject" in u:
            # the resource this unit's evidence must be about (default: verification.subject)
            sref = u["subject"]
            if not isinstance(sref, str) or not sref.startswith("plan:") or sref.partition(":")[2] not in rf:
                return f"unit {uid}: subject must be a plan: reference to one of its request_fields"
        pi = u.get("post_invariants", [])
        if not isinstance(pi, list) or any(i not in invariants or invariants[i].get("phase", "both") == "pre" for i in pi):
            return f"unit {uid}: post_invariants must name post-phase invariants"
        seen[uid] = u
    owner: Dict[str, str] = {}
    for uid, u in seen.items():
        for e in u["effects"]:
            if e in owner:
                return f"effect {e!r} is assigned to two units ({owner[e]}, {uid})"
            owner[e] = uid
    unassigned = [e for e in c.effects if e not in owner]
    if unassigned:
        # an effect outside every unit would be neither required nor explicitly optional
        return f"effects {unassigned} are not assigned to any execution unit"
    state_decl = c.verification.get("state_binding", {})
    if "dependencies" in state_decl:
        required_ids = {d["dependency_id"] for d in state_decl["dependencies"] if d.get("required", True)}
        checked_ids = {d for u in seen.values() if u["required"] and u["state"] != UNIT_STATE_UNBOUND
                       for d in u.get("state_dependencies", [])}
        if required_ids - checked_ids:
            return "required state dependencies covered by no required unit"
    carried = {f for u in seen.values() for f in u["request_fields"]}
    if fields - carried:
        return f"request fields {sorted(fields - carried)} are carried by no execution unit"
    for uid, u in seen.items():
        for j in u.get("evidence", {}).get("joint_with", []):
            if j == uid or j not in seen or uid not in seen[j].get("evidence", {}).get("joint_with", []):
                return f"unit {uid}: joint evidence with {j!r} must be declared by both units"
        if u["required"] and any(not seen[a]["required"] for a in u.get("after", [])):
            return f"unit {uid}: a required unit cannot depend on an optional unit"
    if not any(u["required"] for u in seen.values()):
        return "execution_units: at least one unit must be required"
    listed = {i for u in seen.values() for i in u.get("post_invariants", [])}
    unlisted = sorted(i for i, s in invariants.items() if s.get("phase", "both") != "pre" and i not in listed)
    if unlisted:
        return f"post-phase invariants {unlisted} are bound to no execution unit"
    req = c.verification.get("required_effects")
    if req is not None and set(req) != {e for u in seen.values() if u["required"] for e in u["effects"]}:
        return "verification.required_effects contradicts the required execution units"
    return None


def unit_table(contract: CapabilityContract, plan: Any) -> Tuple[Tuple[Dict[str, Any], ...], Optional[str]]:
    """V0.4: the exact unit table an authorization of `plan` under `contract` binds.
    Deterministic and derived only from the contract and the authorized request."""
    out = []
    for u in contract.execution_units():
        missing = [f for f in u["request_fields"] if not isinstance(plan, dict) or f not in plan]
        if missing:
            return (), f"{u['unit_id']}:{','.join(missing)}"
        row = {"unit_id": u["unit_id"], "required": u["required"], "effects": list(u["effects"]),
               "request": {f: copy.deepcopy(plan[f]) for f in u["request_fields"]},
               "after": list(u.get("after", [])), "state": copy.deepcopy(u["state"]),
               "evidence": copy.deepcopy(u.get("evidence", {})),
               "post_invariants": list(u.get("post_invariants", []))}
        if "subject" in u:
            row["subject"] = {"ref": u["subject"], "value": copy.deepcopy(plan[u["subject"].partition(":")[2]])}
        for key in ("state_dependencies", "establishes"):
            if key in u:
                row[key] = copy.deepcopy(u[key])
        out.append(row)
    return tuple(out), None


def _reason(code: str, detail: str = "") -> Dict[str, str]:
    return {"code": code, "detail": detail}


# ------------------------------------------------------- structural checks
def _contract_problem(c: CapabilityContract) -> Optional[str]:
    for f in ("contract_id", "issuer", "version", "capability", "required_authority", "risk"):
        if not isinstance(getattr(c, f), str) or not getattr(c, f):
            return f"{f} must be a non-empty string"
    if not isinstance(c.reversible, bool):
        return "reversible must be bool"
    if not isinstance(c.inputs, dict) or not c.inputs:
        return "inputs must be a non-empty object"
    for name, spec in c.inputs.items():
        if not isinstance(spec, dict) or spec.get("type") not in INPUT_TYPES:
            return f"input {name}: unknown type"
        unknown = sorted(set(spec) - set(INPUT_KEYS))
        if unknown:
            return f"input {name}: unknown key(s) {unknown}"
    if not isinstance(c.effects, list) or not c.effects or not all(isinstance(e, str) for e in c.effects):
        return "effects must be a non-empty list of strings"
    if not isinstance(c.confirmation_policy, dict) or c.confirmation_policy.get("mode") not in CONFIRMATION_MODES:
        return "unknown confirmation_policy.mode"
    if not isinstance(c.verification, dict) or c.verification.get("read_back") not in READ_BACK_MODES:
        return "unknown verification.read_back"
    problem = _verification_problem(c.verification) or _extension_problem(c)
    if problem:
        return problem
    if "execution_units" in c.extensions:
        problem = _units_problem(c)
        if problem:
            return problem
    req = c.verification.get("required_effects")
    if req is not None and any(e not in c.effects for e in req):
        return "verification.required_effects must be declared effects"
    for kind in ("constraints", "invariants"):
        specs = getattr(c, kind)
        if not isinstance(specs, list):
            return f"{kind} must be a list"
        ids = set()
        for s in specs:
            if not isinstance(s, dict) or not isinstance(s.get("id"), str) or not isinstance(s.get("evaluator"), str):
                return f"{kind}: each entry needs string id and evaluator"
            if not isinstance(s.get("security_critical", True), bool):
                return f"{kind} {s['id']}: security_critical must be bool"
            if s["id"] in ids:
                return f"{kind}: duplicate id {s['id']}"
            ids.add(s["id"])
    return None


def _is_ref(v: Any) -> bool:
    return isinstance(v, str) and ":" in v


def _mentions_ref(value: Any) -> bool:
    if isinstance(value, str):
        return value.startswith(REF_KINDS)
    if isinstance(value, dict):
        return any(_mentions_ref(k) or _mentions_ref(v) for k, v in value.items())
    if isinstance(value, (list, tuple)):
        return any(_mentions_ref(v) for v in value)
    return False


def _extension_problem(c: CapabilityContract) -> Optional[str]:
    """V0.3 optional fields. Malformed => DENY. (Unknown extensions are reported separately.)"""
    ext = c.extensions
    if "security_identity" in ext:
        si = ext["security_identity"]
        if not isinstance(si, dict) or set(si) - set(SECURITY_IDENTITY_KEYS):
            return "security_identity: unknown structure"
        exclude = si.get("exclude", [])
        if not isinstance(exclude, list) or not all(isinstance(f, str) for f in exclude):
            return "security_identity.exclude must be a list of field names"
        bad = sorted(f for f in exclude if f not in NON_SECURITY_ELIGIBLE)
        if bad:
            return f"security_identity.exclude: {bad} cannot be declared non-security"
    if "human_metadata" in ext and not isinstance(ext["human_metadata"], dict):
        return "human_metadata must be an object"
    if "noncritical_extensions" in ext:
        names = ext["noncritical_extensions"]
        if not isinstance(names, list) or not all(isinstance(n, str) for n in names):
            return "noncritical_extensions must be a list of names"
        protocol = sorted(n for n in names if n in CONTRACT_FIELDS or n in OPTIONAL_CONTRACT_FIELDS)
        if protocol:
            return f"noncritical_extensions: protocol fields {protocol} cannot be declared noncritical"
        operational = sorted(n for n in names if n in ext and _mentions_ref(ext[n]))
        if operational:
            # a reference into intent/provider state is an operational dependency, not metadata
            return f"noncritical_extensions: {operational} reference(s) action/provider state"
    return None


def _verification_problem(v: Dict[str, Any]) -> Optional[str]:
    """V0.1 verification fields (all optional; anything present must be well formed).
    V0.3: closed key set; required_effects."""
    unknown = sorted(set(v) - set(VERIFICATION_KEYS))
    if unknown:
        return f"verification: unknown key(s) {unknown}"
    if "subject" in v and not _is_ref(v["subject"]):
        return "verification.subject must be a reference"
    if "evidence_provenance" in v:
        ep = v["evidence_provenance"]
        if not isinstance(ep, list) or not ep or any(p not in PROVENANCES for p in ep):
            return "verification.evidence_provenance must be a non-empty list of known provenances"
        if SELF_REPORTED in ep:
            return "SELF_REPORTED evidence cannot be authoritative"
    if "state_binding" in v:
        sb = v["state_binding"]
        if not isinstance(sb, dict):
            return "verification.state_binding must be an object"
        if set(sb) - set(STATE_BINDING_KEYS):
            return f"verification.state_binding: unknown key(s) {sorted(set(sb) - set(STATE_BINDING_KEYS))}"
        if "dependencies" in sb:
            ds = sb.get("dependencies")
            if not isinstance(ds, list) or not ds:
                return "verification.state_binding.dependencies must be non-empty"
            for d in ds:
                if not isinstance(d, dict) or set(d) - {"dependency_id", "subject", "required"} or not isinstance(d.get("required", True), bool) or not isinstance(d.get("dependency_id"), str) or not d["dependency_id"] or not _is_ref(d.get("subject")):
                    return "verification.state_binding dependency requires dependency_id and subject reference"
            if guarantees(sb.get("required_consistency", "INDIVIDUALLY_CHECKED")) is None:
                return "verification.state_binding.required_consistency unknown"
        elif not _is_ref(sb.get("subject")):
            return "verification.state_binding.subject must be a reference"
    if "required_effects" in v:
        req = v["required_effects"]
        if not isinstance(req, list) or not req or not all(isinstance(e, str) and e for e in req):
            return "verification.required_effects must be a non-empty list of effects"
    return None


def _mentions_fact(value: Any) -> bool:
    if isinstance(value, str):
        return value.startswith("fact:")
    if isinstance(value, dict):
        return any(_mentions_fact(v) for v in value.values())
    if isinstance(value, (list, tuple)):
        return any(_mentions_fact(v) for v in value)
    return False


def _delegation_problem(d: Delegation) -> Optional[str]:
    if not isinstance(d.allowed_authority, list) or not isinstance(d.allowed_capabilities, list):
        return "allowed_authority/allowed_capabilities must be lists"
    if not isinstance(d.constraints, list) or not all(isinstance(x, dict) and isinstance(x.get("id"), str) for x in d.constraints):
        return "constraints must be a list of objects with string id"
    try:
        if parse_instant(d.valid_from) >= parse_instant(d.valid_until):
            return "valid_from must precede valid_until"
    except ValueError as e:
        return f"bad validity window: {e}"
    return None


def _intent_problem(i: Any) -> Optional[str]:
    if not isinstance(i, ActionIntent):
        return "not an ActionIntent"
    for f in ("intent_id", "agent", "principal", "contract_id", "capability", "execution_id"):
        if not isinstance(getattr(i, f), str) or not getattr(i, f):
            return f"{f} must be a non-empty string"
    if not isinstance(i.arguments, dict):
        return "arguments must be an object"
    return None


def _argument_problems(args: Dict[str, Any], inputs: Dict[str, Dict[str, Any]]) -> List[str]:
    problems = []
    for name in args:
        if name not in inputs:
            problems.append(f"unexpected_argument:{name}")
    for name, spec in inputs.items():
        if name not in args:
            if spec.get("required", True):
                problems.append(f"missing_argument:{name}")
            continue
        v, t = args[name], spec["type"]
        if t == "string":
            if not isinstance(v, str):
                problems.append(f"type:{name}:expected_string")
        elif t == "integer":
            if not isinstance(v, int) or isinstance(v, bool):
                problems.append(f"type:{name}:expected_integer")
            elif "minimum" in spec and v < spec["minimum"]:
                problems.append(f"range:{name}:below_minimum")
        elif t == "datetime":
            try:
                parse_instant(v)
            except ValueError:
                problems.append(f"type:{name}:expected_datetime_with_offset")
    return problems


def plan_vs_intent(plan: Dict[str, Any], args: Dict[str, Any], inputs: Dict[str, Dict[str, Any]]) -> List[str]:
    """EXECUTION ⊆ INTENT: every field of the provider request must be the
    image of an intent argument under the contract's `maps_to`, with an
    identical value; every mapped argument must be carried."""
    mapping = {spec["maps_to"]: name for name, spec in inputs.items() if isinstance(spec.get("maps_to"), str)}
    problems = []
    if not isinstance(plan, dict):
        return ["plan_not_an_object"]
    for k, v in plan.items():
        if k not in mapping:
            problems.append(f"field_not_in_intent:{k}")
        elif mapping[k] not in args or not canonical.same(args[mapping[k]], v):
            problems.append(f"value_differs_from_intent:{k}")
    for field, name in mapping.items():
        if name in args and field not in plan:
            problems.append(f"intent_argument_not_carried:{name}")
    return problems


# ===================================================================== verifier
class AuthorizationVerifier:
    def __init__(self, evaluators: ConstraintEvaluatorRegistry, contracts: ContractRegistry,
                 delegations: DelegationStore, ledger: ExecutionLedger, clock: Callable[[], datetime],
                 grants: Optional[GrantStore] = None, evidence_sources: Optional[EvidenceSourceRegistry] = None):
        self._ev = evaluators
        self._contracts = contracts
        self._delegations = delegations
        self._ledger = ledger
        self._clock = clock
        self._receipt_seq = itertools.count(1)
        self._grants = grants if grants is not None else GrantStore()
        self.evidence_sources = evidence_sources if evidence_sources is not None else EvidenceSourceRegistry()
        # V0.4 deployer policy: a contract declaring more than one effect must declare its execution
        # units (else DENY). Off by default: V0-V0.3 multi-effect contracts keep their behaviour.
        self.require_declared_composition = False

    def now(self) -> datetime:
        return self._clock()

    @property
    def grants(self) -> GrantStore:
        return self._grants

    def grant_standing(self, grant_id: Any, grant_digest: Any) -> Optional[Tuple[str, str]]:
        """V0.2: is an issued grant still in force NOW? (issued unaltered, delegation
        unrevoked and in its window, contract unchanged). None if it is, else (code, detail).
        Used by the enforcement boundary immediately before a provider effect."""
        grant = self._grants.get(grant_id)
        if grant is None or grant.digest() != grant_digest:
            return R.GRANT_UNKNOWN, str(grant_id)
        now = self._clock()
        delegation = self._delegations.get(grant.delegation_id)
        if delegation is None or delegation.digest() != grant.delegation_digest:
            return R.UNKNOWN_DELEGATION, str(grant.delegation_id)
        if delegation.revoked:
            return R.DELEGATION_REVOKED, delegation.delegation_id
        try:
            if now < parse_instant(delegation.valid_from):
                return R.DELEGATION_NOT_YET_VALID, delegation.valid_from
            if now >= parse_instant(delegation.valid_until):
                return R.DELEGATION_EXPIRED, delegation.valid_until
        except ValueError as e:
            return R.MALFORMED_DELEGATION, str(e)
        contract = self._contracts.current(grant.contract_id)
        if contract is None or contract.binding_digest() != grant.contract_digest:
            return R.CONTRACT_CHANGED, str(grant.contract_id)
        return None

    # ------------------------------------------------------------ pre-execution
    def authorize(self, intent: ActionIntent, delegation_id: str, facts: Optional[Dict[str, Any]],
                  plan: Optional[Dict[str, Any]], confirmation: Optional[Confirmation] = None,
                  state_binding: Optional[StateBinding] = None,
                  presented_grant: Optional[AuthorizationGrant] = None) -> AuthorizationDecision:
        now = self._clock()
        b: Dict[str, Any] = {"intent_id": getattr(intent, "intent_id", None), "intent_digest": None,
                             "contract_id": None, "contract_version": None, "contract_digest": None,
                             "delegation_id": delegation_id, "delegation_digest": None,
                             "contract_artifact_digest": None}
        warnings: List[Dict[str, str]] = []

        def decide(kind: str, reasons: List[Dict[str, str]], grant=None) -> AuthorizationDecision:
            return AuthorizationDecision(decision=kind, reasons=tuple(reasons), decided_at=now.isoformat(),
                                         warnings=tuple(warnings), grant=grant, **b)

        def deny(code: str, detail: str = "") -> AuthorizationDecision:
            return decide(DENY, [_reason(code, detail)])

        problem = _intent_problem(intent)
        if problem:
            return deny(R.MALFORMED_INTENT, problem)
        # V0.1: a presented grant must be one this verifier issued, unaltered
        if presented_grant is not None and not self._grants.is_issued(presented_grant):
            return deny(R.GRANT_INVALID, str(getattr(presented_grant, "grant_id", None)))

        # 1. contract. V0.3: intent.contract_id is a gateway ADDRESS (bare local id, or
        # issuer-qualified); it must resolve to exactly one (issuer, local id).
        address = intent.contract_id
        if self._contracts.ambiguous(address):
            return deny(R.AMBIGUOUS_CONTRACT, address)
        contract = self._contracts.current(address)
        if contract is None:
            return deny(R.UNKNOWN_CONTRACT, intent.contract_id)
        problem = _contract_problem(contract)
        if problem:
            return deny(R.MALFORMED_CONTRACT, problem)
        if contract.unknown_extensions():
            return deny(R.UNSUPPORTED_EXTENSION, ",".join(contract.unknown_extensions()))
        if contract.issuer != self._contracts.trusted_issuer(address):
            return deny(R.UNTRUSTED_ISSUER, contract.issuer)
        if contract.capability != intent.capability:
            return deny(R.CAPABILITY_MISMATCH, f"{intent.capability} != {contract.capability}")
        if self.require_declared_composition and len(set(contract.effects)) > 1 and not contract.execution_units():
            return deny(R.COMPOSITION_UNDECLARED, f"{len(set(contract.effects))} effects, no execution_units")
        # V0.3: authority binds the security identity; a confirmation binds the artifact
        c_digest = contract.binding_digest()
        artifact_digest = contract.digest()
        b.update(contract_id=address, contract_version=contract.version, contract_digest=c_digest,
                 contract_artifact_digest=artifact_digest)
        try:
            b["intent_digest"] = intent_digest(intent, contract)
        except canonical.CanonicalizationError as e:
            return deny(R.NON_CANONICAL, str(e))

        # 2-4. delegation, principal, agent
        delegation = self._delegations.get(delegation_id)
        if delegation is None:
            return deny(R.UNKNOWN_DELEGATION, str(delegation_id))
        problem = _delegation_problem(delegation)
        if problem:
            return deny(R.MALFORMED_DELEGATION, problem)
        b["delegation_digest"] = delegation.digest()
        if intent.principal != delegation.principal:
            return deny(R.PRINCIPAL_MISMATCH, f"{intent.principal} != {delegation.principal}")
        if intent.agent != delegation.agent:
            return deny(R.AGENT_NOT_DELEGATED, intent.agent)

        # 5. revocation / validity window
        if delegation.revoked:
            return deny(R.DELEGATION_REVOKED, delegation.delegation_id)
        if now < parse_instant(delegation.valid_from):
            return deny(R.DELEGATION_NOT_YET_VALID, delegation.valid_from)
        if now >= parse_instant(delegation.valid_until):
            return deny(R.DELEGATION_EXPIRED, delegation.valid_until)

        # 6. capability (pinned to exact contract digest)
        grants = [g for g in delegation.allowed_capabilities
                  if isinstance(g, dict) and g.get("contract_id") == address
                  and g.get("capability") == contract.capability]
        if not grants:
            return deny(R.CAPABILITY_NOT_DELEGATED, f"{address}/{contract.capability}")
        if not any(g.get("contract_digest") == c_digest for g in grants):
            pinned = ",".join(f"v{g.get('contract_version')}:{g.get('contract_digest')}" for g in grants)
            return deny(R.CONTRACT_CHANGED, f"delegated {pinned}; provider now serves v{contract.version}:{c_digest}")

        # 7. authority
        if contract.required_authority not in delegation.allowed_authority:
            return deny(R.AUTHORITY_NOT_DELEGATED, contract.required_authority)

        # 8. arguments
        problems = _argument_problems(intent.arguments, contract.inputs)
        if problems:
            return decide(DENY, [_reason(R.INVALID_ARGUMENT, p) for p in problems])

        # execution identity: an execution_id is single-use
        if self._ledger.get(intent.execution_id) is not None:
            return deny(R.EXECUTION_ID_USED, intent.execution_id)

        if facts is None or plan is None:
            return deny(R.EVIDENCE_UNAVAILABLE, "provider state or execution plan could not be obtained")
        ctx = EvalContext(intent=intent, contract=contract.decision_view(), delegation=delegation, facts=facts,
                          plan=plan, ledger=self._ledger, now=now)

        # 8b. (V0.1) state binding: authorization over mutable provider state must
        # carry an opaque version token for that state into execution.
        bound_state, problem = self._state_binding(contract, delegation, ctx, state_binding)
        if problem:
            return deny(*problem)
        if presented_grant is not None and presented_grant.state_binding != bound_state:
            return deny(R.STATE_CHANGED, f"granted {_sb(presented_grant.state_binding)}; now {_sb(bound_state)}")

        # 9. constraints
        reasons: List[Dict[str, str]] = []
        deps: Dict[str, List[str]] = {}            # V0.2: declared `fact:` ref -> ids relying on it
        undeclared: List[Dict[str, str]] = []      # V0.2: fact reads nobody declared
        for spec, params, critical in self._bound_constraints(contract, delegation, reasons, warnings):
            self._run(spec, params, ctx, "pre", critical, R.UNSUPPORTED_CONSTRAINT, R.CONSTRAINT_VIOLATED,
                      reasons, warnings, deps=deps, undeclared=undeclared)
        if reasons:
            return decide(DENY, reasons)

        # 10. pre-execution invariants + EXECUTION ⊆ INTENT on the planned request
        for spec in contract.invariants:
            critical = spec.get("security_critical", True)
            phase = spec.get("phase", "both")
            if self._ev.get(spec["evaluator"]) is None or phase in ("pre", "both"):
                self._run(spec, spec.get("params", {}), ctx, "pre", critical, R.UNSUPPORTED_INVARIANT,
                          R.INVARIANT_VIOLATED, reasons, warnings, evaluate=phase in ("pre", "both"),
                          deps=deps, undeclared=undeclared)
            elif phase == "post":
                # post-only invariants also declare what authorization-time state they will compare against
                self._run(spec, spec.get("params", {}), ctx, "pre", critical, R.UNSUPPORTED_INVARIANT,
                          R.INVARIANT_VIOLATED, [], [], deps=deps, undeclared=undeclared)
        for p in plan_vs_intent(plan, intent.arguments, contract.inputs):
            reasons.append(_reason(R.PLAN_EXCEEDS_INTENT, p))
        if reasons:
            return decide(DENY, reasons)
        # V0.4: the exact execution-unit table this authorization binds (empty without units)
        units, problem = self._execution_units(contract, plan)
        if problem:
            return deny(R.UNIT_REQUEST_UNAVAILABLE, problem)

        # V0.2: the state-dependency set. A dependency is carried into execution only by a
        # state binding (which versions every fact the adapter resolved). Gaps are classified,
        # never assumed safe: they are warnings here (V0.1 behaviour of this call is kept) and
        # they make the grant impossible to attenuate into an ExecutionCredential.
        gaps: List[Dict[str, str]] = []
        if bound_state is None:
            gaps += [{"ref": ref, "class": "unbound", "by": ",".join(sorted(by))} for ref, by in sorted(deps.items())]
        gaps += undeclared
        for g in gaps:
            warnings.append(_reason(R.STATE_DEPENDENCY_UNBOUND if g["class"] == "unbound" else R.STATE_READ_UNDECLARED,
                                    f"{g['by']}:{g['ref']}"))
        try:
            resource_value = resolve_ref(contract.verification.get("subject"), ctx)
            resource = {"ref": contract.verification["subject"], "value": resource_value}
        except (RefError, KeyError):
            resource = None

        def allow(conf: Optional[Confirmation]) -> AuthorizationDecision:
            try:
                plan_d = canonical.digest(plan)
            except canonical.CanonicalizationError as e:
                return deny(R.NON_CANONICAL, f"plan: {e}")
            grant = AuthorizationGrant.build(
                intent_id=intent.intent_id, intent_digest=b["intent_digest"], contract_id=address,
                contract_version=contract.version, contract_digest=c_digest, delegation_id=delegation.delegation_id,
                delegation_digest=b["delegation_digest"], confirmation_digest=confirmation_digest(conf),
                plan_digest=plan_d, state_binding=bound_state, execution_id=intent.execution_id,
                principal=intent.principal, agent=intent.agent, capability=contract.capability,
                resource=resource, request=copy.deepcopy(plan), not_after=delegation.valid_until, max_uses=1,
                state_dependencies=tuple(sorted(deps)), dependency_gaps=tuple(gaps), effects=tuple(contract.effects),
                execution_units=units)
            if presented_grant is not None:
                bad = [_reason(R.GRANT_MISMATCH, f) for f in GRANT_BOUND_FIELDS
                       if getattr(presented_grant, f) != getattr(grant, f)]
                if bad:
                    return decide(DENY, bad)
            self._grants.record(grant)
            return decide(ALLOW, [], grant)

        # 11. confirmation
        if not CONFIRMATION_MODES[contract.confirmation_policy["mode"]]:
            return allow(None)
        if confirmation is None:
            return decide(REQUIRE_CONFIRMATION, [_reason(R.CONFIRMATION_REQUIRED)])
        checks = (
            ("principal", confirmation.principal, delegation.principal),
            ("intent_id", confirmation.intent_id, intent.intent_id),
            ("intent_digest", confirmation.intent_digest, b["intent_digest"]),
            ("contract_digest", confirmation.contract_digest, artifact_digest),
            ("delegation_id", confirmation.delegation_id, delegation.delegation_id),
            ("delegation_digest", confirmation.delegation_digest, b["delegation_digest"]),
        )
        bad = [_reason(R.CONFIRMATION_MISMATCH, name) for name, got, want in checks if got != want]
        if bad:
            return decide(DENY, bad)
        # 12.
        return allow(confirmation)

    def _execution_units(self, contract, plan):
        """Binding generation for the unit table (the grant's ExecutionBinding content)."""
        return unit_table(contract, plan)

    def execution_binding_problem(self, grant: AuthorizationGrant) -> Optional[str]:
        """V0.4: does an issued grant's unit table equal what its contract (by digest) and its
        authorized request determine? Checked independently of binding generation, by the
        enforcement boundary before attenuation. None if it does."""
        contract = self._contracts.by_digest(grant.contract_digest)
        if contract is None:
            return "bound contract unavailable"
        expected, problem = unit_table(contract, grant.request)
        if problem:
            return problem
        if not canonical.same(list(grant.execution_units), list(expected)):
            return (f"granted units {list(grant.unit_ids())} != contract units "
                    f"{[u['unit_id'] for u in expected]} (or their content differs)")
        return None

    def _state_binding(self, contract, delegation, ctx, offered):
        """Generic rule: if the contract declares a state binding, or any constraint /
        invariant reads provider state (`fact:`), a binding for the declared subject is
        required. The token itself is opaque. Returns (binding or None, deny-reason or None)."""
        if isinstance(offered, StateBinding) and (offered.critical != {} or not isinstance(offered.noncritical, dict)):
            return None, (R.STATE_BINDING_UNAVAILABLE, "unknown critical or malformed binding extension")
        decl = contract.verification.get("state_binding")
        depends = _mentions_fact([contract.constraints, contract.invariants, delegation.constraints])
        if decl is None:
            if depends:
                return None, (R.STATE_BINDING_UNDECLARED, "authorization reads provider state")
            return None, None
        if "dependencies" in decl:
            if not isinstance(offered, StateBinding) or not offered.dependencies or offered.critical or not isinstance(offered.noncritical, dict):
                return None, (R.STATE_BINDING_UNAVAILABLE, "provider/adapter offers no multi-state binding")
            try:
                expected = []
                for d in decl["dependencies"]:
                    expected.append((d["dependency_id"], resolve_ref(d["subject"], ctx), d.get("required", True)))
                if validate_dependencies(offered.dependencies):
                    raise ValueError("malformed, duplicate or conflicting dependencies")
                got = {d["dependency_id"]: d for d in offered.dependencies}
                if len({d[0] for d in expected}) != len(expected):
                    raise ValueError("duplicate contract dependency ID")
                if set(got) - {d[0] for d in expected}:
                    raise ValueError("undeclared dependency")
                for did, subject, required in expected:
                    item = got.get(did)
                    if required and item is None:
                        raise ValueError("missing required dependency " + did)
                    if item is not None:
                        if item["subject_ref"] != subject:
                            raise ValueError("dependency subject mismatch")
                        if required and not item.get("required", True):
                            raise ValueError("offered requiredness weakens contract")
                required = guarantees(decl.get("required_consistency", "INDIVIDUALLY_CHECKED"))
                observed = guarantees(offered.observed_consistency)
                if required is None or observed is None or guarantees(offered.required_consistency) != required:
                    raise ValueError("malformed consistency guarantees")
                if not required <= observed:
                    raise ValueError("required guarantee not established")
                strong = observed - {"INDIVIDUALLY_CHECKED"}
                if strong:
                    if contract.execution_units():
                        raise ValueError("strong multi-state unit projections require unsupported scoped infrastructure")
                    scope = context_scope(contract, delegation, ctx.intent, offered, ctx.plan)
                    cc = offered.consistency_context
                    if not isinstance(cc, dict) or set(cc) - {"value", "covers", "scope", "source", "critical", "noncritical"}:
                        raise ValueError("unsupported context semantics")
                    if cc.get("critical", {}) != {}:
                        raise ValueError("unknown critical extension")
                    if not isinstance(cc.get("noncritical", {}), dict):
                        raise ValueError("malformed noncritical extension")
                    if not isinstance(cc.get("value"), str) or not cc["value"]:
                        raise ValueError("missing context value")
                    covers = cc.get("covers")
                    if not isinstance(covers, list) or any(not isinstance(x, str) for x in covers) or sorted(covers) != sorted(d["dependency_id"] for d in offered.dependencies if d.get("required", True)):
                        raise ValueError("context coverage mismatch")
                    if not isinstance(cc.get("source"), str) or not cc["source"] or not isinstance(cc.get("scope"), list) or any(not isinstance(x, str) for x in cc["scope"]) or scope not in cc["scope"]:
                        raise ValueError("context scope or lineage mismatch")
                    if not self.evidence_sources.validate_consistency(contract, cc, scope, strong, offered):
                        raise ValueError("no authenticated consistency authority")
                elif offered.consistency_context is not None:
                    raise ValueError("context supplied without strong guarantee")
            except (TypeError, KeyError, ValueError, RefError, canonical.CanonicalizationError) as e:
                return None, (R.STATE_BINDING_UNAVAILABLE, str(e))
            return offered, None
        try:
            subject = resolve_ref(decl["subject"], ctx)
        except RefError as e:
            return None, (R.STATE_BINDING_UNAVAILABLE, f"subject: {e}")
        if not (isinstance(offered, StateBinding)
                and all(isinstance(x, str) and x for x in (offered.subject, offered.version_kind, offered.version_value))):
            return None, (R.STATE_BINDING_UNAVAILABLE, "provider/adapter offers no conditional-execution token")
        if not isinstance(subject, str) or offered.subject != subject:
            return None, (R.STATE_BINDING_SUBJECT_MISMATCH, f"{offered.subject!r} != {subject!r}")
        return offered, None

    def _bound_constraints(self, contract, delegation, reasons, warnings):
        """Contract constraints (params inline or from the delegation, matched by id)
        plus delegation-only constraints (always treated as security-critical)."""
        by_id = {c["id"]: c for c in delegation.constraints}
        used = set()
        out = []
        for spec in contract.constraints:
            critical = spec.get("security_critical", True)
            if spec.get("params_from") == "delegation":
                bound = by_id.get(spec["id"])
                if bound is None:
                    if critical:
                        reasons.append(_reason(R.CONSTRAINT_UNBOUND, spec["id"]))
                    else:
                        warnings.append(_reason(R.CONSTRAINT_UNBOUND, spec["id"]))
                    continue
                used.add(spec["id"])
                params = bound.get("params", {})
            else:
                params = spec.get("params", {})
            out.append((spec, params if isinstance(params, dict) else {}, critical))
        for extra in delegation.constraints:
            if extra["id"] not in used:
                out.append((extra, extra.get("params", {}) if isinstance(extra.get("params"), dict) else {}, True))
        return out

    def _run(self, spec, params, ctx, phase, critical, unsupported_code, violated_code, reasons, warnings,
             evaluate=True, deps=None, undeclared=None):
        fn = self._ev.get(spec.get("evaluator"))
        if fn is None:
            if critical:
                reasons.append(_reason(unsupported_code, f"{spec['id']}:{spec.get('evaluator')}"))
            else:
                warnings.append(_reason(R.SKIPPED_NONCRITICAL, f"{spec['id']}:{spec.get('evaluator')}"))
            return None
        unknown = sorted(set(spec) - set(BASE_SPEC_KEYS) - set(self._ev.spec_keys(spec.get("evaluator"))))
        if unknown:
            # a modifier the evaluator does not interpret: never silently ignored
            if critical:
                reasons.append(_reason(R.UNSUPPORTED_MODIFIER, f"{spec['id']}:{','.join(unknown)}"))
            else:
                warnings.append(_reason(R.SKIPPED_NONCRITICAL, f"{spec['id']}:{','.join(unknown)}"))
            return None
        if not evaluate:
            return None
        tracker = None
        if deps is not None and isinstance(ctx.facts, dict):
            # V0.2: observe which facts the evaluator actually reads
            tracker = _ReadTracker(ctx.facts)
            ctx = dataclasses.replace(ctx, facts=tracker)
        try:
            out = fn(spec, params, ctx, phase)
        except Exception as e:  # evaluator bug => fail closed
            reasons.append(_reason(R.EVALUATOR_ERROR, f"{spec['id']}:{type(e).__name__}:{e}"))
            return None
        if tracker is not None:
            declared = tuple(d for d in getattr(out, "dependencies", ()) if isinstance(d, str))
            for ref in declared:
                deps.setdefault(ref, []).append(spec["id"])
            roots = {d.partition(":")[2].split(".")[0] for d in declared if d.startswith("fact:")}
            for key in sorted(tracker.reads - roots):
                undeclared.append({"ref": f"fact:{key}", "class": "undeclared_read", "by": spec["id"]})
        if out.status != PASS:
            # pre-execution "unverifiable" is treated as failure (fail closed)
            target = reasons if critical else warnings
            target.append(_reason(violated_code, f"{spec['id']}:{out.code}:{out.detail}"))
        return out

    # ----------------------------------------------------------- post-execution
    def verify_execution(self, intent: ActionIntent, decision: AuthorizationDecision,
                         facts: Optional[Dict[str, Any]], plan: Optional[Dict[str, Any]],
                         result: ExecutionResult, evidence: Sequence[Any] = (),
                         out_of_scope: Sequence[Dict[str, Any]] = (),
                         unit_records: Optional[Dict[str, Dict[str, Any]]] = None) -> ActionReceipt:
        """`result` is the execution path's REPORT (a claim). `evidence` is every
        ExecutionEvidence gathered, self-reported or not. A claim or self-reported
        evidence can incriminate (VIOLATION) but never exonerate: VERIFIED requires
        at least one accepted, correctly bound, authoritative piece of evidence."""
        violations: List[Dict[str, str]] = []
        unverified: List[Dict[str, str]] = []
        records: List[Dict[str, str]] = []
        contract = self._contracts.by_digest(decision.contract_digest)
        grant = decision.grant

        if decision.decision != ALLOW:
            violations.append(_reason(R.NOT_AUTHORIZED, decision.decision))
        # V0.2: the enforcement boundary blocked attempts by the executor. Nothing happened
        # (prevention), but the receipt must not call this executor's behaviour clean.
        for attempt in out_of_scope:
            violations.append(_reason(R.OUT_OF_SCOPE_ATTEMPT, f"{attempt.get('reason')}:{attempt.get('operation')}"))
        # 13. execution identity
        if result.execution_id != intent.execution_id:
            violations.append(_reason(R.IDENTITY_MISMATCH, f"{result.execution_id} != {intent.execution_id}"))
        if contract is None:
            violations.append(_reason(R.CONTRACT_UNAVAILABLE, str(decision.contract_digest)))
        elif intent_digest(intent, contract) != decision.intent_digest or intent.intent_id != decision.intent_id:
            violations.append(_reason(R.INTENT_MUTATED, intent.intent_id))

        # 14. the report (claims): may incriminate, never exonerate
        if result.status == EXEC_UNKNOWN:
            unverified.append(_reason(R.OUTCOME_UNKNOWN, result.detail))
        elif result.status == EXEC_PRECONDITION_FAILED:
            unverified.append(_reason(R.STATE_PRECONDITION_FAILED, result.detail))
        elif result.status == EXEC_PARTIAL:
            # V0.3: never full success; the protocol invents no rollback (compensation is domain logic)
            missing = [e for e in (contract.effects if contract is not None else []) if e not in result.observed_effects]
            unverified.append(_reason(R.EXECUTION_PARTIAL, f"performed {list(result.observed_effects)}; "
                                                           f"not performed {missing}; {result.detail}"))
        elif result.status != EXEC_SUCCESS:
            unverified.append(_reason(R.EXEC_NOT_SUCCESSFUL, result.detail))
        if contract is not None and result.status != EXEC_UNKNOWN:
            for e in result.observed_effects:
                if e not in contract.effects:
                    violations.append(_reason(R.UNDECLARED_EFFECT, e))
            if result.status == EXEC_SUCCESS:
                if not canonical.same(result.request, plan):
                    violations.append(_reason(R.REQUEST_DIFFERS))
                for p in plan_vs_intent(result.request, intent.arguments, contract.inputs):
                    violations.append(_reason(R.PLAN_EXCEEDS_INTENT, p))

        # 15. evidence (V0.1)
        authoritative_ok = 0
        covered: set = set()     # V0.3: effects confirmed by accepted authoritative evidence
        unit_rows: List[Dict[str, Any]] = []
        if contract is not None and result.status != EXEC_UNKNOWN and contract.execution_units():
            # V0.4: composite contract — every unit is judged on its own
            authoritative_ok = self._verify_units(intent, decision, contract, facts, plan, result, evidence,
                                                  unit_records, violations, unverified, records, unit_rows)
        elif contract is not None and result.status != EXEC_UNKNOWN:
            ctx = EvalContext(intent=intent, contract=contract.decision_view(),
                              delegation=self._delegations.get(decision.delegation_id),
                              facts=facts, plan=plan, ledger=self._ledger, now=self._clock())
            accepted = contract.verification.get("evidence_provenance", list(DEFAULT_AUTHORITATIVE))
            try:
                subject = resolve_ref(contract.verification.get("subject"), ctx)
            except RefError:
                subject = None
            for ev in evidence:
                ok = self._judge_evidence(ev, intent, contract, ctx, accepted, subject, grant, result,
                                          violations, unverified, records, decision.contract_id)
                authoritative_ok += ok
                if ok:
                    covered.update(ev.observed_effects)
            if result.status == EXEC_SUCCESS and authoritative_ok == 0 and not any(
                    r["outcome"] == "authoritative" for r in records):
                unverified.append(_reason(R.NO_AUTHORITATIVE_EVIDENCE if evidence else R.READ_BACK_UNAVAILABLE))
            # V0.3: every effect the contract says MUST happen needs its own authoritative confirmation;
            # evidence of one effect never stands in for another
            if result.status == EXEC_SUCCESS:
                for e in contract.verification.get("required_effects", []):
                    if e not in covered:
                        unverified.append(_reason(R.REQUIRED_EFFECT_UNVERIFIED, e))

        # 16. receipt.  VERIFIED only if nothing failed AND authoritative evidence fully confirmed it.
        if violations:
            status = VIOLATION
        elif unverified or result.status != EXEC_SUCCESS or authoritative_ok == 0:
            status = UNVERIFIED
        else:
            status = VERIFIED
        return ActionReceipt(
            receipt_id=f"rcpt-{next(self._receipt_seq)}",
            intent_id=intent.intent_id,
            execution_id=intent.execution_id,
            authorization=decision,
            execution_result={"status": result.status, "provider_ref": result.provider_ref, "detail": result.detail},
            observed_effects=tuple(result.observed_effects),
            verification_status=status,
            verification_reasons=tuple(violations + unverified),
            grant_id=grant.grant_id if grant is not None else None,
            evidence=tuple(records),
            units=tuple(unit_rows),
            state_consistency=({"required": sorted(guarantees(grant.state_binding.required_consistency)),
                                "observed": sorted(guarantees(grant.state_binding.observed_consistency))}
                               if grant is not None and grant.state_binding is not None and grant.state_binding.dependencies else None),
        )

    # ------------------------------------------------------- V0.4 unit verification
    def _verify_units(self, intent, decision, contract, facts, plan, result, evidence, unit_records,
                      violations, unverified, records, rows) -> int:
        """Returns the number of verified units. Required units are taken from the CONTRACT."""
        grant = decision.grant
        address = decision.contract_id if decision.contract_id is not None else contract.contract_id
        expected, problem = unit_table(contract, plan)
        units = {u["unit_id"]: u for u in expected}
        if problem or grant is None or not canonical.same(list(grant.execution_units), list(expected)):
            violations.append(_reason(R.EXECUTION_BINDING_MISMATCH,
                                      problem or f"granted {list(grant.unit_ids()) if grant else None}; "
                                                 f"contract requires {list(units)}"))
        judged = list(evidence)
        if unit_records is None:
            # only the confined path records per-unit permits; nothing else can stand in for them
            unverified.append(_reason(R.UNIT_EXECUTION_UNOBSERVED, "no enforcement-boundary unit record"))
            for ev in judged:
                records.append({"evidence_id": str(getattr(ev, "evidence_id", None)),
                                "source": str(getattr(ev, "source_identity", None)),
                                "provenance": str(getattr(ev, "provenance", None)), "outcome": "not_judged"})
            unit_records, judged = {}, []
        ctx = EvalContext(intent=intent, contract=contract.decision_view(),
                          delegation=self._delegations.get(decision.delegation_id),
                          facts=facts, plan=plan, ledger=self._ledger, now=self._clock())
        try:
            subject = resolve_ref(contract.verification.get("subject"), ctx)
        except RefError:
            subject = None
        default_prov = contract.verification.get("evidence_provenance", list(DEFAULT_AUTHORITATIVE))
        executed = {uid for uid, r in unit_records.items() if r.get("status") == EXEC_SUCCESS}
        proof: Dict[str, List[str]] = {uid: [] for uid in units}        # accepted evidence ids per unit
        established: Dict[str, List[Any]] = {uid: [] for uid in units}  # evidence-attested produced state
        problems: Dict[str, List[str]] = {uid: [] for uid in units}
        for ev in judged:
            self._judge_unit_evidence(ev, intent, contract, ctx, address, subject, grant, units, executed,
                                      unit_records, default_prov, proof, established, problems,
                                      violations, unverified, records)
        verified_n = 0
        for uid, u in units.items():
            status = unit_records.get(uid, {}).get("status")
            ok = status == EXEC_SUCCESS and bool(proof[uid]) and not problems[uid]
            pred = u["state"].get(UNIT_STATE_FROM) if isinstance(u["state"], dict) else None
            if ok and pred is not None:
                # continuity: what the boundary applied must be what the predecessor's evidence says it produced
                used = unit_records.get(uid, {}).get("precondition")
                attested = established.get(pred, [])
                if not attested:
                    ok = False
                    unverified.append(_reason(R.UNIT_STATE_UNATTESTED, f"{uid}: state produced by {pred} unattested"))
                else:
                    mismatch = False
                    for a in attested:
                        if grant.state_binding is not None and grant.state_binding.dependencies:
                            try:
                                from .adapter import ExecutionResult
                                report = ExecutionResult(EXEC_SUCCESS, intent.execution_id, None, {}, established_state=a)
                                expected_state = handoff_binding(grant.state_binding, units[pred], u, report, intent.execution_id, unit_records.get(pred, {}).get("precondition")).to_dict()
                            except (TypeError, KeyError, ValueError):
                                expected_state = None
                        else:
                            expected_state = a
                        mismatch |= not canonical.same(expected_state, used)
                    if mismatch:
                        ok = False
                        violations.append(_reason(R.UNIT_STATE_MISMATCH, f"{uid}: applied {used!r}, {pred} produced {attested!r}"))
            if u["required"]:
                if status != EXEC_SUCCESS:
                    unverified.append(_reason(R.REQUIRED_UNIT_NOT_EXECUTED, f"{uid}:{status or 'NOT_EXECUTED'}"))
                elif not ok:
                    unverified.append(_reason(R.REQUIRED_UNIT_UNVERIFIED, f"{uid}:{','.join(problems[uid]) or 'no_accepted_evidence'}"))
            elif status == EXEC_SUCCESS and not ok:
                # an optional effect that happened is still an effect: it cannot hide in a VERIFIED receipt
                unverified.append(_reason(R.EXECUTED_UNIT_UNVERIFIED, f"{uid}:{','.join(problems[uid]) or 'no_accepted_evidence'}"))
            verified_n += int(ok)
            rows.append({"unit_id": uid, "required": u["required"], "execution": status or "NOT_EXECUTED",
                         "verified": ok, "evidence": tuple(proof[uid]), "problems": tuple(problems[uid])})
        return verified_n

    def _judge_unit_evidence(self, ev, intent, contract, ctx, address, subject, grant, units, executed,
                             unit_records, default_prov, proof, established, problems,
                             violations, unverified, records) -> None:
        def record(outcome: str, prov: Any = None) -> None:
            records.append({"evidence_id": str(getattr(ev, "evidence_id", None)),
                            "source": str(getattr(ev, "source_identity", None)),
                            "provenance": str(prov), "outcome": outcome})

        def reject(why: str) -> None:
            record("rejected:" + why, getattr(ev, "provenance", None))
            unverified.append(_reason(R.EVIDENCE_REJECTED, f"{getattr(ev, 'evidence_id', None)}:{why}"))

        if not isinstance(ev, ExecutionEvidence):
            return reject("malformed")
        prov = self.evidence_sources.provenance_of(address, ev.source_identity)
        if prov is None:
            return reject("source_unregistered")
        if ev.provenance != prov:
            return reject(f"provenance_misclaimed:{ev.provenance}!={prov}")
        if ev.execution_id != intent.execution_id:
            return reject("execution_id_mismatch")
        if ev.intent_id != intent.intent_id:
            return reject("intent_id_mismatch")
        tag = f"[{ev.source_identity}] "
        # a registered source reporting an effect outside the contract incriminates, whatever it claims to cover
        outside = [e for e in ev.observed_effects if e not in contract.effects]
        if outside:
            violations.append(_reason(R.UNDECLARED_EFFECT, tag + ",".join(outside)))
            return record("incriminating", prov)
        if prov == SELF_REPORTED:
            return record("non_authoritative", prov)
        covers = tuple(ev.covers_units) if isinstance(ev.covers_units, (list, tuple)) else ()
        if not covers or len(set(covers)) != len(covers):
            return reject("no_unit_claim")
        unknown = [u for u in covers if u not in units]
        if unknown:
            return reject("unit_unknown:" + ",".join(map(str, unknown)))
        uscope = self.evidence_sources.units_of(address, ev.source_identity)
        if uscope is None or any(u not in uscope for u in covers):
            return reject("unit_outside_source_scope:" + ",".join(u for u in covers if uscope is None or u not in uscope))
        scope = self.evidence_sources.scope_of(address, ev.source_identity)
        if scope is not None and not set(ev.observed_effects) <= set(scope):
            return reject("effect_outside_source_scope")
        for a, b in itertools.combinations(covers, 2):
            if b not in units[a]["evidence"].get("joint_with", []):
                return reject(f"joint_evidence_undeclared:{a}+{b}")
        if grant is None or ev.grant_id != grant.grant_id:
            return reject("lineage_mismatch")
        allowed = {e for u in covers for e in units[u]["effects"]}
        if any(e not in allowed for e in ev.observed_effects):
            return reject("effect_outside_covered_units")
        subjects = {canonical.canonical_bytes(units[u]["subject"]["value"] if "subject" in units[u] else subject)
                    for u in covers}
        if len(subjects) > 1:
            return reject("joint_evidence_spans_subjects")
        authoritative = [u for u in covers if prov in units[u]["evidence"].get("provenance", default_prov)]
        record("authoritative" if authoritative else "non_authoritative", prov)
        for u in covers:
            seen_effects = [e for e in units[u]["effects"] if e in ev.observed_effects]
            if u not in executed:
                # the boundary never permitted (or never completed) this unit, yet its effect is attested
                if prov in units[u]["evidence"].get("provenance", default_prov) and seen_effects:
                    violations.append(_reason(R.UNIT_EFFECT_WITHOUT_PERMIT, f"{tag}{u}:{','.join(seen_effects)}"))
        n_viol = len(violations)
        mine: List[Dict[str, str]] = []
        u0 = units[covers[0]]
        subject = u0["subject"]["value"] if "subject" in u0 else subject
        if subject is None:
            mine.append(_reason(R.EVIDENCE_SUBJECT_UNDECLARED, tag))
        elif ev.observed_subject != subject:
            violations.append(_reason(R.EVIDENCE_SUBJECT_MISMATCH, f"{tag}authorized {subject!r}, observed {ev.observed_subject!r}"))
            return
        projection = {f: v for u in covers for f, v in units[u]["request"].items()}
        invariant_ids = {i for u in covers for i in units[u]["post_invariants"]}
        self._postconditions(ev.observed_state, contract, dataclasses.replace(ctx, plan=projection), tag,
                             violations, mine, invariant_ids=invariant_ids)
        states = ev.unit_states if isinstance(ev.unit_states, dict) else {}
        per_unit: Dict[str, List[str]] = {u: [] for u in covers}
        for u in covers:
            if u not in executed:
                continue
            spec = units[u]["state"]
            if spec == UNIT_STATE_AUTHORIZATION:
                want = project_binding(grant.state_binding, units[u]).to_dict() if grant.state_binding is not None else None
            elif isinstance(spec, dict):
                want = unit_records.get(u, {}).get("precondition")
            else:
                want = None
            st = states.get(u) if isinstance(states.get(u), dict) else {}
            if want is not None:
                ap = st.get("applied")
                if ap is None:
                    per_unit[u].append(R.UNIT_STATE_UNATTESTED)
                elif ap == {}:
                    violations.append(_reason(R.STATE_PRECONDITION_NOT_ENFORCED, f"{tag}{u}: applied unconditionally"))
                elif not canonical.same(ap, want):
                    violations.append(_reason(R.UNIT_STATE_MISMATCH, f"{tag}{u}: applied {ap!r}, bound {want!r}"))
            if st.get("established") is not None and u in authoritative:
                # only a source authoritative for the unit can attest the state it produced
                established[u].append(copy.deepcopy(st["established"]))
            missing = [e for e in units[u]["effects"] if e not in ev.observed_effects]
            if missing:
                per_unit[u].append("effects_unobserved:" + ",".join(missing))
        if len(violations) != n_viol:
            return
        for u in covers:
            if u not in executed or u not in authoritative:
                continue
            issues = [m["code"] for m in mine] + per_unit[u]
            if issues:
                problems[u].extend(i for i in issues if i not in problems[u])
            else:
                proof[u].append(str(ev.evidence_id))

    def _judge_evidence(self, ev, intent, contract, ctx, accepted, subject, grant, result,
                        violations, unverified, records, address=None) -> int:
        """Returns 1 iff `ev` is accepted, authoritative, and confirms the execution."""
        def record(outcome: str, prov: Any = None) -> None:
            records.append({"evidence_id": str(getattr(ev, "evidence_id", None)),
                            "source": str(getattr(ev, "source_identity", None)),
                            "provenance": str(prov), "outcome": outcome})

        def reject(why: str) -> int:
            record("rejected:" + why, getattr(ev, "provenance", None))
            unverified.append(_reason(R.EVIDENCE_REJECTED, f"{getattr(ev, 'evidence_id', None)}:{why}"))
            return 0

        if not isinstance(ev, ExecutionEvidence):
            return reject("malformed")
        exec_status = result.status
        address = address if address is not None else contract.contract_id
        prov = self.evidence_sources.provenance_of(address, ev.source_identity)
        if prov is None:
            return reject("source_unregistered")
        if ev.provenance != prov:
            return reject(f"provenance_misclaimed:{ev.provenance}!={prov}")
        # binding: this execution, this intent
        if ev.execution_id != intent.execution_id:
            return reject("execution_id_mismatch")
        if ev.intent_id != intent.intent_id:
            return reject("intent_id_mismatch")
        # V0.3: a source observes only the effects it was registered for
        scope = self.evidence_sources.scope_of(address, ev.source_identity)
        if scope is not None and any(e not in scope for e in ev.observed_effects):
            return reject("effect_outside_source_scope:" + ",".join(e for e in ev.observed_effects if e not in scope))

        authoritative = prov != SELF_REPORTED and prov in accepted
        record("authoritative" if authoritative else "non_authoritative", prov)
        tag = f"[{ev.source_identity}] "
        # Evidence below is about THIS execution. Its violations always count;
        # its "could not observe" only matters if it could have verified.
        mine: List[Dict[str, str]] = []

        if exec_status == EXEC_PARTIAL:
            # V0.3: evidence of an effect the report admits is consistent (still never VERIFIED);
            # evidence of an effect the report denies is a violation; unlabelled evidence can't be judged
            if authoritative:
                denied = [e for e in ev.observed_effects if e not in result.observed_effects]
                if denied:
                    violations.append(_reason(R.EFFECT_DESPITE_FAILURE, tag + ",".join(denied)))
                elif not ev.observed_effects:
                    unverified.append(_reason(R.EVIDENCE_REJECTED, tag + "partial_execution_needs_effect_labels"))
            return 0
        if exec_status != EXEC_SUCCESS:
            # the execution path says nothing happened; bound evidence says it did
            if authoritative:
                violations.append(_reason(R.EFFECT_DESPITE_FAILURE, tag + exec_status))
            return 0
        if subject is None:
            mine.append(_reason(R.EVIDENCE_SUBJECT_UNDECLARED, tag))
        elif ev.observed_subject != subject:
            violations.append(_reason(R.EVIDENCE_SUBJECT_MISMATCH,
                                      f"{tag}authorized {subject!r}, observed {ev.observed_subject!r}"))
            return 0
        n_viol = len(violations)
        for e in ev.observed_effects:
            if e not in contract.effects:
                violations.append(_reason(R.UNDECLARED_EFFECT, tag + e))
        self._postconditions(ev.observed_state, contract, ctx, tag, violations, mine)
        if authoritative and grant is not None and grant.state_binding is not None:
            ap = ev.applied_precondition
            if ap is None:
                mine.append(_reason(R.STATE_PRECONDITION_UNATTESTED, tag))
            elif ap == {}:
                violations.append(_reason(R.STATE_PRECONDITION_NOT_ENFORCED, tag + "provider applied the write unconditionally"))
            elif not canonical.same(ap, grant.state_binding.to_dict()):
                violations.append(_reason(R.STATE_PRECONDITION_MISMATCH, f"{tag}{ap!r}"))
        if not authoritative:
            return 0
        unverified.extend(mine)
        return 1 if not mine and len(violations) == n_viol else 0

    def _postconditions(self, post_state, contract, ctx, tag, violations, unverified, invariant_ids=None) -> None:
        plan = ctx.plan
        if post_state is None:
            unverified.append(_reason(R.READ_BACK_UNAVAILABLE, tag))
            return
        for k, v in (plan or {}).items():
            if k not in post_state:
                unverified.append(_reason(R.POSTCONDITION_UNOBSERVABLE, tag + k))
            elif not canonical.same(post_state[k], v):
                violations.append(_reason(R.POSTCONDITION_FAILED, f"{tag}{k}: expected {v!r}, observed {post_state[k]!r}"))
        pctx = EvalContext(intent=ctx.intent, contract=contract, delegation=ctx.delegation, facts=ctx.facts,
                           plan=plan, ledger=self._ledger, now=ctx.now, post_state=post_state)
        for spec in contract.invariants:
            if spec.get("phase", "both") not in ("post", "both"):
                continue
            if invariant_ids is not None and spec["id"] not in invariant_ids:
                continue   # V0.4: a post invariant runs only on evidence of the units it is bound to
            fn = self._ev.get(spec["evaluator"])
            if fn is None:
                unverified.append(_reason(R.INVARIANT_UNVERIFIABLE, f"{tag}{spec['id']}:no_evaluator"))
                continue
            try:
                out = fn(spec, spec.get("params", {}), pctx, "post")
            except Exception as e:
                unverified.append(_reason(R.INVARIANT_UNVERIFIABLE, f"{tag}{spec['id']}:{type(e).__name__}"))
                continue
            if out.status == FAIL:
                violations.append(_reason(R.INVARIANT_VIOLATED, f"{tag}{spec['id']}:{out.code}:{out.detail}"))
            elif out.status == UNVERIFIABLE:
                unverified.append(_reason(R.INVARIANT_UNVERIFIABLE, f"{tag}{spec['id']}:{out.code}:{out.detail}"))


class _ReadTracker(dict):
    """A dict that remembers which top-level keys were read (V0.2 undeclared-read detection)."""

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.reads: set = set()

    def __getitem__(self, key):
        self.reads.add(key)
        return super().__getitem__(key)

    def get(self, key, default=None):
        self.reads.add(key)
        return super().get(key, default)

    def __contains__(self, key):
        self.reads.add(key)
        return super().__contains__(key)

    def items(self):
        self.reads.update(super().keys())
        return super().items()

    def values(self):
        self.reads.update(super().keys())
        return super().values()

    def __iter__(self):
        self.reads.update(super().keys())
        return super().__iter__()


def _sb(b: Optional[StateBinding]) -> str:
    return f"{b.subject}@{b.version_value}" if b is not None else "none"
