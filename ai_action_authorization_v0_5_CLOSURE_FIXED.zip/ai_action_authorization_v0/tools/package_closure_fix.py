"""Package all deliverables, excluding only generated interpreter caches."""
import hashlib, json, pathlib, zipfile, argparse
ROOT=pathlib.Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',default='/codex/browser/projectless/0001-files-mentioned-by-the-user-uploaded-file-pointe/output')
OUT=pathlib.Path(parser.parse_args().output_dir)
OUT.mkdir(parents=True,exist_ok=True)
artifact=OUT/'ai_action_authorization_v0_5_CLOSURE_FIXED.zip'
paths=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name!='MANIFEST.sha256')
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in paths)
(ROOT/'MANIFEST.sha256').write_text(manifest)
paths.append(ROOT/'MANIFEST.sha256')
with zipfile.ZipFile(artifact,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(paths): z.write(p,'ai_action_authorization_v0/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(artifact) as z:
    assert z.testzip() is None
    for line in manifest.splitlines():
        digest,rel=line.split('  ',1)
        assert hashlib.sha256(z.read('ai_action_authorization_v0/'+rel)).hexdigest()==digest
    assert len(z.namelist())==len(paths)
print(json.dumps({'artifact':str(artifact),'bytes':artifact.stat().st_size,'files':len(paths),'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'zip_crc_and_manifest':'passed'},indent=2))
