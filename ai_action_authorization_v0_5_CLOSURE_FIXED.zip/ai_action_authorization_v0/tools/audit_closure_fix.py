"""Measure against the exact supplied archive; preserve old-file integrity evidence."""
import ast, dataclasses, hashlib, json, pathlib, zipfile
from aaap.objects import StateBinding
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE=ROOT/'historical'/'ai_action_authorization_v0_5_CLOSURE_FIX_BASE.zip'
def metric(source):
    tree=ast.parse(source)
    return {'physical_lines':len(source.splitlines()),'ast_if':sum(isinstance(n,ast.If) for n in ast.walk(tree)),
            'classes':[n.name for n in tree.body if isinstance(n,ast.ClassDef)],
            'functions':{n.name:{'physical_lines':n.end_lineno-n.lineno+1,'if':sum(isinstance(x,ast.If) for x in ast.walk(n)), 'loops':sum(isinstance(x,(ast.For,ast.While)) for x in ast.walk(n))} for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name in ('_state_binding','guarantees','validate_dependencies','context_scope','project_binding','handoff_binding','validate_consistency')}}
with zipfile.ZipFile(BASE) as z:
    prefix='ai_action_authorization_v0/'
    files=[n[len(prefix):] for n in z.namelist() if n.startswith(prefix+'src/aaap/') and n.endswith('.py')]
    before={f:metric(z.read(prefix+f).decode()) for f in files}
    after={f:metric((ROOT/f).read_text()) for f in files}
    integrity=[]
    for n in z.namelist():
        if n.startswith(prefix+'tests/') or n.startswith(prefix+'tools/') or n.startswith(prefix+'review_logs/') or n.startswith(prefix+'review_baseline_documents/') or n[len(prefix):] in ('CLOSURE_REVIEW.md','ADVERSARIAL_RESULTS.md'):
            if n.endswith('/'): continue
            path=ROOT/n[len(prefix):]; raw=z.read(n); actual=path.read_bytes()
            integrity.append({'path':n[len(prefix):],'sha256':hashlib.sha256(raw).hexdigest(),'unchanged':raw==actual})
    report={'baseline':before,'fixed':after,'generic_core_lines_baseline':sum(v['physical_lines'] for v in before.values()),'generic_core_lines_fixed':sum(v['physical_lines'] for v in after.values()),'modules_added':sorted(set(p.name for p in (ROOT/'src/aaap').glob('*.py'))-{pathlib.Path(f).name for f in files}), 'StateBinding_fields':[f.name for f in dataclasses.fields(StateBinding)],'preserved_files':integrity}
report['generic_core_LOC_delta']=report['generic_core_lines_fixed']-report['generic_core_lines_baseline']
assert all(f['unchanged'] for f in integrity)
assert not report['modules_added']
(ROOT/'closure_fix_logs'/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('baseline','fixed','preserved_files')},indent=2))
