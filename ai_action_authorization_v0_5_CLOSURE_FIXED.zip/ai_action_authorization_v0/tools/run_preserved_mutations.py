"""Run preserved mutation definitions in disposable copies against a passing relevant suite.
Avoid claiming kills from unrelated incompatible V0.5 assertions or GC discovery ordering.
Original mutation tools are preserved unchanged. Obsolete anchors are reported, not hidden.
"""
import ast, json, os, pathlib, shutil, subprocess, sys, tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
LOG=ROOT/'closure_fix_logs'

def definitions(file):
    tree=ast.parse(file.read_text()); nodes=[]
    for n in tree.body:
        if isinstance(n,(ast.Import,ast.ImportFrom,ast.Assign)):
            nodes.append(n)
            if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='M' for t in n.targets): break
    scope={'__file__':str(file),'__name__':'preserved_definitions'}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(file),'exec'),scope)
    return scope['M']

if __name__=='__main__':
    rows=[]; env=dict(os.environ,PYTHONPATH='src:.',PYTHONDONTWRITEBYTECODE='1')
    for filename,module in [('mutate_v03.py','tests.test_v03_protocol_boundary'),('mutate_v04.py','tests.test_v04_composite_execution'),('mutate_closure.py','tests.test_closure_adversarial')]:
        for number,(name,file,old,new,*selected) in enumerate(definitions(ROOT/'tools'/filename),1):
            tests=selected or ([module,'tests.test_v04_composite_execution'] if filename=='mutate_v03.py' else [module])
            if name=="partial outcome retried (in doubt)":
                tests.append("tests.test_closure_fix.ResultsTransition.test_partial_is_settled_without_lookup")
            rebased=False
            if filename=='mutate_closure.py':
                if name=='dependency coverage':
                    old='sorted(covers) != sorted(d["dependency_id"] for d in offered.dependencies if d.get("required", True))'; new='False'; tests=['tests.test_closure_fix.AdditionalControls.test_optional_required_context_coverage']; rebased=True
                if name=='execution lineage':
                    tests=['tests.test_closure_fix.Handoffs.test_port']; rebased=True
                if name=='consistency upgrade':
                    old='if not required <= observed:'; new='if False:'; tests=['tests.test_closure_fix.Guarantees.test_both_needs_both']; rebased=True
            baseline=subprocess.run([sys.executable,'-m','unittest',*tests,'-v'],cwd=ROOT,env=env,capture_output=True,text=True)
            row={'tool':filename,'mutation':name,'tests':tests,'baseline_exit':baseline.returncode,'rebased_to_repaired_path':rebased}
            text=(ROOT/file).read_text()
            if text.count(old)!=1:
                row['result']='obsolete_or_ambiguous_anchor'; row['anchor_count']=text.count(old)
            elif baseline.returncode:
                row['result']='baseline_not_passing_no_kill_claim'
            else:
                with tempfile.TemporaryDirectory(prefix='preserved-mutant-') as tmp:
                    target=pathlib.Path(tmp)/'implementation'; shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('__pycache__','closure_fix_logs','review_logs','historical'))
                    (target/file).write_text(text.replace(old,new))
                    r=subprocess.run([sys.executable,'-m','unittest',*tests,'-v'],cwd=target,env=env,capture_output=True,text=True)
                    row['mutant_exit']=r.returncode; row['result']='detected' if r.returncode else 'survived'
                    (LOG/(filename+f'.{number:02}.txt')).write_text('BASELINE\n'+baseline.stderr+'\nMUTANT\n'+r.stderr)
            rows.append(row); print(json.dumps(row),flush=True)
    (LOG/'preserved_mutations.json').write_text(json.dumps(rows,indent=2)+'\n')
