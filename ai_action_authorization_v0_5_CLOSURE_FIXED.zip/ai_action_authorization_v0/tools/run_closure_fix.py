"""Reproducible commands with raw logs and exit statuses; no test filtering by outcome."""
import json, os, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
LOG=ROOT/'closure_fix_logs'; LOG.mkdir(exist_ok=True)
env=dict(os.environ,PYTHONPATH='src:.',PYTHONDONTWRITEBYTECODE='1')
modules=['tests.'+p.stem for p in sorted((ROOT/'tests').glob('test_*.py')) if p.stem not in ('test_closure_adversarial','test_closure_fix')]
runs=[('baseline',[sys.executable,'-m','unittest',*modules,'-v']),('adversarial',[sys.executable,'-m','unittest','tests.test_closure_adversarial','-v']),('closure_fix',[sys.executable,'-m','unittest','tests.test_closure_fix','-v']),('full_suite',[sys.executable,'-m','unittest','discover','-v']),('mutations_fix',[sys.executable,'tools/mutate_closure_fix.py']),('preserved_mutations',[sys.executable,'tools/run_preserved_mutations.py']),('legacy_gc',[sys.executable,'-m','unittest','discover','-v','-k','FINDING_V02_A']),('legacy_through_v04',[sys.executable,'-m','unittest',*[m for m in modules if m!='tests.test_v05_multi_state_binding'],'-v']),('audit',[sys.executable,'tools/audit_closure_fix.py'])]
rows=[]
for name,cmd in runs:
    with (LOG/(name+'.txt')).open('w') as f:
        r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    row={'name':name,'command':cmd,'environment':{'PYTHONPATH':'src:.','PYTHONDONTWRITEBYTECODE':'1'},'exit':r.returncode}
    rows.append(row); print(json.dumps(row),flush=True)
(LOG/'commands.json').write_text(json.dumps({'python':sys.version,'runs':rows},indent=2)+'\n')
