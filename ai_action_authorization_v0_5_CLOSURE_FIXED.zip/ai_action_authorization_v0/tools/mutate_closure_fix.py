"""Each mutant runs only its relevant previously passing boundary security test.
Disposable copies; exact replacement counts and baseline successes mandatory.
"""
import json, os, pathlib, shutil, subprocess, sys, tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
M=[
('requiredness','src/aaap/verifier.py','if required and not item.get("required", True):','if False:','Requirements.test_downgrade'),
('post-U1 B2 identity validation','src/aaap/objects.py','if d.get(k, True if k == \'required\' else None) != old.get(k, True if k == \'required\' else None):','if False:','Handoffs.test_subject'),
('atomic implies snapshot','src/aaap/verifier.py','if not required <= observed:', 'if not required <= (observed | ({"SNAPSHOT_CONSISTENT"} if "ATOMIC_PRECONDITION" in observed else set())):','Guarantees.test_atomic_not_snapshot'),
('dependency scope','src/aaap/objects.py',"'dependencies': sorted([dict(d) for d in binding.dependencies if d.get('required', True)],\n                               key=lambda d: d['dependency_id'])", "'dependencies': []",'Contexts.test_dependency_scope'),
('intent grant execution lineage','src/aaap/objects.py',"'intent': intent_digest(intent, contract),\n        'authorization': delegation.digest(), 'execution': intent.execution_id,", "'intent': None,\n        'authorization': None, 'execution': None,",'Contexts.test_lineage'),
('bare cross-provider boolean','src/aaap/verifier.py','if strong:', 'if strong and isinstance(offered.consistency_context, dict) and offered.consistency_context.get("cross_issuer_scope_proven") is True:\n                    return offered, None\n                if strong:','Contexts.test_bare_boolean'),
('duplicate dependency ID','src/aaap/objects.py',"if d['dependency_id'] in ids:",'if False:','Malformed.test_duplicate'),
('unknown critical extension','src/aaap/verifier.py','if cc.get("critical", {}) != {}:', 'if False:','Contexts.test_critical'),
('post-U1 authoritative token validation','tests/test_closure_fix.py',"if d['binding_value'] != self.st.get(d['subject_ref']): raise PreconditionFailed('authoritative disagreement')\n            self.validations.append((op.unit,d['dependency_id'],d['binding_value']))\n        self.calls.append(op.unit)\n        if op.unit=='U1':", "if op.unit != 'U2' and d['binding_value'] != self.st.get(d['subject_ref']): raise PreconditionFailed('authoritative disagreement')\n            self.validations.append((op.unit,d['dependency_id'],d['binding_value']))\n        self.calls.append(op.unit)\n        if op.unit=='U1':",'Handoffs.test_attacks'),
]
if __name__=='__main__':
    results=[]
    for name,file,old,new,case in M:
        test='tests.test_closure_fix.'+case
        env=dict(os.environ,PYTHONPATH='src:.',PYTHONDONTWRITEBYTECODE='1')
        baseline=subprocess.run([sys.executable,'-m','unittest',test,'-v'],cwd=ROOT,env=env,capture_output=True,text=True)
        assert baseline.returncode==0,(name,baseline.stderr)
        with tempfile.TemporaryDirectory(prefix='closure-fix-mutant-') as tmp:
            target=pathlib.Path(tmp)/'implementation'
            shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('__pycache__','closure_fix_logs','review_logs','historical'))
            p=target/file; s=p.read_text(); assert s.count(old)==1,(name,s.count(old)); p.write_text(s.replace(old,new))
            r=subprocess.run([sys.executable,'-m','unittest',test,'-v'],cwd=target,env=env,capture_output=True,text=True)
            killed=r.returncode!=0 and 'FAIL:' in r.stderr and 'ERROR:' not in r.stderr
            row={'mutation':name,'test':test,'baseline_exit':baseline.returncode,'mutant_exit':r.returncode,'killed_by_security_assertion':killed}
            results.append(row); print(json.dumps(row)); print(r.stderr)
    print(json.dumps({'detected':sum(r['killed_by_security_assertion'] for r in results),'total':len(results)}))
    sys.exit(0 if all(r['killed_by_security_assertion'] for r in results) else 1)
