# Architecture (V0 + V0.1 + V0.2 + V0.3 + V0.4)

This is not a redesign. It describes how the brief's architecture was implemented and which concrete choices filled the gaps the brief left open.

## Core invariant

```
EXECUTION ⊆ INTENT ⊆ DELEGATION ⊆ CAPABILITY CONTRACT
```

Each link is enforced as follows. If any link cannot be established, the result is DENY before execution, or a non-VERIFIED receipt after it.

| Link | Enforced by |
|---|---|
| DELEGATION ⊆ CONTRACT | The delegation grant pins `contract_id + capability + contract_digest` (step 6). `required_authority` must be granted (step 7). |
| INTENT ⊆ DELEGATION | Principal and agent must match (steps 2–3). The delegation must be valid and unrevoked (step 5). Intent arguments must pass every bound constraint (step 9). |
| INTENT ⊆ CONTRACT | Arguments must match the contract `inputs` exactly: no extras, correct types, `minimum` respected (step 8). |
| EXECUTION ⊆ INTENT | Pre-execution: every field of the adapter's planned provider request must be the image of an intent argument under `maps_to`, with an identical value (step 10). Pre-execution invariants also run on the plan. Post-execution: the executed request equals the plan, observed effects ⊆ declared effects, read-back state equals the plan, and post invariants hold (steps 14–15). |

## Components

```
 AI agent ──ActionIntent──▶ ActionGateway ──resolve/plan──▶ ProviderAdapter ──▶ provider
                                │  ▲                              ▲
                     authorize  ▼  │ AuthorizationDecision        │ execute / read_back / lookup
                         AuthorizationVerifier ◀── ConstraintEvaluatorRegistry
                                │
                ContractRegistry · DelegationStore · ExecutionLedger   (authoritative stores)
```

- **AuthorizationVerifier** (`verifier.py`) is the only producer of `AuthorizationDecision` and `ActionReceipt`. It never receives a contract or delegation object from the agent. It reads both from the authoritative stores by id.
- **ActionGateway** (`gateway.py`) is generic orchestration. It re-authorizes at execution time, so an earlier ALLOW or confirmation is never a bearer token. It also enforces single-use `execution_id` and never calls a provider's `execute` twice for the same id.
- **ProviderAdapter** (`adapter.py`) holds all domain code. It has five methods: `resolve`, `plan`, `execute`, `read_back` and `lookup`.
- **ConstraintEvaluatorRegistry** (`evaluators.py`) maps evaluator ids to pure functions.

## The five objects

All five live in `objects.py`.

| Object | Notes |
|---|---|
| CapabilityContract | The brief's fields plus `reversible`. Unknown top-level fields are kept in `extensions`: they are covered by the digest but never interpreted. |
| Delegation | `allowed_capabilities` entries pin a contract digest. Revocation state lives in the store, not in the object. The agent only ever holds deep copies. |
| ActionIntent | Exactly the brief's fields. `delegation_id` is passed alongside the intent (see RESULTS §7). |
| AuthorizationDecision | ALLOW / REQUIRE_CONFIRMATION / DENY, with `reasons[{code, detail}]` and `warnings`. Binds `intent_digest`, `contract_digest` and `delegation_digest`. |
| ActionReceipt | Binds intent, execution_id, decision, provider result, observed effects, and verification status (VERIFIED / UNVERIFIED / VIOLATION) with its reasons. |

There is also one supporting record, `Confirmation`: the principal's approval of one exact decision (its intent, contract and delegation digests).

## Contract schema (V0)

```jsonc
{
  "inputs": { "<arg>": {"type": "string|integer|datetime", "required": true,
                        "security_relevant": true, "maps_to": "<provider request field>", "minimum": 1} },
  "effects": ["..."],
  "confirmation_policy": {"mode": "always|never"},          // anything else => malformed => DENY
  "constraints": [{"id", "evaluator", "target"|"targets", "security_critical", "params" | "params_from": "delegation"}],
  "invariants":  [{"id", "evaluator", "phase": "pre|post|both", "security_critical", "params"}],
  "verification": {"read_back": "required"}                  // anything else => malformed => DENY
}
```

### Constraint parameters

- `params_from: "delegation"`: the delegation supplies the parameters under the same `id`. Examples are the user's 500 000 VND limit, allowed rooms and working hours. If such a constraint is security-critical and the delegation has no binding for it, the result is `constraint_unbound` (DENY).
- Constraints that exist only in the delegation are always treated as security-critical.

### Reference syntax

Evaluators read values only through these references, so they never need to know the domain:

- `arg:<name>`: an intent argument
- `fact:<path>`: provider state from `resolve`
- `plan:<path>`: the planned provider request
- `post:<path>`: provider state from `read_back`

## Evaluators

Registered core evaluators:

| Evaluator | What it does |
|---|---|
| `core.allowed_values` | Value must be in a list. |
| `core.resource_allowlist` | String must be in an allowlist. |
| `core.max_numeric` | Integer must be ≤ max. |
| `core.time_window` | Local-time window and weekdays. Optionally ordered and same-day. |
| `core.preserve_fields` | Pre: the plan does not touch the fields. Post: before == after. |
| `core.execution_at_most_once` | Pre: the id has not been used. Post: exactly one provider attempt. |
| `core.numeric_delta` | Post: `after − before == sign × ref`. |

Unknown evaluator handling:

- Security-critical (constraint or invariant): DENY, with `unsupported_security_constraint` or `unsupported_security_invariant`.
- Non-critical: skipped, with a warning.

Evaluator errors and unresolvable references fail closed.

## Verifier flow

### Pre-execution (`authorize`)

0. Check the intent's shape.
1. Contract: it exists, is structurally valid, its issuer is trusted for that `contract_id`, and its capability matches the intent.
2–4. The delegation exists and is well formed. The principal matches, and the agent matches.
5. The delegation is not revoked and is within its validity window. This is evaluated at the time of every call.
6. The capability is granted **and pinned to the current contract digest**. Otherwise the result is `contract_changed_reauthorization_required`.
7. Authority.
8. Arguments. Then the `execution_id` must be unused (`execution_id_already_used`), and the evidence (facts and plan) must be available.
9. Constraints.
10. Pre-execution invariants, plus plan ⊆ intent.
11. Confirmation:
    - With `mode=always` and no confirmation, the result is REQUIRE_CONFIRMATION.
    - A supplied confirmation must match the principal, intent_id, intent digest, contract digest, delegation id and delegation digest.
12. The decision.

### Post-execution (`verify_execution`)

13. Execution identity, and the intent digest is unchanged.
14. Status, observed effects ⊆ declared effects, and executed request == plan ⊆ intent.
15. Read-back postconditions (plan fields) and post invariants.
16. The receipt.

**VERIFIED** requires a successful execution, a read-back, and no failed or unobservable checks. A successful execution alone never yields VERIFIED.

## Confirmation binding and canonicalization

The intent digest is a SHA-256 over canonical JSON (`canonical.py`) of:

- `intent_id`, `agent`, `principal`, `contract_id`, `capability`, `execution_id`
- every argument the contract does not explicitly mark `security_relevant: false`

V0 limitations:

- Floats are rejected.
- Strings are compared byte-for-byte: no Unicode normalization and no datetime normalization. `14:00+07:00` and `07:00Z` produce different digests. This fails closed, but it can produce false VIOLATIONs (finding F5).
- Lists and tuples serialize identically.
- Nested dicts inside frozen dataclasses are still mutable in Python. Integrity comes from digest re-checks, not from the type system.
- The contract digest covers the entire contract, including `description`, so a purely cosmetic edit also forces reauthorization.

## Execution identity and idempotency

`ExecutionLedger` makes `execution_id` single-use across **all** domains served by one gateway.

| State | Behaviour on a repeat request |
|---|---|
| Same id, same intent, COMPLETED or FAILED | Replay the stored receipt. No provider call. |
| Same id, same intent, IN_DOUBT (timeout) | Call the read-only `adapter.lookup`. If the provider can say what happened, verify and settle. Otherwise stay IN_DOUBT / UNVERIFIED. **`execute` is never re-sent.** |
| Same id, different intent | DENY `execution_id_already_used`. |

Adapters also pass `execution_id` as the provider's idempotency key: Matrix `txnId`, the FakePay idempotency key, and the calendar idempotency key. This is defence in depth for when the ledger is lost (finding F3).

## Trusted base

**V0:** the trusted base was the verifier, the gateway, the stores, the registered evaluators **and every provider adapter**. Facts, plan, reported request and read-back all came from the adapter (finding F6).

**V0.1:** the adapter is still trusted to *read* honestly. Facts, plan and the offered state binding come from it before execution. Its *claims about what it did*, however, can no longer verify anything. The trusted base for `VERIFIED` is:

- the verifier, gateway, stores and evaluators;
- the **registered evidence sources**;
- the deployer's provenance classification;
- the provider's own records and compare-and-swap.

See RESULTS.md §11.

---

# V0.1 — evidence trust (F6) and state binding (F7)

Nothing below changes the V0 flow above. V0.1 adds checks to it.

## New records (`objects.py`)

| Record | Fields | Role |
|---|---|---|
| `StateBinding` | `subject, version_kind, version_value` | Opaque precondition. The core only tests it for equality. |
| `AuthorizationGrant` | `grant_id, intent_id, intent_digest, contract_id, contract_version, contract_digest, delegation_id, delegation_digest, confirmation_digest, plan_digest, state_binding, execution_id` | "This exact execution is authorized under these conditions." Issued only with ALLOW (`decision.grant`). Content-addressed id. Recorded in `GrantStore`. |
| `ExecutionReport` | = `adapter.ExecutionResult` | A **claim** by the execution path: status, provider_ref, request, claimed effects. |
| `ExecutionEvidence` | `evidence_id, execution_id, intent_id, source_identity, provenance, observed_subject, observed_state, observed_effects, applied_precondition` | An observation. Binding = (execution_id, intent_id, observed_subject). `applied_precondition` is the binding the provider says it enforced: `None` means unattested, `{}` means the write was unconditional. |

## PDP / PEP split

```
 agent ─intent─▶ Gateway (PEP) ──resolve/plan/state_binding──▶ Adapter ──▶ provider
                    │   ▲                                         │ execute_conditional(If-Match)
          authorize │   │ decision (+ grant on ALLOW)             ▼
                    ▼   │                                       provider CAS: write iff version current
              Verifier (PDP) ◀── evidence ── EvidenceSource(s) ──▶ provider records (by execution_id)
                    │                      ▲ registered with a provenance class by the deployer
                    └── receipt            └ adapter read-back = SELF_REPORTED (automatic)
```

## Pre-execution additions (`authorize`)

- **0b.** A presented grant must exist unaltered in `GrantStore`. Otherwise: `grant_not_issued_or_altered`.
- **8b. State binding.** A binding is *required* if `verification.state_binding.subject` is declared, or if any contract or delegation constraint or invariant mentions `fact:`.
  - Required but not declared → DENY `state_dependent_authorization_without_declared_binding`.
  - The adapter must offer a `StateBinding` whose subject equals the declared reference. Otherwise: `state_binding_unavailable` or `state_binding_subject_mismatch`.
  - With a presented grant, the fresh binding must equal the grant's. Otherwise: `state_changed_reauthorization_required`.
- **12.** On ALLOW, a grant is built. With a presented grant, every bound field must be reproduced by this fresh authorization. Otherwise: `grant_mismatch:<field>`.

A grant **never skips** steps 1–11. Revocation, expiry, contract change and confirmation are always re-checked. It can only add conditions.

## Execution (`gateway.execute(intent, delegation_id, confirmation=None, grant=None)`)

1. Ledger replay is unchanged (same id + same intent → stored receipt, never re-executed).
2. Full re-authorization, with the presented grant if any.
3. If the grant carries a binding, the gateway calls `adapter.execute_conditional(intent, plan, grant.state_binding)`. The provider must check and write atomically.
   - `PreconditionFailed` → status `PRECONDITION_FAILED`, ledger `FAILED`. The execution_id is spent, so a new authorization is required.
   - An adapter without `execute_conditional` fails closed.
4. Evidence:
   - The adapter's `read_back` is wrapped as `SELF_REPORTED`.
   - Every registered `EvidenceSource.observe(intent, grant)` runs for every non-UNKNOWN outcome, including reported failures.
   - Sources never receive the adapter's report.

## Post-execution (`verify_execution(intent, decision, facts, plan, report, evidence)`)

- **Report checks (V0 steps 13–14)** are kept. They can only add violations.
- **Per evidence item:**
  1. It must be an `ExecutionEvidence`.
  2. Its source must be registered for the contract, and its claimed provenance must equal the registered one.
  3. Its `execution_id` and `intent_id` must match. Otherwise it is **rejected**, which blocks VERIFIED.
  4. Authoritative = registered provenance ≠ `SELF_REPORTED` **and** ∈ `verification.evidence_provenance` (default `PROVIDER_AUTHORITY`, `INDEPENDENT_READBACK`).
  5. Reported failure + authoritative evidence → VIOLATION `effect_observed_despite_reported_failure`.
  6. Subject ≠ `verification.subject` → VIOLATION. An undeclared subject → cannot verify.
  7. Observed effects ⊆ declared effects. Plan postconditions and post invariants run on `observed_state`.
  8. If the grant has a binding (authoritative items only): the applied precondition must equal it. Missing → UNVERIFIED; `{}` or different → VIOLATION.
- **VERIFIED** requires a SUCCESS report, no violations, nothing unverified, and **at least one accepted authoritative item** that passed every check.
- **Asymmetry rule:** self-reported evidence and the report can incriminate, never exonerate.

## Contract additions (all under `verification`, all optional, malformed → DENY)

```jsonc
"verification": {
  "read_back": "required",
  "subject": "plan:room_id",                          // what evidence must be about
  "evidence_provenance": ["PROVIDER_AUTHORITY"],      // SELF_REPORTED is rejected as malformed
  "state_binding": {"subject": "plan:event_id"}       // whose version the authorization depends on
}
```

## Patterns imitated (not imported)

| Pattern | How it appears here |
|---|---|
| HTTP ETag / If-Match | `StateBinding` + `execute_conditional`; provider 412 → `PRECONDITION_FAILED` |
| AP2-style mandate → action → receipt | Grant binds the concrete action; evidence and receipt bind back to execution_id, intent_id and the grant's precondition |
| OPA PEP/PDP | Verifier decides; gateway enforces; the agent only proposes |
| SPIFFE lesson | Source identity and provenance (who observed) are kept separate from the claimed business effect (what happened) |

---

# V0.2 — execution-scoped authority (V01-A) and state-dependency declaration (V01-B)

Nothing above changes. V0.2 adds a second execution path, `gateway.execute_confined()`. The V0.1 `execute()` path is kept for compatibility and reported `NOT_CONFINED`.

## Strengthened invariant

```
EXECUTION AUTHORITY ⊆ AUTHORIZATION GRANT ⊆ ACTION INTENT ⊆ USER DELEGATION ⊆ CAPABILITY CONTRACT
+ NO AUTHORITY BYPASS (a confined executor cannot reach a broader credential/path)
```

| Link | Enforced by |
|---|---|
| EXECUTION AUTHORITY ⊆ GRANT | `ExecutionAuthority.attenuate`: every credential field must equal the grant's (lifetime: inside it). One credential per grant. |
| effect ⊆ EXECUTION AUTHORITY | Enforcement boundary (`ExecutionPort.invoke`): holder, window, grant standing, capability, execution_id, resource, exact request, uses, state binding. All checked before the effector runs. |
| NO BYPASS | `assess()`: deployer declaration plus object-graph reachability of the effector's authority handles. Not confined → refused by default. |

## Path

```
 agent/AI ─intent─▶ Gateway ─authorize─▶ Verifier ──ALLOW + AuthorizationGrant
                       │
                       ├─ assess_confinement(executor) ──NOT_CONFINED──▶ DENY executor_not_confined
                       ├─ authority.attenuate_exact(grant, executor.identity) ──▶ ExecutionCredential (1 use)
                       ▼
            ConfinedExecutor (UNTRUSTED)  ── port.invoke(credential, ProviderOperation) ──▶  Enforcement boundary
              holds: intent copy, plan copy,                                                  │ checks 1–11
              credential, port — nothing else                                                 ▼ (only if all pass)
                                                                         ProviderEffector (TCB, Mode B: holds broad token)
                                                                                              │ precondition = credential.state_binding
                                                                                              ▼
                                                                                          Provider (CAS)
   receipt ◀── Verifier ◀── report = boundary's own record  +  V0.1 evidence sources  +  blocked attempts
```

## New records (`authority.py`)

| Record | Role |
|---|---|
| `ProviderOperation(contract_id, capability, execution_id, request)` | A concrete effect the executor asks for. `request` uses the plan vocabulary (`maps_to`). |
| `ExecutionCredential` | Attenuated authority for one execution; see RESULTS.md §7. Content-addressed; integrity comes from the credential store. |
| `Attenuation(credential, problems)` | Result of a mint: either a credential or every widening found. |
| `Invocation(allowed, reason, detail, result)` | Result of one boundary call. |
| `Confinement(status, mode, reasons, tcb, assumptions)` | `CONFINED` / `NOT_CONFINED`; Mode A/B/C; who is trusted; what the label assumes. |
| `ProviderEffector` | Interface for provider-specific, trusted effect code. It decides nothing. It must honour the state binding atomically or refuse. |

`AuthorizationGrant` (objects.py) gains `principal, agent, capability, resource, request, not_after, max_uses, state_dependencies, dependency_gaps`. All have defaults and all are covered by the digest.

## Isolation modes

- **Mode A — provider-enforced.** The provider checks the scoped credential. Represented, not exercised: no fixture provider can do this.
- **Mode B — trusted gateway.** The effector inside the gateway holds the broad credential; the executor does not. Used by all three fixtures.
- **Mode C — executor retains authority.** Always `NOT_CONFINED`; this includes the legacy path.

## V01-B: state dependencies

- `EvalOutcome.dependencies` lists the `fact:` references an evaluator's decision relied on.
- The verifier aggregates them, and `_ReadTracker` records the facts each evaluator actually read during authorization.
- A dependency is covered only by a state binding.
- Gaps are recorded in the grant: `unbound` or `undeclared_read`.
- Gaps raise warnings on the decision (V0.1 compatibility) and make attenuation impossible (the confined path fails closed).
- Post-only reads are not observable before execution (finding V02-C).
- Coarse whole-resource binding remains `SAFE_BUT_OVERINVALIDATING` (V01-C, deferred).

## Patterns imitated (not imported)

| Pattern | How it appears here |
|---|---|
| OAuth RAR | The credential's capability, resource and request are structured, fine-grained authorization data |
| OAuth Token Exchange | Grant → downstream credential for one executor |
| Macaroons / Biscuit | Attenuation can only narrow; widening is refused (exact-match caveats) |
| DPoP | Holder binding is a separate check from authorization semantics (modeled identity only) |
| AP2 | Grant → credential → operation → receipt, all bound by grant_id and execution_id |
| PEP / PDP | Verifier decides; the boundary enforces; the effector only acts |
| ETag / If-Match / CAS | `credential.state_binding` is applied by the effector as the provider precondition |

---

# V0.3 — protocol boundary (V9 failure wall)

Nothing above changes. V0.3 adds **no object and no binding category**. It tightens what the existing ones accept and adds fields inside them. Ownership is in [PROTOCOL_BOUNDARY.md](PROTOCOL_BOUNDARY.md); the attack map is in [V9_FAILURE_WALL.md](V9_FAILURE_WALL.md).

## Contract identity

```
artifact digest   = digest(entire contract)                         -> Confirmation (what the human saw)
security identity = binding_digest()                                -> Delegation pin, Grant, Credential, grant_standing
                  = artifact digest                                  if no security_identity declared   (V0 behaviour)
                  = digest(contract − declared non-security fields)   otherwise
                    declared fields must be in {description, human_metadata}; the declaration itself is inside the identity
evaluators see    = decision_view(): no declared non-security field, no noncritical extension
```

## Contract address and namespace

| Address | Resolves | Trust |
|---|---|---|
| `issuer::local_id` (`qualified_contract_id`) | That issuer's current contract | Only if that issuer is trusted for that local id |
| `local_id` (V0–V0.2) | The latest contract published under the local id | Ambiguous (DENY `contract_identity_ambiguous`) if more than one issuer is trusted for it |

The verifier uses the **address** everywhere V0.2 used `contract.contract_id`: delegation match, grant, evidence-source registry, boundary and effector registry. `publish(contract, authenticated_issuer=…)` takes the infrastructure's authenticated publisher and refuses a mismatch.

## Closed-world schema (W7)

| Structure | Interpreted keys | Anything else |
|---|---|---|
| top level | V0 fields + `security_identity`, `human_metadata`, `noncritical_extensions` | DENY `unsupported_critical_extension`, unless listed in `noncritical_extensions` (which may not name a protocol field or contain an `arg:`/`fact:`/`plan:`/`post:` reference) |
| `inputs.*` | `type, required, security_relevant, maps_to, minimum` | `malformed_contract` |
| `verification` | `read_back, subject, evidence_provenance, state_binding, required_effects` | `malformed_contract` |
| `verification.state_binding` | `subject` | `malformed_contract` |
| `security_identity` | `exclude` (⊆ {description, human_metadata}) | `malformed_contract` |
| constraint / invariant spec | `id, evaluator, target, targets, security_critical, params, params_from, phase` + the evaluator's declared `spec_keys` | critical → `unsupported_constraint_modifier`; noncritical → skipped with warning |

## Composite actions (N2)

```
grant.effects = contract.effects ──attenuate──▶ credential.effects (equal, else widens_or_changes_effects)
executor ── ONE ProviderOperation ──▶ boundary (V0.2 checks) ──▶ trusted effector
                                                              ├─ call 1 (conditional on credential.state_binding)
                                                              ├─ call 2 only if its effect ∈ credential.effects,
                                                              │          chained by the provider to call 1
                                                              └─ stops part-way → ExecutionResult(PARTIAL, observed_effects=done)
verifier: PARTIAL ⇒ UNVERIFIED execution_partial_no_rollback; evidence of a done effect is consistent,
          evidence of a not-done effect ⇒ VIOLATION; the core never compensates
VERIFIED additionally requires: every verification.required_effects entry confirmed by an accepted
          authoritative evidence item; a source may attest only effects in its registered scope
```

The executor cannot split: a second operation, another capability, another request or another execution id is blocked (T2, T3). The split is provider-specific and lives in the effector (TCB).

## Guarantee level (W10)

`ExecutionAuthority.declare_infrastructure(executor_isolated_from_gateway=, holder_proof_of_possession=, provider_enforces_scoped_credential=)`

| Situation | Status / mode / guarantee |
|---|---|
| Mode C (retained authority, reachable handle) | `NOT_CONFINED` / `MODE_C` / `NONE_ADVISORY_ONLY` |
| A required fact declared **False** (Mode B: isolation; Mode A: provider enforcement) | `NOT_CONFINED` / `MODE_C`, or Mode A → reported `MODE_B` |
| Required facts undeclared | `CONFINED` / `CONFINED_ASSUMING_UNDECLARED_INFRASTRUCTURE`, with the undeclared assumptions listed |
| Required facts declared True | `CONFINED` / `CONFINED_BY_DECLARED_INFRASTRUCTURE` |

`execute_confined` re-assesses after the executor ran. If confinement was lost during execution, the outcome reports `NOT_CONFINED … downgraded_during_execution`.


# V0.4 — composite execution binding

Full design and trust discussion: [COMPOSITE_EXECUTION.md](COMPOSITE_EXECUTION.md). This section lists where each piece sits in the code. No class, module, object or binding category was added (G25).

## Strengthened invariant

```
EXECUTION ⊆ INTENT ⊆ DELEGATION ⊆ CAPABILITY CONTRACT
   for a unit contract, per unit:
   unit request ⊆ authorized request;  unit effects ⊆ contract effects (partitioned);
   unit permit ⊆ credential units ⊆ grant units == unit_table(contract, authorized plan)
```

## Path

```
contract.execution_units ──unit_table()──▶ grant.execution_units            (verifier.authorize, step 10b)
grant ──attenuate(units=?)──▶ credential.units                              (authority; re-derives the table
                                                                             from the contract first)
executor ──ProviderOperation(unit=U)──▶ boundary._check_unit                 (unit ∈ credential, exact request,
                                                                             single use, predecessors SUCCESS)
boundary._perform_unit ──precondition──▶ effector.perform_unit(cred, op, pre)
     precondition = grant StateBinding | predecessor's established_state | none   (computed here, never by the executor)
boundary._composite_result ──▶ SUCCESS / PARTIAL / UNKNOWN / PRECONDITION_FAILED / FAILED  (vs the GRANT's required units)
gateway._finish(unit_records) ──▶ verifier._verify_units ──▶ ActionReceipt.units
```

## Code map

| Concern | Where |
|---|---|
| Unit schema (closed world) | `verifier.UNIT_KEYS`, `UNIT_MANDATORY_KEYS`, `UNIT_EVIDENCE_KEYS`, `_unit_state_problem`, `_units_problem` (called from `_contract_problem`) |
| State vocabulary | `objects.UNIT_STATE_AUTHORIZATION / UNIT_STATE_UNBOUND / UNIT_STATE_FROM` |
| Binding generation | `verifier.unit_table(contract, plan)`; `AuthorizationVerifier._execution_units` |
| Independent re-derivation | `AuthorizationVerifier.execution_binding_problem(grant)`, used by `ExecutionAuthority.attenuate` |
| Grant / credential content | `AuthorizationGrant.execution_units` (digest + `GRANT_BOUND_FIELDS`); `ExecutionCredential.units` (digest) |
| Per-unit permit | `ExecutionAuthority._check_unit`, `_perform_unit`, `_composite_result`, `unit_records` |
| Effector interface | `ProviderEffector.perform_unit(credential, operation, precondition)`; `ExecutionResult.established_state` |
| Honest default executor | `ConfinedExecutor.execute_confined`: one operation per unit, declared order, skip a unit whose predecessor failed |
| Evidence | `ExecutionEvidence.covers_units / grant_id / unit_states`; `EvidenceSourceRegistry.register(..., units=)`, `units_of` |
| Verification | `AuthorizationVerifier._verify_units`, `_judge_unit_evidence`; `_postconditions(invariant_ids=)` |
| Deployer policy | `AuthorizationVerifier.require_declared_composition` (default False) |

## Verifier flow additions

- **Pre-execution.**
  - Contract validation includes the unit schema (malformed → DENY).
  - If the deployer policy is on and the contract has more than one effect but no units → `composite_structure_undeclared`.
  - After `plan ⊆ intent` (step 10): `unit_table` → `grant.execution_units`. A missing request field → `unit_request_unavailable`.
- **Post-execution, step 15 for unit contracts.** It replaces the V0.3 evidence step for those contracts only; unit-less contracts take the unchanged V0.3 path.
  1. Compare `grant.execution_units` with `unit_table(contract, plan)` → `execution_binding_mismatch`.
  2. No boundary unit records (legacy path) → `unit_execution_unobserved`.
  3. Judge each evidence item in this order:
     - source registration and provenance;
     - execution and intent ids;
     - effects outside the contract (VIOLATION);
     - SELF_REPORTED (non-authoritative);
     - unit claim, known units, unit scope, effect scope, joint declaration, grant lineage, effects ⊆ covered units, joint subject;
     - per-unit provenance requirement;
     - authoritative evidence of a unit the boundary did not complete (VIOLATION);
     - subject, request-projection postconditions, per-unit post invariants, applied state.
  4. Per unit: verified iff executed (boundary SUCCESS), accepted evidence exists, no problems, and for `from_unit` the predecessor's attested established state equals the precondition the boundary used.
  5. Required unit not executed / not verified → UNVERIFIED. An optional unit that executed but is not verified → UNVERIFIED.

## Patterns imitated (not imported)

- **AP2-style separately bound stages.** Each unit has its own permit and its own evidence, all tied to one grant lineage (`grant_id` recorded by the provider).
- **Permit-before-commit.** A per-unit check sits immediately before each unit's effect, with the precondition supplied by the PEP, not the caller.
- **Receipt composition.** `ActionReceipt.units` composes per-unit outcomes. The composite status is derived, never reported by the executor.
- **Deterministic PDP/PEP.** No inference: exact equality on opaque ids and canonical JSON.

## V0.5 delta — multi-subject mutable state

V0.5 keeps the five lifecycle objects and four binding categories. `StateBinding` now has a multi-dependency representation. The initial required/observed consistency ordering was unsound and is superseded by the closure-fix independent-property model below. Provider adapters/trusted validators own token semantics; registered authenticated sources establish strong context properties for exact security scopes. No transaction/workflow coordinator was introduced. See `MULTI_STATE_BINDING.md`.

---
## Independent closure review addendum

The historical MULTI_STATE_BINDING_SURVIVED verdict is superseded by **DO_NOT_CLOSE_V0**. See CLOSURE_REVIEW.md and ADVERSARIAL_RESULTS.md. Required dependency flags can be weakened, multi-state established bindings cannot traverse `from_unit`, and atomic checking does not universally imply read-snapshot consistency. The old claims above are preserved as baseline history, not endorsed by this review. No production architecture changes were made.


## V0.5 closure-fix architecture (supersedes initial V0.5 claims)

The independent review's D1–D8 defects are repaired within StateBinding, ExecutionBinding and the existing evidence-source registry. The five lifecycle objects and four binding categories are unchanged. Detailed normative representation and envelope limits are in MULTI_STATE_BINDING.md; executable results and historical assertion incompatibilities are in CLOSURE_FIX_RESULTS.md.

Contract-required dependencies cannot be weakened by offered requiredness. Optional dependencies can be narrowed safely and then participate in full required coverage. Dependency IDs are unique within a binding, issuer/subject conflicts are checked, and malformed or unknown critical state semantics fail closed.

Individual validation, snapshot consistency and atomic precondition enforcement are independent explicit properties. No universal total order exists and no property is inferred from another. Receipts carry property lists. A strong context binds full dependency identities and tokens, contract security identity, security intent, delegation/authorization lineage, execution, exact request and claimed properties. Context reuse requires an authenticated list of exact permitted security-use digests. Deployer-registered authoritative sources authenticate context assertions within explicit property and issuer capabilities; a provider Boolean is insufficient.

Multi-state units declare dependency projections and established-update scopes. The predecessor reports exact established dependencies and execution/unit lineage; the successor merges these with unchanged authorized dependencies. Trusted conditional effectors validate the resulting precondition before execution. Independent unit evidence verifies the same projected continuity. Earlier legitimate updates survive another handoff. Success, receipt verification and rollback remain distinct; no rollback or transaction manager is added.

The current implementation denies strong multi-state projected composite contexts. It does not fabricate a new coherent context after an effect or assume an aggregate context remains valid after projection. This limitation is explicit, tested and requires suitable authoritative infrastructure in future specification work. Ordinary individual A+B → B2 → B2+C composition executes and verifies successfully with independent evidence. No extra protocol primitive was demonstrated necessary.

Security is conditional on complete honest declarations and trusted authorities. Mode B still needs actual process isolation. The runtime-sensitive process-global GC finding remains historical and is rerun separately; a passing GC demonstration does not establish isolation, and an order-sensitive failure does not establish a newly repaired boundary.
