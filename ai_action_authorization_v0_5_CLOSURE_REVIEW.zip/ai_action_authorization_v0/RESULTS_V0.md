# RESULTS — AI Action Authorization Protocol V0 (historical; superseded by RESULTS.md for V0.1)

Run: `python3 -m unittest discover -t . -s tests -v` on Python 3.9.6, macOS.
Result: **57 tests, 57 passed, 0 failed.**

Tests named `test_FINDING_*` *pass* because they assert that a weakness **exists**. They reproduce the findings in §6 and are not evidence that anything works.

---

## 1. Test results

### Required by the brief

| ID | Scenario | Expected | Observed | Result |
|---|---|---|---|---|
| M1 | Matrix send to allowed room | ALLOW | ALLOW → executed → VERIFIED | PASS |
| M2 | Matrix send to unauthorized room (one the user *can* post to) | DENY | DENY `constraint_violated` (allowed_rooms); 0 messages | PASS |
| M3 | Same execution_id twice | ≤ 1 message | Replayed receipt, 1 provider call, 1 message | PASS |
| M4 | Success but read-back unavailable | SUCCESS + UNVERIFIED, never VERIFIED | SUCCESS, UNVERIFIED `read_back_unavailable` | PASS |
| C1 | Reschedule inside working hours | ALLOW + VERIFIED | ALLOW, VERIFIED; title/attendees/location intact | PASS |
| C2 | Move to 18:00–19:00 | DENY | DENY `constraint_violated` (working_hours); 0 provider calls | PASS |
| C3 (pre) | Plan removes an attendee the intent never mentioned | DENY pre-execution | DENY `invariant_violated` (preserve_attendees) + `execution_plan_exceeds_intent` | PASS |
| C3 (post) | Provider silently drops an attendee | VIOLATION | ALLOW → SUCCESS → VIOLATION (preserve_attendees) | PASS |
| C4 | Calendar contract V1 → V2 adds `attendees_notified` | DENY / REAUTHORIZE | ALLOW under V1, then DENY `contract_changed_reauthorization_required` | PASS |
| P1 | 400 000 VND to An | REQUIRE_CONFIRMATION → ALLOW → VERIFIED | As expected; Lam 600 000, An 400 000 | PASS |
| P2 | 700 000 VND | DENY | DENY `constraint_violated` (max_amount); 0 provider calls | PASS |
| P3 | Confirm 400 000, execute 450 000 (still under limit) | DENY | DENY `confirmation_mismatch: intent_digest` | PASS |
| P4 | Confirm An, execute to Binh | DENY | DENY `confirmation_mismatch`; Binh 0 | PASS |
| P5 | Timeout after commit, retry same execution_id | Balance changes once | 1st: UNKNOWN/UNVERIFIED; retry: lookup → VERIFIED; 1 provider call; Lam 600 000 | PASS |
| P6 | Unknown critical constraint `quantum_financial_boundary` | DENY `unsupported_security_constraint` | Exactly that | PASS |
| X1 | Authorize/confirm, revoke, execute (all 3 domains) | DENY `delegation_revoked` | Exactly that in Matrix, Calendar and FakePay; 0 effects | PASS |
| K1 | Old delegation used against FakePay V2 (`credit_line_may_be_used`) | DENY / REAUTHORIZE | DENY `contract_changed_reauthorization_required` (detail names v1 vs v2 digests) | PASS |

### Additional tests

| ID | Scenario | Result |
|---|---|---|
| M3b | Same execution_id, different content | DENY `execution_id_already_used` — PASS |
| M3c | Fresh gateway (empty ledger) retries: Matrix txnId dedupes | 1 message — PASS |
| C2b | Window checked in local offset (10:00Z = 17:00 ICT) | DENY — PASS |
| C2c | Event in non-delegated calendar | DENY (allowed_calendar) — PASS |
| P1b | Execute without confirmation | REQUIRE_CONFIRMATION, no call — PASS |
| P3b | Mutate `intent.arguments` in place after confirming | DENY — PASS |
| P4b | Reuse a confirmation with a new execution_id | DENY — PASS |
| P5c | Provider ignores idempotency keys; core ledger alone | Debited once — PASS |
| P7 | Provider reports undeclared effect `credit_line_may_be_used` under V1 | VIOLATION `undeclared_effect_observed` — PASS |
| K2 | V1 confirmation executed after V2 published | DENY, 0 calls — PASS |
| K3 | New delegation pinned to V2 | Works (reauthorization path) — PASS |
| K4 | Content changed, version string *not* bumped | DENY (digest) — PASS |
| K5 | `credit_line` appears nowhere in core | PASS |
| X1b | Agent tries to revoke | PermissionError — PASS |
| G1 / G1b | Static scan: no domain identifiers or literal provider/capability comparisons in any core file | PASS |
| G2 | Agent edits its copy of the delegation (raises limit) | No effect, DENY — PASS |
| G3 | Confirmation in the agent's own name | DENY — PASS |
| G4 / G5 | Another principal's delegation / another agent | DENY — PASS |
| G6 / G7 / G8 | Float or bool amount / extra argument `use_credit_line` / negative amount | DENY — PASS |
| G9 | Delegation expires between authorization and execution | DENY `delegation_expired` — PASS |
| G10 / G11 | Untrusted issuer / unknown confirmation mode | DENY — PASS |
| G12 / G13 / G14 | Evaluator throws / unknown evaluator in delegation / critical constraint unbound | DENY — PASS |
| G15 | execution_id used in Matrix, reused in FakePay | DENY — PASS |
| G16 | Provider rejects the transfer | FAILED → UNVERIFIED — PASS |
| G17 | Matrix timeout; no lookup API exists | Stays UNVERIFIED, never re-sent — PASS |
| F1–F7 | `test_FINDING_*` | Each weakness reproduced (§6) |

---

## 2. Core files changed when each provider was added

Providers were added in sequence. After each step, SHA-256 hashes of `src/aaap/*.py` were compared with the previous snapshot.

| Step | Core files changed |
|---|---|
| 1. Core + Matrix | All core files created. |
| 2. + Calendar | **None.** All 8 core file hashes identical. |
| 3. + FakePay | **`evaluators.py` only.** One new generic evaluator, `core.numeric_delta` (22 lines + 1 registration line). It was needed to verify the payer's balance moved by exactly `amount`. No earlier evaluator expressed "field changed by exactly X". |
| 3. + FakePay | `verifier.py`, `gateway.py`, `objects.py`, `stores.py`, `canonical.py`, `adapter.py` all **unchanged**. |

**AuthorizationVerifier changes across all three providers: zero.** The evaluator vocabulary grew by one generic entry.

**Caveat (designer bias):** the core was written by someone who had already read all three fixture specifications. "Zero verifier changes" is therefore weaker evidence than it would be if a fourth, unseen domain had been added blind. The step-3 evaluator addition shows the vocabulary is not closed.

---

## 3. All domain-specific logic

All of it lives outside `src/`.

| Domain | Where | What it decides |
|---|---|---|
| Matrix | `fixtures/matrix/contract_v1.json` | Inputs; `content→body` mapping; `message_created`; `messaging.send`; no confirmation; allowed_rooms constraint; at-most-once invariant |
| | `fixtures/matrix/adapter.py` | Principal→access-token mapping; request = `{room_id, body}`; `txnId = execution_id`; read-back via `GET /event`; **no lookup** (the C-S API has none) |
| | `fixtures/matrix/homeserver.py` | Fake homeserver: txnId idempotency, membership, read-back may be unavailable |
| Calendar | `fixtures/calendar/contract_v1.json`, `contract_v2.json` | `new_start→start` and `new_end→end`; `allowed_calendar` targets `fact:calendar_id`; `working_hours` via `core.time_window`; three `preserve_fields` invariants |
| | `fixtures/calendar/adapter.py` | Facts = current event; PATCH semantics; `FullReplaceCalendarAdapter` (deliberately buggy, for C3) |
| | `fixtures/calendar/provider.py` | Fake calendar, idempotency key, attendee-dropping misbehaviour switch |
| FakePay | `fixtures/fakepay/contract_v1.json` (+ v2, quantum, no_minimum) | Amount is an integer ≥ 1; max_amount and currency bound from the delegation; confirmation `always`; `payer_debited_exactly` via `core.numeric_delta` |
| | `fixtures/fakepay/adapter.py` | Payer = owner of the principal's API token; facts = payer balance; idempotency key = execution_id; read-back = transaction + payer balance |
| | `fixtures/fakepay/provider.py` | In-memory ledger, idempotency, timeout-after-commit, extra-effects switch |
| All | `fixtures/*/world.py` | Wiring and the delegation parameters (500 000 VND; `["!team:example.org"]`; 09:00–17:00 +07:00 Mon–Fri; calendar `work`) |

---

## 4. All domain-specific evaluators

**None were needed.** Every fixture rule was expressed with `core.*` evaluators configured by contract and delegation data:

| Rule | Evaluator |
|---|---|
| allowed_rooms | `core.resource_allowlist` on `arg:room_id` |
| allowed_calendar | `core.resource_allowlist` on `fact:calendar_id` |
| working_hours | `core.time_window` |
| preserve_title / attendees / location | `core.preserve_fields` |
| max amount | `core.max_numeric` |
| currency | `core.allowed_values` |
| execution_at_most_once | `core.execution_at_most_once` |
| payer debit | `core.numeric_delta` |

`fakepay.quantum_financial_boundary` is intentionally **not registered** (P6).

---

## 5. Places where the verifier needed semantic knowledge

**In code: none.** The verifier never branches on a provider, capability, effect name or argument name. G1/G1b check this mechanically, and K5 checks that `credit_line` appears nowhere in the core.

The semantic judgement did not disappear, though. It moved into contract fields the verifier trusts blindly:

- **`security_critical`** decides whether an unknown evaluator causes DENY or is skipped (F4).
- **`security_relevant: false`** removes an argument from confirmation binding. No fixture uses it; if misused, a confirmed intent could change that argument after confirmation.
- **`maps_to`** defines what "execution ⊆ intent" means. A wrong mapping makes the check meaningless.
- **`minimum`** is the only thing preventing a negative transfer (F2).
- **`confirmation_policy.mode`** is the only confirmation trigger. `risk: HIGH` and `reversible: false` are *not* interpreted. A contract with `risk: HIGH, mode: never` would not require confirmation.

The verifier is domain-neutral, but its safety equals the correctness of each provider's contract.

---

## 6. Fail-open behaviour

Each item below is reproduced by a test and has not been patched.

| # | Behaviour | Test | Why it occurs | Classification |
|---|---|---|---|---|
| F1 | An agent can forge a `Confirmation` in the principal's name; the transfer executes | `test_FINDING_F1_…` | Confirmation is an unsigned in-process record. The brief excludes crypto signatures. | **Core architecture deficiency** (V0 scope, not an implementation bug). Confirmation binding protects against *mutation after* confirmation (P3/P4), not against *fabrication of* confirmation. |
| F2 | With a contract lacking `minimum`, amount −100 passes the verifier, is confirmed, and pulls money from the recipient (VERIFIED) | `test_FINDING_F2_…` | `core.max_numeric` bounds only from above; the provider fake does not reject negatives. | **Contract deficiency**, and an evaluator deficiency because `max_numeric` has no implicit floor. The shipped v1 contract has `minimum: 1`, so G8 denies it. |
| F3 | Gateway restart (empty ledger) + provider that ignores idempotency + timeout ⇒ same execution_id debits twice | `test_FINDING_F3_…` | The ledger is in-memory; the brief excludes production infrastructure. With an honest provider (P5, M3c) the provider idempotency key prevents it. | **Implementation limitation** (V0 scope). The architecture *needs* a durable ledger or a provider idempotency key; it cannot get exactly-once from either alone. |
| F4 | An unknown **non-critical** constraint is skipped (ALLOW/REQUIRE_CONFIRMATION with a warning); a failing non-critical constraint is also only a warning | `test_FINDING_F4_…` | Deliberate policy: only `security_critical` must fail closed. | **Contract deficiency risk.** Fail-open by design, controlled entirely by the contract author's labels. |
| F6 | A lying adapter sends to the denied room but reports the planned room; the receipt says VERIFIED | `test_FINDING_F6_…` | Facts, plan, executed request and read-back all come from the same adapter. The verifier has no independent evidence channel. | **Core architecture deficiency.** Every adapter is part of the trusted base. "Zero verifier changes per provider" does *not* mean "zero new trusted code per provider". |
| F7 | `allowed_calendar` is checked on facts read before execution. If the event moves to a non-delegated calendar before the patch, the patch applies and the receipt is VERIFIED | `test_FINDING_F7_…` | Constraints over provider state are evaluated pre-execution only. There is no generic way to make the provider write conditional on the checked facts (no If-Match / compare-and-set). No post invariant re-checks `calendar_id`. | **Core architecture deficiency** (TOCTOU). Adding `preserve_fields: [calendar_id]` to the contract would turn it into a post-hoc VIOLATION (detect) but cannot prevent it. |

Fail-safe but noteworthy:

- **F5:** a provider that normalizes datetimes to UTC produces a *false* VIOLATION (`test_FINDING_F5_…`). This comes from the V0 canonicalization limitation.
- **Matrix timeout (G17):** an in-doubt Matrix send stays UNVERIFIED forever because the Matrix client-server API offers no read-only txnId lookup.

---

## 7. Ambiguities discovered

1. **No confirmation object among the five.** Confirmation binding is required, but no object carries the user's approval. A sixth supporting record, `Confirmation`, was added; it is not a protocol object.
2. **ActionIntent has no `delegation_id`.** The verifier cannot tell which delegation the agent acts under. It is passed alongside the intent and bound in the decision and confirmation.
3. **`reversible` is required by FakePay but not listed in the contract fields.** It was added as a field. The verifier does not use it (nor `risk`), see §5.
4. **C3 "DENY pre-execution if detectable"** presumes something to inspect before execution. The intent contains only times, so there is nothing to detect in it. Detection required introducing the adapter's planned provider request ("plan") plus `maps_to`. The brief does not define a plan, but without one, EXECUTION ⊆ INTENT is checkable only after the effect.
5. **`execution_at_most_once` as a contract invariant is redundant.** The gateway enforces single-use execution_id for every contract, including Calendar, which does not declare it. Declaring it only adds a post-check of attempt count. The brief treats it as per-domain; in practice it had to be a core property.
6. **Exactly-once vs at-most-once.** "Balance must change exactly once" is achievable only when the provider exposes a lookup (FakePay) or the original call succeeded. For Matrix after a timeout, the core can guarantee *at most* once but cannot learn whether it happened.
7. **"VERIFIED" for payments covers the payer side only.** The payer's API cannot observe the recipient's balance, so An's +400 000 is asserted in the test against the fake, not verified by the protocol. The payer-balance delta check is also confounded by concurrent transactions.
8. **Contract digest covers `description`.** Any wording change forces reauthorization. This is fail-safe but over-strict; the brief does not say which fields are security-relevant.
9. **`core.allowed_values` vs `core.resource_allowlist`** are semantically near-identical; the brief lists both.
10. **Constraints relying on provider state** (`allowed_calendar` reads the event's calendar) make the verifier depend on adapter-reported facts. The brief's flow does not mention provider state as an input to authorization (→ F6, F7).
11. **Confirmation has no expiry.** The brief is silent. Revocation, expiry and contract change still invalidate it (X1, G9, K2).

---

## 8. Final verdict

**SURVIVED** — for the hypothesis as posed.

### Evidence against each success criterion

| Criterion | Evidence |
|---|---|
| All tests pass | 57/57 |
| Zero provider-specific branches in AuthorizationVerifier | Static scan G1/G1b; manual review |
| Adding FakePay required zero AuthorizationVerifier changes | Hashes; only `evaluators.py` gained a generic evaluator |
| Domain differences stay in contracts, adapters and evaluators | §3, §4 — no domain-specific evaluator was needed |
| Deterministic authorization | No probabilistic step |
| Confirmation binding | P3, P3b, P4, P4b |
| Revocation | X1 in all three domains |
| Duplicate execution prevented | M3, P5, P5c, G15 |
| Unknown critical constraint fails closed | P6, G13 |
| Changed contract invalidates stale authorization without the core understanding the change | C4, K1, K2, K4, K5 |

### What this verdict does not claim

The experiment also exposed two **core architecture deficiencies** that fall outside the hypothesis but matter for any follow-up:

- **F6:** the adapter is in the trusted base, and the verifier has no evidence independent of it.
- **F7:** authorization over provider state is time-of-check / time-of-use. There is no generic precondition binding to the provider write.

There is also an unsigned-confirmation gap (**F1**) that the brief scoped out, and a non-durable ledger (**F3**).

The core survived domain variation. It did not, and as designed cannot, protect against a dishonest adapter or a provider state race.
