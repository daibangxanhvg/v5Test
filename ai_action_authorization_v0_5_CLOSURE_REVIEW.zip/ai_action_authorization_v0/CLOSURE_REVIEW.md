# Independent V0.5 adversarial closure review

## 1. Recommendation

**DO_NOT_CLOSE_V0**

The decision follows executable counterexamples and a missing composition path, not a test count. This review uses only the supplied V0.5 ZIP. No V0.6 work, production fix, new primitive, provider branch, or protocol redesign was introduced. Original source and tests are byte-for-byte preserved. Original verdicts remain historical claims, superseded by this review.

## 2. Defects found

| ID | Finding | Implementation location | Classification |
|---|---|---|---|
| D1 | A contract-required dependency can be offered with `required=False`; authorization accepts it and the shipped adapter skips its conditional check. A race changing B then produces an effect. | verifier.py:774–784; fixtures/multistate/adapter.py:20–23 | Core requirement propagation defect, with an end-to-end shipped-provider exploit. A separately defensive provider could block it. |
| D2 | Valid multi-state state handoff cannot execute U2: `_as_binding` only decodes exactly three legacy keys. No unit dependency subset or merge with unchanged C is implemented. | authority.py:490–500, 642–648; verifier.py:151–159 | Core composition/representation defect; fail-closed availability rather than demonstrated stale U2 execution. |
| D3 | A snapshot requirement is satisfied by atomic observed consistency without any snapshot context. | verifier.py:792–802 | False strong guarantee under legitimate atomic predicate infrastructure; see consistency assessment. |
| D4 | Context coverage binds only dependency IDs; issuer, subject, intent, grant and execution context fields are ignored. A reused context authorizes and executes changed actions/subjects/issuers. | verifier.py:794–802 | Missing generic scope/lineage enforcement. If the adapter fully validates this externally it becomes conditional on that additional trust; core does not implement the claimed protection. |
| D5 | Independent P1/P2 snapshots become accepted as a common snapshot merely by setting `cross_issuer_scope_proven=True`. No authenticated coordinator registration/capability check exists for state consistency. | verifier.py:801–802 | Unverified stronger consistency assertion; trusted adapter compromise can exploit it, and core claims require undocumented external validation. |
| D6 | Same dependency ID on different subjects is accepted because uniqueness is checked on `(id, subject)`. IDs then ambiguously name context coverage. | verifier.py:777, 785 | Identity/coverage ambiguity; no direct authority expansion shown in isolation. |
| D7 | `covers=None` throws TypeError out of authorization, rather than DENY. | verifier.py:799 | Input-validation/availability defect. |
| D8 | Unknown critical context extension is silently accepted. Conflicting tokens for one subject are accepted by core but rejected by the shipped provider. | verifier.py:777–802 | Undefined extension/conflict semantics; conflicting-subject execution remains blocked by provider. |

All locations are relative to `src/aaap` unless otherwise specified. No defect was repaired to produce green output.

## 3. Attacks attempted

Actual authorization/gateway/boundary execution tests cover required dependency omission, stale state, subject substitution, identity duplication, representation change, contract consistency-only evolution, invalid observed guarantee, critical context extension, malformed context, context replay, local snapshots, mixed local levels, atomic-to-snapshot upgrades, provider omission and validator lies.

Composite fixtures use A=r17@v1, B=r42@v7, C=r99@v3; U1 validates A+B and changes B to v8; U2 must validate B@v8+C. They submit real operations through the execution authority and gateway. Variants include stale/substituted/wrong-issuer/wrong-lineage/missing/false-produced/upgraded tokens, partial U1, reordering, injected U3, wrong operation execution ID, and required-unit removal.

## 4. Attacks blocked

Missing required dependency, wrong declared subject, exact duplicate identity, empty binding, missing observed consistency, old grant after representation/contract change, sequential evidence under an atomic requirement, independent local snapshots without the Boolean claim, mixed aggregate individual evidence, reordered/injected units and wrong operation execution IDs are blocked. Provider checks reject changed required tokens and conflicting same-subject tokens. Existing authoritative evidence scope/lineage tests remain intact and executed in full discovery.

Invalid multi-state handoffs are blocked, but **all are masked by the unsupported decoder**, including the valid positive control. They do not establish selective resilience against their particular attacks. U1 changes persist when U2 cannot execute; no rollback is inferred.

## 5. Attacks that succeeded

D1 performs a protected effect after required B changes without checking B. D3 executes under an unmet read-snapshot requirement using valid atomic predicate checks. D4 reuses a context for changed execution, intent, subject and issuer scopes. D5 turns four dependencies from two independent local snapshots into a strong cross-provider claim with a Boolean. D6/D8 get malformed/ambiguous claims through authorization. D7 crashes authorization.

The context replay fixture deliberately supplies a context carrying an old grant identifier; even the initial use accepts this mismatch. Fresh grants do not repair or validate it. These are counterexamples to core scope checks, not claims that every infrastructure-owned snapshot identifier must be single-use. Safe reusable immutable snapshots are possible, but this protocol does not specify or enforce such reuse semantics.

## 6. Trust-boundary limitations

An honest contract and malicious executor cannot inject U3, reorder U2, change the execution ID, or remove required units from an old grant through the tested port. Mode B still requires actual process isolation; Python reachability assessment is not isolation.

A lying/incomplete contract can omit C: the core accepts the reduced declared dependency set and executes despite hidden C changing. Generic core cannot infer undisclosed effects or resources. This is **provider-contract incompleteness**, not evidence that an ontology or coordinator is required.

A lying authoritative validator/effector can claim atomic consistency and execute without checking state. The core cannot manufacture truth. The test shows consistency metadata propagates, but the self-reported effect remains UNVERIFIED. This is **trusted-component compromise**. There is no state-validator capability declaration registry with which to compare returned consistency strengths; evidence-source provenance registration governs effect verification, not pre-execution state validation. Wrong-subject validator responses can only be tested through the existing adapter interface or established-state reports.

Sequential checks cannot provide execution-time atomicity. Global consistency without common authoritative infrastructure is **unsupported infrastructure** and must not become a strong claim by ordinary aggregation. Boolean flags are not independent evidence.

D1 is distinguishable from a provider inventing truth: the contract is honest and the provider follows the exact binding it receives, yet the core has accepted a weakened required flag.

## 7. Consistency-model assessment

The code implements a total order: INDIVIDUALLY_CHECKED < SNAPSHOT_CONSISTENT < ATOMIC_PRECONDITION. The order is not universally sound.

A snapshot is a coherent read provenance property; an atomic precondition is a property of checking predicates and applying an effect. A snapshot can be stale by execution and need not protect the write. Conversely, atomic predicates can use observations collected at different times. The added end-to-end fixture reads opaque stable `on` predicates across states `(on,off)` and `(off,on)`, which never supply a read snapshot `(on,on)`. Before execution the infrastructure reaches `(on,on)` and checks both predicates atomically. Atomic enforcement is valid, but collection had no common snapshot; core still accepts a snapshot requirement and executes. Opaque binding values are not required by V0.5 to be injective, never-reused revisions.

For immutable, injective version identifiers, atomic equality across all subjects can imply simultaneous validity at commit. That narrower infrastructure contract is not encoded here and still requires specifying which snapshot time is promised. Thus snapshot and atomic properties can be incomparable; neither automatically implies the other in general. Sequential successful checks establish neither. No new consistency representation is designed in this review.

## 8. Complexity assessment

Current generic core: 3,501 physical lines including comments/blanks, nine files, 440 AST `if` nodes. `_state_binding` has 56 physical lines, 16 `if` nodes and two loops. Exact measurements are in review_logs/complexity.txt. A true V0.4 LOC delta is not measurable from the sole supplied V0.5 baseline; no V0.4 source archive is included and historical prose is not an independent diff.

StateBinding has seven declared fields: three legacy fields plus dependencies, required consistency, observed consistency, context. There is one StateBinding class; dependencies/context are untyped dictionaries, not independent production classes. Dependency dictionaries interpret six base keys; context interprets `value`, `covers`, and `cross_issuer_scope_proven` without a closed schema. ExecutionResult's established-state annotation remains a legacy `Dict[str,str]`. Handoff decoding and authorization validation therefore implement different representations.

Test-only abstractions are `setup`, binding transformation helpers, a synthetic HandoffEffector and composite wiring. No production abstraction was added. Stable object count conceals missing projection, conflicting schemas and an evidence-free consistency flag. That is not a healthy-boundary proof.

Generic-core lexical and AST/manual audit found no provider names, token parsing, document/payment/calendar/flight/hotel/inventory semantics, fixture-specific branches, Saga, 2PC, rollback or compensation implementation. Exact lexical matches: verifier.py:120 names `execution_partial_no_rollback`; verifier.py:919 disclaims rollback; authority.py:246 disclaims compensating actions; gateway.py:21 disclaims compensation; stores.py:99/123 uses IN_FLIGHT (ledger status, unrelated to flight domain). Generic core does enforce topological unit order, one-use permits, predecessor state transfer and aggregate outcomes; this is existing execution-boundary coordination, not a distributed transaction manager. No prepare/commit protocol, recovery-driven workflow, rollback or compensation engine exists. `required`, `after`, `effects` and `subject` carry declared protocol semantics, not hidden domain roles.

## 9. Is a new primitive required?

Not proved. The ordinary A+B→B+C case is not supported by the current handoff implementation, but a missing decoder/projection/scope contract does not prove an additional primitive is necessary. The review reports the gap and does not redesign it. Distributed atomicity needs appropriate infrastructure; protocol claims cannot substitute for it.

## 10. Should V0.x end here?

No. Required-state weakening and unsupported consistency implication remain executable counterexamples. Common multi-state composition has no successful positive control. Closure would misstate the available guarantees.

Legacy failure: baseline-only discovery on Python 3.12.14 initially passed all 351 tests. Combined discovery reproduces the old GC escape finding failure (expected extra balance 100000, observed 0). Its executor searches process-global GC objects and can select stale reachable fixture instances; outcomes depend on runtime/test order/collection. No original source or test changed. This is an old runtime/order-sensitive finding, not demonstrated V0.5 regression; actual Mode B isolation remains outside this review. Full suite is not clean.
