# RESULTS — V0.5 Multi-Subject State Binding

## Verdict

**MULTI_STATE_BINDING_SURVIVED**

The verdict is architectural, not pass-count based. The existing `StateBinding` category safely carried a set of opaque state dependencies and distinct consistency guarantees without a sixth lifecycle object, fifth binding category, provider-specific core branch, ontology, LLM inference, or transaction coordinator. Stronger guarantees are accepted only when the trusted validation boundary explicitly supplies them; weaker observed guarantees fail closed when stronger is required.

## Required V0.5 experiment results

All 40 V0.5 tests pass. They cover M1–M10, C1–C10, P1–P5, E1–E6, I1–I4, and B1–B5: stale/missing/new dependencies; substitution and replay; issuer collision; mixed opaque representations; sequential TOCTOU; shared snapshot scope; atomic precondition; unsupported consistency; cross-provider limits; contract evolution; V0.4 unit continuity and partial execution; anti-ontology and anti-coordinator boundaries.

The complete discovery run contains 351 tests. 350 pass and one pre-existing V0.2 *finding test* fails in this Python 3.13.5 runtime: `test_FINDING_V02_A_in_process_isolation_is_modeled_not_enforced`. The untouched V0.4 baseline ZIP produces the same failure in this runtime (its GC/runtime escape no longer reaches the expected object). This is recorded as an environment-sensitive baseline finding, not hidden or rewritten. All V0.5 tests and the other V0–V0.4 regressions pass.

## Guarantee findings

- `INDIVIDUALLY_CHECKED`: all required dependencies validated, but no same-snapshot/atomic claim.
- `SNAPSHOT_CONSISTENT`: accepted only with declared context covering the full required set. Two provider-local snapshots are not promoted to one global snapshot.
- `ATOMIC_PRECONDITION`: accepted only when trusted provider infrastructure explicitly reports that strength. Sequential validation cannot satisfy it.
- Stronger observed guarantees may satisfy weaker requirements, while the binding/receipt preserves required vs observed strength.
- Provider tokens remain opaque. Generic core performs no ETag/revision/MVCC/CAS parsing.
- Missing/unknown required validation fails closed.
- StateBinding does not imply atomic business execution. V0.4 partial execution remains possible.

## Protocol-growth accounting

Compared with the supplied V0.4 implementation baseline:

| Item | V0.5 growth |
|---|---:|
| New top-level lifecycle objects | 0 |
| New binding categories | 0 |
| New core modules | 0 |
| Provider-specific core branches | 0 |
| Transaction/workflow coordinator machinery | 0 |
| Ontology / LLM state inference | 0 |
| New `StateBinding` data fields | 4 (`dependencies`, `required_consistency`, `observed_consistency`, `consistency_context`) |
| New generic evaluator classes | 0 |
| Existing-provider migrations required | 0 (legacy 3-field StateBinding preserved) |
| Generic-core source additions/removals | +87 / -14 lines across `objects.py`, `verifier.py`, `__init__.py` |
| Net generic-core line growth | +73 lines |
| Generic-core function count | 176 → 177 (+1 helper method on StateBinding) |
| Approx. AST branch/control nodes | 726 → 762 (+36, +5.0%) |
| New V0.5 tests | 40 |

Proposed and accepted: structured dependency set inside existing `StateBinding`; explicit required/observed guarantee levels; opaque consistency context with declared coverage. Rejected: `MultiStateBinding` top-level object/category, provider token parsers in core, inferred dependencies, global-snapshot inference, Saga, rollback, compensation, 2PC, distributed transaction/workflow coordination.

## Limits

Passing does **not** prove distributed atomicity, serializability, ACID execution across providers, universal state consistency, or completeness of provider-declared dependencies. `ATOMIC_PRECONDITION` is only as trustworthy as the infrastructure/validator assertion behind it. An incomplete or dishonest contract/provider remains inside the documented trust boundary.

---
## Independent closure review results

**DO_NOT_CLOSE_V0**. On Python 3.12.14, original discovery initially passed 351 tests; expanded discovery runs 370 tests and records 13 failures including subtests and the unchanged runtime/order-sensitive legacy finding. New module: 19 methods and 12 failing assertions/subtests. Five targeted mutants were detected by previously passing tests. Raw logs and exact commands are in ADVERSARIAL_RESULTS.md and review_logs/. Original results above are retained historical records; the full reviewed suite is not clean.
