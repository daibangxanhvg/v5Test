# RESULTS — AI Action Authorization Protocol V0.3 (protocol boundary / V9 failure wall)

> Superseded as the current result by [RESULTS.md](RESULTS.md) (V0.4 composite execution binding). Kept unchanged below as the V0.3 record.

Run: `python3 -m unittest discover -t . -s tests -v` on Python 3.9.6, macOS.
Earlier results are unchanged in [RESULTS_V0.md](RESULTS_V0.md), [RESULTS_V01.md](RESULTS_V01.md) and [RESULTS_V02.md](RESULTS_V02.md).

**Final verdict: `BOUNDARY_PARTIALLY_SURVIVED`** (reasoning in §18).

Short version:

- The five lifecycle objects and four bindings were enough. There are 0 new top-level objects, 0 new binding categories, 0 provider-specific core branches, and 0 existing-provider files changed.
- Preventing unauthorized effects never failed open.
- The boundary is not fully closed:
  - The composite newcomer needed about a dozen new *fields* inside the existing bindings.
  - Verifying a composite depends on new provider and deployer declarations. If those are left out, partial evidence verifies the whole action (V03-A, V03-B).
  - Two places show credible pressure toward a sub-effect binding (V03-C, V03-H).
- V9 also found two real deficiencies in V0.2, both fixed generically:
  - V0.2 silently ignored unknown security-critical contract structure (V03-F).
  - V0.2's contract registry let two issuers with the same local id collide (V03-G).

---

## 1. Total tests

**225 tests run. 225 passed. 0 failed. 0 errors.**

| Group | Tests | Files changed since V0.2 |
|---|---|---|
| V0 (`test_matrix`, `test_calendar`, `test_fakepay`, `test_cross_domain`, `test_knowledge_evolution`, `test_adversarial`) | 57 | none |
| V0.1 (`test_v01_f6_f7.py`) | 51 | none |
| V0.2 (`test_v02_execution_authority.py`) | 44 | none |
| **V0.3 (`test_v03_protocol_boundary.py`)** | **73** | new |

Several V0.3 tests run many subtests. P2 runs 15 contract mutations, P3b runs 10 field names, P9 runs 9 unknown semantics, P6a runs 36 file hashes, and P6c runs 5 domains on one gateway.

`test_FINDING_V03_*` tests (5) pass because they assert that a weakness **exists**. They reproduce weaknesses; they are not evidence that something works.

### Mutation check (run once, not part of the suite; script in §19)

29 V0.3 protections were disabled one at a time. 28 of the 29 mutations make the suite fail:

| Disabled protection | Failing tests |
|---|---|
| security identity: `binding_digest` = artifact digest | 3 |
| security identity: ineligible exclusions honoured | 10 |
| grant standing compares artifact digest | 26 |
| confirmation binds security identity instead of artifact | 1 |
| evaluators see the full contract (no decision view) | 2 |
| unknown top-level extension ignored | 3 |
| unknown verification key ignored | 1 |
| unknown input key ignored | 1 |
| unknown state_binding key ignored | 1 |
| unknown constraint modifier ignored | 3 |
| `security_identity` may exclude anything | 10 |
| noncritical list may name protocol fields | 2 |
| noncritical extension may hold references | 1 |
| `required_effects` ⊆ `effects` unchecked | 1 |
| ambiguous bare address resolved anyway | 1 |
| qualified address resolves to bare current | 3 |
| publisher authentication ignored | 1 |
| trust for qualified address ignores issuer | 1 |
| evidence effect scope ignored | 1 |
| required-effects coverage skipped | 4 |
| PARTIAL treated as success | 1 |
| PARTIAL contradicted by evidence accepted | 1 |
| grant does not carry effects | 28 |
| attenuation allows effect widening | 1 |
| infrastructure declared absent ignored | 1 |
| Mode A claim not downgraded | 1 |
| guarantee always reported "declared" | 2 |
| no post-execution confinement re-assessment | 1 |
| PARTIAL settled as IN_DOUBT instead of FAILED | **0** (equivalent mutant) |

The surviving mutant is equivalent: an IN_DOUBT replay only calls the read-only `lookup`, which never re-executes. So both settlements behave the same for every observable test.

Two mutants survived the first run: "confirmation binds security identity" and "trust ignores issuer". I added tests for them (P1c first assertions, P5f). The table above was produced after that.

---

## 2. Regression results (V0 / V0.1 / V0.2)

**152 / 152 pass.**

The files are byte-identical to the V0.2 zip. `tests/v02_baseline_manifest.json` stores the SHA-256 of all 36 V0.2 provider and test files, and P6a re-checks them on every run.

Behaviour notes:

- `test_FINDING_V01_A/B/C/D/E/F`, `test_FINDING_V02_A/B/C/D`, and `F1`–`F5` still reproduce their weaknesses. V0.3 closes none of them and does not claim to.
- `G1`, `G18`, `G20` and `G21` (V0–V0.2 domain-word and branch guards) still pass on the larger core.
- `B1` still reports `CONFINED`. `Confinement.guarantee` is now `CONFINED_ASSUMING_UNDECLARED_INFRASTRUCTURE`, which states what V0.2 only listed as assumptions (§15).

---

## 3. V0.3 P / T / E results

"0 effects" means provider call counters stayed at zero.

### P — protocol boundary

| ID | Scenario | Observed | Result |
|---|---|---|---|
| **P1** | N1 declares `security_identity.exclude = [description, human_metadata]`. The issuer edits only those fields. | Artifact digest changes; `binding_digest` does not. The outstanding grant executes `VERIFIED`, and a credential minted before the edit is still accepted at the boundary. | PASS |
| P1b | The same kind of edit on FakePay, which declares no separation | `contract_changed_reauthorization_required` (V0 behaviour; separation is never inferred) | PASS |
| P1c | N2 with `description` declared non-security. A confirmation is taken, then the description is edited. | Before the edit, the confirmation gives ALLOW. After it, `confirmation_mismatch: contract_digest`, because a confirmation binds the artifact the human saw. A fresh decision has the same `contract_digest` (authority) and a new `contract_artifact_digest`. | PASS |
| P1d | An evaluator tries to read the excluded `description` and `human_metadata` | It sees `""` and nothing. Content outside the identity cannot influence a decision. | PASS |
| **P2** | 15 security-relevant mutations of N1: effect, authority, invariant, constraint criticality, constraint evaluator, state binding dropped, evidence provenance, required effect dropped, input mapping, input made non-security, risk, reversible, confirmation, version label, `security_identity` itself | Each one: binding digest changes; re-authorization with the stale grant → `contract_changed`; the pre-minted credential → `grant_no_longer_in_force: contract_changed`; 0 effects | PASS (15/15) |
| **P3** | Ambiguous changes: (a) a new unknown top-level field; (b) trying to declare 10 security fields non-security; (c) unknown structure inside `security_identity`; (d) a change to a declared noncritical extension | (a) `unsupported_critical_extension`, and the old credential is blocked. (b) `malformed_contract: … cannot be declared non-security`; the ineligible exclusion has no effect on identity. (c) `malformed_contract`. (d) Reauthorization is required (conservative). | PASS |
| **P4** | N2 V1 is publish-only. V2 is publish + external notification. | The V1 grant, V1 confirmation and V1 credential are all refused against V2 (`contract_changed` with v1/v2 detail; boundary `grant_no_longer_in_force`). 0 publishes, 0 notifications. Re-delegating to V2 yields a grant whose `effects` contain both, and it executes VERIFIED. | PASS |
| P4b | A V2-capable effector receives a V1 credential | `credential.effects = (document_published,)`. The effector publishes and does not notify. Minting a credential with wider effects → `widens_or_changes_effects`. | PASS |
| P4c | An effect is added without a version bump | `contract_changed` | PASS |
| **P5** | Issuers `folio.example` and `otherdocs.example` both publish `docs.rename_document` | (a) Qualified addresses `issuer::id` are distinct, and both coexist. A's world still verifies. (b) A's delegation → B `capability_not_delegated`; a forged pin (B's address, A's digest) → `contract_changed`. (c) The bare local id with two trusted issuers → `contract_identity_ambiguous`. (d) A's evidence source is not registered for B (`no_authoritative_evidence`); A's credential at B's address → `capability_not_authorized`. (f) An authentic but untrusted issuer's qualified address → `untrusted_contract_issuer`. (e) B publishing as A with authenticated issuer B → `PermissionError`. | PASS |
| **P6** | Newcomer locality | (a) 36/36 V0.2 provider and test files are byte-identical. (b) No existing provider mentions folio, pubhub, document, rename_document or publish_and_notify. (c) One gateway serves Matrix, Calendar, FakePay, N1 and N2 at once, and all five are `VERIFIED` + `CONFINED`. | PASS |
| **P7** | N1 wire format: `FD-0042`, nested `attributes.displayName`, integer `if_revision`, `client_token` | The protocol side sees `{"document_ref": "doc-42", "display_name": …}` and an opaque `"17"`. The provider receives `("FD-0042", {"attributes": {"displayName": …}}, 17, "exec-n1-1")`. A stale revision is refused by the provider's CAS (409 mapped to `PRECONDITION_FAILED` in the fixture). Non-canonical refs (`doc-042`, `FD-0042`, `42`, …) are refused by the mapping (`evidence_unavailable`), never guessed. | PASS |
| **P8** | Lookalike contract: same capability, description and inputs; another issuer; one extra effect. Also an identical twin that differs only by issuer. | `capability_not_delegated`; the twin's binding digest differs. An audience served by two PubHub lists → plan refused → DENY, 0 calls. The core has no difflib, lower/casefold or description comparison (scanned). | PASS |
| **P9** | 9 unknown security-critical semantics: top-level field, verification key, state_binding key, input key (`pattern`), modifier on a known evaluator, unknown evaluator, confirmation mode, input type, undeclared required effect. Also an unknown modifier in a delegation constraint. | All DENY with a specific code; 0 effects. **V0.2 returned REQUIRE_CONFIRMATION for the first five of these** (probe in §14). | PASS |
| **P10** | A declared noncritical extension `x-ui` | It is preserved (in `to_dict` and the digest) and invisible to evaluators; execution is VERIFIED. An evaluator that relies on it hits `evaluator_error` (fails closed). Declaring `effects` or `security_identity` noncritical → malformed. A noncritical extension containing `fact:folder` → malformed ("references action/provider state"). A noncritical unknown modifier → skipped with a warning. | PASS |

### T — transitions / composite (N2)

| ID | Scenario | Observed | Result |
|---|---|---|---|
| **T1** | Authorized publish+notify | `VERIFIED`. One allowed boundary operation; the trusted effector makes the 2 provider calls. Both scoped observers are authoritative. | PASS |
| **T2** | Publish-only grant. The executor publishes, then tries the same operation again, a `notify` capability, a request with `notify_list`, and a new `execution_id` | `exhausted`, `capability_not_authorized`, `arguments_not_authorized`, `execution_id_not_authorized`. 0 notify calls; empty outbox; receipt `VIOLATION` ×4 `out_of_scope_attempt_blocked`. | PASS |
| T2b | Composite grant for `team`; the executor submits `audience=public` | `arguments_not_authorized`, 0 calls | PASS |
| T2c | Legacy path: the adapter (holding the token) notifies under the publish-only contract | It **happened** (outbox = 1). Labelled `NOT_CONFINED`; receipt `VIOLATION undeclared_effect_observed`. Detected, not prevented (V01-A class, unchanged). | PASS (as documented) |
| **T3** | A→B→C laundering (private→team→public) | (a) A second step with the same credential is blocked; re-presenting the spent grant → DENY. (b) A reader adapter planning `public` under a `team` intent → `execution_plan_exceeds_intent`. (c) An end-state policy (delegation: team only) blocks both the direct and the stepwise path. (d) A path rule whose evaluator does not exist → `unsupported_security_constraint` for **every** transition (fail closed). (e) The same rule supplied by the provider as an evaluator (`fixtures/pubhub/policy.py`): direct private→public DENY, private→team OK, team→public DENY within 24 h, OK after 25 h; `fact:last_private_at` is carried as a state dependency. | PASS |
| **T4** | Publish succeeds, notify fails (503) | Status `PARTIAL`, `UNVERIFIED`, `execution_partial_no_rollback`, `observed_effects = (document_published,)`. The publish evidence is accepted as consistent. **No unpublish**; the document stays `team`. Replay returns the identical receipt with no new call. | PASS |
| T4b | The document is changed between the two calls | The provider refuses the chained notify → `PARTIAL`; no notification | PASS |
| T4c | The effector claims SUCCESS with both effects, but only published | `SUCCESS` / `UNVERIFIED required_effect_unverified` | PASS |
| T4d | The effector reports PARTIAL, but evidence shows the notification was sent | `VIOLATION effect_observed_despite_reported_failure` | PASS |
| T4e | The effector does not chain notify to the bound publish | The notification record attests an unconditional write → `VIOLATION state_precondition_not_enforced` (detected, not prevented; §11 V03-H) | PASS |
| **T5** | Only the publish observer exists, or the notification record is unavailable | `UNVERIFIED required_effect_unverified: external_notification_sent`. It did happen; it is not proven. | PASS |
| **T6** | (a) Publish evidence relabelled as notify, and as both, from publish-scoped sources. (b) Evidence from another execution; a Folio observation smuggled in for N2. (c) Only the adapter's own translation is available. | (a) Both rejected with `effect_outside_source_scope`. (b) `execution_id_mismatch` and `source_unregistered`; still `required_effect_unverified`. (c) Only `SELF_REPORTED`, so `UNVERIFIED`. | PASS |

### E — evolution

| ID | Scenario | Observed | Result |
|---|---|---|---|
| **E1** | The delegation narrows after a grant (revoke D1, issue D2 = team only) | Stale grant → `delegation_revoked`. The pre-minted credential → `grant_no_longer_in_force: delegation_revoked`. Old grant with D2 → DENY. 0 effects. | PASS |
| E1b | D2 is issued but D1 is **not** revoked | D1 still authorizes (delegations are independent; narrowing requires revocation). Recorded as semantics (§13). | PASS (as documented) |
| **E2** | The delegation widens after a grant (D2 = team+public) | The old credential cannot reach public (`arguments_not_authorized`). The old grant and confirmation with a public intent → DENY. | PASS |
| **E3** | A new security-critical mutable dependency (`fact:locked`) | (a) The V1 grant → `contract_changed`; under V2 the dependency is in the grant, and a lock flip after authorization → `state_changed`. (b) The dependency without a binding → `state_dependent_authorization_without_declared_binding`. (c) A custom evaluator declares the dependency, with no binding → gap `unbound` → `attenuation_refused`, 0 renames. (d) Rebinding an existing evaluator name → `ValueError` (registry is append-only). | PASS |
| **E4** | Mode B → Mode C, and infrastructure downgrade | (a) Retained authority → `NOT_CONFINED`/`MODE_C`/`NONE_ADVISORY_ONLY`, refused by default; with `require_confinement=False` the executor is listed in the TCB. (b) Undeclared → `…ASSUMING…`; declared → `…DECLARED…`; isolation declared absent → `NOT_CONFINED infrastructure_absent:executor_isolated_from_gateway`; unknown fact → `ValueError`. (c) A Mode A claim with provider enforcement declared absent → reported `MODE_B`. (d) Metadata and noncritical extensions claiming "CONFINED / MODE_A" change nothing; an unknown critical `required_confinement` → DENY. (e) The executor obtains the token mid-run → outcome `NOT_CONFINED downgraded_during_execution`. | PASS |
| W9a/b | Stale confirmation across audiences; authority removed from a re-issued delegation | `confirmation_mismatch`; `authority_not_delegated` / `delegation_revoked` | PASS |

Guards:

- **G22** (AST): no newcomer identifier or non-docstring string literal in any core file.
- **G23**: no `==`/`!=`/`in` comparison of issuer, capability, contract_id, identity, subject, version_kind, resource, holder, request, effect(s), address or step against a literal, in any core file.
- **G24**: `objects.py` still defines exactly the V0.2 classes; V0.3 adds none.

---

## 4. W1–W10 status

Details and ownership are in [V9_FAILURE_WALL.md](V9_FAILURE_WALL.md).

| | Failure class | Status |
|---|---|---|
| W1 | Artifact ≠ security identity | **Held**, through explicit separation (P1, P1c, P1d). Ambiguous changes fail closed (P3). |
| W2 | Knowledge evolution | **Held** (P2, P4, P4c, E3). A V0.2 gap was found and fixed: unknown structure was silently ignored (V03-F). |
| W3 | Evidence binding / laundering | **Held when the deployer scopes sources and the contract declares required effects** (T5, T6). Otherwise it is open in *verification* (V03-A, V03-B). |
| W4 | Transition splitting | **Held** (T2, T3). Path rules are provider evaluators or fail closed. |
| W5 | Representation leakage / locality | **Held** (P6, P7, G22). |
| W6 | Semantic ambiguity | **Held** (P8); ambiguity is refused at the newcomer boundary. |
| W7 | Unknown critical extension | **Held after a fix** (P9, P10). V0.2 failed five cases (§14). |
| W8 | Owner / namespace identity | **Held after a fix** (P5). V0.2's registry collided (V03-G). Authentication is infrastructure (V03-D). |
| W9 | Stale binding across evolution | **Held** (E1, E2, E3, W9a, W9b, P2). |
| W10 | Operational reality vs declared guarantee | **Held** (E4). The reference deployment still runs on *assumed* isolation (V02-A), now stated in `guarantee`. |

---

## 5. Exact core changes

Counted with `diff` against the unzipped V0.2: **+379 / −51 lines** in `src/aaap/`.

| File | Change | +/− |
|---|---|---|
| `verifier.py` | Closed-world schema: `INPUT_KEYS`, `VERIFICATION_KEYS`, `STATE_BINDING_KEYS`, `BASE_SPEC_KEYS`, `_extension_problem`, `_mentions_ref`, `required_effects ⊆ effects`. Unknown top-level extension → `unsupported_critical_extension`. The contract address is resolved through the registry (ambiguity → DENY). Authority binds `binding_digest`; the confirmation binds the artifact digest. Evaluators get `decision_view()`. `effects` go into the grant and `GRANT_BOUND_FIELDS`. Constraint modifiers are checked against evaluator-declared `spec_keys`. Post-execution: `EXEC_PARTIAL`, evidence effect scope, required-effects coverage, and evidence provenance looked up by address. 5 new reason codes. | +147 / −22 |
| `objects.py` | `OPTIONAL_CONTRACT_FIELDS`, `NON_SECURITY_ELIGIBLE`, `qualified_contract_id`. `CapabilityContract.non_security_fields / binding_digest / declared_noncritical / unknown_extensions / decision_view`. `EXEC_PARTIAL`. `AuthorizationDecision.contract_artifact_digest`. `Confirmation.from_decision` binds the artifact. `AuthorizationGrant.effects`. | +71 / −2 |
| `authority.py` | `ExecutionCredential.effects` (copied from the grant; widening refused). Infrastructure facts and `declare_infrastructure`. `Confinement.guarantee`. A Mode A claim is downgraded when provider enforcement is declared absent. A required fact declared absent → `NOT_CONFINED`. Assumptions are filtered by what was declared. | +66 / −4 |
| `stores.py` | `ContractRegistry`: per-(local id, issuer) trust, qualified addresses, `ambiguous()`, `publish(…, authenticated_issuer)`, index by both digests. `EvidenceSourceRegistry`: optional effect scope and `scope_of`. | +58 / −12 |
| `gateway.py` | `register_evidence_source(…, effects=)`. PARTIAL settles as FAILED (never retried); an unknown status is IN_DOUBT. Post-execution confinement re-assessment (`downgraded_during_execution`). | +16 / −5 |
| `evaluators.py` | The registry records evaluator-declared `spec_keys`; `core.time_window` declares `ordered`. Docstring: append-only. | +15 / −2 |
| `__init__.py` | Exports | +6 / −4 |
| `adapter.py`, `canonical.py` | **Unchanged** | 0 |

No core change mentions a newcomer (G22). None branches on a provider value (G23).

## 6. Existing-provider changes and why

**None.** No file under `fixtures/matrix`, `fixtures/calendar`, `fixtures/fakepay` or `fixtures/__init__.py` changed, and neither did `tests/harness.py` (P6a, hash-checked).

One option was rejected *because* it would have forced existing providers to change: making every declared effect required by default (§10, R11). FakePay V2 declares `credit_line_may_be_used`, an effect that *may* happen, so it would have had to edit its contract solely because a composite newcomer joined. Keeping `required_effects` opt-in avoids that, at the cost of finding V03-A.

The only other existing file touched: `RESULTS.md` was renamed `RESULTS_V02.md`, with one line added that links forward to this file.

## 7. Newcomer-only files

| File | Role |
|---|---|
| `fixtures/folio/{provider,mapping,adapter,effector,observer,world}.py`, `contract_v1.json`, `__init__.py` | N1: fake Folio store with a different wire format. **`mapping.py` is the only code that knows both vocabularies.** Mode B effector, record observer, qualified-address wiring. |
| `fixtures/pubhub/{provider,mapping,adapter,effector,observer,policy,world}.py`, `contract_v1.json`, `contract_v2.json`, `__init__.py` | N2: fake PubHub (publish + notify as two wire calls with provider-side chaining). Audience↔list mapping that refuses ambiguity. Mode B effector that performs the split and reports PARTIAL. Two effect-scoped observers. Provider-supplied path-policy evaluator. |
| `tests/test_v03_protocol_boundary.py` | 73 tests |
| `tests/v02_baseline_manifest.json` | SHA-256 of the 36 V0.2 provider and test files |

881 lines of newcomer fixture code and data.

## 8. Protocol-growth accounting

Columns: (1) Is an existing object or binding sufficient? (2) Is contract or evaluator data enough? (3) Is it provider adapter only? (4) Does it need a new protocol primitive?

| Requirement | (1) | (2) | (3) | (4) |
|---|---|---|---|---|
| Metadata-only change keeps authority (P1) | Yes: CapabilityContract identity → AuthorityBinding (`binding_digest`) | Yes: `security_identity`, `human_metadata` | No | No |
| Human confirmation covers what was shown (P1c) | Yes: Confirmation + `Decision.contract_artifact_digest` | — | No | No |
| Security change invalidates (P2, P4c) | Yes: digest pinning (V0) | — | No | No |
| Ambiguous change fails closed (P3) | Yes: closed eligible list | — | No | No |
| New effect not covered by old authority (P4) | Yes: digest; plus ExecutionBinding field `grant.effects` / `credential.effects` | Effects are contract data | Effector honours effects | No |
| Same local id, two issuers (P5) | Yes: CapabilityContract identity = (issuer, id); registry addressing | — | No | No; authentication = infrastructure |
| Newcomer locality (P6) | Yes | — | Yes: adapter, effector, observer, mapping | No |
| Different wire / version format (P7) | Yes: opaque StateBinding, `maps_to` vocabulary | — | Yes: `mapping.py` | No |
| Similar name ≠ same action (P8) | Yes: digest identity, no equivalence | — | Ambiguity refused in the adapter | No |
| Unknown critical semantics (P9) | Yes: closed-world schema in the verifier | Evaluators declare `spec_keys` | No | No |
| Noncritical extension (P10) | Yes | Yes: `noncritical_extensions` | No | No |
| Authorized composite (T1) | Yes: ExecutionBinding (one exact operation) | Effects declared | **Yes: effector performs the split** | No (Step rejected, R1) |
| Split cannot widen (T2) | Yes: exact single-use credential (V0.2) | — | — | No |
| Split cannot launder (T3) | Yes: Execution + State binding; end-state = contract constraint | Path policy = provider evaluator | — | No (R2) |
| Partial execution (T4) | Yes: ActionReceipt + report status value `PARTIAL` | — | Effector reports it | No (rollback rejected, R6) |
| Partial evidence ≠ whole (T5) | Yes: EvidenceBinding | **`verification.required_effects`** | — | No |
| Evidence relabelling (T6) | Yes: EvidenceBinding | **Deployer effect scope per source** | One observer per sub-effect | No |
| Delegation narrows / widens (E1, E2) | Yes: Delegation + AuthorityBinding (V0–V0.2) | — | — | No |
| New evaluator dependency (E3) | Yes: StateBinding + V0.2 dependency set | — | — | No |
| Mode downgrade (E4, W10) | Yes: confinement assessment | Deployer infrastructure facts | — | No |
| Inter-step state of a composite (T4b, T4e) | **Partly**: binding applies to the operation; later calls rely on provider chaining attested in evidence | — | Yes: provider chaining | No (pressure, V03-H) |
| Post-state invariant over one sub-effect (V03-C) | **No**: not expressible, fails closed (over-strict) | Could be an invariant→effect scope field | — | Not admitted (R10) |

### Final metrics

| Metric | Count |
|---|---|
| New top-level protocol objects | **0** |
| New binding categories | **0** |
| New generic evaluator types | **0** (no evaluator added to `core_registry`; one registry interface field, `spec_keys`) |
| Provider-specific core branches | **0** (G22, G23) |
| Existing-provider files changed solely because of newcomers | **0** (P6a) |
| New fields inside existing objects or bindings | **12**: contract `security_identity`, `human_metadata`, `noncritical_extensions`, `verification.required_effects`; `Decision.contract_artifact_digest`; `Grant.effects`; `Credential.effects`; status `PARTIAL`; evidence-source effect scope; `Confinement.guarantee` (+3 infrastructure facts); qualified contract address; evaluator `spec_keys` |
| New reason codes | 6 |
| Core lines | +379 / −51 |

## 9. New evaluators and bindings

- **Evaluators:** none in the core.
  - One provider evaluator, `pubhub.no_public_within_hold`, lives in the fixture and is registered by the test that uses it.
  - The registry gained `spec_keys` so a known evaluator cannot silently ignore a modifier.
- **Binding categories:** none. New fields per binding:
  - **AuthorityBinding:** `binding_digest` (security identity), artifact digest for confirmations, issuer-qualified address and per-issuer trust.
  - **StateBinding:** unchanged.
  - **EvidenceBinding:** source effect scope, `required_effects`, PARTIAL-consistent evidence rule.
  - **ExecutionBinding:** `effects` in grant and credential, `PARTIAL`, infrastructure facts and `guarantee`.

## 10. Proposed but rejected primitives

Each was checked against all five conditions of the primitive-admission rule. None met all five.

| # | Candidate | Why rejected (failed admission condition) |
|---|---|---|
| R1 | `ExecutionStep` / `CompositeAction` object, or a step partition in the credential | (1) It fits: one authorized operation, split by the trusted effector at the provider boundary (T1). (5) Executor-side splitting fails closed, but the composite still works, so ordinary use is not impossible. |
| R2 | `TransitionHistory` / path-policy binding | (3) The contract or evaluator *is* the right place: path rules need domain history (T3e). Missing → fail closed (T3d). |
| R3 | Semantic-equivalence / capability-alias registry | Forbidden (ontology). (5) Lookalikes are merely unsupported; re-delegation works. |
| R4 | `ContractNamespace` / `IssuerIdentity` object | (1) It fits inside CapabilityContract identity plus the registry. (4) Authentication is infrastructure. |
| R5 | `MetadataManifest` / contract-versioning object | (1)(3) A contract field (`security_identity`) suffices. |
| R6 | `Compensation` / rollback primitive | (3) Compensation is domain semantics; the brief forbids invented rollback (T4). |
| R7 | `InfrastructureAttestation` object | (4) Proof is infrastructure. The protocol only consumes a deployer declaration in the existing confinement assessment. |
| R8 | Contract-level `required_confinement` | (3)(4) It is deployment policy (`require_confinement`). A contract cannot raise reality, and the field fails closed as unknown critical (E4d). |
| R9 | Evaluator-version binding in grants | (1) Not needed: the registry is append-only, so evaluator meaning changes only through a contract or delegation digest (E3d). |
| R10 | Sub-effect-scoped invariants (invariant → effect) | (5) Not met: without it the composite *executes*; only VERIFIED is unreachable when a post-state invariant is declared (V03-C, fails closed). Recorded as pressure. |
| R11 | "Every declared effect is required" default | It would break W5 (§6). Kept opt-in → V03-A. |

## 11. Ontology-pressure findings

| ID | Pressure | Outcome | Class |
|---|---|---|---|
| O1 | Composites need "this effect **must** happen" as well as "this effect **may** happen" | Generic modality (`required_effects` ⊆ `effects`). Labels stay opaque. | `CONTRACT_DEFICIENCY` if omitted (V03-A) |
| O2 | Path or history transitions (private→team→public) | Pushed to a provider evaluator (T3e) or fails closed (T3d); the core learns nothing | none |
| O3 | Lookalike names and descriptions | No equivalence; identity is the digest (P8) | none |
| O4 | Invariants that apply to only one sub-effect | Not expressible; fails closed (V03-C) | `EVIDENCE_MODEL_DEFICIENCY` / `ONTOLOGY_PRESSURE` (weak) |
| O5 | State continuity between the two calls of a composite | Provider chaining, attested in evidence; unchained is *detected* (T4e) | `STATE_BINDING_DEFICIENCY` / `PROVIDER_LIMITATION` (V03-H) |

**No failure class forced a global ontology.** No effect, field, audience, visibility or document concept entered the core (G22).

## 12. Representation-leakage findings

**None found.**

- Folio's refs, nested body, integer revision and `client_token` exist only in `fixtures/folio/mapping.py`, the effector and the observer (P7a).
- PubHub's lists and visibility exist only in `fixtures/pubhub/mapping.py` (P8b).
- The core sees the contract's `maps_to` vocabulary and opaque version strings.
- G22 scans every core string literal and identifier for 14 newcomer words.
- One near-leak was avoided by design. The core never learned "steps": the composite split is inside the effector (R1). The cost is that the effector sits in the TCB for the split (V03-J).

## 13. Knowledge-evolution findings

| ID | Finding | Status | Class |
|---|---|---|---|
| **V03-F** | V0.2 **silently ignored** unknown top-level fields, unknown `verification` keys, unknown `state_binding` keys, unknown input keys (e.g. `pattern`) and unknown modifiers on known evaluators. The authorization proceeded as if they did not exist (§14 probe). | **Fixed generically**: closed-world schema plus declared evaluator `spec_keys` | `KNOWLEDGE_EVOLUTION_DEFICIENCY` (V0.2) |
| K2 | Metadata-only edits over-invalidated everything (V0 limitation) | Explicit opt-in separation (P1). Without a declaration, the V0 behaviour stays (P1b). | — |
| K3 | Evaluator meaning could in principle change under a pinned contract | Not possible in the model: the registry is append-only (E3d) | — |
| K4 | Narrowing a delegation takes effect only by revoking the old one (E1b) | Recorded semantics, not changed | `AUTHORITY_ATTENUATION_DEFICIENCY` (usability; safe) |
| K5 | A change to a noncritical extension forces reauthorization (P3d) | `SAFE_BUT_OVERINVALIDATING`, by choice | `KNOWLEDGE_EVOLUTION_DEFICIENCY` (minor) |

## 14. Fail-closed cases

Probe run against **unchanged V0.2** and V0.3 with the same contract mutations (`tools/w7_probe.py`, output reproduced):

```
== V0.2
unknown top-level field (two_person_rule)     REQUIRE_CONFIRMATION   ['confirmation_required']
unknown verification key (attestation)        REQUIRE_CONFIRMATION   ['confirmation_required']
unknown state_binding key (granularity)       REQUIRE_CONFIRMATION   ['confirmation_required']
unknown input key (pattern)                   REQUIRE_CONFIRMATION   ['confirmation_required']
unknown modifier on known evaluator           REQUIRE_CONFIRMATION   ['confirmation_required']
== V0.3
unknown top-level field (two_person_rule)     DENY                   ['unsupported_critical_extension']
unknown verification key (attestation)        DENY                   ['malformed_contract']
unknown state_binding key (granularity)       DENY                   ['malformed_contract']
unknown input key (pattern)                   DENY                   ['malformed_contract']
unknown modifier on known evaluator           DENY                   ['unsupported_constraint_modifier']
```

All V0.3 fail-closed cases:

1. Unknown top-level contract field unless declared noncritical (P3a, P9)
2. Unknown key in inputs, `verification`, `state_binding` or `security_identity` (P3c, P9)
3. Unknown modifier on a known evaluator, in a contract or delegation (P9, P9b)
4. An exclusion from security identity outside {description, human_metadata} (P3b)
5. A noncritical declaration naming a protocol field, or a noncritical extension holding a reference (P10b)
6. An evaluator relying on a noncritical or excluded field (P1d, P10b)
7. A bare contract id served by more than one trusted issuer (P5c)
8. An untrusted issuer's qualified address (P5f); a publisher claiming another issuer (P5e)
9. An unmappable or ambiguous newcomer representation: no plan → DENY (P7c, P8b)
10. A path rule whose semantics are not provided (T3d)
11. Executor-side splitting of an authorized operation (T2, T3a)
12. PARTIAL never VERIFIED and never retried (T4)
13. Required effect without its own authoritative evidence (T4c, T5)
14. Evidence outside its source's effect scope (T6a)
15. Infrastructure declared absent → NOT_CONFINED (E4b); unknown infrastructure fact → error
16. Unknown critical `required_confinement` (E4d)
17. A post-state invariant not observable by sub-effect evidence → UNVERIFIED (V03-C, over-strict)

## 15. Infrastructure-outsourced cases

| Dependency | Where it shows | Without it |
|---|---|---|
| Authenticated contract issuer | `publish(…, authenticated_issuer=)` (P5e) | A forged contract can occupy a qualified address. Pinning still denies it: DoS, not authority (V03-D). |
| Executor isolation from the gateway process | `executor_isolated_from_gateway`; V02-A unchanged | `CONFINED` is only `…ASSUMING_UNDECLARED_INFRASTRUCTURE` |
| Holder proof-of-possession | `holder_proof_of_possession`; V02-B unchanged | Holder = port identity (modeled) |
| Provider-side scoped-credential enforcement (Mode A) | `provider_enforces_scoped_credential` (E4c) | A Mode A claim is reported as Mode B |
| Evidence-source integrity and honesty | Deployer provenance and effect scope (V0.1 + V0.3) | An unscoped lying source can attest any effect (V03-B) |
| Atomic CAS / conditional writes, provider chaining | Folio `if_revision`, PubHub `if_rev`, `chained_to` | Detected, not prevented (T4e) |
| Signatures on contracts, grants, credentials, evidence | Not implemented (scope) | Integrity comes from in-memory stores |

## 16. Did the five objects + four bindings remain sufficient?

**Yes, for representation.** Every V0.3 requirement was expressed with CapabilityContract, Delegation, ActionIntent, AuthorizationGrant and ActionReceipt, plus the four bindings (G24; §8: 0 new objects, 0 new categories).

**Not without growth inside them.** About 12 fields were added (§8). The composite newcomer alone accounts for `effects` in grant and credential, `PARTIAL`, `required_effects` and evidence effect scope. Two requirements are only partly expressible:

- inter-step state (V03-H);
- sub-effect invariants (V03-C).

Both fail closed or are detected; neither is silently allowed.

## 17. Did the boundary remain stable?

- **Prevention side: yes.**
  - Under every attack, no unauthorized effect reached a provider through the confined path.
  - Every stale authority was refused.
  - Every unknown critical semantic was denied.
  - The core learned no newcomer concept.
- **Verification side: conditionally.**
  - VERIFIED for a composite is sound only if the provider declares `required_effects` and the deployer scopes evidence sources.
  - When either is missing, a publish-only observation verifies publish+notify (V03-A, V03-B, both reproduced).
  - These are new declaration burdens that did not exist for single-effect contracts.
- **Two V0.2 deficiencies were found by the wall**, not by earlier rounds: V03-F (silent ignore) and V03-G (namespace collision). The boundary claimed by V0.2 was therefore *not* already stable; V0.3 had to close it.

## 18. Final verdict: **`BOUNDARY_PARTIALLY_SURVIVED`**

| BOUNDARY_SURVIVED requirement | Met? | Evidence |
|---|---|---|
| Old protections preserved | Yes | 152/152, files hash-identical |
| No provider-specific core branches | Yes | G1, G18–G23 |
| Newcomers force no existing-provider changes | Yes | P6a–c |
| Unknown critical semantics fail closed | Yes, **after fixing V0.2** | P9, §14 |
| Transition / evidence laundering prevented or safely unsupported | Transitions: yes (T2, T3). Evidence: **only with provider and deployer declarations** | T5, T6 vs V03-A, V03-B |
| Security evolution invalidates stale authority | Yes | P2, P4, E1–E3, W9 |
| Metadata-only changes avoid invalidation only via explicit separation | Yes | P1, P1b, P3 |
| No universal ontology or equivalence engine | Yes | P8c, G22, §11 |
| No unjustified new top-level primitive | Yes | G24, §10 |
| Guarantee cannot exceed infrastructure reality | Yes; the reference deployment is labelled *assumed* | E4, §15 |

**Why not `BOUNDARY_SURVIVED`.** The brief defines `PARTIALLY_SURVIVED` as: the architecture mostly holds, but "common cross-domain requirements create credible pressure for another primitive/binding or unexpectedly strong provider declarations". That is what happened:

- Composite effects are a common cross-domain requirement (publish+notify, charge+receipt, book+invite).
  - Sound verification of them now depends on two declarations that single-effect domains never needed: `required_effects` from the provider and per-source effect scope from the deployer.
  - Omitting either silently weakens VERIFIED (V03-A, V03-B). It never weakens prevention.
- Two composite properties are only partly representable without a sub-effect structure. Both fail closed or are detected, but they are credible pressure toward another binding field:
  - inter-step state, via provider chaining (V03-H);
  - sub-effect invariants (V03-C).
- The composite split works only because the trusted effector performs it. This adds provider-specific split logic to the TCB (V03-J).

**Why not `BOUNDARY_FAILED`.**

- No existing provider was modified.
- The core learned no newcomer semantics.
- No representation mapping leaked into the core.
- No global ontology was needed.
- The primitive count did not grow: 0 objects, 0 binding categories.
- Every case the protocol cannot state safely fails closed or is detected; none is silently allowed at authorization time.

**What this does not show.**

- Universal interoperability.
- Real provider APIs: all five providers are in-memory fakes written by the same author as the core and tests (designer bias).
- Cryptographic integrity, process isolation, or authenticated publishing; all are modeled inputs.
- That twelve fields is the final count: a third domain shape (e.g. long-running or approval-chained actions) may add more.

---

## 19. Findings register (V0.3)

| ID | Finding | Test | Classification |
|---|---|---|---|
| V03-A | A composite contract that omits `required_effects` is VERIFIED on evidence of one sub-effect | `test_FINDING_V03_A` | `CONTRACT_DEFICIENCY` (provider declaration); verification-only |
| V03-B | An authoritative source registered without an effect scope can relabel one observation as another | `test_FINDING_V03_B` | `INFRASTRUCTURE_DEPENDENCY` (evidence integrity is TCB) / `EVIDENCE_MODEL_DEFICIENCY` |
| V03-C | Post-phase invariants run on every evidence item; sub-effect evidence that cannot observe the state makes the composite un-VERIFIABLE | `test_FINDING_V03_C` | `EVIDENCE_MODEL_DEFICIENCY` (fails closed) |
| V03-D | Without the authenticated-issuer input, any caller can occupy a qualified address (pinning turns it into DoS) | `test_FINDING_V03_D` | `INFRASTRUCTURE_DEPENDENCY` |
| V03-E | Non-security status of `description` is the issuer's word; text can drift under never-confirm grants (enforcement cannot widen) | `test_FINDING_V03_E` | `CONTRACT_DEFICIENCY` (accepted residual of P1) |
| V03-F | V0.2 silently ignored 5 kinds of unknown critical structure | P9, §14 probe | `KNOWLEDGE_EVOLUTION_DEFICIENCY` — **fixed** |
| V03-G | V0.2 keyed contract identity, trust and evidence by local id: a second issuer overwrote trust/current (fail-closed DoS, no authority gain thanks to digest pins) | P5a–f | `PROTOCOL_BOUNDARY_DEFICIENCY` — **fixed** inside CapabilityContract identity |
| V03-H | State continuity between the calls of a composite is provider chaining; unchained calls are detected (VIOLATION), not prevented | T4b, T4e | `STATE_BINDING_DEFICIENCY` / `PROVIDER_LIMITATION` |
| V03-I | Delegation narrowing needs revocation of the old delegation | E1b | `AUTHORITY_ATTENUATION_DEFICIENCY` (semantics) |
| V03-J | Composite split and PARTIAL honesty live in the trusted effector; lies are detected by evidence (T4c, T4d), not prevented | T4c, T4d | `PROVIDER_LIMITATION` (TCB) |
| V03-K | A change to a noncritical extension forces reauthorization | P3d | `SAFE_BUT_OVERINVALIDATING` |
| V03-L | The reference deployment's `CONFINED` rests on undeclared isolation (V02-A); now labelled `CONFINED_ASSUMING_UNDECLARED_INFRASTRUCTURE` | B1, E4b | `ENFORCEMENT_BOUNDARY_DEFICIENCY` (in-process model) / `INFRASTRUCTURE_DEPENDENCY` |

Earlier findings F1–F7, V01-A…H and V02-A…G are unchanged; their tests still reproduce them.

The mutation script is `tools/mutate_v03.py`. It applies each mutation in place, runs the suite, and restores the file.
