# V0.5 — Multi-Subject State Binding

V0.5 generalizes the **content of the existing `StateBinding`**. It does not add a lifecycle object or binding category. Legacy `(subject, version_kind, version_value)` remains valid. Multi-subject form carries an opaque dependency table: `dependency_id`, issuer namespace, `subject_ref`, opaque `binding_type`, opaque `binding_value`, and `required`.

The generic core checks identity, declared coverage, exact grant lineage, required-dependency completeness, and guarantee ordering. It never parses the token. Token interpretation and actual current-state validation remain at the trusted provider/validator boundary.

## Consistency guarantees

`INDIVIDUALLY_CHECKED` means every required dependency was checked, with no same-snapshot or atomic claim. `SNAPSHOT_CONSISTENT` additionally requires an opaque consistency context whose declared coverage is exactly the required dependency set. `ATOMIC_PRECONDITION` means the trusted provider infrastructure asserts the required set is checked as one execution precondition immediately before the protected effect commit. Stronger may satisfy weaker; weaker never satisfies stronger.

A local snapshot from provider X plus a local snapshot from provider Y is not a global snapshot. Multi-issuer strong consistency is accepted only when an explicit trusted common consistency context is supplied; the protocol does not create that coordinator.

## Composite execution

V0.4 execution units remain unchanged. Different units may depend on different subsets; a shared dependency keeps one identity. A unit may establish state consumed by a later unit using the existing `from_unit` mechanism. That post-U1 state is a new binding; pre-U1 state cannot masquerade as it.

StateBinding says nothing about atomic business effects. U1 may succeed and U2 may fail. No rollback, compensation, Saga, 2PC, or distributed transaction machinery was added.

## Trust boundary

The contract/provider is authoritative for declaring security-relevant mutable dependencies. The trusted validator/provider adapter is authoritative for validating opaque tokens and asserting the guarantee actually supplied. If either omits a security-critical dependency, generic core cannot discover domain truth and no LLM/ontology inference is attempted. Unknown critical representation or unavailable required validation fails closed.

## Primitive decision

No new primitive was necessary for the tested architecture. A structured set inside existing `StateBinding` was sufficient. This result does not prove distributed atomicity, serializability, or universal state consistency.
