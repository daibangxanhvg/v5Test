# V0.5 Adversarial Closure Review --- Codex Brief

## Purpose

Do NOT design V0.6.

This is a final adversarial closure review of the attached V0.5
implementation before deciding whether to close the V0 Experimental
Architecture phase.

The implementation currently reports: - 351 tests - 350 pass - 1 known
runtime-sensitive legacy failure - verdict: MULTI_STATE_BINDING_SURVIVED

Do not trust that verdict. Independently inspect the implementation and
attempt to break it.

## Scope

Focus narrowly on interactions that appear under-tested:

1.  V0.4 composite ExecutionBinding units × V0.5 multi-subject
    StateBinding.
2.  State handoff where U1 mutates state later consumed by U2.
3.  Cross-provider consistency claims.
4.  Consistency-context scope/coverage/replay.
5.  Dependency lineage/substitution/replay.
6.  Required consistency downgrade/upgrade.
7.  Provider/contract omission trust boundary.
8.  Whether the generic core can accidentally claim a stronger guarantee
    than infrastructure actually provides.
9.  Whether the implementation quietly became transaction/workflow
    coordination.
10. Whether apparently generic fields encode hidden domain semantics.

Preserve all existing tests. Do not weaken, delete, skip, or rewrite old
failures merely to obtain green output.

## Critical adversarial scenario

Test this end-to-end, not with set/list assertions:

``` text
Initial:
A@a1
B@b1
C@c1

Composite action:
U1 requires A@a1 + B@b1
U2 requires B + C

U1 executes and legitimately changes B:
B@b1 -> B@b2

Required property:
U2 must consume an explicitly established/validated B@b2 binding.
It must NOT:
- reuse B@b1,
- infer B@b2 merely because U1 succeeded,
- accept a B token from another subject/issuer/action/execution,
- silently upgrade sequential validation into snapshot/atomic consistency.
```

Attack variants: - execute U2 with old B@b1; - substitute B token from
another resource; - substitute same local subject ID from another
issuer; - replay B@b2 from another execution; - omit post-U1 B
validation; - forge/declare a stronger consistency level without
supporting validation evidence; - execute U2 before U1; - U1 succeeds
but its claimed produced state differs from authoritative current B; -
U1 partial/failed but U2 attempts to consume claimed B@b2.

These must be real verifier/execution-path tests wherever the
architecture supports such a path.

## Cross-provider adversarial matrix

Build substantive tests for:

### X1 --- independent local snapshots

Provider P1 supplies snapshot S1 covering A+B. Provider P2 supplies
snapshot S2 covering C+D. The core MUST NOT infer one global
SNAPSHOT_CONSISTENT context across A+B+C+D.

### X2 --- sequential cross-provider checks

All dependencies validate individually. A changes after its check but
before final protected execution. The system may claim only the
guarantee actually established. If stronger consistency is required,
block.

### X3 --- claimed external coordinator

A trusted fixture claims a common context across P1/P2. Require explicit
scope/coverage/lineage. Missing one required subject must prevent the
stronger claim.

### X4 --- context replay

Reuse a valid consistency context for: - different subject set, -
different issuer set, - different ActionIntent, - different
AuthorizationGrant, - different execution. Reject unless the protocol
explicitly and safely defines that reuse.

### X5 --- mixed guarantees

Some dependencies are atomic locally, others only individually checked.
Do not collapse the aggregate to ATOMIC_PRECONDITION.

## StateBinding adversarial tests

Add real tests for: - duplicate dependency_id with conflicting
subject/token; - duplicate subject with conflicting required bindings; -
required=false dependency attempting to carry security-critical
semantics; - empty dependency set when contract requires mutable-state
dependency; - unknown critical consistency extension; - observed
consistency missing/None; - malformed consistency context coverage; -
context says it covers dependency IDs that are absent; - required
dependency exists in binding but validator never actually checks it; -
validator returns success for wrong subject; - validator returns
stronger level than its trusted capability declaration; - contract
evolves after grant by changing only consistency requirement; - binding
representation changes while opaque value happens to be identical.

Do not invent provider-specific parsing.

## V0.4 × V0.5 composition

Replace weak structural tests where useful with end-to-end tests through
actual generic verifier/execution components.

At minimum substantively test: - U1 depends A+B, U2 depends B+C; -
shared B does not widen authority; - post-U1 state transition B1-\>B2 is
explicit; - partial U1 cannot authorize U2; - required-unit removal
cannot remove its state dependencies; - injected U3 cannot smuggle a new
mutable-state dependency; - evidence for U1 cannot establish U2 state
unless explicitly authoritative for that state fact; - StateBinding does
not imply rollback if U2 fails.

## Trust-boundary attack

Explicitly test/document:

### Honest contract, malicious executor

Expected: confinement/bindings should block unauthorized behavior within
claimed mode.

### Incomplete/lying CapabilityContract

Contract omits a real security-relevant mutable dependency/effect.
Generic core must NOT pretend it can discover it. Document exactly which
guarantee becomes conditional on contract/provider truthfulness.

### Lying state validator/provider

If authoritative validator lies about current state or consistency, core
cannot create truth. Do not disguise this limitation.

The review must distinguish: - protocol defect, - trusted-component
compromise, - unsupported infrastructure, - provider-contract
incompleteness.

## Core audit

Search generic core for: - provider/domain names, - ETag/MVCC/CAS
parsing, - document/payment/calendar/flight/hotel/inventory semantics, -
rollback/commit/compensation/Saga/2PC logic, - special cases for
synthetic fixtures.

Report exact findings.

Also inspect whether the three consistency levels form a simple total
ordering where they should not. If any real case shows
SNAPSHOT_CONSISTENT and ATOMIC_PRECONDITION are incomparable properties
rather than universally stronger/weaker, report this as an architecture
finding instead of forcing tests to pass.

This point is important: do not assume the hierarchy is correct merely
because V0.5 implemented it.

## Complexity audit

Report: - generic-core LOC delta relative to V0.4 if measurable; -
number of StateBinding fields/types; - branching/validation
complexity; - test-only abstractions vs production abstractions; - any
sign that "no new primitive" is being achieved by stuffing excessive
semantics into StateBinding.

A stable object count alone is NOT sufficient evidence of a healthy
boundary.

## Legacy failing test

Investigate the one existing runtime-sensitive failure enough to
classify it.

Do NOT spend the review redesigning Mode B isolation.

Report whether it is: - genuine regression introduced by V0.5, -
Python/runtime sensitivity of an old test, - or unresolved.

Do not mark the full suite clean if it is not clean.

## Mutation/adversarial quality

Where practical, mutation-test key protections: - remove dependency
coverage check; - remove lineage check; - allow consistency upgrade; -
skip post-U1 state validation; - ignore missing required dependency.

The corresponding adversarial tests should fail.

Do not create meaningless mutation tests just to increase count.

## Decision rule

This review is NOT successful merely because all newly added tests pass.

Return exactly one architecture recommendation:

### `CLOSE_V0_EXPERIMENTAL_ARCHITECTURE`

Use only if: - no new core architectural defect is found; - V0.4×V0.5
composition survives substantive attacks; - consistency claims remain
honest; - multi-provider limitations are explicit/fail-closed; - no new
primitive is credibly required; - no transaction-coordinator creep; -
remaining failures are trust/infrastructure boundaries already outside
protocol responsibility.

### `CLOSE_WITH_EXPLICIT_LIMITATIONS`

Use if architecture is stable enough to stop V0.x experimentation, but
important limitations must be carried into the next specification phase.

### `DO_NOT_CLOSE_V0`

Use if a real core defect remains that can produce unauthorized
execution, false strong verification/consistency claims, stale-state
execution under claimed guarantees, or if ordinary cross-domain use
requires another architectural primitive.

## Required deliverables

Return a complete reviewed ZIP containing the implementation plus:

-   `CLOSURE_REVIEW.md`
-   `ADVERSARIAL_RESULTS.md`
-   `ARCHITECTURE.md`
-   `RESULTS.md`
-   existing protocol documents
-   all added adversarial tests
-   exact test commands/results

`CLOSURE_REVIEW.md` must contain: 1. recommendation; 2. defects found;
3. attacks attempted; 4. attacks blocked; 5. attacks that succeeded; 6.
trust-boundary limitations; 7. consistency-model assessment; 8.
complexity assessment; 9. whether a new primitive is required; 10.
whether V0.x should end here.

Do not start V0.6. Do not broaden into standards comparison. Do not
propose productization. Do not optimize for closure.
