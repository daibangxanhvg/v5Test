# Adversarial execution results

Recommendation: **DO_NOT_CLOSE_V0**. Detailed interpretation and limitations: CLOSURE_REVIEW.md.

Run from this archive's implementation directory, Python 3.12.14, standard library only:

```sh
PYTHONPATH=src:. python -m unittest discover -v
PYTHONPATH=src:. python -m unittest tests.test_closure_adversarial -v
PYTHONPATH=src:. python tools/mutate_closure.py
python tools/audit_closure.py
```

| Run | Result | Raw output |
|---|---|---|
| Original baseline before additions | 351 tests, OK, exit 0 | review_logs/baseline.txt |
| New adversarial module | 19 test methods, 12 failing assertions/subtests, exit 1 | review_logs/adversarial.txt |
| Combined preserved suite | 370 tests, 13 failing assertions/subtests, exit 1 | review_logs/full_suite.txt |
| Targeted mutations | Five selected tests pass before mutation; all five mutants detected | review_logs/mutations.txt |

Failure counts include subtests, not unique failing methods. Nine adversarial methods fail, with context replay contributing four failures. Combined discovery additionally reproduces the untouched legacy GC finding failure. A green standalone baseline does not mean the expanded suite is green.

## Matrix and evidentiary strength

| Requested area | Executed evidence / conclusion |
|---|---|
| A+B U1, B+C U2; explicit post-U1 B2 | Real composite gateway positive control fails: U1 executes; decoder rejects complete established binding; U2 never validates B2+C. |
| Stale B1, substitute subject, issuer, wrong lineage, absent validation token, false state, upgrade, partial U1 | Real composite variants block; nonselective decoder rejection masks individual token protections. No claim that these variants prove lineage/coverage survival. |
| Reordered U2 / injected U3 / wrong operation execution | Real boundary rejects each, no effector call. |
| Required-unit removal | Publish changed contract and execute old grant: DENY, no effect. |
| Shared B authority / evidence U1→U2 | Request fields remain exact and unit checks remain closed; original V0.4 evidence-scope tests execute in full suite. Multi-state successful shared-B/evidence path cannot be proved because positive control fails. |
| Rollback | Failed U2 leaves B changed by U1; no rollback promised or implemented. |
| X1 two local snapshots | Four dependencies P1:A+B and P2:C+D: rejected without flag, accepted with bare flag. |
| X2 sequential cross-provider checks | Strong request with aggregate individual guarantee denied. Required single-provider race is blocked by conditional provider check; core has no cross-provider atomic infrastructure. No stronger claim inferred from genuine individual level. |
| X3 claimed coordinator | Exact ID coverage checked for snapshot only; no independent coordinator authentication. Bare flag accepted as demonstrated by X1. |
| X4 scope/context replay | Changed subject, issuer, intent, execution accepted; mismatched grant context ignored from first use. Grant itself remains intent-pinned; attack obtains fresh grants reusing context. |
| X5 mixed guarantees | Aggregate individual observation under required atomic level denied; local guarantee annotations do not establish aggregate guarantee. |
| Duplicate identity | Exact (id,subject) duplicates denied; same id/different subject accepted. |
| Duplicate subject | Conflicting tokens accepted by core, blocked by actual conditional provider. |
| required=false | Contract-required B downgraded in offered binding; B changes during execute and effect occurs. |
| Empty set / missing required dependency / validator omission | Empty/missing declared binding denied; required flag attack demonstrates actual skipped validation. Deliberately lying validator remains trust compromise. |
| Unknown critical / observed None / malformed coverage | Unknown context critical annotation accepted; observed None denied; covers=None crashes verifier. Extra or missing IDs denied. |
| Wrong subject / strength above capability | Wrong declared subject denied. No trusted state-validator capability declaration API exists; cannot enforce upper capability bound. Lying adapter experiment reports atomic state metadata without effect verification. |
| Consistency-only contract evolution / opaque representation change | Both invalidate old grant and block execution. |
| Honest contract malicious executor | Boundary unit injection, ordering and lineage attacks blocked. |
| Incomplete contract / lying provider | Actual executions demonstrate conditional truth boundary, explicitly distinguished from core defects. |
| Snapshot vs atomic ordering | Atomic predicate execution with no read snapshot accepted under snapshot requirement; architecture finding, not a provider token parser change. |

## Mutations

Disposable copies only; baseline source never mutated. Each selected test is run first unchanged and must pass. Then exactly one replacement is applied and the same test must fail:

1. Remove snapshot ID coverage comparison: existing C4 test detects it.
2. Ignore missing required dependency: added omission/substitution test detects it.
3. Remove operation execution lineage check: added boundary test detects actual U1 execution.
4. Permit weaker observed consistency: added strong-request matrix detects it.
5. Remove provider's post-U1 notification precondition: existing end-to-end S1b detects successful stale execution (receipt becomes VIOLATION).

The fifth mutation targets provider-owned validation on the supported legacy handoff path. It does not establish functioning V0.5 multi-state post-U1 validation. The unsupported positive control prevents a meaningful isolated mutation of that missing path. Already missing context lineage/capability checks cannot be removed to demonstrate test strength.

All original files except review addenda in ARCHITECTURE.md and RESULTS.md are byte-identical to the supplied ZIP. Original versions of those documents are retained under review_baseline_documents/. Source/tests SHA-256 verification is recorded in review_logs/baseline_integrity.json. No old tests are deleted, skipped, rewritten or marked expected failures. New security expectation failures are deliberately visible.
