from aaap import ActionIntent, Delegation, qualified_contract_id
from tests.harness import load_contract, make_core
from .adapter import MultiAdapter
ISSUER="opaque.example"; LOCAL_ID="r.apply"; ADDRESS=qualified_contract_id(ISSUER,LOCAL_ID); DID="dlg-ms"
def build(guarantee="INDIVIDUALLY_CHECKED", context=None, state=None, kinds=None, contract=None):
    core=make_core(); contract=contract or load_contract("multistate","contract_v1.json"); core.contracts.trust_issuer(LOCAL_ID,ISSUER); core.contracts.publish(contract,authenticated_issuer=ISSUER)
    core.delegations.issue(Delegation(DID,"lam","agent-1",["r.write"],[{"contract_id":ADDRESS,"capability":"r_apply","contract_version":contract.version,"contract_digest":contract.binding_digest()}],[],"2026-10-01T00:00:00+07:00","2026-11-01T00:00:00+07:00"))
    st=state or {"r17":"v1","r42":"v7","r99":"v3"}; core.gateway.register_adapter(ADDRESS,MultiAdapter(st,guarantee=guarantee,context=context,kinds=kinds)); return core,st,contract
def intent(**kw):
    args={"a":"r17","b":"r42","c":"r99"}; args.update(kw); return ActionIntent("int-ms","agent-1","lam",ADDRESS,"r_apply",args,"exec-ms")
