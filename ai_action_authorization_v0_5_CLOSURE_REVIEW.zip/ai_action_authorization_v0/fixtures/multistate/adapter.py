from aaap import ProviderAdapter, StateBinding
from aaap.adapter import ExecutionResult, PreconditionFailed
from aaap.objects import EXEC_SUCCESS
class MultiAdapter(ProviderAdapter):
    def __init__(self, state, issuer="opaque.example", guarantee="INDIVIDUALLY_CHECKED", context=None, kinds=None):
        self.state=state; self.issuer=issuer; self.guarantee=guarantee; self.context=context; self.kinds=kinds or {}; self.effects=[]
    def resolve(self,intent): return dict(self.state)
    def plan(self,intent,facts): return {k:intent.arguments[k] for k in ("a","b","c")}
    def state_binding(self,intent,facts):
        ds=[]
        for i,k in enumerate(("a","b","c"),1):
            ds.append({"dependency_id":f"d{i}","issuer":self.issuer,"subject_ref":intent.arguments[k],"binding_type":self.kinds.get(k,"opaque"),"binding_value":str(facts[intent.arguments[k]]),"required":True})
        return StateBinding(dependencies=tuple(ds), required_consistency="INDIVIDUALLY_CHECKED", observed_consistency=self.guarantee, consistency_context=self.context)
    def execute(self,intent,plan): return self.execute_conditional(intent,plan,None)
    def execute_conditional(self,intent,plan,precondition):
        # Provider/trusted-validator boundary owns token semantics. Generic core never parses values.
        if precondition is not None:
            for d in precondition.dependencies:
                if d.get("required",True) and str(self.state.get(d["subject_ref"])) != d["binding_value"]:
                    raise PreconditionFailed("opaque dependency stale")
        self.effects.append(intent.execution_id)
        return ExecutionResult(EXEC_SUCCESS,intent.execution_id,intent.execution_id,dict(plan),["r.effect"])
    def read_back(self,intent,result): return {"a":intent.arguments["a"]}
