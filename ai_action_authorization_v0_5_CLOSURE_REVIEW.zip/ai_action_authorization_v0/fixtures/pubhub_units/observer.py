"""V0.4 PubHub evidence sources. Each reads PubHub's own record (PROVIDER_AUTHORITY).

- UnitRecordObserver: the record of ONE unit (key = execution_id#unit). The deployer registers
  it with that unit as its unit scope.
- CompositeActivityObserver: PubHub's activity view of a whole execution: ONE evidence item
  covering several units (used only where the contract declares joint evidence, C11).
The observers pass through what PubHub recorded: unit id, grant lineage, the revision a write
was conditioned on (applied) and the revision it left (established)."""
from __future__ import annotations

from typing import Dict, Sequence

from aaap.adapter import EvidenceSource
from aaap.objects import PROVIDER_AUTHORITY, ExecutionEvidence

from fixtures.pubhub import mapping

from .effector import rev_token, unit_key


def _applied(subject, if_rev):
    return {} if if_rev is None else rev_token(subject, if_rev)


def _view(rec, lists):
    """(observed_state, unit_state) of one PubHub record."""
    if rec["kind"] == "publish":
        state = mapping.normalize(rec["result"])
        established = rev_token(rec["doc"], rec["result"]["rev"])
    else:
        state = {"document_ref": rec["doc"], "audience": mapping.audience_of_list(rec["list"], lists),
                 "recipients": rec["result"]["recipients"]}
        established = rev_token(rec["doc"], rec["rev"])
    return state, {"applied": _applied(rec["doc"], rec["if_rev"]), "established": established}


class UnitRecordObserver(EvidenceSource):
    def __init__(self, hub, tokens: Dict[str, str], unit: str, lists=None, identity: str = None):
        self.hub, self.tokens, self.unit, self.lists = hub, tokens, unit, lists
        self.identity = identity or f"pubhub.example/unit-record/{unit}"

    def observe(self, intent, grant):
        rec = self.hub.record(self.tokens[intent.principal], unit_key(intent.execution_id, self.unit))
        if rec is None:
            return None
        state, ust = _view(rec, self.lists)
        return ExecutionEvidence(
            evidence_id=f"{self.identity}:{intent.execution_id}", execution_id=intent.execution_id,
            intent_id=rec["metadata"].get("intent_id"), source_identity=self.identity, provenance=PROVIDER_AUTHORITY,
            observed_subject=rec["doc"], observed_state=state, observed_effects=tuple(rec["effects"]),
            covers_units=(rec["metadata"].get("unit"),), grant_id=rec["metadata"].get("grant_id"),
            unit_states={rec["metadata"].get("unit"): ust})


class CompositeActivityObserver(EvidenceSource):
    identity = "pubhub.example/activity"

    def __init__(self, hub, tokens: Dict[str, str], units: Sequence[str], lists=None):
        self.hub, self.tokens, self.units, self.lists = hub, tokens, tuple(units), lists

    def observe(self, intent, grant):
        token = self.tokens[intent.principal]
        recs = [r for r in (self.hub.record(token, unit_key(intent.execution_id, u)) for u in self.units) if r]
        if not recs:
            return None
        state, effects, ust = {}, [], {}
        for rec in recs:
            s, u = _view(rec, self.lists)
            state.update({k: v for k, v in s.items() if k in ("document_ref", "audience")})
            effects += rec["effects"]
            ust[rec["metadata"].get("unit")] = u
        first = recs[0]["metadata"]
        return ExecutionEvidence(
            evidence_id=f"{self.identity}:{intent.execution_id}", execution_id=intent.execution_id,
            intent_id=first.get("intent_id"), source_identity=self.identity, provenance=PROVIDER_AUTHORITY,
            observed_subject=recs[0]["doc"], observed_state=state, observed_effects=tuple(effects),
            covers_units=tuple(r["metadata"].get("unit") for r in recs), grant_id=first.get("grant_id"),
            unit_states=ust)
