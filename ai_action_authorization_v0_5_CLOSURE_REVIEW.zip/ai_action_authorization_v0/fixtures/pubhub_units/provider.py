"""V0.4 PubHub extension: the same FakePubHub (V0.3 file unchanged) plus a CONDITIONAL notify.

`notify_if(..., if_rev)` sends the notification only if the document is still at `if_rev`
(compare-and-swap), so the second unit of a composite can be bound to the state the first
unit produced. The V0.3 `notify(chained_to=...)` (provider-side chaining) is left as it was."""
from __future__ import annotations

import copy
from typing import Optional

from fixtures.pubhub.provider import FakePubHub, PubHubError


class UnitHub(FakePubHub):
    def __init__(self, clock) -> None:
        super().__init__(clock)
        self.expose_versions = True      # S6 switch: a provider that does not expose the produced revision

    def notify_if(self, token: str, list_name: str, doc_id: str, key: str, if_rev: Optional[int],
                  metadata: Optional[dict] = None) -> dict:
        caller = self._auth(token)
        self.notify_calls += 1
        if key in self._records:
            return copy.deepcopy(self._records[key]["result"])
        if self.before_notify:
            self.before_notify()
        if self.fail_notify:
            raise PubHubError(self.fail_notify)
        doc = self.docs[doc_id]
        if if_rev is not None and if_rev != doc["rev"]:
            raise PubHubError("412 stale rev")
        note = {"list": list_name, "doc": doc_id, "recipients": list(self.lists[list_name])}
        self.outbox.append(note)
        self._records[key] = {"kind": "notify", "doc": doc_id, "caller": caller, "list": list_name,
                              "if_rev": if_rev, "rev": doc["rev"], "metadata": dict(metadata or {}),
                              "effects": ["external_notification_sent"], "result": copy.deepcopy(note)}
        return copy.deepcopy(note)
