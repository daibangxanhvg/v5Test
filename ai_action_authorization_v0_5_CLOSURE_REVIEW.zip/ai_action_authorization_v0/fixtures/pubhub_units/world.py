"""V0.4 wiring: PubHub publish_and_notify V3 with two opaque execution units.

Same issuer and local id as N2 (it is PubHub's next contract version). Reuses the V0.3 PubHub
adapter, mapping and delegation helpers unchanged. `unit_ids` renames the units (B1): the
renaming is applied to the contract, the effector's role table and the observers, i.e. only
on the provider side."""
from __future__ import annotations

import json

from aaap import PROVIDER_AUTHORITY, CapabilityContract, ConfinedExecutor

from fixtures.pubhub.adapter import PubHubAdapter
from fixtures.pubhub.world import ADDRESS, ISSUER, LOCAL_ID, NOW, TOKENS, audiences, delegation, intent, pin  # noqa: F401
from tests.harness import load_contract, make_core

from .effector import NOTIFIED, PUBLISHED, UnitPubHubEffector
from .observer import UnitRecordObserver
from .provider import UnitHub

DID = "dlg-pub-1"


def rename_units(contract: CapabilityContract, names) -> CapabilityContract:
    """Provider-side renaming of unit ids everywhere they occur in the contract."""
    d = contract.to_dict()
    for u in d.get("execution_units", []):
        u["unit_id"] = names.get(u["unit_id"], u["unit_id"])
        u["after"] = [names.get(a, a) for a in u.get("after", [])]
        if isinstance(u.get("state"), dict):
            u["state"] = {"from_unit": names.get(u["state"]["from_unit"], u["state"]["from_unit"])}
        ev = u.get("evidence")
        if isinstance(ev, dict) and "joint_with" in ev:
            ev["joint_with"] = [names.get(j, j) for j in ev["joint_with"]]
    return CapabilityContract.from_dict(json.loads(json.dumps(d)))


def build(core=None, contract_file="contract_v3.json", contract=None, observers=("publish", "notify"),
          delegation_id=DID, constraints=None, lists=None, unit_ids=None):
    core = core or make_core()
    hub = UnitHub(core.clock)
    hub.tokens["tok-lam-pubhub"] = "lam"
    hub.add("p-7", "Launch plan", visibility="private")
    hub.lists = {"list:team-internal": ["an@example.com", "binh@example.com"],
                 "list:public-subscribers": ["press@example.org", "everyone@example.org"]}
    names = dict(unit_ids or {})
    contract = contract or load_contract("pubhub_units", contract_file)
    if names:
        contract = rename_units(contract, names)
    core.contracts.trust_issuer(LOCAL_ID, ISSUER)
    core.contracts.publish(contract, authenticated_issuer=ISSUER)
    core.delegations.issue(delegation(delegation_id, contract, constraints))
    core.gateway.register_adapter(ADDRESS, PubHubAdapter(hub, TOKENS, lists))
    effects = {"publish": (PUBLISHED,), "notify": (NOTIFIED,)}
    for role in observers:
        uid = names.get(role, role)
        core.gateway.register_evidence_source(ADDRESS, UnitRecordObserver(hub, TOKENS, uid, lists),
                                              PROVIDER_AUTHORITY, effects=effects[role], units=(uid,))
    return core, hub, contract


def build_confined(core=None, executor=None, lists=None, unit_ids=None, effector=None, **kw):
    core, hub, contract = build(core, lists=lists, unit_ids=unit_ids, **kw)
    names = dict(unit_ids or {})
    roles = {names.get("publish", "publish"): "publish", names.get("notify", "notify"): "notify"}
    eff = effector(hub, TOKENS, lists, roles) if effector else UnitPubHubEffector(hub, TOKENS, lists, roles)
    core.gateway.authority.register_effector(ADDRESS, eff)
    core.gateway.register_executor(ADDRESS, executor or ConfinedExecutor("agent-1"))
    return core, hub, contract, eff
