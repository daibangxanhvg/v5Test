"""V0.4 PubHub unit effector (Mode B, TRUSTED: holds the PubHub token).

It performs ONE execution unit per call, under the precondition the enforcement boundary
computed. What a unit id means is configured here (`roles`: unit id -> provider call); the
protocol core never learns it. It records the grant lineage and unit id with every provider
write, and reports the revision the effect produced (`established_state`) if the provider
exposes it. It has no whole-operation mode: the composite split is the boundary's, not its own."""
from __future__ import annotations

from typing import Dict, Optional

from aaap.adapter import ExecutionResult, PreconditionFailed
from aaap.authority import MODE_B, ProviderEffector
from aaap.objects import EXEC_SUCCESS

from fixtures.pubhub import mapping
from fixtures.pubhub.provider import PubHubError

from .provider import UnitHub

PUBLISHED, NOTIFIED = "document_published", "external_notification_sent"
DEFAULT_ROLES = {"publish": "publish", "notify": "notify"}


def unit_key(execution_id: str, unit: str) -> str:
    return f"{execution_id}#{unit}"


def rev_token(doc_id: str, rev) -> Dict[str, str]:
    return {"subject": doc_id, "version_kind": "rev", "version_value": str(rev)}


class UnitPubHubEffector(ProviderEffector):
    mode = MODE_B

    def __init__(self, hub: UnitHub, tokens: Dict[str, str], lists=None, roles: Optional[Dict[str, str]] = None):
        self.hub, self.tokens, self.lists = hub, tokens, lists
        self.roles = dict(DEFAULT_ROLES if roles is None else roles)
        self.calls = 0

    def authority_handles(self):
        return [self.hub, self.tokens] + list(self.tokens.values())

    def perform(self, credential, operation):
        raise NotImplementedError("unit contract: one unit per operation")

    def _meta(self, credential, unit):
        return {"intent_id": credential.intent_id, "grant_id": credential.grant_id, "unit": unit}

    def perform_unit(self, credential, operation, precondition):
        self.calls += 1
        role = self.roles.get(operation.unit)
        token = self.tokens[credential.principal]
        r, eid = operation.request, credential.execution_id
        key = unit_key(eid, operation.unit)
        if_rev = int(precondition.version_value) if precondition is not None else None
        try:
            if role == "publish":
                doc = self.hub.publish(token, r["document_ref"], mapping.visibility_for(r["audience"], self.lists),
                                       if_rev, key, self._meta(credential, operation.unit))
                est = rev_token(doc["id"], doc["rev"]) if self.hub.expose_versions else None
                return ExecutionResult(EXEC_SUCCESS, eid, key, dict(r), [PUBLISHED], established_state=est)
            if role == "notify":
                self.hub.notify_if(token, mapping.list_for(r["audience"], self.lists), r["document_ref"], key,
                                   if_rev, self._meta(credential, operation.unit))
                rev = self.hub.docs[r["document_ref"]]["rev"]
                est = rev_token(r["document_ref"], rev) if self.hub.expose_versions else None
                return ExecutionResult(EXEC_SUCCESS, eid, key, dict(r), [NOTIFIED], established_state=est)
        except PubHubError as e:
            if "412" in str(e):
                raise PreconditionFailed(str(e))
            raise
        raise NotImplementedError(f"unit {operation.unit!r} is not a PubHub unit")
