"""N1 evidence source: Folio's own record for the execution's client_token, translated
to the protocol vocabulary at the newcomer boundary. Never sees the adapter's report."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import EvidenceSource
from aaap.objects import PROVIDER_AUTHORITY, ExecutionEvidence

from . import mapping
from .provider import FakeFolio


class FolioRecordObserver(EvidenceSource):
    identity = "folio.example/rename-record"

    def __init__(self, folio: FakeFolio, tokens: Dict[str, str]):
        self.folio = folio
        self.tokens = tokens

    def observe(self, intent, grant):
        rec = self.folio.record(self.tokens[intent.principal], intent.execution_id)
        if rec is None:
            return None
        subject = mapping.to_protocol_ref(rec["ref"])
        applied = ({} if rec["if_revision"] is None else
                   {"subject": subject, "version_kind": "revision", "version_value": str(rec["if_revision"])})
        return ExecutionEvidence(
            evidence_id=f"{self.identity}:{intent.execution_id}", execution_id=intent.execution_id,
            intent_id=rec["metadata"].get("intent_id"), source_identity=self.identity, provenance=PROVIDER_AUTHORITY,
            observed_subject=subject, observed_state=mapping.normalize(rec["result"]),
            observed_effects=tuple(rec["effects"]), applied_precondition=applied)
