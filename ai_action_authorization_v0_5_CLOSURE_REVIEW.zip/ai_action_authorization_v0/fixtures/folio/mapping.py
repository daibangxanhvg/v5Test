"""N1 newcomer boundary: the ONLY place that knows both the protocol vocabulary and
Folio's wire representation. Nothing outside fixtures/folio imports it."""
from __future__ import annotations

from typing import Any, Dict


class MappingError(ValueError):
    pass


def to_provider_ref(document_ref: Any) -> str:
    """protocol "doc-42"  ->  provider "FD-0042". Anything else is not mappable (fail closed)."""
    if not isinstance(document_ref, str) or not document_ref.startswith("doc-"):
        raise MappingError(f"not a Folio document reference: {document_ref!r}")
    num = document_ref[len("doc-"):]
    if not num.isdigit() or str(int(num)) != num:
        raise MappingError(f"non-canonical document number: {document_ref!r}")
    return f"FD-{int(num):04d}"


def to_protocol_ref(provider_ref: str) -> str:
    return f"doc-{int(provider_ref[len('FD-'):])}"


def normalize(doc: Dict[str, Any]) -> Dict[str, Any]:
    """Provider document -> protocol facts / observed state."""
    a = doc["attributes"]
    return {"document_ref": to_protocol_ref(doc["ref"]), "display_name": a["displayName"], "owner": a["owner"],
            "folder": a["folder"], "locked": a["locked"], "revision": str(doc["rev"])}


def to_wire(request: Dict[str, Any]) -> Dict[str, Any]:
    """Protocol request (plan vocabulary) -> Folio rename body."""
    return {"ref": to_provider_ref(request["document_ref"]),
            "body": {"attributes": {"displayName": request["display_name"]}}}


def binding_to_wire(version_value: str) -> int:
    """Opaque protocol version token -> Folio's integer revision."""
    if not version_value.isdigit():
        raise MappingError(f"not a Folio revision: {version_value!r}")
    return int(version_value)
