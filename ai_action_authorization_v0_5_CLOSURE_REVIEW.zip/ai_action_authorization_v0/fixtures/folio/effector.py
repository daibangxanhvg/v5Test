"""N1 gateway effector (Mode B). TRUSTED: holds the principal's Folio token, which can
also MOVE documents. Called only after the enforcement boundary accepted the operation.
Translates the protocol request to Folio's wire format; applies the credential's state
binding as `if_revision`."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult, PreconditionFailed
from aaap.authority import MODE_B, ProviderEffector
from aaap.objects import EXEC_SUCCESS

from . import mapping
from .provider import FakeFolio, FolioError

EFFECT = "document_renamed"


class FolioGatewayEffector(ProviderEffector):
    mode = MODE_B

    def __init__(self, folio: FakeFolio, tokens: Dict[str, str]):
        self.folio = folio
        self.tokens = tokens
        self.calls = 0

    def authority_handles(self):
        return [self.folio, self.tokens] + list(self.tokens.values())

    def perform(self, credential, operation):
        self.calls += 1
        if operation.capability != "rename_document" or EFFECT not in credential.effects:
            raise NotImplementedError(operation.capability)
        sb = credential.state_binding
        wire = mapping.to_wire(operation.request)
        try:
            doc = self.folio.rename(self.tokens[credential.principal], wire["ref"], wire["body"],
                                    mapping.binding_to_wire(sb.version_value) if sb else None,
                                    client_token=operation.execution_id, metadata={"intent_id": credential.intent_id})
        except FolioError as e:
            if "409" in str(e):
                raise PreconditionFailed(str(e))
            raise
        return ExecutionResult(EXEC_SUCCESS, operation.execution_id, doc["ref"], dict(operation.request), [EFFECT])
