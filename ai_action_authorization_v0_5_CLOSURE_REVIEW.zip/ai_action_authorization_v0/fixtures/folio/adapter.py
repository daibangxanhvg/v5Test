from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult, PreconditionFailed, ProviderAdapter
from aaap.objects import EXEC_SUCCESS, StateBinding

from . import mapping
from .provider import FakeFolio, FolioError


class FolioAdapter(ProviderAdapter):
    """Gateway-side reader (and legacy-path executor) for N1. All Folio wire knowledge
    is in mapping.py; the protocol only ever sees the normalized vocabulary."""

    def __init__(self, folio: FakeFolio, tokens: Dict[str, str]):
        self.folio = folio
        self.tokens = tokens

    def resolve(self, intent):
        ref = mapping.to_provider_ref(intent.arguments["document_id"])
        return mapping.normalize(self.folio.get(self.tokens[intent.principal], ref))

    def plan(self, intent, facts):
        a = intent.arguments
        return {"document_ref": a["document_id"], "display_name": a["new_name"]}

    def state_binding(self, intent, facts):
        return StateBinding(subject=facts["document_ref"], version_kind="revision", version_value=facts["revision"])

    def _rename(self, intent, plan, if_revision):
        wire = mapping.to_wire(plan)
        doc = self.folio.rename(self.tokens[intent.principal], wire["ref"], wire["body"], if_revision,
                                client_token=intent.execution_id, metadata={"intent_id": intent.intent_id})
        return ExecutionResult(EXEC_SUCCESS, intent.execution_id, doc["ref"], dict(plan), ["document_renamed"])

    def execute(self, intent, plan):
        return self._rename(intent, plan, None)

    def execute_conditional(self, intent, plan, precondition):
        try:
            return self._rename(intent, plan, mapping.binding_to_wire(precondition.version_value))
        except FolioError as e:
            if "409" in str(e):
                raise PreconditionFailed(str(e))
            raise

    def read_back(self, intent, result):
        return mapping.normalize(self.folio.get(self.tokens[intent.principal],
                                                mapping.to_provider_ref(result.request["document_ref"])))
