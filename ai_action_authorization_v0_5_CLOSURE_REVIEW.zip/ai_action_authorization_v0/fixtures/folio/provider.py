"""N1 newcomer provider "Folio": an in-memory document store whose wire format is
deliberately unlike the protocol's vocabulary and unlike the three V0 providers.

- documents are addressed by provider refs "FD-0042" (the protocol says "doc-42");
- the name lives at body["attributes"]["displayName"];
- the version is an INTEGER revision, sent as `if_revision=<int>`;
- the idempotency key is called `client_token`.

A rename sent with if_revision is applied only if the revision is still current
(checked and applied in one step). The provider keeps a record per client_token.
"""
from __future__ import annotations

import copy
from typing import Dict, Optional


class FolioError(Exception):
    pass


class FakeFolio:
    def __init__(self) -> None:
        self.tokens: Dict[str, str] = {}
        self.docs: Dict[str, dict] = {}
        self._records: Dict[str, dict] = {}
        self.rename_calls = 0
        self.move_calls = 0

    def add(self, ref: str, display_name: str, owner: str, folder: str, locked: bool = False, rev: int = 17) -> None:
        self.docs[ref] = {"ref": ref, "rev": rev,
                          "attributes": {"displayName": display_name, "owner": owner, "folder": folder,
                                         "locked": locked}}

    def _auth(self, token: str) -> str:
        if token not in self.tokens:
            raise FolioError("401 unauthenticated")
        return self.tokens[token]

    def get(self, token: str, ref: str) -> dict:
        self._auth(token)
        if ref not in self.docs:
            raise FolioError("404 no such document")
        return copy.deepcopy(self.docs[ref])

    def rename(self, token: str, ref: str, body: dict, if_revision: Optional[int], client_token: str,
               metadata: Optional[dict] = None) -> dict:
        caller = self._auth(token)
        self.rename_calls += 1
        if client_token in self._records:
            return copy.deepcopy(self._records[client_token]["result"])
        doc = self.docs.get(ref)
        if doc is None:
            raise FolioError("404 no such document")
        if if_revision is not None and if_revision != doc["rev"]:
            raise FolioError("409 revision_conflict")
        doc["attributes"]["displayName"] = body["attributes"]["displayName"]
        doc["rev"] += 1
        self._records[client_token] = {"ref": ref, "caller": caller, "if_revision": if_revision,
                                       "metadata": dict(metadata or {}), "effects": ["document_renamed"],
                                       "result": copy.deepcopy(doc)}
        return copy.deepcopy(doc)

    def move(self, token: str, ref: str, folder: str) -> None:
        """Broad authority the rename credential must not reach."""
        self._auth(token)
        self.move_calls += 1
        self.docs[ref]["attributes"]["folder"] = folder
        self.docs[ref]["rev"] += 1

    def external_edit(self, ref: str, **attributes) -> None:
        """Somebody else edits the document (bumps the revision)."""
        self.docs[ref]["attributes"].update(attributes)
        self.docs[ref]["rev"] += 1

    def record(self, token: str, client_token: str) -> Optional[dict]:
        caller = self._auth(token)
        rec = self._records.get(client_token)
        return copy.deepcopy(rec) if rec and rec["caller"] == caller else None
