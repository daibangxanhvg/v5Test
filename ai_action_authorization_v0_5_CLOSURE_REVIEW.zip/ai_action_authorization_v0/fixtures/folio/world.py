"""N1 wiring. Uses an issuer-qualified contract address (V0.3), so another issuer may use
the same local contract id without collision."""
from __future__ import annotations

from aaap import PROVIDER_AUTHORITY, ActionIntent, ConfinedExecutor, Delegation, qualified_contract_id

from tests.harness import load_contract, make_core

from .adapter import FolioAdapter
from .effector import FolioGatewayEffector
from .observer import FolioRecordObserver
from .provider import FakeFolio

ISSUER = "folio.example"
LOCAL_ID = "docs.rename_document"
ADDRESS = qualified_contract_id(ISSUER, LOCAL_ID)
TOKENS = {"lam": "tok-lam-folio"}
FOLDERS = [{"id": "allowed_folder", "params": {"allowed": ["shared"]}}]


def pin(contract, address=ADDRESS) -> dict:
    return {"contract_id": address, "capability": contract.capability, "contract_version": contract.version,
            "contract_digest": contract.binding_digest()}


def delegation(did, contract, constraints=None, authority=("docs.write",), address=ADDRESS,
               valid_until="2026-11-01T00:00:00+07:00") -> Delegation:
    return Delegation(delegation_id=did, principal="lam", agent="agent-1", allowed_authority=list(authority),
                      allowed_capabilities=[pin(contract, address)],
                      constraints=list(FOLDERS if constraints is None else constraints),
                      valid_from="2026-10-01T00:00:00+07:00", valid_until=valid_until)


def build(core=None, contract=None, observe=True, delegation_id="dlg-folio-1"):
    core = core or make_core()
    folio = FakeFolio()
    folio.tokens["tok-lam-folio"] = "lam"
    folio.add("FD-0042", "Q3 draft", owner="lam", folder="shared")
    folio.add("FD-0043", "Payroll", owner="lam", folder="private-hr")
    contract = contract or load_contract("folio", "contract_v1.json")
    core.contracts.trust_issuer(LOCAL_ID, ISSUER)
    core.contracts.publish(contract, authenticated_issuer=ISSUER)
    core.delegations.issue(delegation(delegation_id, contract))
    core.gateway.register_adapter(ADDRESS, FolioAdapter(folio, TOKENS))
    if observe:
        core.gateway.register_evidence_source(ADDRESS, FolioRecordObserver(folio, TOKENS), PROVIDER_AUTHORITY,
                                              effects=("document_renamed",))
    return core, folio, contract


def build_confined(core=None, executor=None, **kw):
    core, folio, contract = build(core, **kw)
    effector = FolioGatewayEffector(folio, TOKENS)
    core.gateway.authority.register_effector(ADDRESS, effector)
    core.gateway.register_executor(ADDRESS, executor or ConfinedExecutor("agent-1"))
    return core, folio, contract, effector


def intent(document_id="doc-42", new_name="Q3 report (final)", execution_id="exec-n1-1", intent_id="int-n1-1",
           address=ADDRESS):
    return ActionIntent(intent_id=intent_id, agent="agent-1", principal="lam", contract_id=address,
                        capability="rename_document",
                        arguments={"document_id": document_id, "new_name": new_name}, execution_id=execution_id)
