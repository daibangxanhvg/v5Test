"""FakePay gateway effector (V0.2, Mode B). TRUSTED: holds the principal's API
token, which can pay ANY recipient any amount up to the balance. Called only
after the enforcement boundary accepted the operation. Applies the credential's
state binding as the account-revision precondition."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult, PreconditionFailed, ProviderTimeout
from aaap.authority import MODE_B, ProviderEffector
from aaap.objects import EXEC_SUCCESS

from .provider import FakePay, NetworkTimeout, PaymentError


class FakePayGatewayEffector(ProviderEffector):
    mode = MODE_B

    def __init__(self, pay: FakePay, tokens: Dict[str, str]):
        self.pay = pay
        self.tokens = tokens
        self.calls = 0

    def authority_handles(self):
        return [self.pay, self.tokens] + list(self.tokens.values())

    def perform(self, credential, operation):
        self.calls += 1
        if operation.capability != "transfer_money":
            raise NotImplementedError(operation.capability)
        r = operation.request
        sb = credential.state_binding
        try:
            tx = self.pay.transfer(self.tokens[credential.principal], r["recipient"], r["amount"], r["currency"],
                                   idempotency_key=operation.execution_id,
                                   if_match=sb.version_value if sb else None,
                                   metadata={"intent_id": credential.intent_id})
        except NetworkTimeout as e:
            raise ProviderTimeout(str(e))
        except PaymentError as e:
            if str(e) == "precondition_failed":
                raise PreconditionFailed(str(e))
            raise
        return ExecutionResult(EXEC_SUCCESS, operation.execution_id, tx["tx_id"],
                               {"recipient": tx["recipient"], "amount": tx["amount"], "currency": tx["currency"]},
                               list(tx["effects"]))
