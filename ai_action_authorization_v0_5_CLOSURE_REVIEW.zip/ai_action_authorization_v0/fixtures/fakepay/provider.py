"""FakePay: in-memory payment provider with Stripe-style idempotency keys.

V0.1: every account has a revision that changes on every balance movement.
A transfer sent with `if_match=<payer account version>` commits only if the
payer account is still at that version (checked and committed in one step);
otherwise nothing moves. Transactions keep client `metadata` and the
`if_match` they were committed under."""
from __future__ import annotations

import copy
import itertools
from typing import Dict, List, Optional


class PaymentError(Exception):
    pass


class NetworkTimeout(Exception):
    """Raised AFTER the transfer committed: the client never sees the response."""


class FakePay:
    def __init__(self, balances: Dict[str, int], currency: str = "VND"):
        self.balances = dict(balances)
        self.currency = currency
        self.tokens: Dict[str, str] = {}
        self.transactions: Dict[str, dict] = {}      # idempotency key -> tx
        self.ledger: List[dict] = []                 # every committed movement
        self.honor_idempotency = True
        self.timeout_after_commit_once = False
        self.extra_effects: List[str] = []           # e.g. a provider that silently draws credit
        self.transfer_calls = 0
        self._seq = itertools.count(1)
        self.revisions: Dict[str, int] = {a: 0 for a in self.balances}

    def _account(self, token: str) -> str:
        if token not in self.tokens:
            raise PaymentError("unauthenticated")
        return self.tokens[token]

    def balance(self, token: str) -> int:
        return self.balances[self._account(token)]

    def account(self, token: str) -> str:
        return self._account(token)

    def account_version(self, token: str) -> str:
        a = self._account(token)
        return f"rev-{self.revisions.get(a, 0)}/{self.balances[a]}"

    def _move(self, account: str, delta: int) -> None:
        self.balances[account] += delta
        self.revisions[account] = self.revisions.get(account, 0) + 1

    def external_debit(self, account: str, amount: int) -> None:
        """Activity on the account from outside this gateway (card payment, other app...)."""
        self._move(account, -amount)

    def transfer(self, token: str, recipient: str, amount: int, currency: str, idempotency_key: str,
                 if_match: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        self.transfer_calls += 1
        payer = self._account(token)
        if self.honor_idempotency and idempotency_key in self.transactions:
            return copy.deepcopy(self.transactions[idempotency_key])
        # compare-and-swap on the payer account: check and commit with nothing in between
        if if_match is not None and if_match != self.account_version(token):
            raise PaymentError("precondition_failed")
        if currency != self.currency:
            raise PaymentError("currency_not_supported")
        if recipient not in self.balances:
            raise PaymentError("unknown_recipient")
        if self.balances[payer] < amount:
            raise PaymentError("insufficient_funds")
        self._move(payer, -amount)
        self._move(recipient, amount)
        tx = {"tx_id": f"tx-{next(self._seq)}", "payer": payer, "recipient": recipient, "amount": amount,
              "currency": currency, "effects": ["money_moved"] + list(self.extra_effects),
              "if_match": if_match, "metadata": dict(metadata or {})}
        self.transactions[idempotency_key] = tx
        self.ledger.append(copy.deepcopy(tx))
        if self.timeout_after_commit_once:
            self.timeout_after_commit_once = False
            raise NetworkTimeout("response lost after commit")
        return copy.deepcopy(tx)

    def get_transaction(self, token: str, idempotency_key: str) -> Optional[dict]:
        payer = self._account(token)
        tx = self.transactions.get(idempotency_key)
        return copy.deepcopy(tx) if tx and tx["payer"] == payer else None
