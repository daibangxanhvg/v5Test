from __future__ import annotations

from aaap import ActionIntent

from tests.harness import delegation, load_contract, make_core

from aaap import PROVIDER_AUTHORITY

from aaap import ConfinedExecutor

from .effector import FakePayGatewayEffector
from .adapter import FakePayAdapter
from .observer import FakePayTransactionObserver
from .provider import FakePay

LIMITS = [{"id": "max_amount", "params": {"max": 500000}},
          {"id": "currency", "params": {"values": ["VND"]}}]


def build(core=None, contract_file="contract_v1.json", delegation_id="dlg-pay-1", observe=True):
    core = core or make_core()
    pay = FakePay({"lam": 1_000_000, "an": 0, "binh": 0})
    pay.tokens["tok-lam"] = "lam"
    contract = load_contract("fakepay", contract_file)
    core.contracts.trust_issuer(contract.contract_id, "fakepay.example.vn")
    core.contracts.publish(contract)
    core.delegations.issue(delegation(delegation_id, "lam", "agent-1", ["financial.transfer"], [contract], LIMITS))
    core.gateway.register_adapter(contract.contract_id, FakePayAdapter(pay, {"lam": "tok-lam"}))
    if observe:
        core.gateway.register_evidence_source(contract.contract_id,
                                              FakePayTransactionObserver(pay, {"lam": "tok-lam"}), PROVIDER_AUTHORITY)
    return core, pay, contract


def intent(recipient="an", amount=400000, currency="VND", execution_id="exec-p-1", intent_id="int-p-1"):
    return ActionIntent(intent_id=intent_id, agent="agent-1", principal="lam", contract_id="fakepay.transfer_money",
                        capability="transfer_money",
                        arguments={"recipient": recipient, "amount": amount, "currency": currency},
                        execution_id=execution_id)


def build_confined(core=None, executor=None, observe=True, **kw):
    """V0.2 Mode B wiring: the gateway keeps the provider token (reader adapter + effector);
    the executor gets nothing but what execute_confined hands it."""
    core, pay, contract = build(core, observe=observe, **kw)
    effector = FakePayGatewayEffector(pay, {"lam": "tok-lam"})
    core.gateway.authority.register_effector(contract.contract_id, effector)
    core.gateway.register_executor(contract.contract_id, executor or ConfinedExecutor("agent-1"))
    return core, pay, contract, effector
