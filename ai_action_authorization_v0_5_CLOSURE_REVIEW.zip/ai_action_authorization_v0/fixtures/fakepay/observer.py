"""FakePay evidence source (V0.1). Separate from the adapter: it looks up the
provider's transaction record by the execution's idempotency key and reads the
payer balance. It never sees what the adapter reported."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import EvidenceSource
from aaap.objects import PROVIDER_AUTHORITY, ExecutionEvidence

from .provider import FakePay


class FakePayTransactionObserver(EvidenceSource):
    identity = "fakepay.example.vn/transactions"

    def __init__(self, pay: FakePay, tokens: Dict[str, str]):
        self.pay = pay
        self.tokens = tokens

    def observe(self, intent, grant):
        token = self.tokens[intent.principal]
        tx = self.pay.get_transaction(token, intent.execution_id)
        if tx is None:
            return None
        applied = ({} if tx["if_match"] is None else
                   {"subject": tx["payer"], "version_kind": "account_revision", "version_value": tx["if_match"]})
        return ExecutionEvidence(
            evidence_id=f"{self.identity}:{tx['tx_id']}", execution_id=intent.execution_id,
            intent_id=tx["metadata"].get("intent_id"), source_identity=self.identity, provenance=PROVIDER_AUTHORITY,
            observed_subject=tx["recipient"],
            observed_state={"recipient": tx["recipient"], "amount": tx["amount"], "currency": tx["currency"],
                            "payer_balance": self.pay.balance(token)},
            observed_effects=tuple(tx["effects"]), applied_precondition=applied)
