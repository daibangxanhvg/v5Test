from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult, PreconditionFailed, ProviderAdapter, ProviderTimeout
from aaap.objects import EXEC_SUCCESS, StateBinding

from .provider import FakePay, NetworkTimeout, PaymentError


class FakePayAdapter(ProviderAdapter):
    def __init__(self, pay: FakePay, tokens: Dict[str, str]):
        self.pay = pay
        self.tokens = tokens  # principal -> API token; the payer is whoever the token belongs to

    def resolve(self, intent):
        token = self.tokens[intent.principal]
        return {"payer_balance": self.pay.balance(token), "payer_account": self.pay.account(token),
                "payer_account_version": self.pay.account_version(token)}

    def state_binding(self, intent, facts):
        return StateBinding(subject=facts["payer_account"], version_kind="account_revision",
                            version_value=facts["payer_account_version"])

    def plan(self, intent, facts):
        a = intent.arguments
        return {"recipient": a["recipient"], "amount": a["amount"], "currency": a["currency"]}

    def _result(self, intent, tx):
        return ExecutionResult(EXEC_SUCCESS, intent.execution_id, tx["tx_id"],
                               {"recipient": tx["recipient"], "amount": tx["amount"], "currency": tx["currency"]},
                               list(tx["effects"]))

    def execute(self, intent, plan, if_match=None):
        try:
            tx = self.pay.transfer(self.tokens[intent.principal], plan["recipient"], plan["amount"],
                                   plan["currency"], idempotency_key=intent.execution_id,
                                   if_match=if_match, metadata={"intent_id": intent.intent_id})
        except NetworkTimeout as e:
            raise ProviderTimeout(str(e))
        except PaymentError as e:
            if str(e) == "precondition_failed":
                raise PreconditionFailed(str(e))
            raise
        return self._result(intent, tx)

    def execute_conditional(self, intent, plan, precondition):
        return self.execute(intent, plan, if_match=precondition.version_value)

    def read_back(self, intent, result):
        token = self.tokens[intent.principal]
        tx = self.pay.get_transaction(token, intent.execution_id)
        if tx is None:
            return None
        return {"recipient": tx["recipient"], "amount": tx["amount"], "currency": tx["currency"],
                "payer_balance": self.pay.balance(token)}

    def lookup(self, intent):
        tx = self.pay.get_transaction(self.tokens[intent.principal], intent.execution_id)
        return self._result(intent, tx) if tx else None
