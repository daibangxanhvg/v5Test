from __future__ import annotations

from aaap.adapter import EvidenceSource
from aaap.objects import PROVIDER_AUTHORITY, ExecutionEvidence

from .effector import key


class TriRecordObserver(EvidenceSource):
    def __init__(self, store, tokens, unit):
        self.store, self.tokens, self.unit = store, tokens, unit
        self.identity = f"triad.example/record/{unit}"

    def observe(self, intent, grant):
        rec = self.store.record(self.tokens[intent.principal], key(intent.execution_id, self.unit))
        if rec is None:
            return None
        if rec["op"] == "op_z":
            state, ust = {"tag": rec["state"]["tag"]}, {"applied": None, "established": None}
        else:
            subj = rec["subject"]
            state = {"cell": subj, "value": rec["state"]["v"]}
            tok = lambda v: {"subject": subj, "version_kind": "ver", "version_value": str(v)}
            ust = {"applied": {} if rec["if_ver"] is None else tok(rec["if_ver"]), "established": tok(rec["state"]["ver"])}
        return ExecutionEvidence(
            evidence_id=f"{self.identity}:{intent.execution_id}", execution_id=intent.execution_id,
            intent_id=rec["metadata"].get("intent_id"), source_identity=self.identity, provenance=PROVIDER_AUTHORITY,
            observed_subject=rec["subject"], observed_state=state, observed_effects=tuple(rec["effects"]),
            covers_units=(rec["metadata"].get("unit"),), grant_id=rec["metadata"].get("grant_id"),
            unit_states={rec["metadata"].get("unit"): ust})
