"""B2 wiring: a synthetic domain with three opaque required units on one gateway core."""
from __future__ import annotations

from aaap import PROVIDER_AUTHORITY, ActionIntent, ConfinedExecutor, Delegation, qualified_contract_id

from tests.harness import load_contract, make_core

from .adapter import TriAdapter
from .effector import TriEffector
from .observer import TriRecordObserver
from .provider import TriStore

ISSUER, LOCAL_ID = "triad.example", "x.apply"
ADDRESS = qualified_contract_id(ISSUER, LOCAL_ID)
TOKENS = {"lam": "tok-lam-tri"}
DID = "dlg-tri-1"
UNITS = ("a1", "b2", "c3")


def build_confined(core=None, contract=None, observers=UNITS, executor=None):
    core = core or make_core()
    store = TriStore()
    store.tokens["tok-lam-tri"] = "lam"
    store.cells["k-1"] = {"v": "old", "ver": 3}
    contract = contract or load_contract("triad", "contract_v1.json")
    core.contracts.trust_issuer(LOCAL_ID, ISSUER)
    core.contracts.publish(contract, authenticated_issuer=ISSUER)
    core.delegations.issue(Delegation(
        delegation_id=DID, principal="lam", agent="agent-1", allowed_authority=["x.write"],
        allowed_capabilities=[{"contract_id": ADDRESS, "capability": contract.capability,
                               "contract_version": contract.version, "contract_digest": contract.binding_digest()}],
        constraints=[], valid_from="2026-10-01T00:00:00+07:00", valid_until="2026-11-01T00:00:00+07:00"))
    core.gateway.register_adapter(ADDRESS, TriAdapter(store, TOKENS))
    for u in observers:
        core.gateway.register_evidence_source(ADDRESS, TriRecordObserver(store, TOKENS, u), PROVIDER_AUTHORITY,
                                              units=(u,))
    eff = TriEffector(store, TOKENS)
    core.gateway.authority.register_effector(ADDRESS, eff)
    core.gateway.register_executor(ADDRESS, executor or ConfinedExecutor("agent-1"))
    return core, store, contract, eff


def intent(execution_id="exec-tri-1", intent_id="int-tri-1", value="new", tag="t-9"):
    return ActionIntent(intent_id=intent_id, agent="agent-1", principal="lam", contract_id=ADDRESS,
                        capability="x_apply", arguments={"cell": "k-1", "value": value, "tag": tag},
                        execution_id=execution_id)
