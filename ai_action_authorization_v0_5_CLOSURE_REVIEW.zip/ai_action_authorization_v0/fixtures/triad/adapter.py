from __future__ import annotations

from aaap.adapter import ProviderAdapter
from aaap.objects import StateBinding


class TriAdapter(ProviderAdapter):
    """Gateway-side reader (resolve / plan / state binding / read-back). Executes nothing."""

    def __init__(self, store, tokens):
        self.store, self.tokens = store, tokens

    def resolve(self, intent):
        c = self.store.get(self.tokens[intent.principal], intent.arguments["cell"])
        return {"cell": intent.arguments["cell"], "v": c["v"], "ver": str(c["ver"])}

    def plan(self, intent, facts):
        a = intent.arguments
        return {"cell": a["cell"], "value": a["value"], "tag": a["tag"]}

    def state_binding(self, intent, facts):
        return StateBinding(subject=facts["cell"], version_kind="ver", version_value=facts["ver"])

    def read_back(self, intent, result):
        c = self.store.get(self.tokens[intent.principal], intent.arguments["cell"])
        return {"cell": intent.arguments["cell"], "value": c["v"]}
