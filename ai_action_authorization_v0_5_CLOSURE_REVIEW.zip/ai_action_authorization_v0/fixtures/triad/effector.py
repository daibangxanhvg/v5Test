"""B2 Mode B effector: unit id -> TriStore operation (provider-side table)."""
from __future__ import annotations

from aaap.adapter import ExecutionResult, PreconditionFailed
from aaap.authority import MODE_B, ProviderEffector
from aaap.objects import EXEC_SUCCESS

from .provider import TriError

ROLES = {"a1": "op_k", "b2": "op_m", "c3": "op_z"}


def key(eid, unit):
    return f"{eid}#{unit}"


class TriEffector(ProviderEffector):
    mode = MODE_B

    def __init__(self, store, tokens, roles=None):
        self.store, self.tokens, self.roles = store, tokens, dict(roles or ROLES)

    def authority_handles(self):
        return [self.store, self.tokens] + list(self.tokens.values())

    def perform_unit(self, credential, operation, precondition):
        tok, r, u = self.tokens[credential.principal], operation.request, operation.unit
        k = key(credential.execution_id, u)
        meta = {"intent_id": credential.intent_id, "grant_id": credential.grant_id, "unit": u}
        ver = int(precondition.version_value) if precondition is not None else None
        role = self.roles.get(u)
        try:
            if role == "op_k":
                self.store.op_k(tok, r["cell"], r["value"], ver, k, meta)
            elif role == "op_m":
                self.store.op_m(tok, r["cell"], ver, k, meta)
            elif role == "op_z":
                self.store.op_z(tok, r["tag"], k, meta)
            else:
                raise NotImplementedError(u)
        except TriError as e:
            if "409" in str(e):
                raise PreconditionFailed(str(e))
            raise
        rec = self.store.record(tok, k)
        est = None
        if role in ("op_k", "op_m"):
            est = {"subject": r["cell"], "version_kind": "ver", "version_value": str(rec["state"]["ver"])}
        return ExecutionResult(EXEC_SUCCESS, credential.execution_id, k, dict(r), list(rec["effects"]),
                               established_state=est)
