"""B2 synthetic newcomer "TriStore": three unrelated provider operations, deliberately meaningless.

- op_k(cell, value, if_ver): set a cell's value (CAS on `ver`, which then increments);
- op_m(cell, if_ver): seal a cell (CAS on `ver`, which then increments);
- op_z(tag): append a tag to a journal (no versioned state).
Every call records (operation, caller, metadata, effect label) under its idempotency key."""
from __future__ import annotations

import copy
from typing import Dict, List, Optional


class TriError(Exception):
    pass


class TriStore:
    def __init__(self) -> None:
        self.tokens: Dict[str, str] = {}
        self.cells: Dict[str, dict] = {}
        self.journal: List[str] = []
        self._records: Dict[str, dict] = {}
        self.calls = {"op_k": 0, "op_m": 0, "op_z": 0}

    def _auth(self, token):
        if token not in self.tokens:
            raise TriError("401")
        return self.tokens[token]

    def get(self, token, cell):
        self._auth(token)
        return copy.deepcopy(self.cells[cell])

    def _cas(self, cell, if_ver):
        if if_ver is not None and if_ver != self.cells[cell]["ver"]:
            raise TriError("409 version")

    def _rec(self, key, caller, op, subject, label, meta, if_ver, state):
        self._records[key] = {"op": op, "caller": caller, "subject": subject, "effects": [label],
                              "metadata": dict(meta or {}), "if_ver": if_ver, "state": copy.deepcopy(state)}

    def op_k(self, token, cell, value, if_ver: Optional[int], key, meta=None):
        caller = self._auth(token)
        self.calls["op_k"] += 1
        if key in self._records:
            return
        self._cas(cell, if_ver)
        self.cells[cell].update(v=value, ver=self.cells[cell]["ver"] + 1)
        self._rec(key, caller, "op_k", cell, "x.e1", meta, if_ver, self.cells[cell])

    def op_m(self, token, cell, if_ver: Optional[int], key, meta=None):
        caller = self._auth(token)
        self.calls["op_m"] += 1
        if key in self._records:
            return
        self._cas(cell, if_ver)
        self.cells[cell].update(sealed=True, ver=self.cells[cell]["ver"] + 1)
        self._rec(key, caller, "op_m", cell, "x.e2", meta, if_ver, self.cells[cell])

    def op_z(self, token, tag, key, meta=None):
        caller = self._auth(token)
        self.calls["op_z"] += 1
        if key in self._records:
            return
        self.journal.append(tag)
        self._rec(key, caller, "op_z", tag, "x.e3", meta, None, {"tag": tag})

    def record(self, token, key):
        caller = self._auth(token)
        rec = self._records.get(key)
        return copy.deepcopy(rec) if rec and rec["caller"] == caller else None
