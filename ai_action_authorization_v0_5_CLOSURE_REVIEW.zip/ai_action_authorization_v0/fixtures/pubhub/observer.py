"""N2 evidence sources, one per sub-effect, each reading PubHub's own record:
- PublishRecordObserver: the publish request record (key = execution_id);
- NotificationObserver: the notification record (key = execution_id + ":notify").
Each is registered with an effect scope, so one cannot attest to the other's effect."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import EvidenceSource
from aaap.objects import PROVIDER_AUTHORITY, ExecutionEvidence

from . import mapping
from .provider import FakePubHub


def _applied(subject, if_rev):
    return {} if if_rev is None else {"subject": subject, "version_kind": "rev", "version_value": str(if_rev)}


class PublishRecordObserver(EvidenceSource):
    identity = "pubhub.example/publish-record"

    def __init__(self, hub: FakePubHub, tokens: Dict[str, str]):
        self.hub, self.tokens = hub, tokens

    def observe(self, intent, grant):
        rec = self.hub.record(self.tokens[intent.principal], intent.execution_id)
        if rec is None:
            return None
        return ExecutionEvidence(
            evidence_id=f"{self.identity}:{intent.execution_id}", execution_id=intent.execution_id,
            intent_id=rec["metadata"].get("intent_id"), source_identity=self.identity, provenance=PROVIDER_AUTHORITY,
            observed_subject=rec["doc"], observed_state=mapping.normalize(rec["result"]),
            observed_effects=tuple(rec["effects"]), applied_precondition=_applied(rec["doc"], rec["if_rev"]))


class NotificationObserver(EvidenceSource):
    identity = "pubhub.example/notification-record"

    def __init__(self, hub: FakePubHub, tokens: Dict[str, str], lists=None):
        self.hub, self.tokens, self.lists = hub, tokens, lists

    def observe(self, intent, grant):
        rec = self.hub.record(self.tokens[intent.principal], intent.execution_id + ":notify")
        if rec is None:
            return None
        state = {"document_ref": rec["doc"], "audience": mapping.audience_of_list(rec["list"], self.lists),
                 "recipients": rec["result"]["recipients"]}
        return ExecutionEvidence(
            evidence_id=f"{self.identity}:{intent.execution_id}", execution_id=intent.execution_id,
            intent_id=rec["metadata"].get("intent_id"), source_identity=self.identity, provenance=PROVIDER_AUTHORITY,
            observed_subject=rec["doc"], observed_state=state, observed_effects=tuple(rec["effects"]),
            # the notify was chained by the provider to the publish that ran under the binding
            applied_precondition=_applied(rec["doc"], rec["root_if_rev"]))
