from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult, PreconditionFailed, ProviderAdapter
from aaap.objects import EXEC_PARTIAL, EXEC_SUCCESS, StateBinding

from . import mapping
from .provider import FakePubHub, PubHubError


class PubHubAdapter(ProviderAdapter):
    """Gateway-side reader for N2 (and the legacy, NOT_CONFINED executor)."""

    def __init__(self, hub: FakePubHub, tokens: Dict[str, str], lists=None):
        self.hub = hub
        self.tokens = tokens
        self.lists = lists

    def resolve(self, intent):
        return mapping.normalize(self.hub.get(self.tokens[intent.principal], intent.arguments["document_id"]))

    def plan(self, intent, facts):
        a = intent.arguments
        mapping.list_for(a["audience"], self.lists)          # ambiguous audience => no plan => DENY
        return {"document_ref": a["document_id"], "audience": a["audience"]}

    def state_binding(self, intent, facts):
        return StateBinding(subject=facts["document_ref"], version_kind="rev", version_value=facts["revision"])

    def execute(self, intent, plan):
        return self.execute_conditional(intent, plan, None)

    def execute_conditional(self, intent, plan, precondition):
        token = self.tokens[intent.principal]
        eid = intent.execution_id
        try:
            self.hub.publish(token, plan["document_ref"], mapping.visibility_for(plan["audience"], self.lists),
                             int(precondition.version_value) if precondition else None, eid,
                             {"intent_id": intent.intent_id})
        except PubHubError as e:
            if "412" in str(e):
                raise PreconditionFailed(str(e))
            raise
        try:
            self.hub.notify(token, mapping.list_for(plan["audience"], self.lists), plan["document_ref"],
                            eid + ":notify", chained_to=eid, metadata={"intent_id": intent.intent_id})
        except PubHubError as e:
            return ExecutionResult(EXEC_PARTIAL, eid, eid, dict(plan), ["document_published"], f"notify: {e}")
        return ExecutionResult(EXEC_SUCCESS, eid, eid, dict(plan), ["document_published", "external_notification_sent"])

    def read_back(self, intent, result):
        return mapping.normalize(self.hub.get(self.tokens[intent.principal], result.request["document_ref"]))
