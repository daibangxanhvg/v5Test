"""N2 gateway effector (Mode B). TRUSTED: holds the PubHub token (which can also notify any
list and unpublish). One authorized operation = two PubHub calls: the split lives HERE,
at the newcomer's provider boundary, not in the protocol core and not in the executor.

- performs only effects in credential.effects (a publish-only credential never notifies);
- publish is conditional on the credential's state binding; notify is chained to that
  publish by the provider (refused if the document changed in between);
- if it stops part-way it reports EXEC_PARTIAL with the effects that did happen, and
  never unpublishes (no invented rollback)."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult, PreconditionFailed
from aaap.authority import MODE_B, ProviderEffector
from aaap.objects import EXEC_PARTIAL, EXEC_SUCCESS

from . import mapping
from .provider import FakePubHub, PubHubError

PUBLISHED, NOTIFIED = "document_published", "external_notification_sent"


class PubHubGatewayEffector(ProviderEffector):
    mode = MODE_B

    def __init__(self, hub: FakePubHub, tokens: Dict[str, str], lists=None):
        self.hub = hub
        self.tokens = tokens
        self.lists = lists
        self.calls = 0

    def authority_handles(self):
        return [self.hub, self.tokens] + list(self.tokens.values())

    def perform(self, credential, operation):
        self.calls += 1
        if operation.capability != "publish_and_notify" or PUBLISHED not in credential.effects:
            raise NotImplementedError(operation.capability)
        token = self.tokens[credential.principal]
        r, eid, sb = operation.request, operation.execution_id, credential.state_binding
        meta = {"intent_id": credential.intent_id}
        try:
            self.hub.publish(token, r["document_ref"], mapping.visibility_for(r["audience"], self.lists),
                             int(sb.version_value) if sb else None, eid, meta)
        except PubHubError as e:
            if "412" in str(e):
                raise PreconditionFailed(str(e))
            raise
        done = [PUBLISHED]
        if NOTIFIED in credential.effects:
            try:
                self.hub.notify(token, mapping.list_for(r["audience"], self.lists), r["document_ref"],
                                eid + ":notify", chained_to=eid, metadata=meta)
                done.append(NOTIFIED)
            except PubHubError as e:
                return ExecutionResult(EXEC_PARTIAL, eid, eid, dict(r), done, f"notify failed: {e}")
        return ExecutionResult(EXEC_SUCCESS, eid, eid, dict(r), done)
