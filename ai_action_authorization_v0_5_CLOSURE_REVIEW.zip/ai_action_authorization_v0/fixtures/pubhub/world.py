"""N2 wiring (issuer-qualified address)."""
from __future__ import annotations

from aaap import PROVIDER_AUTHORITY, ActionIntent, ConfinedExecutor, Delegation, qualified_contract_id

from tests.harness import load_contract, make_core

from .adapter import PubHubAdapter
from .effector import PubHubGatewayEffector
from .observer import NotificationObserver, PublishRecordObserver
from .provider import FakePubHub

ISSUER = "pubhub.example"
LOCAL_ID = "docs.publish_and_notify"
ADDRESS = qualified_contract_id(ISSUER, LOCAL_ID)
TOKENS = {"lam": "tok-lam-pubhub"}
NOW = "2026-10-13T09:31:00+07:00"


def audiences(*values):
    return [{"id": "allowed_audience", "params": {"values": list(values)}}]


def pin(contract, address=ADDRESS) -> dict:
    return {"contract_id": address, "capability": contract.capability, "contract_version": contract.version,
            "contract_digest": contract.binding_digest()}


def delegation(did, contract, constraints=None, authority=("docs.publish",), address=ADDRESS) -> Delegation:
    return Delegation(delegation_id=did, principal="lam", agent="agent-1", allowed_authority=list(authority),
                      allowed_capabilities=[pin(contract, address)],
                      constraints=list(audiences("team") if constraints is None else constraints),
                      valid_from="2026-10-01T00:00:00+07:00", valid_until="2026-11-01T00:00:00+07:00")


def build(core=None, contract_file="contract_v2.json", contract=None, observe=True, observers=("publish", "notify"),
          delegation_id="dlg-pub-1", constraints=None, lists=None):
    core = core or make_core()
    hub = FakePubHub(core.clock)
    hub.tokens["tok-lam-pubhub"] = "lam"
    hub.add("p-7", "Launch plan", visibility="private")
    hub.lists = {"list:team-internal": ["an@example.com", "binh@example.com"],
                 "list:public-subscribers": ["press@example.org", "everyone@example.org"]}
    contract = contract or load_contract("pubhub", contract_file)
    core.contracts.trust_issuer(LOCAL_ID, ISSUER)
    core.contracts.publish(contract, authenticated_issuer=ISSUER)
    core.delegations.issue(delegation(delegation_id, contract, constraints))
    core.gateway.register_adapter(ADDRESS, PubHubAdapter(hub, TOKENS, lists))
    if observe:
        if "publish" in observers:
            core.gateway.register_evidence_source(ADDRESS, PublishRecordObserver(hub, TOKENS), PROVIDER_AUTHORITY,
                                                  effects=("document_published",))
        if "notify" in observers:
            core.gateway.register_evidence_source(ADDRESS, NotificationObserver(hub, TOKENS, lists),
                                                  PROVIDER_AUTHORITY, effects=("external_notification_sent",))
    return core, hub, contract


def build_confined(core=None, executor=None, lists=None, **kw):
    core, hub, contract = build(core, lists=lists, **kw)
    effector = PubHubGatewayEffector(hub, TOKENS, lists)
    core.gateway.authority.register_effector(ADDRESS, effector)
    core.gateway.register_executor(ADDRESS, executor or ConfinedExecutor("agent-1"))
    return core, hub, contract, effector


def intent(document_id="p-7", audience="team", execution_id="exec-n2-1", intent_id="int-n2-1", address=ADDRESS):
    return ActionIntent(intent_id=intent_id, agent="agent-1", principal="lam", contract_id=address,
                        capability="publish_and_notify",
                        arguments={"document_id": document_id, "audience": audience}, execution_id=execution_id)
