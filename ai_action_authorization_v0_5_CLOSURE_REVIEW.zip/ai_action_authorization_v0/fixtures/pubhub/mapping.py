"""N2 newcomer boundary: protocol audience  <->  PubHub visibility + mailing list.

A protocol audience must map to EXACTLY one PubHub list. Zero or several candidates is
an ambiguous mapping: refused (fail closed), never resolved by similarity."""
from __future__ import annotations

from typing import Dict, Tuple


class AmbiguousMapping(ValueError):
    pass


# PubHub list -> (visibility it implies, protocol audiences it is declared to serve)
LISTS: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    "list:team-internal": ("team", ("team",)),
    "list:public-subscribers": ("public", ("public",)),
}


def list_for(audience: str, lists: Dict[str, Tuple[str, Tuple[str, ...]]] = None) -> str:
    lists = LISTS if lists is None else lists
    candidates = sorted(name for name, (_, serves) in lists.items() if audience in serves)
    if len(candidates) != 1:
        raise AmbiguousMapping(f"audience {audience!r} maps to {candidates}")
    return candidates[0]


def visibility_for(audience: str, lists=None) -> str:
    return (LISTS if lists is None else lists)[list_for(audience, lists)][0]


def audience_of_list(list_name: str, lists=None) -> str:
    serves = (LISTS if lists is None else lists)[list_name][1]
    if len(serves) != 1:
        raise AmbiguousMapping(list_name)
    return serves[0]


def normalize(doc: dict) -> dict:
    return {"document_ref": doc["id"], "audience": doc["visibility"], "visibility": doc["visibility"],
            "title": doc["title"], "revision": str(doc["rev"]), "last_private_at": doc["last_private_at"]}
