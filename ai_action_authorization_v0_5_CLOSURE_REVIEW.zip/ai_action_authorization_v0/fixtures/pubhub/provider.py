"""N2 newcomer provider "PubHub": publishing plus external notification, as TWO wire calls.

- publish(doc, visibility, if_rev, key): sets visibility; compare-and-swap on `rev`.
- notify(list, doc, key, chained_to): sends an external notification to a mailing list.
  `chained_to` names the publish request it follows; the provider refuses the notify if
  the document changed since that publish (provider-side chaining of the two steps).
- unpublish exists (broad authority) but nothing in the protocol ever calls it.

Each call keeps a record under its idempotency key.
"""
from __future__ import annotations

import copy
from typing import Callable, Dict, List, Optional


class PubHubError(Exception):
    pass


class FakePubHub:
    def __init__(self, clock: Callable[[], object]) -> None:
        self.clock = clock
        self.tokens: Dict[str, str] = {}
        self.docs: Dict[str, dict] = {}
        self.lists: Dict[str, List[str]] = {}
        self.outbox: List[dict] = []
        self._records: Dict[str, dict] = {}
        self.publish_calls = self.notify_calls = self.unpublish_calls = 0
        self.fail_notify: Optional[str] = None      # misbehaviour switch for T4
        self.before_notify: Optional[Callable[[], None]] = None   # something happens between the two calls

    def _auth(self, token: str) -> str:
        if token not in self.tokens:
            raise PubHubError("401")
        return self.tokens[token]

    def add(self, doc_id: str, title: str, visibility: str = "private", rev: int = 5,
            last_private_at: Optional[str] = None) -> None:
        self.docs[doc_id] = {"id": doc_id, "title": title, "visibility": visibility, "rev": rev,
                             "last_private_at": last_private_at}

    def get(self, token: str, doc_id: str) -> dict:
        self._auth(token)
        if doc_id not in self.docs:
            raise PubHubError("404")
        return copy.deepcopy(self.docs[doc_id])

    def publish(self, token: str, doc_id: str, visibility: str, if_rev: Optional[int], key: str,
                metadata: Optional[dict] = None) -> dict:
        caller = self._auth(token)
        self.publish_calls += 1
        if key in self._records:
            return copy.deepcopy(self._records[key]["result"])
        doc = self.docs[doc_id]
        if if_rev is not None and if_rev != doc["rev"]:
            raise PubHubError("412 stale rev")
        if doc["visibility"] == "private" and visibility != "private":
            doc["last_private_at"] = self.clock().isoformat()
        doc["visibility"] = visibility
        doc["rev"] += 1
        self._records[key] = {"kind": "publish", "doc": doc_id, "caller": caller, "if_rev": if_rev,
                              "metadata": dict(metadata or {}), "effects": ["document_published"],
                              "result": copy.deepcopy(doc)}
        return copy.deepcopy(doc)

    def notify(self, token: str, list_name: str, doc_id: str, key: str, chained_to: Optional[str],
               metadata: Optional[dict] = None) -> dict:
        caller = self._auth(token)
        self.notify_calls += 1
        if key in self._records:
            return copy.deepcopy(self._records[key]["result"])
        if self.before_notify:
            self.before_notify()
        if self.fail_notify:
            raise PubHubError(self.fail_notify)
        root = self._records.get(chained_to) if chained_to else None
        if chained_to and (root is None or root["result"]["rev"] != self.docs[doc_id]["rev"]):
            raise PubHubError("412 document changed since publish")
        note = {"list": list_name, "doc": doc_id, "recipients": list(self.lists[list_name])}
        self.outbox.append(note)
        self._records[key] = {"kind": "notify", "doc": doc_id, "caller": caller, "list": list_name,
                              "chained_to": chained_to, "root_if_rev": root["if_rev"] if root else None,
                              "metadata": dict(metadata or {}), "effects": ["external_notification_sent"],
                              "result": copy.deepcopy(note)}
        return copy.deepcopy(note)

    def unpublish(self, token: str, doc_id: str) -> None:
        self._auth(token)
        self.unpublish_calls += 1
        self.docs[doc_id]["visibility"] = "private"
        self.docs[doc_id]["rev"] += 1

    def external_edit(self, doc_id: str, **fields) -> None:
        self.docs[doc_id].update(fields)
        self.docs[doc_id]["rev"] += 1

    def record(self, token: str, key: str) -> Optional[dict]:
        caller = self._auth(token)
        rec = self._records.get(key)
        return copy.deepcopy(rec) if rec and rec["caller"] == caller else None
