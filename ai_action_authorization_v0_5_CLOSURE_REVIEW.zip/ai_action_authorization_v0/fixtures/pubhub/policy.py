"""PubHub's own transition policy, supplied by the provider as a contract evaluator.

"A document that was private less than `hold_hours` ago must not become public,
directly or through an intermediate audience." This is a PATH property over the
document's history: no generic evaluator can state it without knowing what
"private", "public" and "last_private_at" mean. It therefore belongs to the provider's
contract semantics, not to the protocol core. Without it registered, a contract that
names it fails closed (unsupported security constraint)."""
from __future__ import annotations

from aaap.evaluators import FAIL, PASS, EvalOutcome, OK, RefError, parse_instant, resolve_ref

NAME = "pubhub.no_public_within_hold"
DEPS = ("fact:visibility", "fact:last_private_at")


def no_public_within_hold(spec, params, ctx, phase):
    if phase != "pre":
        return OK
    try:
        target = resolve_ref("arg:audience", ctx)
    except RefError as e:
        return EvalOutcome(FAIL, "target_unresolvable", str(e))
    visibility, last_private = ctx.facts["visibility"], ctx.facts["last_private_at"]
    if target == "public":
        if visibility == "private":
            return EvalOutcome(FAIL, "private_to_public_directly")
        if last_private is not None:
            age = ctx.now - parse_instant(last_private)
            if age.total_seconds() < params["hold_hours"] * 3600:
                return EvalOutcome(FAIL, "public_within_hold_of_private", f"{age} since private")
    return EvalOutcome(PASS, dependencies=DEPS)


def register(registry) -> None:
    registry.register(NAME, no_public_within_hold)
