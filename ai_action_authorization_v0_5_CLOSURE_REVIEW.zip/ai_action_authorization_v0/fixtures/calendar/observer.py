"""Calendar evidence source (V0.1). Separate from the adapter: it reads the
provider's own record of the request made under the execution's idempotency key
(which event it changed, the If-Match it was applied under, and the event as the
write left it). It never sees what the adapter reported."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import EvidenceSource
from aaap.objects import PROVIDER_AUTHORITY, ExecutionEvidence

from .provider import FakeCalendar


class CalendarRecordObserver(EvidenceSource):
    identity = "calendar.example.com/request-record"

    def __init__(self, cal: FakeCalendar, tokens: Dict[str, str]):
        self.cal = cal
        self.tokens = tokens

    def observe(self, intent, grant):
        token = self.tokens[intent.principal]
        rec = self.cal.request_record(token, intent.execution_id)
        if rec is None:
            return None
        state = rec["result"]
        applied = ({} if rec["if_match"] is None else
                   {"subject": rec["event_id"], "version_kind": "etag", "version_value": rec["if_match"]})
        return ExecutionEvidence(
            evidence_id=f"{self.identity}:{intent.execution_id}", execution_id=intent.execution_id,
            intent_id=rec["metadata"].get("intent_id"), source_identity=self.identity,
            provenance=PROVIDER_AUTHORITY, observed_subject=rec["event_id"], observed_state=state,
            observed_effects=tuple(rec["effects"]), applied_precondition=applied)
