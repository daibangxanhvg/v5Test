"""Calendar gateway effector (V0.2, Mode B). TRUSTED: holds the principal's
calendar token, which can modify or DELETE any event. Called only after the
enforcement boundary accepted the operation. Applies the credential's state
binding as If-Match (provider compare-and-swap)."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult, PreconditionFailed
from aaap.authority import MODE_B, ProviderEffector
from aaap.objects import EXEC_SUCCESS

from .provider import CalendarError, FakeCalendar


class CalendarGatewayEffector(ProviderEffector):
    mode = MODE_B

    def __init__(self, cal: FakeCalendar, tokens: Dict[str, str]):
        self.cal = cal
        self.tokens = tokens
        self.calls = 0

    def authority_handles(self):
        return [self.cal, self.tokens] + list(self.tokens.values())

    def perform(self, credential, operation):
        self.calls += 1
        token = self.tokens[credential.principal]
        r = operation.request
        sb = credential.state_binding
        try:
            with self.cal.request_headers(if_match=sb.version_value if sb else None,
                                          metadata={"intent_id": credential.intent_id}):
                if operation.capability == "reschedule_event":
                    changes = {k: v for k, v in r.items() if k != "event_id"}
                    ev = self.cal.patch_event(token, r["event_id"], changes, operation.execution_id)
                    return ExecutionResult(EXEC_SUCCESS, operation.execution_id, ev["event_id"], dict(r),
                                           ["event_time_modified"])
                if operation.capability == "delete_event":
                    self.cal.delete_event(token, r["event_id"])
                    return ExecutionResult(EXEC_SUCCESS, operation.execution_id, r["event_id"], dict(r),
                                           ["event_deleted"])
        except CalendarError as e:
            if "412" in str(e):
                raise PreconditionFailed(str(e))
            raise
        raise NotImplementedError(operation.capability)
