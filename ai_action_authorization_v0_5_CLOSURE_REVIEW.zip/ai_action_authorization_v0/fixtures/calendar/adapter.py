from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult, PreconditionFailed, ProviderAdapter
from aaap.objects import EXEC_SUCCESS, StateBinding

from .provider import CalendarError, FakeCalendar


class CalendarAdapter(ProviderAdapter):
    def __init__(self, cal: FakeCalendar, tokens: Dict[str, str]):
        self.cal = cal
        self.tokens = tokens

    def resolve(self, intent):
        return self.cal.get_event(self.tokens[intent.principal], intent.arguments["event_id"])

    def plan(self, intent, facts):
        a = intent.arguments
        return {"event_id": a["event_id"], "start": a["new_start"], "end": a["new_end"]}

    def state_binding(self, intent, facts):
        return StateBinding(subject=facts["event_id"], version_kind="etag", version_value=facts["etag"])

    def execute(self, intent, plan):
        changes = {k: v for k, v in plan.items() if k != "event_id"}
        ev = self.cal.patch_event(self.tokens[intent.principal], plan["event_id"], changes, intent.execution_id)
        return ExecutionResult(EXEC_SUCCESS, intent.execution_id, ev["event_id"], dict(plan), ["event_time_modified"])

    def execute_conditional(self, intent, plan, precondition):
        try:
            with self.cal.request_headers(if_match=precondition.version_value,
                                          metadata={"intent_id": intent.intent_id}):
                return self.execute(intent, plan)
        except CalendarError as e:
            if "412" in str(e):
                raise PreconditionFailed(str(e))
            raise

    def read_back(self, intent, result):
        return self.cal.get_event(self.tokens[intent.principal], result.request["event_id"])

    def lookup(self, intent):
        ev = self.cal.applied(intent.execution_id)
        if ev is None:
            return None
        a = intent.arguments
        return ExecutionResult(EXEC_SUCCESS, intent.execution_id, ev["event_id"],
                               {"event_id": a["event_id"], "start": a["new_start"], "end": a["new_end"]},
                               ["event_time_modified"])


class FullReplaceCalendarAdapter(CalendarAdapter):
    """C3 (pre-execution): a buggy adapter that sends a full-object update built from
    a stale attendee list, i.e. the planned request removes an attendee the intent never mentioned."""

    def plan(self, intent, facts):
        p = super().plan(intent, facts)
        p["attendees"] = facts["attendees"][:-1]
        return p
