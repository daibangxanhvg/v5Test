"""In-memory calendar provider with PATCH semantics and an idempotency key.

V0.1: every read returns an `etag` (a digest of the event's current content, so
ANY modification changes it). A PATCH sent with an If-Match header is applied
only if the etag is still current, checked and applied in one step (HTTP 412
otherwise). The provider keeps a record per idempotency key of what that
request did (event, If-Match it was applied under, client metadata).
"""
from __future__ import annotations

import contextlib
import copy
import hashlib
import json
from typing import Dict, Optional


class CalendarError(Exception):
    pass


def _etag(event: dict) -> str:
    return '"' + hashlib.sha256(json.dumps(event, sort_keys=True).encode()).hexdigest()[:16] + '"'


class FakeCalendar:
    def __init__(self) -> None:
        self.tokens: Dict[str, str] = {}
        self.events: Dict[str, dict] = {}
        self._applied: Dict[str, dict] = {}   # idempotency key -> event snapshot after patch
        self._records: Dict[str, dict] = {}   # idempotency key -> request record (V0.1)
        self._headers: Dict[str, object] = {}
        self.patch_calls = 0
        self.delete_calls = 0
        # misbehaviour switch for C3: provider silently drops this attendee on any update
        self.drop_attendee_on_update: Optional[str] = None

    def add_event(self, event: dict) -> None:
        self.events[event["event_id"]] = copy.deepcopy(event)

    def get_event(self, token: str, event_id: str) -> dict:
        if token not in self.tokens:
            raise CalendarError("unauthenticated")
        if event_id not in self.events:
            raise CalendarError("not_found")
        ev = copy.deepcopy(self.events[event_id])
        ev["etag"] = _etag(self.events[event_id])
        return ev

    @contextlib.contextmanager
    def request_headers(self, if_match: Optional[str] = None, metadata: Optional[dict] = None):
        """HTTP request headers for the next call (If-Match, client metadata)."""
        self._headers = {"if_match": if_match, "metadata": dict(metadata or {})}
        try:
            yield
        finally:
            self._headers = {}

    def patch_event(self, token: str, event_id: str, changes: dict, idempotency_key: str) -> dict:
        self.patch_calls += 1
        if idempotency_key in self._applied:
            return copy.deepcopy(self._applied[idempotency_key])
        if token not in self.tokens:
            raise CalendarError("unauthenticated")
        if event_id not in self.events:
            raise CalendarError("not_found")
        ev = self.events[event_id]
        if_match = self._headers.get("if_match")
        # compare-and-swap: check and write with nothing in between
        if if_match is not None and if_match != _etag(ev):
            raise CalendarError("412 precondition_failed")
        ev.update(copy.deepcopy(changes))
        if self.drop_attendee_on_update and self.drop_attendee_on_update in ev["attendees"]:
            ev["attendees"] = [a for a in ev["attendees"] if a != self.drop_attendee_on_update]
        self._applied[idempotency_key] = copy.deepcopy(ev)
        self._records[idempotency_key] = {"event_id": event_id, "caller": self.tokens[token],
                                          "if_match": if_match, "metadata": dict(self._headers.get("metadata") or {}),
                                          "effects": ["event_time_modified"], "result": copy.deepcopy(ev)}
        return copy.deepcopy(ev)

    def delete_event(self, token: str, event_id: str) -> None:
        """V0.2: the broad token can delete any event (used to show what a confined executor cannot do)."""
        if token not in self.tokens:
            raise CalendarError("unauthenticated")
        if event_id not in self.events:
            raise CalendarError("not_found")
        self.delete_calls += 1
        del self.events[event_id]

    def applied(self, idempotency_key: str) -> Optional[dict]:
        return copy.deepcopy(self._applied.get(idempotency_key))

    def request_record(self, token: str, idempotency_key: str) -> Optional[dict]:
        """Provider's own record of what the request with this idempotency key did."""
        if token not in self.tokens:
            raise CalendarError("unauthenticated")
        rec = self._records.get(idempotency_key)
        return copy.deepcopy(rec) if rec and rec["caller"] == self.tokens[token] else None
