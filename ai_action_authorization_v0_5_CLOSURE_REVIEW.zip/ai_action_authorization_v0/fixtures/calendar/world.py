from __future__ import annotations

from aaap import ActionIntent

from tests.harness import delegation, load_contract, make_core

from aaap import PROVIDER_AUTHORITY

from aaap import ConfinedExecutor

from .effector import CalendarGatewayEffector
from .adapter import CalendarAdapter
from .observer import CalendarRecordObserver
from .provider import FakeCalendar

WORKING_HOURS = {"start": "09:00", "end": "17:00", "utc_offset": "+07:00", "weekdays": [0, 1, 2, 3, 4]}
ORIGINAL = {"event_id": "evt-1", "calendar_id": "work", "title": "Sprint review",
            "attendees": ["lam@example.com", "an@example.com", "binh@example.com"],
            "location": "Room 3", "start": "2026-10-14T10:00:00+07:00", "end": "2026-10-14T11:00:00+07:00"}
PERSONAL = {"event_id": "evt-2", "calendar_id": "personal", "title": "Dentist", "attendees": ["lam@example.com"],
            "location": "Clinic", "start": "2026-10-14T13:00:00+07:00", "end": "2026-10-14T14:00:00+07:00"}


def build(core=None, adapter_cls=CalendarAdapter, observe=True):
    core = core or make_core()
    cal = FakeCalendar()
    cal.tokens["tok-lam"] = "lam"
    cal.add_event(ORIGINAL)
    cal.add_event(PERSONAL)
    contract = load_contract("calendar", "contract_v1.json")
    core.contracts.trust_issuer(contract.contract_id, "calendar.example.com")
    core.contracts.publish(contract)
    core.delegations.issue(delegation(
        "dlg-cal-1", "lam", "agent-1", ["calendar.modify"], [contract],
        [{"id": "allowed_calendar", "params": {"allowed": ["work"]}},
         {"id": "working_hours", "params": WORKING_HOURS}]))
    core.gateway.register_adapter(contract.contract_id, adapter_cls(cal, {"lam": "tok-lam"}))
    if observe:
        core.gateway.register_evidence_source(contract.contract_id, CalendarRecordObserver(cal, {"lam": "tok-lam"}),
                                              PROVIDER_AUTHORITY)
    return core, cal, contract


def intent(event_id="evt-1", new_start="2026-10-14T14:00:00+07:00", new_end="2026-10-14T15:00:00+07:00",
           execution_id="exec-c-1", intent_id="int-c-1"):
    return ActionIntent(intent_id=intent_id, agent="agent-1", principal="lam",
                        contract_id="calendar.reschedule_event", capability="reschedule_event",
                        arguments={"event_id": event_id, "new_start": new_start, "new_end": new_end},
                        execution_id=execution_id)


def build_confined(core=None, executor=None, observe=True, **kw):
    """V0.2 Mode B wiring: the gateway keeps the provider token (reader adapter + effector);
    the executor gets nothing but what execute_confined hands it."""
    core, cal, contract = build(core, observe=observe, **kw)
    effector = CalendarGatewayEffector(cal, {"lam": "tok-lam"})
    core.gateway.authority.register_effector(contract.contract_id, effector)
    core.gateway.register_executor(contract.contract_id, executor or ConfinedExecutor("agent-1"))
    return core, cal, contract, effector
