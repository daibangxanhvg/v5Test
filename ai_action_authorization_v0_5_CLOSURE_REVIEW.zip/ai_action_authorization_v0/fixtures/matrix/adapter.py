from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult, ProviderAdapter
from aaap.objects import EXEC_SUCCESS

from .homeserver import FakeHomeserver, MatrixError


class MatrixAdapter(ProviderAdapter):
    def __init__(self, hs: FakeHomeserver, tokens: Dict[str, str]):
        self.hs = hs
        self.tokens = tokens  # principal -> access token held by the gateway, not the agent

    def resolve(self, intent):
        if intent.principal not in self.tokens:
            raise KeyError("no credentials for principal")
        return {}

    def plan(self, intent, facts):
        return {"room_id": intent.arguments["room_id"], "body": intent.arguments["content"]}

    def execute(self, intent, plan):
        event_id = self.hs.send_message(self.tokens[intent.principal], plan["room_id"], plan["body"],
                                        txn_id=intent.execution_id,
                                        extra_content={"org.aaap.intent_id": intent.intent_id})
        return ExecutionResult(EXEC_SUCCESS, intent.execution_id, event_id, dict(plan), ["message_created"])

    def read_back(self, intent, result):
        try:
            ev = self.hs.get_event(self.tokens[intent.principal], result.request["room_id"], result.provider_ref)
        except MatrixError:
            return None
        return {"room_id": ev["room_id"], "body": ev["content"].get("body")}

    # lookup(): the Matrix C-S API has no read-only "what happened to txnId X"
    # endpoint, so the base class default (None => stays in doubt) is kept.
    # state_binding()/execute_conditional(): PUT /send has no precondition
    # header, so the base class defaults (no binding, no conditional send) are kept.
