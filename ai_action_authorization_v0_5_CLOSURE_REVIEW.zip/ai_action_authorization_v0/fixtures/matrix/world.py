"""Matrix fixture wiring: provider, adapter, contract, delegation."""
from __future__ import annotations

from aaap import ActionIntent

from tests.harness import delegation, load_contract, make_core

from aaap import PROVIDER_AUTHORITY

from aaap import ConfinedExecutor

from .effector import MatrixGatewayEffector
from .adapter import MatrixAdapter
from .observer import MatrixSyncObserver
from .homeserver import FakeHomeserver

ALLOWED_ROOM = "!team:example.org"
OTHER_ROOM = "!finance:example.org"


def build(core=None, observe=True):
    core = core or make_core()
    hs = FakeHomeserver()
    hs.add_user("tok-lam", "@lam:example.org")
    hs.create_room(ALLOWED_ROOM, ["@lam:example.org"])
    hs.create_room(OTHER_ROOM, ["@lam:example.org"])
    contract = load_contract("matrix", "contract_v1.json")
    core.contracts.trust_issuer(contract.contract_id, "matrix.example.org")
    core.contracts.publish(contract)
    core.delegations.issue(delegation(
        "dlg-matrix-1", "lam", "agent-1", ["messaging.send"], [contract],
        [{"id": "allowed_rooms", "params": {"allowed": [ALLOWED_ROOM]}}]))
    core.gateway.register_adapter(contract.contract_id, MatrixAdapter(hs, {"lam": "tok-lam"}))
    if observe:
        core.gateway.register_evidence_source(contract.contract_id, MatrixSyncObserver(hs, {"lam": "tok-lam"}),
                                              PROVIDER_AUTHORITY)
    return core, hs, contract


def intent(room_id=ALLOWED_ROOM, content="standup at 10", execution_id="exec-m-1", intent_id="int-m-1"):
    return ActionIntent(intent_id=intent_id, agent="agent-1", principal="lam", contract_id="matrix.send_message",
                        capability="send_message", arguments={"room_id": room_id, "content": content},
                        execution_id=execution_id)


def build_confined(core=None, executor=None, observe=True, **kw):
    """V0.2 Mode B wiring: the gateway keeps the provider token (reader adapter + effector);
    the executor gets nothing but what execute_confined hands it."""
    core, hs, contract = build(core, observe=observe, **kw)
    effector = MatrixGatewayEffector(hs, {"lam": "tok-lam"})
    core.gateway.authority.register_effector(contract.contract_id, effector)
    core.gateway.register_executor(contract.contract_id, executor or ConfinedExecutor("agent-1"))
    return core, hs, contract, effector
