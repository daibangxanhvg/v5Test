"""Matrix gateway effector (V0.2, Mode B). TRUSTED: lives in the gateway and holds
the principal's access token, which can send to ANY room the user is in. The
executor never receives it. Called only after the enforcement boundary accepted
the operation; it decides nothing, it translates an operation into a C-S API call."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import ExecutionResult
from aaap.authority import MODE_B, ProviderEffector
from aaap.objects import EXEC_SUCCESS

from .homeserver import FakeHomeserver


class MatrixGatewayEffector(ProviderEffector):
    mode = MODE_B

    def __init__(self, hs: FakeHomeserver, tokens: Dict[str, str]):
        self.hs = hs
        self.tokens = tokens
        self.calls = 0

    def authority_handles(self):
        return [self.hs, self.tokens] + list(self.tokens.values())

    def perform(self, credential, operation):
        self.calls += 1
        if credential.state_binding is not None:
            raise NotImplementedError("PUT /send has no precondition: cannot honour a state binding")
        token = self.tokens[credential.principal]
        r = operation.request
        if operation.capability == "send_message":
            event_id = self.hs.send_message(token, r["room_id"], r["body"], txn_id=operation.execution_id,
                                            extra_content={"org.aaap.intent_id": credential.intent_id})
            return ExecutionResult(EXEC_SUCCESS, operation.execution_id, event_id, dict(r), ["message_created"])
        raise NotImplementedError(operation.capability)
