"""Matrix evidence source (V0.1). Separate from the adapter: it finds the event
the homeserver created for the execution's txnId via the sender's own /sync
stream (`unsigned.transaction_id`), wherever that event landed. It never sees
the event_id or room the adapter reported."""
from __future__ import annotations

from typing import Dict

from aaap.adapter import EvidenceSource
from aaap.objects import PROVIDER_AUTHORITY, ExecutionEvidence

from .homeserver import FakeHomeserver, MatrixError

EFFECT_OF_EVENT_TYPE = {"m.room.message": "message_created"}


class MatrixSyncObserver(EvidenceSource):
    identity = "matrix.example.org/sync"

    def __init__(self, hs: FakeHomeserver, tokens: Dict[str, str]):
        self.hs = hs
        self.tokens = tokens

    def observe(self, intent, grant):
        try:
            events = self.hs.sync_own_events(self.tokens[intent.principal])
        except MatrixError:
            return None
        for ev in events:
            if ev["unsigned"]["transaction_id"] == intent.execution_id:
                return ExecutionEvidence(
                    evidence_id=f"{self.identity}:{ev['event_id']}", execution_id=intent.execution_id,
                    intent_id=ev["content"].get("org.aaap.intent_id"), source_identity=self.identity,
                    provenance=PROVIDER_AUTHORITY, observed_subject=ev["room_id"],
                    observed_state={"room_id": ev["room_id"], "body": ev["content"].get("body")},
                    observed_effects=(EFFECT_OF_EVENT_TYPE.get(ev["type"], "unknown:" + ev["type"]),))
        return None
