"""In-memory fixture of the Matrix client-server send/read surface that matters here.

Faithful to the spec in the two properties under test:
- PUT /_matrix/client/v3/rooms/{roomId}/send/{eventType}/{txnId} is idempotent
  per (access token, txnId): a retry returns the original event_id, no new event.
- GET /_matrix/client/v3/rooms/{roomId}/event/{eventId} may be unavailable
  (permissions, history visibility, E2EE content not decryptable by the reader...).

V0.1 additions:
- /sync returns the caller's own events with `unsigned.transaction_id` (only to
  the access token that sent them), modelled by sync_own_events();
- membership is mutable (leave_room); sends are checked against membership at
  send time, but the C-S API has NO conditional send (no If-Match on PUT /send).
"""
from __future__ import annotations

import copy
import itertools
from typing import Dict, List, Tuple


class MatrixError(Exception):
    def __init__(self, errcode: str, msg: str = ""):
        super().__init__(f"{errcode}: {msg}")
        self.errcode = errcode


class FakeHomeserver:
    def __init__(self) -> None:
        self.users: Dict[str, str] = {}             # access_token -> user_id
        self.rooms: Dict[str, List[dict]] = {}      # room_id -> timeline
        self.members: Dict[str, set] = {}
        self._txns: Dict[Tuple[str, str], str] = {}
        self._events: Dict[str, dict] = {}
        self._seq = itertools.count(1)
        self.readback_available = True
        self.send_calls = 0

    def add_user(self, token: str, user_id: str) -> None:
        self.users[token] = user_id

    def create_room(self, room_id: str, members) -> None:
        self.rooms[room_id] = []
        self.members[room_id] = set(members)

    def _user(self, token: str) -> str:
        if token not in self.users:
            raise MatrixError("M_UNKNOWN_TOKEN")
        return self.users[token]

    def leave_room(self, room_id: str, user_id: str) -> None:
        self.members[room_id].discard(user_id)

    def send_message(self, token: str, room_id: str, body: str, txn_id: str, extra_content=None) -> str:
        self.send_calls += 1
        user = self._user(token)
        if (token, txn_id) in self._txns:
            return self._txns[(token, txn_id)]
        if room_id not in self.rooms or user not in self.members[room_id]:
            raise MatrixError("M_FORBIDDEN", f"{user} not in {room_id}")
        event_id = f"$ev{next(self._seq)}"
        content = {"msgtype": "m.text", "body": body}
        content.update(extra_content or {})   # namespaced custom keys are allowed in event content
        event = {"event_id": event_id, "room_id": room_id, "sender": user, "type": "m.room.message",
                 "content": content}
        self.rooms[room_id].append(event)
        self._events[event_id] = event
        self._txns[(token, txn_id)] = event_id
        return event_id

    def sync_own_events(self, token: str) -> List[dict]:
        """Events sent with this access token, as /sync shows them to it (with unsigned.transaction_id)."""
        self._user(token)
        if not self.readback_available:
            raise MatrixError("M_FORBIDDEN", "event content not visible to reader")
        out = []
        for (tok, txn), event_id in self._txns.items():
            if tok == token:
                ev = copy.deepcopy(self._events[event_id])
                ev["unsigned"] = {"transaction_id": txn}
                out.append(ev)
        return out

    def get_event(self, token: str, room_id: str, event_id: str) -> dict:
        self._user(token)
        if not self.readback_available:
            raise MatrixError("M_FORBIDDEN", "event not visible to reader")
        ev = self._events.get(event_id)
        if ev is None or ev["room_id"] != room_id:
            raise MatrixError("M_NOT_FOUND")
        return copy.deepcopy(ev)

    def timeline(self, room_id: str) -> List[dict]:
        return copy.deepcopy(self.rooms.get(room_id, []))
