# V9 Failure Wall — W1–W10

V9 is used here only as an adversarial wall against the bounded V0.3 core. No V9 architecture is restored.

**Ownership** says who carries the mitigation:

| Owner | Meaning |
|---|---|
| **P** | Protocol core: generic, domain-free |
| **C** | Provider contract or evaluator data |
| **N** | Newcomer boundary: adapter, effector, observer, mapping |
| **I** | Infrastructure: modeled input, not implemented |
| **FC** | Fail closed: the protocol refuses rather than guesses |

Test IDs refer to `tests/test_v03_protocol_boundary.py` unless noted.

| # | Failure class | Attack actually run | Result | Mitigation | Ownership |
|---|---|---|---|---|---|
| **W1** | Artifact identity ≠ semantic/security identity | P1: description and human metadata edited. P1b: the same edit with no declared separation. P1c: confirmation taken before the edit. P1d: evaluator reads excluded metadata. P3a–d: unknown field, attempts to exclude 10 security fields, malformed `security_identity`, noncritical extension changed. | **Held.** Metadata-only edits keep grants and credentials only when the issuer declared the separation. A human confirmation still binds the artifact the human saw. Excluded content is invisible to evaluators. Anything ambiguous reauthorizes or is malformed. | `CapabilityContract.binding_digest()`: the artifact minus a **closed** eligible list {description, human_metadata}, opt-in through `security_identity`. `decision_view()`. Confirmation bound to `contract_artifact_digest`. No semantic hashing. | P + C (declaration) + FC |
| **W2** | Knowledge evolution | P2: 15 security mutations. P4: publish → publish+notify. P4c: silent effect change, same version. E3: a new mutable dependency, a new evaluator, a rebound evaluator name. | **Held.** No old grant, confirmation, delegation or credential gains authority. V0.2 gap found and fixed: unknown structure was ignored (V03-F). | Digest pinning (V0). `effects` in grant and credential. Append-only evaluator registry. Closed-world schema. V0.2 state-dependency set. | P + FC |
| **W3** | Evidence binding / laundering | T5: only the publish observation exists. T6a: publish evidence relabelled as notify, and as both. T6b: another execution's record; a Folio record smuggled into N2. T6c: only the adapter's translation. P5d: issuer A's source for issuer B's contract. | **Held when declared:** each sub-effect needs its own authoritative, in-scope evidence. **Open in verification when declarations are missing:** V03-A (no `required_effects`), V03-B (unscoped source). Prevention is unaffected. | `verification.required_effects`. Evidence-source effect scope. V0.1 execution/intent/source/provenance binding, keyed by the qualified contract address. | P + C + deployer + I (source integrity) |
| **W4** | Transition splitting / authorization laundering | T2: publish-only grant; executor publishes, then tries notify 4 ways. T2b: wider audience. T3a: second step with the same credential or grant. T3b: reader plans A→C under an A→B intent. T3c: end-state policy. T3d: path rule with no semantics. T3e: provider-supplied path rule. T2c: legacy adapter. | **Held.** A grant authorizes one exact operation once, and every extra step is blocked before provider code runs. A→C cannot be reached through B unless the delegation's end-state policy or the provider's path evaluator allows it. Unknown path semantics → DENY for all transitions. Legacy path: detected only (V01-A class). | V0.2 exact single-use credential + state binding. `plan ⊆ intent`. End-state constraints as contract data. Path policy as a **provider** evaluator (`fixtures/pubhub/policy.py`) or fail closed. | P + C + FC |
| **W5** | Representation leakage / newcomer locality | P6a: hashes of all 36 V0.2 provider and test files. P6b: existing providers scanned for newcomer names. P6c: one gateway serving 5 domains. P7a–c: Folio's wire format, integer revisions, unmappable refs. G22: AST scan of the core. | **Held.** 0 existing files changed. 0 newcomer identifiers or literals in the core. Mappings exist only in `fixtures/*/mapping.py`. The composite split is in the newcomer effector. | Contract `maps_to` vocabulary. Opaque `StateBinding`. Newcomer adapter, effector, observer and mapping. | N |
| **W6** | Semantic ambiguity | P8a: lookalike contract (same capability, description and inputs; extra effect); a twin that differs only by issuer. P8b: audience served by two lists. P8c: scan for similarity code. | **Held.** No automatic equivalence. Identity is the digest. Ambiguous mapping → no plan → DENY. | No equivalence engine (forbidden). The adapter refuses ambiguity. | P + N + FC |
| **W7** | Unknown critical extension | P9: 9 unknown critical semantics + a delegation-constraint modifier. P10a–c: declared noncritical extension; extension relied on by an evaluator; noncritical naming protocol fields; noncritical holding a reference; noncritical modifier. §14 probe run on V0.2. | **Held after a fix.** V0.2 proceeded in 5 of these cases. V0.3 denies all of them. A noncritical extension is preserved, ignored and invisible to evaluators, and cannot carry a reference or shadow a protocol field. | Closed-world schema; `noncritical_extensions`; evaluator-declared `spec_keys`. | P + C + FC |
| **W8** | Owner / namespace identity | P5a–f: two issuers with the same local id; bare id; forged pin; per-issuer evidence and boundary; untrusted issuer's qualified address; publisher claiming another issuer. FINDING_V03_D: unauthenticated publish. | **Held after a fix.** In V0.2 the second issuer overwrote trust and current (V03-G). Now `issuer::id` addresses are distinct; a bare id with two trusted issuers is ambiguous → DENY. Without authentication, a forged contract can occupy an address, but pins deny it: DoS only. | Registry keyed by (issuer, local id). Per-issuer trust. `authenticated_issuer` as an infrastructure input. | P + I |
| **W9** | Stale binding across evolution | E1: delegation narrowed by revocation. E1b: narrowing without revocation. E2: delegation widened. E3a: dependency flips. W9a: confirmation reused for another audience. W9b: authority removed. P2: contract change. P7b: stale revision. | **Held.** Every stale contract, delegation, confirmation, state or authority binding is refused at re-authorization **and** at the boundary. E1b is recorded semantics: delegations are independent, so narrowing needs revocation. | V0–V0.2 bindings, re-checked at execution and at invocation (`grant_standing`). | P |
| **W10** | Operational reality vs declared guarantee | E4a: Mode B → C. E4b: undeclared / declared / absent isolation; unknown fact. E4c: Mode A claim without provider enforcement. E4d: contract metadata claiming confinement; unknown `required_confinement`. E4e: downgrade during execution. | **Held.** `guarantee` = `NONE_ADVISORY_ONLY` / `CONFINED_ASSUMING_UNDECLARED_INFRASTRUCTURE` / `CONFINED_BY_DECLARED_INFRASTRUCTURE`. A fact declared absent → `NOT_CONFINED`. A Mode A claim → Mode B when the provider does not enforce. Contracts cannot raise the label. The outcome reports the weakest state seen. The reference deployment remains *assumed* (V02-A). | Mode A/B/C (V0.2) + deployer infrastructure facts + post-execution re-assessment. | P + I + FC |

## Result summary

| Status | Classes |
|---|---|
| Held | W1, W2, W4, W5, W6, W9, W10 |
| Held after fixing a V0.2 deficiency found by this wall | W7 (V03-F), W8 (V03-G) |
| Held when provider and deployer declarations are present; verification-only gap otherwise | W3 (V03-A, V03-B) |
| Forced a global ontology | none |


---

# V0.4 — the wall re-run against composite execution units

V0.4 re-ran the wall classes that composite actions touch, against PubHub V3 (two units, sequential state) and the synthetic triad domain. Test IDs refer to `tests/test_v04_composite_execution.py`. V0.3's W1–W10 tests all still pass unchanged.

| # | Failure class (composite form) | Attack actually run | Result | Mitigation | Ownership |
|---|---|---|---|---|---|
| **W2** | Knowledge evolution of the unit structure | E1 unit added; E2 required → optional; E3 optional → required; E4 evidence requirement stronger; E5 dependency added | **Held.** The binding digest changes in every case; the stale grant → `contract_changed`; every unit of the pre-minted credential → `grant_no_longer_in_force`; 0 effects. Old evidence → `lineage_mismatch` (E3b). | Units are inside the contract's security identity; the grant pins it | P |
| **W3** | Evidence binding / laundering per unit | C2 missing unit evidence; C4a–d relabel (scope, content, full relabel, joint claim); C5 cross-execution replay; C6 cross-action replay; C11 joint evidence with and without declaration; C12 wrong authority (scope, unscoped, provenance); C15 claim without the effect; C16 joint across subjects | **Held for unit contracts.** Every laundering or replay is rejected or a VIOLATION; one item covers two units only when the contract says so. **V03-B closed for unit contracts:** an unscoped source attests no unit. Residual: a lying source inside its own unit scope (V04-E). | Unit claim, grant lineage, unit-scoped sources, effects ⊆ covered units, explicit joint, per-unit provenance, per-unit applied/established state | P + C + deployer + I |
| **W3′** | Must-happen effects (V03-A) | C8a effect in no unit; C8b implicit `required`; C8c / C8c2 / C8d faulty binding generation; CT2–CT3 incomplete / lying contract; FINDING_V04_A / B | **Held when declared:** omission fails closed and required units always come from the contract. **Not closable by the core** when the contract hides the effect (V04-A) or declares no units (V04-B). | Effect partition over units; independent re-derivation of the unit table; deployer strict policy (opt-in) | P + C + I (contract authenticity) |
| **W4** | Transition splitting through units | C7a undeclared unit, whole-op; S3 skip; S4 reorder; A1 subset credential; A2 injection; A3 argument mutation; A4 removal; A5 duplication; CT4 combined | **Held.** Every out-of-binding unit operation is refused before provider code. A partial composite is never SUCCESS (aggregated against the grant's required units). | Per-unit permit: unit ∈ credential, exact unit request, single use, predecessors complete | P |
| **W4′** | Inter-step state (V03-H) | S1a–c sequential binding, external edit, stale V1; S2a–c substitution (other resource, other unit's state, executor-supplied precondition); S6a–c intermediate state unavailable / unattested / invisible | **Held, now prevented** (V0.3: detected). The precondition is computed by the boundary from the predecessor's produced token and applied by provider CAS. Unavailable or foreign state → the unit is not attempted. | Boundary-computed `from_unit` precondition; evidence cross-check | P + N (provider exposes versions) |
| **W5** | Locality | B5a 56 V0.3 files hash-identical; B5b no unit vocabulary in existing providers; B5c six domains on one gateway; B2 new domain | **Held.** One new field was needed for B2 (per-unit `subject`), and it is generic. | Newcomer fixtures only | N |
| **W6** | Semantic ambiguity of units | B3 lookalike ids, a same-named unit in another contract; B4 undeclared and conditional dependencies | **Held.** No equivalence; no invented dependency; a conditional dependency fails closed. | Exact equality; closed unit schema | P + FC |
| **W7** | Unknown critical unit structure | C9 (25 cases); `tools/v04_probe.py` on the V0.3 core | **Held.** All DENY. The previous core denies a unit contract (`unsupported_critical_extension`). | Closed unit schema; `execution_units` in the optional-field list | P + FC |
| **W9** | Stale bindings across unit evolution | E1–E5 | **Held** | V0–V0.3 pinning | P |
| **W10** | Operational reality vs claimed guarantee | C13 legacy path; C7b, FINDING_V04_D effector extra effects | **Held for the label:** a unit contract outside the boundary is UNVERIFIED. The effector is still in the TCB for the effect inside a unit. | Per-unit boundary records required for VERIFIED | P + I |

## V0.4 summary

| Status | Classes |
|---|---|
| Held | W2, W4, W4′, W5, W6, W7, W9, W10 (composite forms) |
| Held for unit contracts; residual is infrastructure (source integrity) | W3 |
| Held when declared; contract completeness is a stated trust boundary | W3′ |
| Forced a global ontology | none |
| Forced a new object or binding category | none. Pressure for multi-subject StateBinding content (V04-C) |

## V0.5 reuse of the failure wall

V0.5 applies: artifact identity is not semantic identity; evidence/bindings require lineage; representation leakage is forbidden; transition/state laundering is rejected by subject/dependency identity; unknown security-critical semantics fail closed. It deliberately does not revive universal ontology/equivalence machinery.
