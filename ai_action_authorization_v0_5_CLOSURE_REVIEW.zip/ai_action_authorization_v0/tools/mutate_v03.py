"""V0.3 mutation check: disable one protection at a time, run the whole suite, restore.
Run from the project root:  python3 tools/mutate_v03.py"""
import os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
M = [
 ("security identity: binding_digest = artifact digest", "src/aaap/objects.py",
  'if "security_identity" not in self.extensions:\n            return self.digest()', 'if True:\n            return self.digest()'),
 ("security identity: ineligible exclusions honoured", "src/aaap/objects.py",
  '{f for f in exclude if f in NON_SECURITY_ELIGIBLE}', '{f for f in exclude}'),
 ("grant standing uses artifact digest", "src/aaap/verifier.py",
  'contract.binding_digest() != grant.contract_digest', 'contract.digest() != grant.contract_digest'),
 ("confirmation binds security identity instead of artifact", "src/aaap/verifier.py",
  '("contract_digest", confirmation.contract_digest, artifact_digest)', '("contract_digest", confirmation.contract_digest, c_digest)'),
 ("evaluators see full contract", "src/aaap/verifier.py",
  'contract=contract.decision_view(), delegation=delegation', 'contract=contract, delegation=delegation'),
 ("unknown top-level extension ignored", "src/aaap/verifier.py",
  'if contract.unknown_extensions():', 'if False:'),
 ("unknown verification key ignored", "src/aaap/verifier.py",
  'unknown = sorted(set(v) - set(VERIFICATION_KEYS))', 'unknown = []'),
 ("unknown input key ignored", "src/aaap/verifier.py",
  'unknown = sorted(set(spec) - set(INPUT_KEYS))', 'unknown = []'),
 ("unknown state_binding key ignored", "src/aaap/verifier.py",
  'if set(sb) - set(STATE_BINDING_KEYS):', 'if False:'),
 ("unknown constraint modifier ignored", "src/aaap/verifier.py",
  'unknown = sorted(set(spec) - set(BASE_SPEC_KEYS) - set(self._ev.spec_keys(spec.get("evaluator"))))', 'unknown = []'),
 ("security_identity may exclude anything", "src/aaap/verifier.py",
  'bad = sorted(f for f in exclude if f not in NON_SECURITY_ELIGIBLE)', 'bad = []'),
 ("noncritical may name protocol fields", "src/aaap/verifier.py",
  'protocol = sorted(n for n in names if n in CONTRACT_FIELDS or n in OPTIONAL_CONTRACT_FIELDS)', 'protocol = []'),
 ("noncritical may be operational", "src/aaap/verifier.py",
  'operational = sorted(n for n in names if n in ext and _mentions_ref(ext[n]))', 'operational = []'),
 ("required_effects must be declared effects: unchecked", "src/aaap/verifier.py",
  'if req is not None and any(e not in c.effects for e in req):', 'if False:'),
 ("ambiguous bare address resolved", "src/aaap/verifier.py",
  'if self._contracts.ambiguous(address):', 'if False:'),
 ("qualified address resolves to bare current", "src/aaap/stores.py",
  'return self._current_q.get(address)', 'return self._current.get(address.partition(QUALIFIER)[2])'),
 ("publisher authentication ignored", "src/aaap/stores.py",
  'if authenticated_issuer is not None and authenticated_issuer != contract.issuer:', 'if False:'),
 ("trust by local id ignores issuer", "src/aaap/stores.py",
  'return issuer if issuer in self._trusted.get(local, ()) else None', 'return issuer'),
 ("evidence effect scope ignored", "src/aaap/verifier.py",
  'if scope is not None and any(e not in scope for e in ev.observed_effects):', 'if False:'),
 ("required effects coverage skipped", "src/aaap/verifier.py",
  'if e not in covered:', 'if False:'),
 ("partial treated as success", "src/aaap/verifier.py",
  'elif result.status == EXEC_PARTIAL:\n', 'elif False:\n'),
 ("partial evidence contradicting report accepted", "src/aaap/verifier.py",
  'if denied:\n', 'if False:\n'),
 ("grant does not carry effects", "src/aaap/verifier.py",
  'effects=tuple(contract.effects),', 'effects=(),'),   # V0.4: line now continues with execution_units
 ("attenuation: effects widening allowed", "src/aaap/authority.py",
  'if effects is not None and tuple(effects) != cred_effects:', 'if False:'),   # V0.4: compares the unit-narrowed set
 ("infrastructure declared absent ignored", "src/aaap/authority.py",
  'absent = [k for k in REQUIRED_INFRA[mode] if self._infra.get(k) is False]', 'absent = []'),
 ("mode A claim not downgraded", "src/aaap/authority.py",
  'if mode == MODE_A and self._infra.get(INFRA_PROVIDER_ENFORCES) is False:', 'if False:'),
 ("guarantee always declared", "src/aaap/authority.py",
  'GUARANTEE_ASSUMED if undeclared else GUARANTEE_DECLARED', 'GUARANTEE_DECLARED'),
 ("no post-execution re-assessment", "src/aaap/gateway.py",
  'if confinement.status == CONFINED and after.status != CONFINED:', 'if False:'),
 ("partial outcome retried (in doubt)", "src/aaap/gateway.py",
  'EXEC_PARTIAL: FAILED,', 'EXEC_PARTIAL: IN_DOUBT,'),
]
for name, f, a, b in M:
    path = os.path.join(ROOT, f)
    orig = open(path).read()
    assert orig.count(a) == 1, (name, orig.count(a))
    open(path, "w").write(orig.replace(a, b))
    try:
        r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-t", ".", "-s", "tests"],
                           capture_output=True, text=True, cwd=ROOT)
        m = re.search(r"FAILED \((.*)\)", r.stderr)
        n = sum(int(x) for x in re.findall(r"=(\d+)", m.group(1))) if m else 0
        print(f"{n:3d}  {name}")
    finally:
        open(path, "w").write(orig)
