"""Reproducible source complexity and lexical audit (no code changes)."""
import ast,json,pathlib
root=pathlib.Path(__file__).resolve().parents[1]
for p in sorted((root/'src/aaap').glob('*.py')):
 t=ast.parse(p.read_text()); print(json.dumps({'file':str(p.relative_to(root)),'physical_LOC':len(p.read_text().splitlines()),'if_nodes':sum(isinstance(n,ast.If) for n in ast.walk(t)),'functions':sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) for n in ast.walk(t))}))
p=root/'src/aaap/verifier.py';t=ast.parse(p.read_text())
n=next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name=='_state_binding')
print(json.dumps({'_state_binding_LOC':n.end_lineno-n.lineno+1,'if_nodes':sum(isinstance(x,ast.If) for x in ast.walk(n)),'loops':sum(isinstance(x,(ast.For,ast.While)) for x in ast.walk(n))}))
