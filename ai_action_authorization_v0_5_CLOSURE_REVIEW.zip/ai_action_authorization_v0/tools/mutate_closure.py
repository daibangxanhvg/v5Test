"""Targeted mutations in disposable copies; never edits the reviewed baseline.
A killed mutant requires a previously passing selected test to fail.
"""
import os, pathlib, shutil, subprocess, sys, tempfile, json
ROOT=pathlib.Path(__file__).resolve().parents[1]
M=[
 ('dependency coverage','src/aaap/verifier.py','sorted(cc.get("covers", [])) != required_ids','False','tests.test_v05_multi_state_binding.C_Consistency.test_C4_wrong_snapshot_scope'),
 ('missing required dependency','src/aaap/verifier.py','if required and item is None:','if False:','tests.test_closure_adversarial.DependencyAttacks.test_missing_stale_substitution_and_malformed'),
 ('execution lineage','src/aaap/authority.py','if op.execution_id != cred.execution_id:','if False:','tests.test_closure_adversarial.CompositeAttacks.test_reordering_injection_and_wrong_execution_block_at_port'),
 ('consistency upgrade','src/aaap/verifier.py','if STATE_CONSISTENCY_LEVELS.index(offered.observed_consistency) < STATE_CONSISTENCY_LEVELS.index(required):','if False:','tests.test_closure_adversarial.ConsistencyAttacks.test_independent_snapshots_and_sequential_strong_request_block'),
 ('post-U1 provider validation','fixtures/pubhub_units/effector.py','                                   if_rev, self._meta(credential, operation.unit))','                                   None, self._meta(credential, operation.unit))','tests.test_v04_composite_execution.S1_SequentialStateBinding.test_S1b_state_changed_between_units_the_second_unit_cannot_execute'),
]
if __name__=='__main__':
 for name,file,old,new,test in M:
  if old=='PLACEHOLDER': continue
  env=dict(os.environ,PYTHONPATH='src:.',PYTHONDONTWRITEBYTECODE='1')
  baseline=subprocess.run([sys.executable,'-m','unittest',test],cwd=ROOT,env=env,capture_output=True,text=True)
  assert baseline.returncode==0,(name,baseline.stderr)
  with tempfile.TemporaryDirectory(prefix='closure-mutant-') as tmp:
   target=pathlib.Path(tmp)/'baseline'; shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('__pycache__','review_logs'))
   p=target/file; s=p.read_text(); assert s.count(old)==1,(name,s.count(old));p.write_text(s.replace(old,new))
   r=subprocess.run([sys.executable,'-m','unittest',test],cwd=target,env=env,capture_output=True,text=True)
   print(json.dumps({'mutation':name,'test':test,'baseline_exit':baseline.returncode,'mutant_exit':r.returncode,'killed':r.returncode!=0}))
   print(r.stderr)
