"""V0.4 mutation check: disable one composite-execution protection at a time, run the whole suite, restore.
Run from the project root:  python3 tools/mutate_v04.py"""
import os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
V, A, O, G, D, S = ("src/aaap/verifier.py", "src/aaap/authority.py", "src/aaap/objects.py", "src/aaap/gateway.py",
                    "src/aaap/adapter.py", "src/aaap/stores.py")
M = [
 # --- contract unit structure (closed world)
 ("unit structure not validated", V, 'problem = _units_problem(c)', 'problem = None'),
 ("unknown unit key ignored", V, 'unknown = sorted(set(u) - set(UNIT_KEYS))', 'unknown = []'),
 ("explicit required/state not demanded", V, 'missing = [k for k in UNIT_MANDATORY_KEYS if k not in u]', 'missing = []'),
 ("unknown unit state accepted", V, 'problem = _unit_state_problem(uid, u["state"], after)', 'problem = None'),
 ("unknown unit evidence key ignored", V, 'if not isinstance(ev, dict) or set(ev) - set(UNIT_EVIDENCE_KEYS):', 'if not isinstance(ev, dict):'),
 ("after may name later/unknown units", V, ' or any(a not in seen for a in after):', ':'),
 ("effect may sit in two units", V, 'if e in owner:', 'if False:'),
 ("effect may sit in no unit (V03-A)", V, 'if unassigned:', 'if False:'),
 ("request field may be carried by no unit", V, 'if fields - carried:', 'if False:'),
 ("joint evidence may be one-sided", V, 'if j == uid or j not in seen or uid not in seen[j].get("evidence", {}).get("joint_with", []):', 'if False:'),
 ("required may depend on optional", V, 'if u["required"] and any(not seen[a]["required"] for a in u.get("after", [])):', 'if False:'),
 ("post invariant may be bound to no unit", V, 'if unlisted:', 'if False:'),
 ("required_effects may contradict units", V, 'if req is not None and set(req) != {e for u in seen.values() if u["required"] for e in u["effects"]}:', 'if False:'),
 ("strict composition policy ignored", V, 'if self.require_declared_composition and len(set(contract.effects)) > 1', 'if False and len(set(contract.effects)) > 1'),
 # --- binding generation / grant / credential
 ("grant carries no unit table", V, 'execution_units=units)', 'execution_units=())'),
 ("unit table not a bound grant field", V, '"principal", "agent", "capability", "resource", "state_dependencies", "effects",\n                      "execution_units")', '"principal", "agent", "capability", "resource", "state_dependencies", "effects")'),
 ("grant digest omits unit table", O, 'if self.execution_units:   # absent', 'if False:   # absent'),
 ("credential digest omits units", A, 'if self.units:\n            body["units"]', 'if False:\n            body["units"]'),
 ("attenuation skips binding re-derivation", A, 'if problem:\n                problems.append((C.EXECUTION_BINDING_INCONSISTENT, problem))', 'if False:\n                pass'),
 ("attenuation accepts unknown unit subset", A, ' or any(u not in ids for u in units)):', '):'),
 # --- enforcement boundary
 ("unknown unit falls back to a granted one", A, 'u = cred.unit(op.unit)\n', 'u = cred.unit(op.unit) or cred.units[0]\n'),
 ("unit request not compared", A, 'if not _same(op.request, u["request"]):', 'if False:'),
 ("unit not single-use", A, 'if op.unit in done:', 'if False:'),
 ("unit order not enforced", A, 'waiting = [a for a in u.get("after", []) if done.get(a, {}).get("status") != EXEC_SUCCESS]', 'waiting = []'),
 ("unit op accepted on unit-less credential", A, "if op.unit is not None:\n            return block(C.UNIT_NOT_AUTHORIZED", "if False:\n            return block(C.UNIT_NOT_AUTHORIZED"),
 ("dependent unit uses authorization state", A, 'precondition = _as_binding(getattr(pred, "established_state", None))', 'precondition = cred.state_binding'),
 ("established state of another subject accepted", A, 'elif cred.state_binding is None or precondition.subject != cred.state_binding.subject:', 'elif False:'),
 ("composite aggregated against credential subset", A, 'table = grant.execution_units if grant is not None else cred.units', 'table = cred.units'),
 ("any successful unit = composite success", A, 'elif all(status_of.get(u["unit_id"]) == EXEC_SUCCESS for u in table if u["required"]):', 'elif done:'),
 ("honest executor runs units after a failed predecessor", D, 'if any(p not in done for p in u.get("after", [])):\n                continue', 'if False:\n                continue'),
 # --- verification
 ("required units taken from the grant", V, 'units = {u["unit_id"]: u for u in expected}', 'units = {u["unit_id"]: u for u in (grant.execution_units if grant else expected)}'),
 ("grant unit table not compared with contract", V, 'if problem or grant is None or not canonical.same(list(grant.execution_units), list(expected)):', 'if problem or grant is None:'),
 ("optional executed unit may stay unproven", V, 'elif status == EXEC_SUCCESS and not ok:', 'elif False:'),
 ("required unit not executed not reported", V, 'if status != EXEC_SUCCESS:\n                    unverified.append(_reason(R.REQUIRED_UNIT_NOT_EXECUTED', 'if False:\n                    unverified.append(_reason(R.REQUIRED_UNIT_NOT_EXECUTED'),
 ("evidence without unit claim accepted", V, 'if not covers or len(set(covers)) != len(covers):', 'if False:'),
 ("unit scope ignored", V, 'if uscope is None or any(u not in uscope for u in covers):', 'if False:'),
 ("unscoped source attests every unit", V, 'if uscope is None or any(u not in uscope for u in covers):', 'if uscope is not None and any(u not in uscope for u in covers):'),
 ("joint evidence needs no declaration", V, 'if b not in units[a]["evidence"].get("joint_with", []):', 'if False:'),
 ("grant lineage ignored", V, 'if grant is None or ev.grant_id != grant.grant_id:', 'if grant is None:'),
 ("evidence effects outside covered units accepted", V, 'if any(e not in allowed for e in ev.observed_effects):', 'if False:'),
 ("joint evidence may span subjects", V, 'if len(subjects) > 1:', 'if False:'),
 ("unit provenance requirement ignored", V, 'authoritative = [u for u in covers if prov in units[u]["evidence"].get("provenance", default_prov)]', 'authoritative = list(covers)'),
 ("effect without permit not a violation", V, 'violations.append(_reason(R.UNIT_EFFECT_WITHOUT_PERMIT,', '[].append(_reason(R.UNIT_EFFECT_WITHOUT_PERMIT,'),
 ("undeclared effect in unit evidence ignored", V, 'if outside:\n            violations.append(_reason(R.UNDECLARED_EFFECT', 'if False:\n            violations.append(_reason(R.UNDECLARED_EFFECT'),
 ("per-unit subject ignored", V, 'subject = u0["subject"]["value"] if "subject" in u0 else subject', 'subject = subject'),
 ("postconditions on full plan, not unit projection", V, 'dataclasses.replace(ctx, plan=projection)', 'ctx'),
 ("post invariants run on every unit's evidence", V, 'if invariant_ids is not None and spec["id"] not in invariant_ids:', 'if False:'),
 ("applied unit state not compared", V, 'elif not canonical.same(ap, want):', 'elif False:'),
 ("unit applied state may be unattested", V, 'if ap is None:\n                    per_unit[u].append(R.UNIT_STATE_UNATTESTED)', 'if False:\n                    per_unit[u].append(R.UNIT_STATE_UNATTESTED)'),
 ("predecessor-established state not cross-checked", V, 'if ok and pred is not None:', 'if False:'),
 ("established state accepted from a non-authoritative source", V, 'if st.get("established") is not None and u in authoritative:', 'if st.get("established") is not None:'),
 ("unit effects need not be observed", V, 'if missing:\n                per_unit[u].append("effects_unobserved:"', 'if False:\n                per_unit[u].append("effects_unobserved:"'),
 ("unit-mode verification skipped (legacy path)", V, 'and contract.execution_units():\n', 'and False:\n'),
 ("no boundary unit record treated as observed", V, 'if unit_records is None:\n            # only the confined path', 'if False:\n            # only the confined path'),
 ("source unit scope not stored", S, 'self._units[key] = uscope', 'self._units[key] = None'),
]
if __name__ == "__main__":
    survivors = []
    for name, f, a, b in M:
        path = os.path.join(ROOT, f)
        orig = open(path).read()
        assert orig.count(a) == 1, (name, orig.count(a))
        open(path, "w").write(orig.replace(a, b))
        try:
            r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-t", ".", "-s", "tests"],
                               capture_output=True, text=True, cwd=ROOT)
            m = re.search(r"FAILED \((.*)\)", r.stderr)
            n = sum(int(x) for x in re.findall(r"=(\d+)", m.group(1))) if m else 0
            print(f"{n:3d}  {name}")
            if n == 0:
                survivors.append(name)
        finally:
            open(path, "w").write(orig)
    print(f"{len(M) - len(survivors)}/{len(M)} mutations detected; survivors: {survivors}")
