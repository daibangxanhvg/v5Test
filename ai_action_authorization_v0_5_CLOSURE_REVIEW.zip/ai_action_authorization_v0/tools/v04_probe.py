"""V0.4 probe: what does a core make of the V3 execution-unit contract?
Usage (from the project root):  python3 tools/v04_probe.py [path/to/other/project/src]
With no argument it probes this project's core. Pointing it at an unzipped V0.3 `src/` shows
that the previous core fails closed on `execution_units` (unknown critical extension)."""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "src"))
sys.path.insert(1, ROOT)
from aaap import CapabilityContract, Confirmation  # noqa: E402
from fixtures.pubhub import world as n2  # noqa: E402

with open(os.path.join(ROOT, "fixtures", "pubhub_units", "contract_v3.json"), encoding="utf-8") as f:
    v3 = CapabilityContract.from_dict(json.load(f))
core, hub, _ = n2.build(contract=v3, observe=False)
d = core.gateway.request_authorization(n2.intent(), "dlg-pub-1")
if d.decision == "REQUIRE_CONFIRMATION":
    d = core.gateway.request_authorization(n2.intent(), "dlg-pub-1", Confirmation.from_decision(d, "lam", n2.NOW))
import aaap  # noqa: E402
print(f"core={os.path.dirname(aaap.__file__)}")
print(f"decision={d.decision} codes={d.codes()} units={getattr(d.grant, 'execution_units', None) and [u['unit_id'] for u in d.grant.execution_units]}")
