"""W7 probe: the same unknown-semantics contract mutations against a project tree.
Usage: python3 tools/w7_probe.py <project root>   (run it on the V0.2 tree and on this one)"""
import sys, os
root = sys.argv[1]
sys.path[:0] = [root, os.path.join(root, "src")]
from aaap import CapabilityContract
from fixtures.fakepay import world
from tests.harness import delegation
cases = {
 "unknown top-level field (two_person_rule)": lambda d: d.update(two_person_rule={"approvers": 2}),
 "unknown verification key (attestation)": lambda d: d["verification"].update(attestation="required"),
 "unknown state_binding key (granularity)": lambda d: d["verification"]["state_binding"].update(granularity="field"),
 "unknown input key (pattern)": lambda d: d["inputs"]["recipient"].update(pattern="^an$"),
 "unknown modifier on known evaluator": lambda d: d["constraints"][0].update(inclusive=False),
}
for name, m in cases.items():
    core, pay, v1 = world.build()
    d = v1.to_dict(); m(d); c = CapabilityContract.from_dict(d)
    core.contracts.publish(c)
    core.delegations.issue(delegation("dlg-x", "lam", "agent-1", ["financial.transfer"], [c], world.LIMITS))
    dec = core.gateway.request_authorization(world.intent(recipient="an"), "dlg-x")
    print(f"{name:45s} {dec.decision:22s} {dec.codes()}")
