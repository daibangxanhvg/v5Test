# RESULTS — AI Action Authorization Protocol V0.1 (F6/F7 adversarial hardening)

Run: `python3 -m unittest discover -t . -s tests -v` on Python 3.9.6, macOS.
V0 results are kept unchanged in [RESULTS_V0.md](RESULTS_V0.md). V0.2 results: [RESULTS_V02.md](RESULTS_V02.md).

**Final verdict: `PARTIALLY_SURVIVED`** (reasoning in §15).

---

## 1. Totals

**108 tests run. 108 passed. 0 failed.**

| Group | Count | Notes |
|---|---|---|
| V0 tests | 57 | 55 are byte-for-byte unchanged. 2 had their final assertion inverted (see below). |
| New V0.1 tests (`tests/test_v01_f6_f7.py`) | 51 | E1–E6, S1–S6, X1–X4, fail-closed probes U1–U5, core guards G18–G19, and 6 `test_FINDING_V01_*` reproductions. |

### The two V0 tests that changed

`test_FINDING_F6_…` and `test_FINDING_F7_…` asserted that the F6/F7 weaknesses **exist**: the receipt was `VERIFIED`. This brief closes those weaknesses, so those assertions had to fail.

- The scenario code of both tests is unchanged.
- Only the expected verdict changed:
  - F6: `VERIFIED` → `VIOLATION` (`evidence_subject_mismatch`).
  - F7: `VERIFIED` → `UNVERIFIED` with execution status `PRECONDITION_FAILED`, and the event is not modified.
- The full diff is 12 lines in `tests/test_adversarial.py`.

No other V0 test, including the test-local fake providers in F5 and G17, was edited. No V0 protection was removed.

`test_FINDING_*` tests pass because they assert that a weakness **exists**. They are reproductions, not evidence that something works.

---

## 2. Result of every required F6/F7 test

All results come from `tests/test_v01_f6_f7.py`. "3 domains" means the test runs as subtests in Matrix, Calendar and FakePay.

### F6 — Evidence

| ID | Scenario | Expected | Observed | Result |
|---|---|---|---|---|
| E1 | Only the adapter's own read-back exists (3 domains) | SUCCESS + UNVERIFIED | SUCCESS, UNVERIFIED `no_authoritative_evidence`. Evidence recorded as `SELF_REPORTED / non_authoritative`. | PASS |
| E1b | Correct evidence from a source classified SELF_REPORTED (3 domains) | not VERIFIED | UNVERIFIED | PASS |
| E1c | Source classified SELF_REPORTED labels its evidence PROVIDER_AUTHORITY (3 domains) | rejected | `evidence_rejected: provenance_misclaimed` → UNVERIFIED | PASS |
| E1d | Evidence names a source identity nobody registered (3 domains) | rejected | `source_unregistered` → UNVERIFIED | PASS |
| E1e | Contract lists `SELF_REPORTED` as authoritative | fail closed | DENY `malformed_contract` | PASS |
| E1f | Register the adapter, or an impostor using the execution-path identity, as an evidence source | refused | `ValueError` | PASS |
| **E2** | Matrix: authorized room A. Adapter writes to forbidden room B and reports and reads back A. Homeserver /sync (by txnId) sees B. | not VERIFIED, ideally VIOLATION | **VIOLATION** `evidence_subject_mismatch` ("authorized !team, observed !finance"). Message really is in B. | PASS |
| E2b | The same attack in Calendar (patches evt-2, reports evt-1) and FakePay (pays Binh, reports An) | VIOLATION | VIOLATION `evidence_subject_mismatch` in both | PASS |
| E2c | Adapter performs the effect, then reports FAILED (Matrix) or PRECONDITION_FAILED (FakePay) | not VERIFIED | VIOLATION `effect_observed_despite_reported_failure` | PASS |
| **E3** | Genuine evidence from execution E1 attached to E2 (3 domains) | rejected, E2 not VERIFIED | `evidence_rejected: execution_id_mismatch` → UNVERIFIED | PASS |
| **E4** | Correct execution_id, different intent_id (3 domains) | rejected | `evidence_rejected: intent_id_mismatch` → UNVERIFIED | PASS |
| **E5** | Correctly bound evidence about a different subject (3 domains) | reject or violation | VIOLATION `evidence_subject_mismatch` | PASS |
| **E6** | Correctly bound provider evidence (3 domains) | VERIFIED | VERIFIED. The authoritative item is the `PROVIDER_AUTHORITY` observer, not the execution path. The receipt carries the grant_id. | PASS |
| E6b | Contract accepts only `INDEPENDENT_READBACK` | provider evidence insufficient | UNVERIFIED `no_authoritative_evidence` | PASS |
| E6c | `TRUSTED_EXECUTOR` evidence, without and with contract opt-in | UNVERIFIED, then VERIFIED | As expected | PASS |

### F7 — State binding

| ID | Scenario | Expected | Observed | Result |
|---|---|---|---|---|
| **S1** | Calendar grant bound to etag V1; execute while V1 | executes, VERIFIED | VERIFIED. The provider record shows the write was applied under If-Match V1. | PASS |
| **S2a** | Grant at V1; event's location edited (V2); execute with grant | no effect, conflict, re-auth | DENY `state_changed_reauthorization_required`; 0 provider calls | PASS |
| **S2b** | Grant at V1; event moved to the forbidden `personal` calendar | same | DENY `state_changed_…`; 0 calls. A fresh authorization is then DENIED on `allowed_calendar`. | PASS |
| **S2c** | State changes **inside** the execution window (between gateway check and provider write) | no effect | Provider CAS refuses atomically → `PRECONDITION_FAILED`, UNVERIFIED `state_precondition_failed_reauthorization_required`; event unchanged; no provider record | PASS |
| S2d | Adapter drops the If-Match (unconditional write) | not VERIFIED | VIOLATION `state_precondition_not_enforced` (provider record shows no If-Match) | PASS |
| **S3a** | FakePay grant bound to payer account revision; external debit before execution | no stale commit | DENY `state_changed_…`; 0 transfer calls; An 0 | PASS |
| **S3b** | External debit inside the execution window | no partial financial effect | `PRECONDITION_FAILED`; FakePay ledger empty; Lam 950 000 (only the external debit); An 0 | PASS |
| S3c | Fresh authorization and confirmation against the new state | works | VERIFIED; Lam 550 000, An 400 000 | PASS |
| **S4a** | Matrix: authorize; principal leaves the room; execute | stale auth cannot bypass | Authorization never depended on membership (`arg:room_id` only), so there is no binding. The homeserver refuses at send time → FAILED, 0 messages. | PASS |
| S4b | Matrix contract variant whose constraint reads room membership (`fact:`) | fail closed | DENY `state_dependent_authorization_without_declared_binding` (undeclared) or `state_binding_unavailable` (declared). 0 sends. | PASS |
| S4c | Matrix adapter claims a binding it cannot enforce | fail closed | ALLOW, then `execute_conditional` is unimplemented → FAILED; 0 sends | PASS |
| **S5a** | Calendar grant edited to carry evt-2's etag | fail closed | DENY `grant_not_issued_or_altered`; 0 calls | PASS |
| S5b | Adapter offers subject evt-1 with evt-2's etag | fail closed | ALLOW (the core cannot interpret tokens), then provider 412 → `PRECONDITION_FAILED`; evt-1 unchanged | PASS |
| S5c | Adapter offers a binding for subject evt-2 | fail closed | DENY `state_binding_subject_mismatch` | PASS |
| S5d | FakePay grant edited with another account version | fail closed | DENY `grant_not_issued_or_altered` | PASS |
| **S6a** | After S2c-style failure: retry with the same grant, retry without a grant, re-authorize the same execution_id | still fail | Both retries replay the PRECONDITION_FAILED receipt with 0 new provider calls. Re-authorizing gives `execution_id_already_used`. A new execution_id (new binding) gives VERIFIED and keeps the concurrent edit. | PASS |
| S6b | A stale FakePay grant retried 3 times | still fail | DENY `state_changed_…` every time; 0 transfer calls | PASS |

### Cross-cutting

| ID | Scenario | Observed | Result |
|---|---|---|---|
| **X1** | Authorize, grant, revoke, execute (3 domains) | DENY `delegation_revoked`; 0 effects. The grant is not a bearer capability. | PASS |
| **X2** | Confirm and grant, then mutate `amount` in place or present the grant with recipient Binh | DENY (`confirmation_mismatch` / grant mismatch); 0 transfers | PASS |
| X2b | Matrix grant presented with different content | DENY `grant_mismatch` | PASS |
| **X3** | Grant issued, then Calendar v2 or FakePay v2 published | DENY `contract_changed_reauthorization_required`; 0 effects | PASS |
| **X4** | Same grant executed twice (3 domains); grant presented for another execution_id | Replay with an identical receipt and 1 effect; the other id is DENIED | PASS |
| X4b | Execution id reused across domains | DENY `execution_id_already_used` | PASS |

### Fail-closed probes (insufficient or unknown evidence)

| ID | Scenario | Observed |
|---|---|---|
| U1 | Evidence source returns a non-evidence object | rejected `malformed` → UNVERIFIED |
| U2 | Authoritative evidence with no observed state (3 domains) | UNVERIFIED `read_back_unavailable` |
| U3 | Contract has no `verification.subject` | UNVERIFIED `evidence_subject_undeclared` |
| U4 | Grant has a state binding; evidence does not attest the applied precondition | UNVERIFIED `state_precondition_unattested` |
| U5 | Attested precondition differs from the grant's | VIOLATION `state_precondition_mismatch` |

### Mutation check (performed once, not part of the suite)

Each new protection was disabled in turn and the suite re-run. Every mutation caused failures:

- self-reported counted as authoritative: 16
- no execution_id binding: 2
- no intent_id binding: 2
- no subject check: 5
- no provenance-claim check: 2
- unconditional execute: 24
- grant store bypass: 2
- no stale-grant check: 6
- no effect-despite-failure check: 1
- no "unconditional write" check: 1
- no `fact:` dependency rule: 1

---

## 3. Exact core files changed

Hashes of every file were compared against the unzipped V0.

| Core file | Change | Lines (+/−) |
|---|---|---|
| `src/aaap/verifier.py` | V0.1 reason codes. Validation of the new `verification` fields. Step 8b state-binding rule. Grant integrity, stale-grant and grant-binding checks. Grant issuance on ALLOW. `verify_execution` rewritten around a report plus a list of evidence (`_judge_evidence`, `_postconditions`). | +253 / −46 |
| `src/aaap/gateway.py` | Evidence-source registration (with an "adapter is never its own source" guard). The adapter's read-back is wrapped as SELF_REPORTED. State binding obtained from the adapter. `execute(…, grant=)`. Conditional execution via `execute_conditional`. `PreconditionFailed` → `PRECONDITION_FAILED`. Observers run on every non-UNKNOWN outcome. | +81 / −19 |
| `src/aaap/objects.py` | Provenance constants, `EXEC_PRECONDITION_FAILED`, `StateBinding`, `AuthorizationGrant`, `ExecutionEvidence`, `confirmation_digest`. `AuthorizationDecision.grant` and `ActionReceipt.grant_id` / `.evidence` (all with defaults). | +97 / −0 |
| `src/aaap/adapter.py` | `PreconditionFailed`, `ExecutionReport` (= `ExecutionResult`), `state_binding()` and `execute_conditional()` with fail-closed defaults, `EvidenceSource`. | +42 / −2 |
| `src/aaap/stores.py` | `GrantStore`, `EvidenceSourceRegistry`. | +41 / −1 |
| `src/aaap/__init__.py` | Exports. | +8 / −4 |
| `src/aaap/evaluators.py` | **Unchanged.** | 0 |
| `src/aaap/canonical.py` | **Unchanged.** | 0 |

No new core files were added.

---

## 4. Did Matrix require core changes?

**No Matrix-specific core change.**

The core was changed once for F6/F7 generically, before any fixture was touched. Adding Matrix support required only fixture work:

- `fixtures/matrix/observer.py`: a /sync, txnId-correlated observer.
- `homeserver.py`: `sync_own_events`, `leave_room`, and custom content keys.
- An `org.aaap.intent_id` content key in the adapter.
- `verification.subject` in the contract.

Matrix offers no conditional send, so it gets no state binding. The core handles that generically by fail-closed DENY when a binding would be needed (S4b).

## 5. Did Calendar require core changes?

**No Calendar-specific core change.** Calendar support is all fixture work:

- Etag on reads.
- An If-Match request header with compare-and-swap inside `patch_event`.
- A per-idempotency-key request record holding the post-write snapshot.
- The adapter's `state_binding` and `execute_conditional`.
- `observer.py`.
- The contract fields `verification.subject` and `verification.state_binding`.

## 6. Did FakePay require core changes?

**No FakePay-specific core change.** FakePay support is all fixture work:

- Account revisions.
- `transfer(if_match=, metadata=)` with compare-and-swap.
- `external_debit` to simulate outside activity.
- The adapter's `state_binding` and `execute_conditional`.
- `observer.py`.
- Contract fields in all four FakePay contracts.

**One generic core change happened after the fixtures existed.** The stale-grant comparison moved from the end of `authorize` to step 8b, so a stale grant reports `state_changed_…` instead of whichever constraint happens to fail on the new state. This came from the S2b semantics and is not domain-specific.

**Designer-bias caveat (as in V0):** the same author wrote the core and all three fixtures with the brief in view. "No domain-specific core change" is weaker evidence than a blind fourth domain would give.

---

## 7. Every new generic mechanism

No new constraint evaluator was added. `evaluators.py` is unchanged.

1. **`StateBinding(subject, version_kind, version_value)`**: an opaque precondition. The core only compares it for equality.
2. **State-binding requirement rule (verifier step 8b):**
   - A binding is required if the contract declares `verification.state_binding.subject`, **or** if any contract or delegation constraint or invariant mentions a `fact:` reference.
   - If a binding is required but none is declared, the result is DENY `state_dependent_authorization_without_declared_binding`.
   - If the adapter offers no binding, the result is DENY `state_binding_unavailable`.
   - If the binding's subject differs from the declared subject reference, the result is DENY `state_binding_subject_mismatch`.
3. **Conditional execution:** `ProviderAdapter.execute_conditional(intent, plan, precondition)`, `PreconditionFailed`, and execution status `PRECONDITION_FAILED`.
   - The default implementation raises, so an adapter without it fails closed.
   - The gateway always uses the **grant's** binding as the precondition.
4. **`AuthorizationGrant` + `GrantStore`:**
   - The grant is issued only with ALLOW and is content-addressed.
   - A presented grant must be one the store issued, unaltered (`grant_not_issued_or_altered`).
   - It must be reproduced field-for-field by a full fresh authorization (`grant_mismatch:<field>`).
   - Its state binding must still be current (`state_changed_reauthorization_required`).
5. **`ExecutionReport`:** the adapter's `ExecutionResult`, now treated as a claim only.
6. **`ExecutionEvidence`, provenance classes, `EvidenceSource`, `EvidenceSourceRegistry`:**
   - Provenance (`SELF_REPORTED`, `PROVIDER_AUTHORITY`, `INDEPENDENT_READBACK`, `TRUSTED_EXECUTOR`) is assigned to a **source at registration** by the deployer. Evidence whose claimed provenance differs is rejected.
   - The adapter's read-back is automatically SELF_REPORTED.
   - An adapter object cannot be registered as an evidence source.
7. **Evidence-source policy in the contract:**
   - `verification.evidence_provenance` is optional. The default is `PROVIDER_AUTHORITY` and `INDEPENDENT_READBACK`.
   - `TRUSTED_EXECUTOR` is opt-in.
   - Listing `SELF_REPORTED` makes the contract malformed.
8. **Evidence judging (`_judge_evidence`):**
   - Each item must bind to `execution_id`, `intent_id` and the subject (`verification.subject` reference). A binding mismatch causes rejection; a subject mismatch is a VIOLATION.
   - Postconditions and post invariants run on each item's `observed_state`.
   - Observed effects must be ⊆ the declared effects.
   - When the grant carries a binding, the applied precondition must be attested and equal to it (missing → UNVERIFIED; unconditional `{}` or different → VIOLATION).
   - Authoritative evidence about an execution reported as failed causes VIOLATION.
9. **Asymmetry rule:** claims and self-reported evidence can **incriminate** (cause VIOLATION) but can never **exonerate** (contribute to VERIFIED).
10. **Observers run even when the execution path reports failure.** They are not run for UNKNOWN; the V0 in-doubt and lookup path is unchanged.
11. **Self-report subject extraction:** the gateway reads the self-reported subject from the adapter's read-back using the field name of the `verification.subject` reference. This is a generic convention and only ever incriminates.

## 8. Every provider/domain-specific rule introduced

All of these are outside `src/`.

| Domain | Where | Rule |
|---|---|---|
| Matrix | `matrix/contract_v1.json` | `verification.subject = plan:room_id`. No state binding: the authorization reads only the intent. |
| | `matrix/adapter.py` | Adds `org.aaap.intent_id` to the event content. Explicitly no state binding and no conditional send. |
| | `matrix/homeserver.py` | `/sync` own events with `unsigned.transaction_id` (visible only to the sending token); `leave_room`; custom content keys. |
| | `matrix/observer.py` | Finds the event by txnId == execution_id. Subject = actual room; maps `m.room.message` → `message_created`. Registered `PROVIDER_AUTHORITY`. |
| Calendar | `calendar/contract_v1.json`, `contract_v2.json` | `verification.subject = plan:event_id`; `verification.state_binding.subject = plan:event_id`. Required anyway, because `allowed_calendar` reads `fact:calendar_id`. |
| | `calendar/provider.py` | Etag = digest of the event's content (any edit changes it). `request_headers(if_match, metadata)`. CAS inside `patch_event`. Per-key request record: event, caller, If-Match, metadata, effects, post-write snapshot. |
| | `calendar/adapter.py` | Binding = `(event_id, "etag", etag)`. `execute_conditional` sends If-Match and intent metadata; HTTP 412 → `PreconditionFailed`. |
| | `calendar/observer.py` | Reads the request record by execution_id. Subject = the event actually patched; state = post-write snapshot; applied precondition = the recorded If-Match (`{}` if none). Registered `PROVIDER_AUTHORITY`. |
| FakePay | all 4 `fakepay/contract*.json` | `verification.subject = plan:recipient`; `verification.state_binding.subject = fact:payer_account`. Bound because the post invariant `payer_debited_exactly` compares against the authorization-time balance. |
| | `fakepay/provider.py` | Account revision bumps on every movement. `transfer(if_match=, metadata=)` with CAS before commit. `external_debit`. Transactions store If-Match and metadata. |
| | `fakepay/adapter.py` | Facts gain `payer_account` and `payer_account_version`. Binding = `(payer, "account_revision", version)`. `precondition_failed` → `PreconditionFailed`. |
| | `fakepay/observer.py` | Transaction by idempotency key. Subject = actual recipient; state = tx fields + payer balance (read now; see finding V01-F). Registered `PROVIDER_AUTHORITY`. |
| All | `*/world.py` | Register the observer as `PROVIDER_AUTHORITY` (`observe=False` turns it off for tests). |

---

## 9. Was `AuthorizationGrant` necessary?

**Yes, as a narrow execution-binding record. Not as a capability.**

The alternative was tested on paper and in code. V0 re-authorizes inside `execute()`. Without a carried artifact, that path re-reads provider state and silently authorizes against **S2**. That is safe only when the new state still satisfies the constraints, and it is wrong for the brief's S2/S3/S6 semantics: the principal confirmed against S1, so execution against S2 must stop and require fresh authorization. Something must therefore carry S1's binding from authorization to execution.

Three options were considered:

- **Extend `AuthorizationDecision` with the binding.** This works mechanically, but a decision is also produced for DENY and REQUIRE_CONFIRMATION and for previews. It mixes "what the PDP concluded" with "what the PEP may do".
- **Put the binding in the `Confirmation`.** This does not cover contracts that need no confirmation (Calendar). It would also make human approval stale on every unrelated state change.
- **A distinct grant, issued only with ALLOW (chosen).** It binds intent digest, contract digest and version, delegation digest, confirmation digest, plan digest, state binding and execution_id. That gives one object for the adapter and provider to enforce (the If-Match value), and one for evidence to attest against (the applied precondition).

What the grant earned, measured by tests:

| Test | Why it needs the grant |
|---|---|
| S2a, S2b, S3a, S6b | A fresh re-read alone would execute against S2. |
| S5a, S5d | Tampering is detectable because grants are store-issued and content-addressed. |
| S2d, U4, U5 | Evidence can prove the provider honoured *this* precondition. |
| X2b, X4 | A grant cannot be moved to another intent or execution. |

What the grant deliberately is **not**:

- It never skips re-authorization. Revocation, expiry, contract change and confirmation are re-checked (X1, X3).
- It only *adds* conditions.
- It has no expiry of its own and no signature (scope).
- The store is in-memory, like the V0 ledger. After a restart, presented grants are rejected and the caller must re-authorize (fail closed).

## 10. Can self-reported evidence ever become `VERIFIED`?

**No, not in this model.** Five structural guarantees enforce this:

1. The contract validator rejects `SELF_REPORTED` in `evidence_provenance` (E1e).
2. The verifier computes `authoritative = registered_provenance != SELF_REPORTED and registered_provenance in accepted`. This is a hard rule, not configuration.
3. Provenance comes from the deployer's registry, not from the evidence. A self-promoting claim is rejected (E1c), and unregistered sources are rejected (E1d).
4. The adapter's own read-back is registered SELF_REPORTED by `register_adapter`. An adapter object cannot be registered as a source, and the execution-path identity is reserved (E1f).
5. `VERIFIED` requires `authoritative_ok ≥ 1`. Self-reported evidence and the report can only add violations.

**Limit:** the core can only see object identity and type. A deployer who registers, as `PROVIDER_AUTHORITY`, an observer that in fact reads the adapter's own memory ("fake independence") is not detectable by the core. Independence is a deployment property (§11).

## 11. Exact trust assumptions for authoritative evidence

`VERIFIED` means "an authoritative source observed this" only under all of the following:

1. **The provider is honest about its own records.** The txnId → event mapping, idempotency-key → request record, transaction record, the If-Match it actually enforced, and the post-write snapshot are all trusted. A malicious provider is out of scope; the brief does not claim to detect it.
2. **The provider enforces the precondition it records** (CAS is atomic and is what it says).
3. **Evidence-source code is in the trusted base.** Each observer is fixture code; in the experiment it is "independent" of the adapter only structurally:
   - it is a separate object;
   - it never receives the adapter's report;
   - it locates the effect by execution_id, not by the adapter's provider_ref or room.
   It uses the same principal credential the gateway holds.
4. **Deployer classification is correct.** Whoever calls `register_evidence_source(…, PROVIDER_AUTHORITY)` vouches that the source reads the provider and not the execution path.
5. **The execution_id reaches the provider unchanged** as its idempotency key or txnId. An adapter that uses a different key makes the effect invisible to the observer, which gives UNVERIFIED, not VERIFIED.
6. **The `intent_id` in evidence is client metadata supplied on the write by the execution path.** It binds evidence to an intent against mix-ups and replay (E3, E4). It is **not** proof of which intent the adapter meant.
7. **The channel between source and verifier is in-process** and integrity is assumed. There are no signatures (scope).
8. **Observed state is only as fresh as its read.** The Calendar post-write snapshot is commit-time. The FakePay payer balance is observation-time (finding V01-F).

## 12. Does conditional execution close the tested TOCTOU cases?

**Yes, for every tested case, in the fixture providers.**

| Case | Mechanism | Outcome |
|---|---|---|
| State change between grant and execute (S2a, S2b, S3a, S6b) | Grant binding ≠ fresh binding → DENY before the provider. The provider compare-and-swap would also catch it. | No effect |
| State change inside the execution window (S2c, S3b, V0 F7 scenario) | Provider-native compare-and-swap; check and write happen in one step | No effect, no partial effect |
| Token from another resource (S5b) | Provider compare-and-swap (tokens are per-resource) | No effect |
| Adapter skips the precondition (S2d) | Not *prevented*. Detected by authoritative evidence. | VIOLATION |
| Retry of a stale execution (S6a) | Ledger replay; the execution_id is spent | No re-execution |

The guarantee is only as strong as the provider's compare-and-swap. Where the adapter is trusted to pass the precondition and does not, the effect happens and is only **detected** afterwards (S2d). Where the provider has no compare-and-swap (Matrix), any state-dependent authorization is **denied**, never executed stale (S4b, S4c).

## 13. Cases that remain impossible to verify without provider cooperation

The fixtures had to be given these provider features. Each one is a cooperation requirement, not a core capability:

| Capability required | Matrix (real C-S API) | Calendar | FakePay / payments |
|---|---|---|---|
| Effect lookup keyed by the client's execution id | Partial: `unsigned.transaction_id` in /sync, only for the same access token or device. There is no direct lookup (V0 G17). | Fixture request record. Real calendar APIs generally lack idempotency records. | Stripe-style idempotent object lookup is common. |
| Private client metadata to bind intent_id | **No.** Only content keys, which are public to the room (V01-E). | Some APIs have private extended properties. | Common (e.g., payment `metadata`). |
| Conditional write on resource version (CAS) | **No conditional send.** | HTTP ETag/If-Match is common for calendar APIs. Not verified against a live service here. | **Uncommon** at account level. The FakePay account-revision CAS is invented for the fixture. |
| Record of the precondition actually applied | No | Fixture only | Fixture only |
| Commit-time snapshot of observed state | No | Fixture post-write snapshot | No: balance read later (V01-F) |

Without these, the core's correct behaviour is to **not** say VERIFIED and to **deny** state-dependent actions. It does that (E1, U2–U4, S4b). It cannot do better.

Also unverifiable in principle with execution-scoped evidence: **effects the execution path performs outside the execution** (V01-A).

## 14. New findings and classifications

Each finding below is reproduced by a test that passes because the weakness exists.

| # | Finding | Test | Classification | Why this class |
|---|---|---|---|---|
| V01-A | An adapter holding the principal's credential performs the authorized action correctly **and** an unauthorized one under another txnId. The receipt is truthfully VERIFIED for its own execution and silent about the extra effect. | `test_FINDING_V01_A_…` | `CORE_ARCHITECTURE_DEFICIENCY` | Evidence is execution-scoped by design, and the adapter has credential custody. Closing it needs credential isolation (the provider only accepts writes carrying a live grant) or complete per-principal audit evidence. Both are architectural, not per-domain. |
| V01-B | The binding requirement is inferred from explicit `fact:` references. `core.numeric_delta` and `core.preserve_fields` read `ctx.facts` implicitly. A FakePay contract that omits `state_binding` executes unbound, and in-window activity commits against S2 (post-check gives a false VIOLATION). | `test_FINDING_V01_B_…` | `GENERIC_EVALUATOR_DEFICIENCY` | Evaluators do not declare which state they read, so the core cannot infer the binding requirement. The shipped contracts declare it explicitly. |
| V01-C | The FakePay account revision changes on **any** movement, including incoming money. That invalidates grants that should still hold, and the principal must re-confirm. | `test_FINDING_V01_C_…` | `STATE_BINDING_DEFICIENCY` | An opaque whole-resource token cannot express "only these fields matter". This is safe but costs liveness. |
| V01-D | Self-reported evidence may incriminate. A lying read-back turns an authoritatively confirmed execution into VIOLATION. | `test_FINDING_V01_D_…` | `EVIDENCE_MODEL_DEFICIENCY` | There is no precedence rule between self-report and authority. V0.1 chooses "any violation wins" (fail-safe, but the receipt can be poisoned). |
| V01-E | Matrix intent binding travels as a public event-content key. The provider write also contains a field the intent never had, outside `plan_vs_intent`. | `test_FINDING_V01_E_…` | `PROVIDER_LIMITATION` | Matrix offers no private per-request metadata. |
| V01-F | FakePay evidence pairs the transaction record with a balance read later. Movement between commit and observation makes a correct transfer look like a wrong debit. | `test_FINDING_V01_F_…` | `EVIDENCE_MODEL_DEFICIENCY` | `observed_state` carries no "as of" binding. |
| V01-G | Matrix cannot carry a state binding (no conditional send). Any Matrix capability whose authorization depends on room state is denied. | `S4b`, `S4c` | `PROVIDER_LIMITATION` | This is the correct fail-closed outcome of the generic rule. |
| V01-H | Account-level conditional transfers do not exist in typical payment APIs. S3 holds only because the fixture invented them. | (S3 tests; real-API claim not testable here) | `PROVIDER_LIMITATION` | — |

V0 findings status:

- F6 and F7 are closed in the tested model (§1).
- F1 (forgeable confirmation) still reproduces.
- F2 still reproduces.
- F3 still reproduces: the restarted gateway re-reads state and gets a fresh binding, so state binding does not help.
- F4 still reproduces.
- F5 still reproduces: false VIOLATION via the self-report, because the UTC provider's record lives on a different provider object than the observer reads.

---

## 15. Final verdict: **`PARTIALLY_SURVIVED`**

### Success criteria

| Criterion | Met? | Evidence |
|---|---|---|
| Old tests still pass | Yes | 57/57. 55 unchanged; the 2 V0 finding tests for F6/F7 inverted because the weakness is closed. |
| A lying or self-reporting adapter cannot manufacture VERIFIED (tested model) | Yes | E1–E1f, E2, E2b, E2c, F6 test |
| Evidence replay and binding attacks fail | Yes | E3, E4, E5, U1, U5 |
| Stale state cannot execute (tested conditional-execution model) | Yes | S2a–c, S3a–b, S5a–d, S6a–b, F7 test |
| Revocation, confirmation and contract bindings hold | Yes | X1, X2, X2b, X3 |
| At-most-once holds | Yes | X4, X4b, S6a, and all V0 idempotency tests |
| No provider-specific branches in core | Yes | G1, G1b, G18 (extended word list over every core file), G19; `evaluators.py` untouched |
| Unknown or insufficient evidence does not fail open | Yes | U1–U4, E1d, E6b, S4b, S4c |

### Why not `SURVIVED`

All `SURVIVED` bullets hold in the tested model. But the brief defines `PARTIALLY_SURVIVED` as "generic architecture remains intact but **meaningful provider cooperation** … required", and that is exactly what happened.

Every F6/F7 guarantee rests on provider features that had to be added to the fakes (§13):

- execution-id-keyed records;
- client metadata;
- atomic compare-and-swap;
- a record of the applied precondition.

Two of these do not exist where they would be needed:

- Matrix has no conditional send and no private metadata.
- Account-level compare-and-swap is not standard for payments.

Separately, V01-A shows that "VERIFIED" means "this execution happened as authorized", **not** "the adapter did nothing else". That boundary is architectural.

### Why not `FAILED`

None of the protections required the core to understand rooms, events or money:

- The verifier compares opaque tokens, provenance labels and bound identifiers.
- All domain meaning stays in contracts, adapters, observers and fake providers.
- The core changes were generic and were made once.

### What this does **not** show

The brief's non-claims stand. This experiment does not show that:

- malicious providers are detectable;
- independent evidence exists for real APIs;
- arbitrary APIs support atomic conditional writes;
- cryptographic identity is solved;
- distributed TOCTOU is solved;
- the protocol applies universally.

The fixtures were written by the same author as the core.
