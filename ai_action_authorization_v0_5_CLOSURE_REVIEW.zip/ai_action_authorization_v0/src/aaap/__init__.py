"""AI Action Authorization Protocol — V0 prototype core (domain-agnostic). V0.2: execution-scoped authority.
V0.3: protocol boundary (no new protocol object).
V0.4: composite execution binding (opaque execution units inside ExecutionBinding; no new object)."""
from .adapter import (
    ConfinedExecutor, EvidenceSource, ExecutionReport, ExecutionResult, PreconditionFailed, ProviderAdapter, ProviderTimeout,
)
from .evaluators import ConstraintEvaluatorRegistry, core_registry
from .authority import (
    CONFINED, GUARANTEE_ASSUMED, GUARANTEE_DECLARED, GUARANTEE_NONE, INFRA_ISOLATION, INFRA_POP,
    INFRA_PROVIDER_ENFORCES, MODE_A, MODE_B, MODE_C, NOT_CONFINED, Attenuation, C, Confinement, ExecutionAuthority,
    ExecutionCredential, ExecutionPort, Invocation, ProviderEffector, ProviderOperation,
)
from .gateway import ActionGateway, GatewayCodes, GatewayOutcome
from .objects import (
    ALLOW, DENY, EXEC_PARTIAL, INDEPENDENT_READBACK, PROVIDER_AUTHORITY, REQUIRE_CONFIRMATION, SELF_REPORTED, TRUSTED_EXECUTOR,
    UNVERIFIED, VERIFIED, VIOLATION, UNIT_STATE_AUTHORIZATION, UNIT_STATE_FROM, UNIT_STATE_UNBOUND,
    ActionIntent, ActionReceipt, AuthorizationDecision, AuthorizationGrant, CapabilityContract, Confirmation,
    Delegation, ExecutionEvidence, StateBinding, qualified_contract_id,
)
from .stores import ContractRegistry, DelegationStore, EvidenceSourceRegistry, ExecutionLedger, GrantStore
from .verifier import AuthorizationVerifier, R, STATE_CONSISTENCY_LEVELS
