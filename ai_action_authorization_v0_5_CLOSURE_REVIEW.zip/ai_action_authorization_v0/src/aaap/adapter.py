"""Provider adapter interface. Adapters hold all provider/domain specifics;
the core only calls these methods.

V0.1: the adapter is the EXECUTION PATH. Everything it returns is a claim
(ExecutionResult == ExecutionReport; its read_back == SELF_REPORTED evidence).
Evidence that can verify an execution comes from separately registered
EvidenceSource objects (see gateway.register_evidence_source).

V0.4: ExecutionResult may carry the opaque state token a unit's effect established (the
input to a dependent unit's precondition). The default ConfinedExecutor submits one
operation per authorized execution unit, in declared order."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .objects import EXEC_SUCCESS


class ProviderTimeout(Exception):
    """The provider call's outcome is unknown (effect may or may not have happened)."""


class PreconditionFailed(Exception):
    """The provider refused a conditional write: the bound state is no longer current.
    No effect happened."""


@dataclass(frozen=True)
class ExecutionResult:
    status: str                 # objects.EXEC_SUCCESS / EXEC_FAILED / EXEC_UNKNOWN
    execution_id: str
    provider_ref: Optional[str]
    request: Dict[str, Any]     # what was actually sent to the provider
    observed_effects: List[str] = field(default_factory=list)   # claimed effects
    detail: str = ""
    # V0.4: StateBinding dict of the state this (unit) effect produced, if the provider exposes it
    established_state: Optional[Dict[str, str]] = None


# V0.1 name for the same thing: a claim made by the execution path.
# (claimed_status=status, claimed_result=provider_ref+request, claimed_effects=observed_effects;
#  intent_id and reporter_identity are known to the gateway, which made the call.)
ExecutionReport = ExecutionResult


class ProviderAdapter:
    def resolve(self, intent) -> Dict[str, Any]:
        """Read-only provider state the constraints/invariants need (facts)."""
        raise NotImplementedError

    def plan(self, intent, facts: Dict[str, Any]) -> Dict[str, Any]:
        """The exact provider request that execute() will send."""
        raise NotImplementedError

    def execute(self, intent, plan: Dict[str, Any]) -> ExecutionResult:
        """Send `plan` using intent.execution_id as the provider idempotency key.
        Raise ProviderTimeout if the outcome is unknown."""
        raise NotImplementedError

    def read_back(self, intent, result: ExecutionResult) -> Optional[Dict[str, Any]]:
        """Independent post-execution read of provider state, or None if unavailable."""
        raise NotImplementedError

    def lookup(self, intent) -> Optional[ExecutionResult]:
        """Read-only: find the outcome of a previous attempt for intent.execution_id.
        Return None if the provider offers no way to know."""
        return None

    # ------------------------------------------------------------- V0.1
    def state_binding(self, intent, facts: Dict[str, Any]):
        """The provider's opaque version token (objects.StateBinding) for the state
        `facts` were read from, or None if the provider cannot condition a write on it."""
        return None

    def execute_conditional(self, intent, plan: Dict[str, Any], precondition) -> ExecutionResult:
        """Like execute(), but the provider must apply the write atomically ONLY IF
        `precondition` (a StateBinding) is still current; else raise PreconditionFailed."""
        raise NotImplementedError("provider offers no conditional execution")


class EvidenceSource:
    """Observes the outcome of one execution OUTSIDE the execution path.

    Receives only core-validated inputs (the intent and the grant), never the
    adapter's report, so the execution path cannot steer what is observed.
    Its provenance class is assigned at registration, not self-declared."""
    identity: str = ""

    def observe(self, intent, grant) -> Optional[Any]:
        """Return objects.ExecutionEvidence for intent.execution_id, or None."""
        raise NotImplementedError


class ConfinedExecutor:
    """V0.2: the UNTRUSTED execution path (the AI-side executor) in confined mode.

    It receives plain data (intent, plan), one ExecutionCredential and an
    ExecutionPort. It holds no provider client or provider credential; its only
    path to a provider effect is port.invoke(credential, operation), which the
    enforcement boundary checks. Whatever it returns is ignored: the gateway takes
    the outcome from the boundary's own record.

    This default implementation submits exactly the planned request. V0.4: for a credential
    that carries execution units it submits each unit's exact request, in declared order,
    skipping a unit whose declared predecessors did not succeed (the boundary would refuse it)."""
    identity: str = ""

    def __init__(self, identity: str):
        self.identity = identity

    def execute_confined(self, intent, plan: Dict[str, Any], credential, port) -> Any:
        from .authority import ProviderOperation
        units = getattr(credential, "units", ())
        if not units:
            return port.invoke(credential, ProviderOperation(credential.contract_id, credential.capability,
                                                             credential.execution_id, dict(plan)))
        done, out = set(), []
        for u in units:
            if any(p not in done for p in u.get("after", [])):
                continue
            inv = port.invoke(credential, ProviderOperation(credential.contract_id, credential.capability,
                                                            credential.execution_id, dict(u["request"]),
                                                            unit=u["unit_id"]))
            out.append(inv)
            if inv.allowed and inv.result is not None and inv.result.status == EXEC_SUCCESS:
                done.add(u["unit_id"])
        return out
