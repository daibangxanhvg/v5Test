"""The five core protocol objects (+ one supporting record, Confirmation).

V0.1 adds three execution-binding records: StateBinding, AuthorizationGrant,
ExecutionEvidence (ExecutionReport is adapter.ExecutionResult, see adapter.py).

V0.2 extends AuthorizationGrant with what attenuation needs (principal, agent,
capability, resource, exact authorized request, lifetime, uses, state-dependency
set). The attenuated ExecutionCredential itself lives in authority.py.

V0.3 (protocol boundary) adds no object. It adds, inside existing objects:
- CapabilityContract security identity (binding_digest): the artifact digest minus
  fields the issuer EXPLICITLY declares non-security, from a closed protocol list;
- extension criticality: an unknown top-level contract field is security-critical
  unless the contract declares it noncritical;
- issuer-qualified contract addresses (qualified_contract_id);
- the authorized effect set carried in the grant (ExecutionBinding);
- EXEC_PARTIAL: some, not all, declared effects were performed.

V0.4 (composite execution binding) adds no object either. Inside existing ones:
- CapabilityContract may declare `execution_units`: opaque, provider-named units that
  partition its effects (explicitly required or optional), with the request fields each
  unit carries, an explicit order relation, an explicit state precondition and an
  evidence requirement. Unit ids and effect labels are never interpreted;
- AuthorizationGrant.execution_units: the exact unit table authorized (ExecutionBinding);
- ExecutionEvidence: which units it covers, the grant lineage it was recorded under, and
  per-unit applied/established state tokens;
- ActionReceipt.units: per-unit execution and verification outcome.

Objects are frozen dataclasses. Nested dict/list fields are NOT deeply
immutable in Python; immutability of security-relevant data is enforced by
digest binding (see verifier), not by the type system.
"""
from __future__ import annotations

import copy
import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from . import canonical

# ---------------------------------------------------------------- decisions
ALLOW = "ALLOW"
REQUIRE_CONFIRMATION = "REQUIRE_CONFIRMATION"
DENY = "DENY"

# ---------------------------------------------------- verification statuses
VERIFIED = "VERIFIED"
UNVERIFIED = "UNVERIFIED"
VIOLATION = "VIOLATION"

# ------------------------------------------------- provider execution status
EXEC_SUCCESS = "SUCCESS"
EXEC_FAILED = "FAILED"
EXEC_UNKNOWN = "UNKNOWN"  # e.g. network timeout: effect may or may not have happened
EXEC_PRECONDITION_FAILED = "PRECONDITION_FAILED"  # provider refused: bound state no longer current
EXEC_PARTIAL = "PARTIAL"  # V0.3: some declared effects happened, others did not (report.observed_effects says which)

# ------------------------------------- V0.4 execution-unit state preconditions
UNIT_STATE_AUTHORIZATION = "authorization"     # the grant's authorization-time state binding
UNIT_STATE_UNBOUND = "unbound"                 # explicitly no state precondition
UNIT_STATE_FROM = "from_unit"                  # the state a declared predecessor unit established

# ------------------------------------------------------- evidence provenance
# Assigned to an evidence SOURCE by whoever deploys the gateway, never taken
# from the evidence itself. Not all classes are equally authoritative.
SELF_REPORTED = "SELF_REPORTED"              # the execution path describing its own work
PROVIDER_AUTHORITY = "PROVIDER_AUTHORITY"    # the provider's own record, read outside the execution path
INDEPENDENT_READBACK = "INDEPENDENT_READBACK"  # a separate reader observing resulting state
TRUSTED_EXECUTOR = "TRUSTED_EXECUTOR"        # an executor inside the trusted base (opt-in per contract)
PROVENANCES = (SELF_REPORTED, PROVIDER_AUTHORITY, INDEPENDENT_READBACK, TRUSTED_EXECUTOR)
DEFAULT_AUTHORITATIVE = (PROVIDER_AUTHORITY, INDEPENDENT_READBACK)


# =============================================================== 1. Contract
CONTRACT_FIELDS = (
    "contract_id", "issuer", "version", "capability", "description", "inputs",
    "effects", "risk", "reversible", "required_authority", "confirmation_policy",
    "invariants", "constraints", "verification",
)
# V0.3: optional protocol fields (absent in every V0-V0.2 contract, so their digests are unchanged)
OPTIONAL_CONTRACT_FIELDS = ("security_identity", "human_metadata", "noncritical_extensions",
                            "execution_units")   # V0.4
# the closed list of fields an issuer may declare outside the contract's security identity
NON_SECURITY_ELIGIBLE = ("description", "human_metadata")
QUALIFIER = "::"


def qualified_contract_id(issuer: str, contract_id: str) -> str:
    """V0.3: issuer-qualified contract address. Two issuers may use the same local id;
    their qualified addresses never collide. Authenticating the issuer is infrastructure."""
    return f"{issuer}{QUALIFIER}{contract_id}"


@dataclass(frozen=True)
class CapabilityContract:
    contract_id: str
    issuer: str
    version: str
    capability: str
    description: str
    inputs: Dict[str, Dict[str, Any]]
    effects: List[str]
    risk: str
    reversible: bool
    required_authority: str
    confirmation_policy: Dict[str, Any]
    invariants: List[Dict[str, Any]]
    constraints: List[Dict[str, Any]]
    verification: Dict[str, Any]
    # Unknown top-level fields are kept (and digested) but never interpreted.
    extensions: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CapabilityContract":
        data = copy.deepcopy(data)
        missing = [f for f in CONTRACT_FIELDS if f not in data]
        if missing:
            raise ValueError(f"contract missing fields: {missing}")
        known = {f: data.pop(f) for f in CONTRACT_FIELDS}
        return cls(**known, extensions=data)

    def to_dict(self) -> Dict[str, Any]:
        d = {f: copy.deepcopy(getattr(self, f)) for f in CONTRACT_FIELDS}
        d.update(copy.deepcopy(self.extensions))
        return d

    def digest(self) -> str:
        """Artifact identity: every byte of the contract."""
        return canonical.digest(self.to_dict())

    # ------------------------------------------------------------------ V0.3
    def non_security_fields(self) -> Tuple[str, ...]:
        """Fields the issuer explicitly declared outside the security identity. Only names
        from the closed NON_SECURITY_ELIGIBLE list ever count; anything else is ignored here
        (and makes the contract malformed in the verifier)."""
        si = self.extensions.get("security_identity")
        exclude = si.get("exclude") if isinstance(si, dict) else None
        if not isinstance(exclude, list):
            return ()
        return tuple(sorted({f for f in exclude if f in NON_SECURITY_ELIGIBLE}))

    def binding_digest(self) -> str:
        """Security identity: what delegations, confirmations-of-authority, grants and
        credentials bind. Equal to digest() unless the issuer declared a security_identity
        (then: digest of everything except the declared non-security fields). The
        declaration itself is inside the identity, so changing it is a security change."""
        if "security_identity" not in self.extensions:
            return self.digest()
        d = self.to_dict()
        for f in self.non_security_fields():
            d.pop(f, None)
        return canonical.digest({"_": "aaap-v0.3-contract-security-identity", "contract": d})

    def declared_noncritical(self) -> Tuple[str, ...]:
        names = self.extensions.get("noncritical_extensions")
        return tuple(n for n in names if isinstance(n, str)) if isinstance(names, list) else ()

    def unknown_extensions(self) -> Tuple[str, ...]:
        """Top-level fields this protocol version does not know and the issuer did not declare noncritical."""
        known = set(OPTIONAL_CONTRACT_FIELDS) | set(self.declared_noncritical())
        return tuple(sorted(k for k in self.extensions if k not in known))

    def execution_units(self) -> List[Dict[str, Any]]:
        """V0.4: the declared unit table ([] = the contract declares no composition)."""
        units = self.extensions.get("execution_units")
        return copy.deepcopy(units) if isinstance(units, list) else []

    def decision_view(self) -> "CapabilityContract":
        """What evaluators may see: no declared non-security field and no noncritical extension.
        Content that is outside the security identity can therefore never influence a decision."""
        hidden = set(self.declared_noncritical()) | (set(self.non_security_fields()) - {"description"})
        ext = {k: copy.deepcopy(v) for k, v in self.extensions.items() if k not in hidden}
        desc = "" if "description" in self.non_security_fields() else self.description
        return dataclasses.replace(self, description=desc, extensions=ext)


# ============================================================= 2. Delegation
@dataclass(frozen=True)
class Delegation:
    delegation_id: str
    principal: str
    agent: str
    allowed_authority: List[str]
    # each: {"contract_id", "capability", "contract_version", "contract_digest"}
    allowed_capabilities: List[Dict[str, Any]]
    # each: {"id", "params"} binding a contract constraint, or a full
    # {"id", "evaluator", "target"/"targets", "params"} extra constraint
    constraints: List[Dict[str, Any]]
    valid_from: str   # ISO-8601 with offset
    valid_until: str  # ISO-8601 with offset
    revoked: bool = False

    def to_dict(self, include_revocation: bool = True) -> Dict[str, Any]:
        d = {
            "delegation_id": self.delegation_id,
            "principal": self.principal,
            "agent": self.agent,
            "allowed_authority": list(self.allowed_authority),
            "allowed_capabilities": copy.deepcopy(list(self.allowed_capabilities)),
            "constraints": copy.deepcopy(list(self.constraints)),
            "valid_from": self.valid_from,
            "valid_until": self.valid_until,
        }
        if include_revocation:
            d["revoked"] = self.revoked
        return d

    def digest(self) -> str:
        # Revocation state is checked separately; it is not part of the grant's identity.
        return canonical.digest(self.to_dict(include_revocation=False))


# ============================================================ 3. ActionIntent
@dataclass(frozen=True)
class ActionIntent:
    intent_id: str
    agent: str
    principal: str
    contract_id: str
    capability: str
    arguments: Dict[str, Any]
    execution_id: str


def intent_digest(intent: ActionIntent, contract: CapabilityContract) -> str:
    """Digest of the security-relevant view of an intent.

    An input is security-relevant unless the contract explicitly marks it
    `"security_relevant": false` (fail closed). Arguments not declared by the
    contract are included (they are rejected by argument validation anyway).
    """
    args = {
        k: v for k, v in intent.arguments.items()
        if contract.inputs.get(k, {}).get("security_relevant", True) is not False
    }
    return canonical.digest({
        "_": "aaap-v0-intent",
        "intent_id": intent.intent_id,
        "agent": intent.agent,
        "principal": intent.principal,
        "contract_id": intent.contract_id,
        "capability": intent.capability,
        "execution_id": intent.execution_id,
        "arguments": args,
    })


# =================================================== 4. AuthorizationDecision
@dataclass(frozen=True)
class AuthorizationDecision:
    decision: str
    reasons: Tuple[Dict[str, str], ...]
    intent_id: Optional[str]
    intent_digest: Optional[str]
    contract_id: Optional[str]
    contract_version: Optional[str]
    contract_digest: Optional[str]
    delegation_id: Optional[str]
    delegation_digest: Optional[str]
    decided_at: str
    warnings: Tuple[Dict[str, str], ...] = ()
    grant: Optional["AuthorizationGrant"] = None   # V0.1: present iff decision == ALLOW
    # V0.3: the full artifact digest (what a human confirming the action was shown).
    # contract_digest above is the contract's security identity (binding_digest).
    contract_artifact_digest: Optional[str] = None

    def codes(self) -> List[str]:
        return [r["code"] for r in self.reasons]


# ========================================================== 5. ActionReceipt
@dataclass(frozen=True)
class ActionReceipt:
    receipt_id: str
    intent_id: str
    execution_id: str
    authorization: AuthorizationDecision
    execution_result: Dict[str, Any]   # {"status", "provider_ref", "detail"}
    observed_effects: Tuple[str, ...]
    verification_status: str
    verification_reasons: Tuple[Dict[str, str], ...]
    grant_id: Optional[str] = None
    # V0.1: every piece of evidence considered: {evidence_id, source, provenance, outcome}
    evidence: Tuple[Dict[str, str], ...] = ()
    # V0.4: per execution unit {unit_id, required, execution, verified, evidence, reasons}; () = no units
    units: Tuple[Dict[str, Any], ...] = ()
    # V0.5: honest state-precondition guarantee accounting; does not imply effect atomicity.
    state_consistency: Optional[Dict[str, str]] = None

    def codes(self) -> List[str]:
        return [r["code"] for r in self.verification_reasons]


# ======================================= supporting record (not a core object)
@dataclass(frozen=True)
class Confirmation:
    """The principal's approval of ONE exact authorization decision.

    Not one of the five core objects; the brief requires confirmation binding
    but specifies no object for it (recorded in RESULTS.md as an ambiguity).
    V0 has no signatures: anyone in-process can construct one.
    """
    principal: str
    intent_id: str
    intent_digest: str
    contract_digest: str
    delegation_id: str
    delegation_digest: str
    confirmed_at: str

    @classmethod
    def from_decision(cls, decision: AuthorizationDecision, principal: str, confirmed_at: str) -> "Confirmation":
        if decision.decision != REQUIRE_CONFIRMATION:
            raise ValueError("only a REQUIRE_CONFIRMATION decision can be confirmed")
        return cls(
            principal=principal,
            intent_id=decision.intent_id,
            intent_digest=decision.intent_digest,
            # V0.3: a confirmation binds the artifact the human saw, metadata included
            contract_digest=decision.contract_artifact_digest or decision.contract_digest,
            delegation_id=decision.delegation_id,
            delegation_digest=decision.delegation_digest,
            confirmed_at=confirmed_at,
        )


# ======================================== V0.1 execution-binding records
@dataclass(frozen=True)
class StateBinding:
    """Existing StateBinding, generalized in V0.5 without a new binding category.

    Legacy single-subject fields remain the first three fields for V0--V0.4 compatibility.
    `dependencies`, when present, is the opaque multi-subject representation. Generic core
    binds identity/lineage/scope and guarantee strength; it never parses binding values.
    """
    subject: str = ""
    version_kind: str = ""
    version_value: str = ""
    dependencies: Tuple[Dict[str, Any], ...] = ()
    required_consistency: str = "INDIVIDUALLY_CHECKED"
    observed_consistency: str = "INDIVIDUALLY_CHECKED"
    consistency_context: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        if not self.dependencies:
            return {"subject": self.subject, "version_kind": self.version_kind, "version_value": self.version_value}
        d = {"dependencies": copy.deepcopy(list(self.dependencies)),
             "required_consistency": self.required_consistency, "observed_consistency": self.observed_consistency}
        if self.consistency_context is not None:
            d["consistency_context"] = copy.deepcopy(self.consistency_context)
        return d

    def dependency_table(self) -> Tuple[Dict[str, Any], ...]:
        if self.dependencies:
            return tuple(copy.deepcopy(self.dependencies))
        if self.subject and self.version_kind and self.version_value:
            return ({"dependency_id": "legacy", "issuer": "", "subject_ref": self.subject,
                     "binding_type": self.version_kind, "binding_value": self.version_value, "required": True},)
        return ()


@dataclass(frozen=True)
class AuthorizationGrant:
    """This exact execution is authorized under these exact authority, intent,
    contract, confirmation and state conditions.

    Issued only with an ALLOW. Not a bearer capability: presenting it never
    skips re-authorization; it can only add conditions (it pins the
    authorization-time state binding and plan)."""
    grant_id: str
    intent_id: str
    intent_digest: str
    contract_id: str
    contract_version: str
    contract_digest: str
    delegation_id: str
    delegation_digest: str
    confirmation_digest: Optional[str]
    plan_digest: str
    state_binding: Optional[StateBinding]
    execution_id: str
    # ---- V0.2: everything an ExecutionCredential may be attenuated from
    principal: Optional[str] = None
    agent: Optional[str] = None                       # the only identity a credential may be minted for
    capability: Optional[str] = None
    resource: Optional[Dict[str, Any]] = None         # {"ref": <verification.subject>, "value": ...}
    request: Optional[Dict[str, Any]] = None          # the exact authorized provider request (= plan)
    not_after: Optional[str] = None                   # grant validity ends (delegation valid_until)
    max_uses: int = 1
    state_dependencies: Tuple[str, ...] = ()          # opaque `fact:` refs the decision relied on
    # dependencies the authorization could NOT carry into execution:
    # ({"ref", "class": "unbound" | "undeclared_read", "by": <constraint/invariant id>}, ...)
    dependency_gaps: Tuple[Dict[str, str], ...] = ()
    # ---- V0.3: the effect set this authorization covers (ExecutionBinding). A Mode A provider
    # or a Mode B effector can refuse to cause any effect outside it.
    effects: Tuple[str, ...] = ()
    # ---- V0.4: the exact execution-unit table (ExecutionBinding). Each entry:
    # {unit_id, required, effects, request, after, state, evidence, post_invariants}, where
    # `request` is the projection of the authorized request onto the unit's declared fields.
    execution_units: Tuple[Dict[str, Any], ...] = ()

    def body(self) -> Dict[str, Any]:
        body = {
            "_": "aaap-v0.2-grant", "effects": list(self.effects),
            "principal": self.principal, "agent": self.agent, "capability": self.capability,
            "resource": self.resource, "request": self.request, "not_after": self.not_after,
            "max_uses": self.max_uses, "state_dependencies": list(self.state_dependencies),
            "dependency_gaps": [dict(g) for g in self.dependency_gaps],
            "intent_id": self.intent_id, "intent_digest": self.intent_digest,
            "contract_id": self.contract_id, "contract_version": self.contract_version,
            "contract_digest": self.contract_digest,
            "delegation_id": self.delegation_id, "delegation_digest": self.delegation_digest,
            "confirmation_digest": self.confirmation_digest, "plan_digest": self.plan_digest,
            "state_binding": self.state_binding.to_dict() if self.state_binding else None,
            "execution_id": self.execution_id,
        }
        if self.execution_units:   # absent for unit-less grants: V0-V0.3 grant digests are unchanged
            body["execution_units"] = copy.deepcopy(list(self.execution_units))
        return body

    def digest(self) -> str:
        return canonical.digest(self.body())

    def unit_ids(self) -> Tuple[str, ...]:
        return tuple(u.get("unit_id") for u in self.execution_units)

    @classmethod
    def build(cls, **fields: Any) -> "AuthorizationGrant":
        tmp = cls(grant_id="", **fields)
        return dataclasses.replace(tmp, grant_id="grant-" + tmp.digest()[len("sha256:"):][:24])


@dataclass(frozen=True)
class ExecutionEvidence:
    """What an evidence source observed about one execution.

    Binding = (execution_id, intent_id, observed_subject). `applied_precondition`
    is the state binding the provider reports it enforced on the write (None if
    the write was unconditional or the source cannot tell)."""
    evidence_id: str
    execution_id: str
    intent_id: str
    source_identity: str
    provenance: str
    observed_subject: Optional[str]
    observed_state: Optional[Dict[str, Any]]
    observed_effects: Tuple[str, ...] = ()
    applied_precondition: Optional[Dict[str, str]] = None
    # ---- V0.4 (only judged for contracts that declare execution units)
    covers_units: Tuple[str, ...] = ()      # opaque unit ids this item attests to
    grant_id: Optional[str] = None          # lineage: the grant the provider recorded the effect under
    # unit_id -> {"applied": <StateBinding dict> | {} (unconditional) | None (unknown),
    #             "established": <StateBinding dict> | None}  (the state the unit's effect produced)
    unit_states: Optional[Dict[str, Dict[str, Any]]] = None


def confirmation_digest(c: Optional["Confirmation"]) -> Optional[str]:
    return canonical.digest(dataclasses.asdict(c)) if c is not None else None
