"""ConstraintEvaluatorRegistry and the generic core evaluators.

Evaluator signature:
    fn(spec: dict, params: dict, ctx: EvalContext, phase: "pre" | "post") -> EvalOutcome

`spec` comes from the contract (or a delegation-only constraint); `params`
come from the contract (`params`) or the delegation (`params_from: delegation`).
Evaluators know nothing about providers; they read values through references:

    arg:<name>   ActionIntent.arguments
    fact:<path>  provider state resolved before execution
    plan:<path>  the provider request the adapter intends to send
    post:<path>  provider state read back after execution

V0.2: an evaluator whose decision relies on mutable provider state DECLARES it by
returning the `fact:` references it relied on in EvalOutcome.dependencies. The
core treats them as opaque strings; it only aggregates them into the grant's
state-dependency set and requires a state binding to cover them. Reads of
ctx.facts that are not declared are detected and classified by the core.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, time, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from . import canonical

PASS = "pass"
FAIL = "fail"
UNVERIFIABLE = "unverifiable"


@dataclass(frozen=True)
class EvalOutcome:
    status: str
    code: str = ""
    detail: str = ""
    dependencies: Tuple[str, ...] = ()   # V0.2: `fact:` references the decision relied on


OK = EvalOutcome(PASS)


@dataclass
class EvalContext:
    intent: Any
    contract: Any
    delegation: Any
    facts: Optional[Dict[str, Any]]
    plan: Optional[Dict[str, Any]]
    ledger: Any
    now: datetime
    post_state: Optional[Dict[str, Any]] = None


class RefError(Exception):
    pass


def resolve_ref(ref: Any, ctx: EvalContext) -> Any:
    if not isinstance(ref, str) or ":" not in ref:
        raise RefError(f"bad reference {ref!r}")
    kind, _, path = ref.partition(":")
    sources = {
        "arg": ctx.intent.arguments,
        "fact": ctx.facts,
        "plan": ctx.plan,
        "post": ctx.post_state,
    }
    if kind not in sources:
        raise RefError(f"unknown reference kind {kind!r}")
    cur = sources[kind]
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            raise RefError(f"{ref} not available")
        cur = cur[part]
    return cur


Evaluator = Callable[[Dict[str, Any], Dict[str, Any], EvalContext, str], EvalOutcome]


class ConstraintEvaluatorRegistry:
    """Append-only: a registered name can never be rebound, so an evaluator's meaning can
    only change by a contract (or delegation) naming a different evaluator, which changes
    that contract's (delegation's) digest.

    V0.3: an evaluator also declares the spec modifiers it interprets beyond the protocol's
    own spec keys (e.g. "ordered"). A spec carrying a modifier its evaluator does not
    declare is an unknown semantic: the verifier fails closed instead of ignoring it."""

    def __init__(self) -> None:
        self._evaluators: Dict[str, Evaluator] = {}
        self._spec_keys: Dict[str, Tuple[str, ...]] = {}

    def register(self, name: str, fn: Evaluator, spec_keys: Sequence[str] = ()) -> None:
        if name in self._evaluators:
            raise ValueError(f"evaluator {name} already registered")
        self._evaluators[name] = fn
        self._spec_keys[name] = tuple(spec_keys)

    def spec_keys(self, name: Any) -> Tuple[str, ...]:
        return self._spec_keys.get(name, ()) if isinstance(name, str) else ()

    def get(self, name: Any) -> Optional[Evaluator]:
        return self._evaluators.get(name) if isinstance(name, str) else None

    def names(self) -> List[str]:
        return sorted(self._evaluators)


# ------------------------------------------------------------------ helpers
def _fact_refs(refs: Sequence[Any]) -> Tuple[str, ...]:
    return tuple(r for r in refs if isinstance(r, str) and r.startswith("fact:"))


def _ok(*refs: Any) -> EvalOutcome:
    """PASS, declaring every `fact:` reference among `refs` as a state dependency."""
    deps = _fact_refs(refs)
    return EvalOutcome(PASS, dependencies=deps) if deps else OK


def parse_instant(value: Any) -> datetime:
    if not isinstance(value, str):
        raise ValueError("instant must be a string")
    s = value[:-1] + "+00:00" if value.endswith("Z") else value
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        raise ValueError("instant must carry a UTC offset")
    return dt


def _parse_offset(value: str) -> timezone:
    sign = -1 if value.startswith("-") else 1
    hh, mm = value.lstrip("+-").split(":")
    return timezone(sign * timedelta(hours=int(hh), minutes=int(mm)))


# ---------------------------------------------------------- core.allowed_values
def allowed_values(spec, params, ctx, phase):
    if phase != "pre":
        return OK
    values = params.get("values")
    if not isinstance(values, list):
        return EvalOutcome(FAIL, "bad_params", "values must be a list")
    try:
        v = resolve_ref(spec.get("target"), ctx)
    except RefError as e:
        return EvalOutcome(FAIL, "target_unresolvable", str(e))
    if any(canonical.same(v, a) for a in values):
        return _ok(spec.get("target"))
    return EvalOutcome(FAIL, "value_not_allowed", f"{v!r} not in allowed values")


# ------------------------------------------------------ core.resource_allowlist
def resource_allowlist(spec, params, ctx, phase):
    if phase != "pre":
        return OK
    allowed = params.get("allowed")
    if not isinstance(allowed, list):
        return EvalOutcome(FAIL, "bad_params", "allowed must be a list")
    try:
        v = resolve_ref(spec.get("target"), ctx)
    except RefError as e:
        return EvalOutcome(FAIL, "target_unresolvable", str(e))
    if isinstance(v, str) and v in allowed:
        return _ok(spec.get("target"))
    return EvalOutcome(FAIL, "resource_not_allowed", f"{v!r} not in allowlist")


# ------------------------------------------------------------ core.max_numeric
def max_numeric(spec, params, ctx, phase):
    if phase != "pre":
        return OK
    limit = params.get("max")
    if not isinstance(limit, int) or isinstance(limit, bool):
        return EvalOutcome(FAIL, "bad_params", "max must be an integer")
    try:
        v = resolve_ref(spec.get("target"), ctx)
    except RefError as e:
        return EvalOutcome(FAIL, "target_unresolvable", str(e))
    if not isinstance(v, int) or isinstance(v, bool):
        return EvalOutcome(FAIL, "not_integer", repr(v))
    if v > limit:
        return EvalOutcome(FAIL, "exceeds_max", f"{v} > {limit}")
    return _ok(spec.get("target"))


# ------------------------------------------------------------ core.time_window
def time_window(spec, params, ctx, phase):
    """All targets must fall inside [start, end] local time on allowed weekdays.
    With spec "ordered": true, targets must be strictly increasing and on one local day."""
    if phase != "pre":
        return OK
    try:
        tz = _parse_offset(params["utc_offset"])
        start = time.fromisoformat(params["start"])
        end = time.fromisoformat(params["end"])
        weekdays = params.get("weekdays", [0, 1, 2, 3, 4, 5, 6])
    except (KeyError, ValueError, AttributeError) as e:
        return EvalOutcome(FAIL, "bad_params", str(e))
    targets = spec.get("targets")
    if not isinstance(targets, list) or not targets:
        return EvalOutcome(FAIL, "bad_spec", "targets must be a non-empty list")
    locals_: List[datetime] = []
    for ref in targets:
        try:
            dt = parse_instant(resolve_ref(ref, ctx)).astimezone(tz)
        except (RefError, ValueError) as e:
            return EvalOutcome(FAIL, "target_unresolvable", f"{ref}: {e}")
        if dt.weekday() not in weekdays:
            return EvalOutcome(FAIL, "outside_time_window", f"{ref} on weekday {dt.weekday()}")
        if not (start <= dt.time() <= end):
            return EvalOutcome(FAIL, "outside_time_window", f"{ref} at {dt.time()} not in {start}-{end}")
        locals_.append(dt)
    if spec.get("ordered"):
        for a, b in zip(locals_, locals_[1:]):
            if not a < b:
                return EvalOutcome(FAIL, "not_ordered", f"{a.isoformat()} !< {b.isoformat()}")
            if a.date() != b.date():
                return EvalOutcome(FAIL, "outside_time_window", "window spans multiple days")
    return _ok(*targets)


# ---------------------------------------------------------- core.preserve_fields
def preserve_fields(spec, params, ctx, phase):
    fields = params.get("fields")
    if not isinstance(fields, list) or not fields:
        return EvalOutcome(FAIL, "bad_params", "fields must be a non-empty list")
    if phase == "pre":
        if ctx.plan is None:
            return EvalOutcome(FAIL, "plan_unavailable")
        touched = [f for f in fields if f in ctx.plan]
        if touched:
            return EvalOutcome(FAIL, "plan_modifies_preserved_field", ",".join(touched))
        # the post-check compares against these authorization-time facts
        return _ok(*("fact:" + f for f in fields if isinstance(f, str)))
    if ctx.facts is None or ctx.post_state is None:
        return EvalOutcome(UNVERIFIABLE, "state_unavailable")
    for f in fields:
        if f not in ctx.facts or f not in ctx.post_state:
            return EvalOutcome(UNVERIFIABLE, "field_unobservable", f)
        if not canonical.same(ctx.facts[f], ctx.post_state[f]):
            return EvalOutcome(FAIL, "preserved_field_changed",
                               f"{f}: {ctx.facts[f]!r} -> {ctx.post_state[f]!r}")
    return OK


# ---------------------------------------------------- core.execution_at_most_once
def execution_at_most_once(spec, params, ctx, phase):
    eid = ctx.intent.execution_id
    if phase == "pre":
        if ctx.ledger.get(eid) is not None:
            return EvalOutcome(FAIL, "execution_id_already_used", eid)
        return OK
    attempts = ctx.ledger.attempts(eid)
    if attempts != 1:
        return EvalOutcome(FAIL, "provider_called_more_than_once", f"{attempts} attempts for {eid}")
    return OK


# ------------------------------------------------------------ core.numeric_delta
def numeric_delta(spec, params, ctx, phase):
    """post: post[field] - fact[field] == sign * value(delta_ref)."""
    field, sign = params.get("field"), params.get("sign")
    if phase != "post":
        # the post-check compares against the authorization-time fact
        return _ok("fact:" + field) if isinstance(field, str) else OK
    if not isinstance(field, str) or sign not in (1, -1):
        return EvalOutcome(FAIL, "bad_params", "need field and sign in {1,-1}")
    try:
        delta = resolve_ref(params.get("delta_ref"), ctx)
    except RefError as e:
        return EvalOutcome(FAIL, "bad_params", str(e))
    if ctx.facts is None or ctx.post_state is None or field not in ctx.facts or field not in ctx.post_state:
        return EvalOutcome(UNVERIFIABLE, "field_unobservable", field)
    before, after = ctx.facts[field], ctx.post_state[field]
    if not all(isinstance(x, int) and not isinstance(x, bool) for x in (before, after, delta)):
        return EvalOutcome(UNVERIFIABLE, "not_integer", field)
    if after - before != sign * delta:
        return EvalOutcome(FAIL, "unexpected_delta", f"{field}: {before} -> {after}, expected delta {sign * delta}")
    return OK


def core_registry() -> ConstraintEvaluatorRegistry:
    r = ConstraintEvaluatorRegistry()
    r.register("core.allowed_values", allowed_values)
    r.register("core.resource_allowlist", resource_allowlist)
    r.register("core.max_numeric", max_numeric)
    r.register("core.time_window", time_window, spec_keys=("ordered",))
    r.register("core.preserve_fields", preserve_fields)
    r.register("core.execution_at_most_once", execution_at_most_once)
    r.register("core.numeric_delta", numeric_delta)  # added in build step 3 (RESULTS.md §2)
    return r
