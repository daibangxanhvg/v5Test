"""V0 canonical representation and digest.

Deliberately narrow (see ARCHITECTURE.md "Canonicalization limitations"):
- Only JSON-native values: str, int, bool, None, list/tuple, dict with str keys.
- Floats are REJECTED (no canonical float form in V0).
- Strings are compared byte-for-byte after UTF-8 encoding; no Unicode
  normalization, no datetime normalization ("10:00+07:00" != "03:00+00:00").
- Tuples and lists serialize identically.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any


class CanonicalizationError(ValueError):
    pass


def _check(value: Any, path: str = "$") -> None:
    if value is None or isinstance(value, (bool, str)):
        return
    if isinstance(value, int):
        return
    if isinstance(value, float):
        raise CanonicalizationError(f"float not allowed in V0 canonical form at {path}")
    if isinstance(value, (list, tuple)):
        for i, item in enumerate(value):
            _check(item, f"{path}[{i}]")
        return
    if isinstance(value, dict):
        for k, item in value.items():
            if not isinstance(k, str):
                raise CanonicalizationError(f"non-string key at {path}")
            _check(item, f"{path}.{k}")
        return
    raise CanonicalizationError(f"unsupported type {type(value).__name__} at {path}")


def canonical_bytes(value: Any) -> bytes:
    _check(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_bytes(value)).hexdigest()


def same(a: Any, b: Any) -> bool:
    """Canonical equality. Any non-canonicalizable value compares unequal (fail closed)."""
    try:
        return canonical_bytes(a) == canonical_bytes(b)
    except CanonicalizationError:
        return False
