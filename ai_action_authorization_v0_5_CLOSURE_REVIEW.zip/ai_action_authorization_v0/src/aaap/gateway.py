"""ActionGateway: the only path from an ActionIntent to a provider effect.

Generic orchestration: gather evidence through the registered adapter, ask the
verifier, enforce single-use execution_id via the ledger, execute, read back,
ask the verifier for the receipt. Authorization is re-evaluated at execution
time; a previous ALLOW / confirmation / grant is never a bearer token.

V0.1:
- the adapter's state binding travels in the AuthorizationGrant and execution
  is conditional on it (provider-native compare-and-swap via execute_conditional);
- the adapter's own read-back is wrapped as SELF_REPORTED evidence; evidence that
  can verify comes only from separately registered EvidenceSources.

V0.2 (execute_confined): the grant is attenuated into a single-use
ExecutionCredential, handed to an untrusted ConfinedExecutor together with an
ExecutionPort; every provider effect must pass the enforcement boundary
(authority.ExecutionAuthority). The legacy execute() path is kept unchanged and
is reported NOT_CONFINED: there the adapter itself holds provider credentials.

V0.3: evidence sources may be registered with an effect scope; a PARTIAL outcome is
settled (never re-executed, never compensated); confinement is re-assessed after the
executor ran, and a downgrade during execution is what the outcome reports.

V0.4: evidence sources may also be scoped to opaque execution units; for a unit credential
the boundary's per-unit permit records go to the verifier with the composite outcome.
"""
from __future__ import annotations

import copy
import dataclasses
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from . import canonical
from .adapter import (
    ConfinedExecutor, EvidenceSource, ExecutionResult, PreconditionFailed, ProviderAdapter, ProviderTimeout,
)
from .authority import CONFINED, MODE_C, NOT_CONFINED, TCB_BY_MODE, Confinement, ExecutionAuthority, ExecutionCredential
from .objects import (
    ALLOW, DENY, EXEC_FAILED, EXEC_PARTIAL, EXEC_PRECONDITION_FAILED, EXEC_SUCCESS, EXEC_UNKNOWN, SELF_REPORTED,
    ActionIntent,
    ActionReceipt, AuthorizationDecision, AuthorizationGrant, Confirmation, ExecutionEvidence, intent_digest,
)
from .stores import COMPLETED, FAILED, IN_DOUBT, ContractRegistry, ExecutionLedger
from .verifier import AuthorizationVerifier


@dataclass(frozen=True)
class GatewayOutcome:
    decision: AuthorizationDecision
    receipt: Optional[ActionReceipt]
    replayed: bool = False
    # V0.2
    confinement: Optional[Confinement] = None
    credential: Optional[ExecutionCredential] = None
    boundary_events: Tuple[Dict[str, Any], ...] = ()


# the V0.1 path: the adapter holds provider credentials and calls the provider itself
LEGACY_CONFINEMENT = Confinement(NOT_CONFINED, MODE_C, ("adapter_executes_with_its_own_provider_credentials",),
                                 TCB_BY_MODE[MODE_C])


class GatewayCodes:
    GRANT_REQUIRED = "grant_required_for_confined_execution"
    NO_EXECUTOR = "no_confined_executor_registered"
    NOT_CONFINED = "executor_not_confined"
    ATTENUATION_REFUSED = "attenuation_refused"


class ActionGateway:
    def __init__(self, verifier: AuthorizationVerifier, contracts: ContractRegistry, ledger: ExecutionLedger):
        self._verifier = verifier
        self._contracts = contracts
        self._ledger = ledger
        self._adapters: Dict[str, ProviderAdapter] = {}
        self._sources: Dict[str, List[EvidenceSource]] = {}
        self._executors: Dict[str, Tuple[ConfinedExecutor, bool]] = {}
        self.authority = ExecutionAuthority(verifier)

    def register_adapter(self, contract_id: str, adapter: ProviderAdapter) -> None:
        self._adapters[contract_id] = adapter
        # whatever the execution path says about its own work is SELF_REPORTED
        self._verifier.evidence_sources.register(contract_id, self._self_identity(contract_id), SELF_REPORTED)

    def register_evidence_source(self, contract_id: str, source: EvidenceSource, provenance: str,
                                 effects: Optional[Tuple[str, ...]] = None,
                                 units: Optional[Tuple[str, ...]] = None) -> None:
        """Deployer act: classify an observer of `contract_id` executions.
        The execution path itself can never be registered as anything but SELF_REPORTED.
        V0.3: `effects` limits which effects this source may attest to (None = unscoped).
        V0.4: `units` names the execution units it is authoritative for (None = none)."""
        if source is self._adapters.get(contract_id) or isinstance(source, ProviderAdapter):
            raise ValueError("an adapter cannot be its own evidence source")
        if source.identity == self._self_identity(contract_id):
            raise ValueError("identity reserved for the execution path")
        self._verifier.evidence_sources.register(contract_id, source.identity, provenance, effects, units)
        self._sources.setdefault(contract_id, []).append(source)

    def register_executor(self, contract_id: str, executor: ConfinedExecutor,
                          retains_provider_authority: bool = False) -> None:
        """V0.2 deployer act: the untrusted executor for confined execution of `contract_id`.
        `retains_provider_authority=True` declares Mode C (never reported CONFINED)."""
        if executor is self._adapters.get(contract_id) or isinstance(executor, ProviderAdapter):
            # an adapter holds provider credentials by construction (V0.1 interface)
            retains_provider_authority = True
        self._executors[contract_id] = (executor, bool(retains_provider_authority))

    def assess_confinement(self, contract_id: str) -> Confinement:
        entry = self._executors.get(contract_id)
        if entry is None:
            return LEGACY_CONFINEMENT
        executor, retains = entry
        extra = [self, self._ledger, self._contracts] + list(self._adapters.values()) \
            + [s for ss in self._sources.values() for s in ss]
        return self.authority.assess(contract_id, executor, retains, extra)

    @staticmethod
    def _self_identity(contract_id: str) -> str:
        return f"execution-path:{contract_id}"

    # -------------------------------------------------------------- evidence
    def _evidence(self, intent: ActionIntent) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]], Any]:
        adapter = self._adapters.get(getattr(intent, "contract_id", None))
        if adapter is None:
            return None, None, None
        try:
            facts = adapter.resolve(intent)
            plan = adapter.plan(intent, copy.deepcopy(facts))
        except Exception:
            return None, None, None
        try:
            binding = adapter.state_binding(intent, copy.deepcopy(facts))
        except Exception:
            binding = None
        return facts, plan, binding

    def request_authorization(self, intent: ActionIntent, delegation_id: str,
                              confirmation: Optional[Confirmation] = None) -> AuthorizationDecision:
        """On ALLOW, decision.grant is the AuthorizationGrant to present to execute()."""
        facts, plan, binding = self._evidence(intent)
        return self._verifier.authorize(intent, delegation_id, facts, plan, confirmation, binding)

    # ------------------------------------------------------------- execution
    def execute(self, intent: ActionIntent, delegation_id: str, confirmation: Optional[Confirmation] = None,
                grant: Optional[AuthorizationGrant] = None) -> GatewayOutcome:
        entry = self._ledger.get(getattr(intent, "execution_id", None))
        if entry is not None and self._same_intent(intent, entry):
            return self._replay(intent, entry)
        # (a different intent reusing an execution_id is DENIED by the verifier)

        # Full re-authorization (revocation wins). A presented grant can only
        # narrow it: the fresh authorization must reproduce every grant binding.
        facts, plan, binding = self._evidence(intent)
        decision = self._verifier.authorize(intent, delegation_id, facts, plan, confirmation, binding, grant)
        if decision.decision != ALLOW:
            return GatewayOutcome(decision, None)

        adapter = self._adapters[intent.contract_id]
        eid = intent.execution_id
        precondition = decision.grant.state_binding
        self._ledger.claim(eid, decision.intent_digest, decision, facts, plan)
        self._ledger.record_attempt(eid)
        try:
            if precondition is None:
                result = adapter.execute(intent, copy.deepcopy(plan))
            else:
                result = adapter.execute_conditional(intent, copy.deepcopy(plan), precondition)
        except ProviderTimeout as e:
            result = ExecutionResult(EXEC_UNKNOWN, eid, None, plan, [], f"timeout: {e}")
        except PreconditionFailed as e:
            result = ExecutionResult(EXEC_PRECONDITION_FAILED, eid, None, plan, [], f"stale state binding: {e}")
        except Exception as e:
            result = ExecutionResult(EXEC_FAILED, eid, None, plan, [], f"{type(e).__name__}: {e}")
        out = self._finish(intent, decision, facts, plan, result, adapter)
        return dataclasses.replace(out, confinement=LEGACY_CONFINEMENT)

    # ------------------------------------------------------ V0.2 confined path
    def execute_confined(self, intent: ActionIntent, delegation_id: str,
                         confirmation: Optional[Confirmation] = None, grant: Optional[AuthorizationGrant] = None,
                         require_confinement: bool = True) -> GatewayOutcome:
        """GRANT -> ExecutionCredential -> untrusted executor -> enforcement boundary -> provider.

        The grant is REQUIRED. Full re-authorization happens first (revocation, contract
        change, confirmation, stale state all win). With require_confinement (default) an
        executor that is not CONFINED is refused before any credential exists."""
        entry = self._ledger.get(getattr(intent, "execution_id", None))
        if entry is not None and self._same_intent(intent, entry):
            out = self._replay(intent, entry)
            return dataclasses.replace(out, confinement=self.assess_confinement(intent.contract_id))

        facts, plan, binding = self._evidence(intent)
        decision = self._verifier.authorize(intent, delegation_id, facts, plan, confirmation, binding, grant)
        if decision.decision != ALLOW:
            return GatewayOutcome(decision, None)
        if grant is None:
            return GatewayOutcome(_refuse(decision, GatewayCodes.GRANT_REQUIRED), None)
        if intent.contract_id not in self._executors:
            return GatewayOutcome(_refuse(decision, GatewayCodes.NO_EXECUTOR, intent.contract_id), None)
        executor, _ = self._executors[intent.contract_id]
        confinement = self.assess_confinement(intent.contract_id)
        if require_confinement and confinement.status != CONFINED:
            return GatewayOutcome(_refuse(decision, GatewayCodes.NOT_CONFINED, ",".join(confinement.reasons)),
                                  None, confinement=confinement)
        att = self.authority.attenuate_exact(decision.grant, getattr(executor, "identity", None))
        if att.credential is None:
            return GatewayOutcome(_refuse(decision, GatewayCodes.ATTENUATION_REFUSED,
                                          ";".join(f"{c}:{d}" for c, d in att.problems)), None, confinement=confinement)
        cred = att.credential
        adapter = self._adapters[intent.contract_id]
        eid = intent.execution_id
        self._ledger.claim(eid, decision.intent_digest, decision, facts, plan)
        self._ledger.record_attempt(eid)
        try:
            executor.execute_confined(copy.deepcopy(intent), copy.deepcopy(plan), cred,
                                      self.authority.port(executor.identity))
        except Exception:
            pass   # the executor's behaviour is judged by what reached the boundary, not by its return
        after = self.assess_confinement(intent.contract_id)
        if confinement.status == CONFINED and after.status != CONFINED:
            # V0.3: the label reports the weakest state observed, never the best
            confinement = dataclasses.replace(after, reasons=after.reasons + ("downgraded_during_execution",))
        result = self.authority.result_of(cred.credential_id)
        if result is None:
            result = ExecutionResult(EXEC_FAILED, eid, None, plan, [], "executor made no in-scope invocation")
        blocked = self.authority.blocked_attempts(cred.credential_id)
        out = self._finish(intent, decision, facts, plan, result, adapter, blocked,
                           self.authority.unit_records(cred.credential_id))
        return dataclasses.replace(out, confinement=confinement, credential=cred,
                                   boundary_events=tuple(e for e in self.authority.log
                                                         if e["credential_id"] == cred.credential_id))

    def _finish(self, intent, decision, facts, plan, result, adapter, out_of_scope=(), unit_records=None) -> GatewayOutcome:
        evidence: List[Any] = []
        if result.status == EXEC_SUCCESS:
            try:
                post = adapter.read_back(intent, result)
            except Exception:
                post = None
            if post is not None:
                evidence.append(self._self_report(intent, decision, post))
        if result.status != EXEC_UNKNOWN:
            # observers run even when the execution path reports failure:
            # an effect it denies is still an effect
            for source in self._sources.get(intent.contract_id, []):
                try:
                    ev = source.observe(copy.deepcopy(intent), decision.grant)
                except Exception:
                    ev = None
                if ev is not None:
                    evidence.append(ev)
        receipt = self._verifier.verify_execution(intent, decision, facts, plan, result, evidence, out_of_scope,
                                                  unit_records)
        state = {EXEC_SUCCESS: COMPLETED, EXEC_FAILED: FAILED, EXEC_PRECONDITION_FAILED: FAILED,
                 EXEC_PARTIAL: FAILED, EXEC_UNKNOWN: IN_DOUBT}.get(result.status, IN_DOUBT)
        self._ledger.settle(intent.execution_id, state, receipt)
        return GatewayOutcome(decision, receipt)

    def _self_report(self, intent, decision, post: Dict[str, Any]) -> ExecutionEvidence:
        """The adapter's read-back, labelled for what it is. The subject is whatever the
        adapter's own read-back says it is (it may incriminate itself, never exonerate)."""
        identity = self._self_identity(intent.contract_id)
        contract = self._contracts.by_digest(decision.contract_digest)
        subject = None
        ref = contract.verification.get("subject") if contract is not None else None
        if isinstance(ref, str) and ":" in ref and isinstance(post, dict):
            subject = post.get(ref.partition(":")[2])
        return ExecutionEvidence(evidence_id=f"{identity}:{intent.execution_id}", execution_id=intent.execution_id,
                                 intent_id=intent.intent_id, source_identity=identity, provenance=SELF_REPORTED,
                                 observed_subject=subject, observed_state=copy.deepcopy(post))

    def _same_intent(self, intent, entry) -> bool:
        contract = self._contracts.by_digest(entry["contract_digest"])
        try:
            return contract is not None and intent_digest(intent, contract) == entry["intent_digest"]
        except canonical.CanonicalizationError:
            return False

    def _replay(self, intent, entry) -> GatewayOutcome:
        """Same execution_id, same intent: never call the provider's execute again."""
        if entry["state"] != IN_DOUBT:
            return GatewayOutcome(entry["decision"], entry["receipt"], replayed=True)
        adapter = self._adapters[intent.contract_id]
        try:
            found = adapter.lookup(intent)
        except Exception:
            found = None
        if found is None:
            return GatewayOutcome(entry["decision"], entry["receipt"], replayed=True)
        out = self._finish(intent, entry["decision"], entry["facts"], entry["plan"], found, adapter)
        return GatewayOutcome(out.decision, out.receipt, replayed=True)


def _refuse(decision: AuthorizationDecision, code: str, detail: str = "") -> AuthorizationDecision:
    """An ALLOW that the confined path cannot act on becomes a DENY (no grant attached)."""
    return dataclasses.replace(decision, decision=DENY, reasons=({"code": code, "detail": detail},), grant=None)
