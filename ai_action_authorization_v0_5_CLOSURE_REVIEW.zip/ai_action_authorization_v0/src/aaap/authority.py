"""V0.2 — execution-scoped authority.

    AuthorizationGrant --attenuate--> ExecutionCredential --invoke--> EnforcementBoundary --> ProviderEffector

- ExecutionCredential: the attenuated authority for ONE execution. It is derived
  from an issued grant and can never authorize anything the grant does not.
- attenuate(): the only way to mint one. Every requested field must be equal to
  (or, for lifetime, inside) the grant's. Widening is refused, not clipped.
- EnforcementBoundary (ExecutionAuthority.invoke via an ExecutionPort): checks a
  credential against a concrete ProviderOperation immediately before the effect.
  Only then does it call the provider-specific effector registered for the contract.
- Confinement: whether the executor could bypass the boundary. Reported, never assumed.

No provider/capability/resource names appear here. Capability, resource and request
values are compared as opaque data; the resource is located with the contract's own
`verification.subject` reference. No signatures, tokens or cryptography (scope):
credential integrity comes from the in-memory CredentialStore, holder identity is
the identity of the port the call arrives on.

V0.3:
- the credential carries the grant's authorized effect set (ExecutionBinding), so a
  Mode A provider or a Mode B effector can refuse any effect outside it;
- the deployer declares infrastructure facts (isolation, proof-of-possession, provider
  enforcement). A fact declared ABSENT removes the guarantee that depends on it; an
  undeclared fact stays an explicit assumption. The reported guarantee never exceeds
  what is declared, and nothing in a contract can raise it.

V0.4 (composite execution binding):
- a credential attenuated from a grant with execution units carries the unit table (all
  units, or an explicitly requested subset: unit-level narrowing). Before minting, the grant's
  unit table is re-derived from the contract, independently of binding generation;
- the boundary issues a separate permit per unit, immediately before that unit's effect:
  the unit must be in the credential, its request must equal the unit's bound request, it
  is single-use, and every declared predecessor must have completed;
- the state precondition passed to the effector is computed by the boundary, never by the
  executor: the authorization-time binding, or the state the declared predecessor unit's
  effect established. If that state is unavailable or is about another subject, the unit's
  effect is not attempted (PRECONDITION_FAILED);
- the composite outcome is aggregated against the GRANT's required units.
Unit ids are opaque: no unit, effect or field name appears here.
"""
from __future__ import annotations

import copy
import dataclasses
import types
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, Iterable, List, Optional, Tuple

from . import canonical
from .adapter import ExecutionResult, PreconditionFailed, ProviderTimeout
from .evaluators import parse_instant
from .objects import (
    EXEC_FAILED, EXEC_PARTIAL, EXEC_PRECONDITION_FAILED, EXEC_SUCCESS, EXEC_UNKNOWN, UNIT_STATE_AUTHORIZATION,
    UNIT_STATE_FROM, AuthorizationGrant, StateBinding,
)

# ------------------------------------------------------------ isolation modes
MODE_A = "MODE_A_PROVIDER_ENFORCED"            # provider itself checks the scoped credential
MODE_B = "MODE_B_TRUSTED_GATEWAY"              # gateway (TCB) holds the broad credential; executor does not
MODE_C = "MODE_C_EXECUTOR_RETAINS_AUTHORITY"   # executor can also reach a broad credential/path
MODES = (MODE_A, MODE_B, MODE_C)
CONFINED = "CONFINED"
NOT_CONFINED = "NOT_CONFINED"

# V0.3: infrastructure facts a deployer may declare (True = present, False = known absent)
INFRA_ISOLATION = "executor_isolated_from_gateway"
INFRA_POP = "holder_proof_of_possession"
INFRA_PROVIDER_ENFORCES = "provider_enforces_scoped_credential"
INFRA_FACTS = (INFRA_ISOLATION, INFRA_POP, INFRA_PROVIDER_ENFORCES)
# facts without which the mode's no-bypass property does not hold at all
REQUIRED_INFRA = {MODE_A: (INFRA_PROVIDER_ENFORCES,), MODE_B: (INFRA_ISOLATION,)}
# guarantee levels (V0.3)
GUARANTEE_NONE = "NONE_ADVISORY_ONLY"
GUARANTEE_ASSUMED = "CONFINED_ASSUMING_UNDECLARED_INFRASTRUCTURE"
GUARANTEE_DECLARED = "CONFINED_BY_DECLARED_INFRASTRUCTURE"

TCB_BY_MODE = {
    MODE_A: ("verifier", "grant_store", "execution_authority.attenuate", "credential_store",
             "provider (enforces the credential)", "evidence_sources"),
    MODE_B: ("verifier", "grant_store", "execution_authority.attenuate", "credential_store",
             "execution_authority.invoke (enforcement boundary)", "gateway effector (holds broad provider credential)",
             "gateway-side reader adapter", "evidence_sources", "provider"),
    MODE_C: ("verifier", "grant_store", "executor (holds broad provider credential: it IS trusted, not confined)",
             "evidence_sources", "provider"),
}


class C:
    """Reason codes for attenuation and enforcement."""
    # attenuation
    GRANT_NOT_ISSUED = "grant_not_issued_or_altered"
    GRANT_ALREADY_ATTENUATED = "grant_already_attenuated"
    STATE_DEPENDENCY_GAP = "state_dependency_gap"
    HOLDER_NOT_GRANTEE = "holder_not_grantee"
    WIDENS_CAPABILITY = "widens_capability"
    WIDENS_RESOURCE = "widens_resource"
    WIDENS_REQUEST = "widens_request"
    WIDENS_EXECUTION = "widens_execution_id"
    WIDENS_USES = "widens_max_uses"
    WIDENS_LIFETIME = "widens_lifetime"
    DROPS_STATE_BINDING = "drops_or_changes_state_binding"
    WIDENS_EFFECTS = "widens_or_changes_effects"
    BAD_LIFETIME = "malformed_lifetime"
    WIDENS_UNITS = "widens_or_changes_units"                                  # V0.4
    EXECUTION_BINDING_INCONSISTENT = "execution_binding_inconsistent_with_contract"  # V0.4
    # enforcement
    MALFORMED = "malformed_invocation"
    CREDENTIAL_NOT_ISSUED = "credential_not_issued_or_altered"
    HOLDER_MISMATCH = "credential_holder_mismatch"
    NOT_YET_VALID = "credential_not_yet_valid"
    EXPIRED = "credential_expired"
    GRANT_NOT_IN_FORCE = "grant_no_longer_in_force"
    CAPABILITY_NOT_AUTHORIZED = "capability_not_authorized"
    RESOURCE_NOT_AUTHORIZED = "resource_not_authorized"
    RESOURCE_UNVERIFIABLE = "resource_unverifiable"
    ARGUMENTS_NOT_AUTHORIZED = "arguments_not_authorized"
    EXECUTION_NOT_AUTHORIZED = "execution_id_not_authorized"
    EXHAUSTED = "credential_exhausted"
    EXECUTION_CONSUMED = "execution_id_already_consumed"
    NO_BOUNDARY = "no_enforcement_boundary_for_contract"
    # V0.4 per-unit enforcement
    UNIT_UNSPECIFIED = "unit_not_specified"
    UNIT_NOT_AUTHORIZED = "unit_not_authorized"
    UNIT_CONSUMED = "unit_already_performed"
    UNIT_ORDER = "unit_predecessor_incomplete"


# ===================================================================== records
@dataclass(frozen=True)
class ProviderOperation:
    """A concrete provider effect the executor asks for. `request` uses the
    provider-request vocabulary of the contract's `maps_to` (the same as a plan)."""
    contract_id: str
    capability: str
    execution_id: str
    request: Dict[str, Any]
    unit: Optional[str] = None      # V0.4: the opaque execution unit this operation performs

    def summary(self) -> str:
        u = f"#{self.unit}" if self.unit is not None else ""
        try:
            return f"{self.contract_id}/{self.capability}/{self.execution_id}{u}:{canonical.canonical_bytes(self.request).decode()}"
        except Exception:
            return f"{self.contract_id}/{self.capability}/{self.execution_id}{u}:<non-canonical>"


@dataclass(frozen=True)
class ExecutionCredential:
    """Attenuated authority for exactly one execution of one grant."""
    credential_id: str
    grant_id: str
    grant_digest: str
    holder: str
    principal: str
    intent_id: str
    contract_id: str
    capability: str
    resource: Optional[Dict[str, Any]]
    request: Dict[str, Any]
    execution_id: str
    state_binding: Optional[StateBinding]
    state_dependencies: Tuple[str, ...]
    not_before: str
    expires_at: str
    max_uses: int
    effects: Tuple[str, ...] = ()      # V0.3: the only effects this credential may cause
    units: Tuple[Dict[str, Any], ...] = ()   # V0.4: the only execution units it may perform

    def body(self) -> Dict[str, Any]:
        body = {
            "_": "aaap-v0.2-execution-credential",
            "grant_id": self.grant_id, "grant_digest": self.grant_digest, "holder": self.holder,
            "principal": self.principal, "intent_id": self.intent_id, "contract_id": self.contract_id,
            "capability": self.capability, "resource": self.resource, "request": self.request,
            "execution_id": self.execution_id,
            "state_binding": self.state_binding.to_dict() if self.state_binding else None,
            "state_dependencies": list(self.state_dependencies),
            "not_before": self.not_before, "expires_at": self.expires_at, "max_uses": self.max_uses,
            "effects": list(self.effects),
        }
        if self.units:
            body["units"] = copy.deepcopy(list(self.units))
        return body

    def digest(self) -> str:
        return canonical.digest(self.body())

    def unit(self, unit_id: Any) -> Optional[Dict[str, Any]]:
        return next((u for u in self.units if u.get("unit_id") == unit_id), None) if isinstance(unit_id, str) else None


@dataclass(frozen=True)
class Attenuation:
    credential: Optional[ExecutionCredential]
    problems: Tuple[Tuple[str, str], ...] = ()

    def codes(self) -> List[str]:
        return [p[0] for p in self.problems]


@dataclass(frozen=True)
class Invocation:
    allowed: bool
    reason: Optional[str]
    detail: str = ""
    result: Optional[ExecutionResult] = None


@dataclass(frozen=True)
class Confinement:
    status: str                    # CONFINED / NOT_CONFINED
    mode: str                      # MODE_A / MODE_B / MODE_C
    reasons: Tuple[str, ...] = ()
    tcb: Tuple[str, ...] = ()
    # what a CONFINED label silently depends on; stated, because this model cannot enforce it
    assumptions: Tuple[str, ...] = ()
    # V0.3: how strong the label is, given what the deployer declared about infrastructure
    guarantee: str = GUARANTEE_NONE


CONFINEMENT_ASSUMPTIONS = (
    "executor runs outside the gateway's address space (in-process isolation is modeled, not enforced)",
    "holder identity = identity of the port the call arrives on (no proof-of-possession)",
    "effector and provider behave as specified (TCB)",
)
# which infrastructure fact, once declared present, discharges which assumption (V0.3)
_ASSUMPTION_FACT = {CONFINEMENT_ASSUMPTIONS[0]: INFRA_ISOLATION, CONFINEMENT_ASSUMPTIONS[1]: INFRA_POP}
_MODE_A_ASSUMPTION = "provider verifies the scoped credential itself (Mode A infrastructure)"


# ============================================================ provider side
class ProviderEffector:
    """Provider-specific code that performs an operation the boundary has ALREADY
    authorized. Lives inside the TCB (Mode B: in the gateway, holding the broad
    provider credential; Mode A: the provider's own credential check).

    It is not an authorization component: it must not decide whether an operation
    is allowed. It must apply `credential.state_binding` as an atomic provider
    precondition (raise PreconditionFailed if stale) or refuse.

    V0.3: it must not cause any effect outside `credential.effects`. If one authorized
    operation needs several provider calls, the effector makes them (the split lives at
    the provider boundary, inside the TCB) and reports EXEC_PARTIAL, with the effects that
    did happen, if it stops part-way. It never invents a compensating action."""
    mode: str = MODE_B

    def perform(self, credential: ExecutionCredential, operation: ProviderOperation) -> ExecutionResult:
        raise NotImplementedError

    def perform_unit(self, credential: ExecutionCredential, operation: ProviderOperation,
                     precondition: Optional[StateBinding]) -> ExecutionResult:
        """V0.4: perform exactly the effect(s) of `operation.unit`, applying `precondition`
        atomically when it is not None (raise PreconditionFailed if stale). Report in
        `established_state` the provider's version token for the state the effect produced,
        if the provider exposes one. What a unit id means is this effector's knowledge only."""
        raise NotImplementedError("effector performs no execution units")

    def authority_handles(self) -> Iterable[Any]:
        """Objects/strings that confer broad provider authority (clients, tokens).
        Used only to check that an executor cannot reach them."""
        return ()


class ExecutionPort:
    """The executor's only sanctioned path to provider effects. Bound to one holder identity."""

    def __init__(self, authority: "ExecutionAuthority", holder: str):
        self._authority = authority
        self._holder = holder

    @property
    def holder(self) -> str:
        return self._holder

    def invoke(self, credential: Any, operation: Any) -> Invocation:
        return self._authority._invoke(self._holder, credential, operation)


# ===================================================== attenuation + boundary
class ExecutionAuthority:
    def __init__(self, verifier: Any, max_lifetime: timedelta = timedelta(minutes=5)):
        self._verifier = verifier
        self._max_lifetime = max_lifetime
        self._effectors: Dict[str, ProviderEffector] = {}
        self._issued: Dict[str, str] = {}             # credential_id -> digest
        self._uses: Dict[str, int] = {}               # credential_id -> uses consumed
        self._consumed_executions: set = set()
        self._results: Dict[str, ExecutionResult] = {}
        self.log: List[Dict[str, Any]] = []           # every invocation, allowed or blocked
        self._infra: Dict[str, bool] = {}             # V0.3: deployer-declared infrastructure facts
        self._creds: Dict[str, ExecutionCredential] = {}               # V0.4
        self._unit_records: Dict[str, Dict[str, Dict[str, Any]]] = {}  # V0.4: credential_id -> unit -> record

    def declare_infrastructure(self, **facts: bool) -> None:
        """V0.3 deployer act. True = the mechanism is in place (provided by infrastructure this
        prototype does not implement); False = known absent. Undeclared = assumed, and said so."""
        for k, v in facts.items():
            if k not in INFRA_FACTS or not isinstance(v, bool):
                raise ValueError(f"unknown infrastructure fact {k!r}={v!r}")
            self._infra[k] = v

    def infrastructure(self) -> Dict[str, bool]:
        return dict(self._infra)

    def register_effector(self, contract_id: str, effector: ProviderEffector) -> None:
        if getattr(effector, "mode", None) not in (MODE_A, MODE_B):
            raise ValueError("an effector must declare MODE_A or MODE_B")
        self._effectors[contract_id] = effector

    def effector_for(self, contract_id: str) -> Optional[ProviderEffector]:
        return self._effectors.get(contract_id)

    def port(self, holder: str) -> ExecutionPort:
        return ExecutionPort(self, holder)

    # -------------------------------------------------------------- attenuation
    def attenuate(self, grant: Any, *, holder: Any, contract_id: Any, capability: Any, resource: Any,
                  request: Any, execution_id: Any, state_binding: Any, max_uses: Any,
                  not_before: Optional[str] = None, expires_at: Optional[str] = None,
                  effects: Any = None, units: Any = None) -> Attenuation:
        """Mint an ExecutionCredential whose every field is inside `grant`. Any widening is refused."""
        now = self._verifier.now()
        problems: List[Tuple[str, str]] = []
        if not isinstance(grant, AuthorizationGrant) or not self._verifier.grants.is_issued(grant):
            return Attenuation(None, ((C.GRANT_NOT_ISSUED, str(getattr(grant, "grant_id", None))),))
        standing = self._verifier.grant_standing(grant.grant_id, grant.digest())
        if standing is not None:
            return Attenuation(None, ((C.GRANT_NOT_IN_FORCE, ":".join(standing)),))
        if grant.dependency_gaps:
            problems.append((C.STATE_DEPENDENCY_GAP,
                             ",".join(f"{g['class']}:{g['by']}:{g['ref']}" for g in grant.dependency_gaps)))
        if not isinstance(holder, str) or holder != grant.agent:
            problems.append((C.HOLDER_NOT_GRANTEE, f"{holder!r} != {grant.agent!r}"))
        if contract_id != grant.contract_id or capability != grant.capability:
            problems.append((C.WIDENS_CAPABILITY, f"{contract_id!r}/{capability!r}"))
        if not _same(resource, grant.resource):
            problems.append((C.WIDENS_RESOURCE, repr(resource)))
        if not _same(request, grant.request) or _digest(request) != grant.plan_digest:
            problems.append((C.WIDENS_REQUEST, "request differs from the granted request"))
        if execution_id != grant.execution_id:
            problems.append((C.WIDENS_EXECUTION, repr(execution_id)))
        if state_binding != grant.state_binding:
            problems.append((C.DROPS_STATE_BINDING, repr(state_binding)))
        # V0.4: execution units — the grant's table must be the contract's; a subset may be requested
        granted_units = tuple(grant.execution_units)
        selected: Tuple[Dict[str, Any], ...] = granted_units
        if granted_units:
            problem = self._verifier.execution_binding_problem(grant)
            if problem:
                problems.append((C.EXECUTION_BINDING_INCONSISTENT, problem))
            ids = grant.unit_ids()
            if units is not None:
                if (not isinstance(units, (list, tuple)) or not units or len(set(units)) != len(units)
                        or any(u not in ids for u in units)):
                    problems.append((C.WIDENS_UNITS, repr(units)))
                else:
                    selected = tuple(u for u in granted_units if u["unit_id"] in units)
        elif units is not None:
            problems.append((C.WIDENS_UNITS, "grant binds no execution units"))
        cred_effects = tuple(grant.effects)
        if granted_units:
            mine = {e for u in selected for e in u["effects"]}
            cred_effects = tuple(e for e in grant.effects if e in mine)
        if effects is not None and tuple(effects) != cred_effects:
            problems.append((C.WIDENS_EFFECTS, repr(effects)))
        if not isinstance(max_uses, int) or isinstance(max_uses, bool) or not 1 <= max_uses <= grant.max_uses:
            problems.append((C.WIDENS_USES, repr(max_uses)))
        try:
            nb = parse_instant(not_before) if not_before is not None else now
            ceiling = min(parse_instant(grant.not_after), now + self._max_lifetime)
            ea = parse_instant(expires_at) if expires_at is not None else ceiling
            if not nb < ea or nb < now:
                problems.append((C.BAD_LIFETIME, f"{nb.isoformat()}..{ea.isoformat()}"))
            if ea > ceiling:
                problems.append((C.WIDENS_LIFETIME, f"{ea.isoformat()} > {ceiling.isoformat()}"))
        except (TypeError, ValueError) as e:
            problems.append((C.BAD_LIFETIME, str(e)))
        if problems:
            return Attenuation(None, tuple(problems))
        if not self._verifier.grants.claim_attenuation(grant.grant_id):
            return Attenuation(None, ((C.GRANT_ALREADY_ATTENUATED, grant.grant_id),))
        tmp = ExecutionCredential(
            credential_id="", grant_id=grant.grant_id, grant_digest=grant.digest(), holder=holder,
            principal=grant.principal, intent_id=grant.intent_id, contract_id=grant.contract_id,
            capability=grant.capability, resource=copy.deepcopy(grant.resource), request=copy.deepcopy(grant.request),
            execution_id=grant.execution_id, state_binding=grant.state_binding,
            state_dependencies=tuple(grant.state_dependencies), not_before=nb.isoformat(),
            expires_at=ea.isoformat(), max_uses=max_uses, effects=cred_effects,
            units=copy.deepcopy(selected))
        cred = dataclasses.replace(tmp, credential_id="cred-" + tmp.digest()[len("sha256:"):][:24])
        self._issued[cred.credential_id] = cred.digest()
        self._uses[cred.credential_id] = 0
        self._creds[cred.credential_id] = cred
        return Attenuation(cred)

    def attenuate_exact(self, grant: AuthorizationGrant, holder: str) -> Attenuation:
        """The narrowest credential a grant allows: everything copied, one use, default lifetime."""
        return self.attenuate(grant, holder=holder, contract_id=grant.contract_id, capability=grant.capability,
                              resource=copy.deepcopy(grant.resource), request=copy.deepcopy(grant.request),
                              execution_id=grant.execution_id, state_binding=grant.state_binding, max_uses=1)

    # ------------------------------------------------------- enforcement boundary
    def _invoke(self, caller: str, credential: Any, operation: Any) -> Invocation:
        out = self._check(caller, credential, operation)
        if out is None:
            out = self._perform(credential, operation)
        self.log.append({"caller": caller, "credential_id": getattr(credential, "credential_id", None),
                         "operation": operation.summary() if isinstance(operation, ProviderOperation) else repr(operation),
                         "allowed": out.allowed, "reason": out.reason, "detail": out.detail,
                         "status": out.result.status if out.result is not None else None})
        return out

    def _check(self, caller: str, cred: Any, op: Any) -> Optional[Invocation]:
        def block(code: str, detail: str = "") -> Invocation:
            return Invocation(False, code, detail)

        if not isinstance(cred, ExecutionCredential) or not isinstance(op, ProviderOperation):
            return block(C.MALFORMED, "need an ExecutionCredential and a ProviderOperation")
        try:
            if self._issued.get(cred.credential_id) != cred.digest():
                return block(C.CREDENTIAL_NOT_ISSUED, str(cred.credential_id))
        except Exception as e:
            return block(C.CREDENTIAL_NOT_ISSUED, f"{type(e).__name__}")
        if caller != cred.holder:
            return block(C.HOLDER_MISMATCH, f"{caller!r} presented a credential held by {cred.holder!r}")
        now = self._verifier.now()
        if now < parse_instant(cred.not_before):
            return block(C.NOT_YET_VALID, cred.not_before)
        if now >= parse_instant(cred.expires_at):
            return block(C.EXPIRED, cred.expires_at)
        standing = self._verifier.grant_standing(cred.grant_id, cred.grant_digest)
        if standing is not None:
            return block(C.GRANT_NOT_IN_FORCE, ":".join(standing))
        if op.contract_id != cred.contract_id or op.capability != cred.capability:
            return block(C.CAPABILITY_NOT_AUTHORIZED, f"{op.contract_id}/{op.capability}")
        if op.execution_id != cred.execution_id:
            return block(C.EXECUTION_NOT_AUTHORIZED, str(op.execution_id))
        if cred.units:
            return self._check_unit(cred, op, block)
        if op.unit is not None:
            return block(C.UNIT_NOT_AUTHORIZED, f"{op.unit!r}: credential binds no execution units")
        if cred.resource is not None:
            kind, _, path = str(cred.resource.get("ref")).partition(":")
            got = _lookup(op.request, path) if kind == "plan" else _MISSING
            if got is _MISSING:
                return block(C.RESOURCE_UNVERIFIABLE, str(cred.resource.get("ref")))
            if not _same(got, cred.resource.get("value")):
                return block(C.RESOURCE_NOT_AUTHORIZED, f"{got!r}")
        if not _same(op.request, cred.request):
            return block(C.ARGUMENTS_NOT_AUTHORIZED, "request differs from the credential's request")
        if self._uses.get(cred.credential_id, 0) >= cred.max_uses:
            return block(C.EXHAUSTED, f"{cred.max_uses} use(s)")
        if cred.execution_id in self._consumed_executions:
            return block(C.EXECUTION_CONSUMED, cred.execution_id)
        if cred.contract_id not in self._effectors:
            return block(C.NO_BOUNDARY, cred.contract_id)
        return None

    def _check_unit(self, cred: ExecutionCredential, op: ProviderOperation, block) -> Optional[Invocation]:
        """V0.4 per-unit permit (after holder, lifetime, grant standing, capability, execution id)."""
        if op.unit is None:
            return block(C.UNIT_UNSPECIFIED, "the credential binds execution units; name one")
        u = cred.unit(op.unit)
        if u is None:
            return block(C.UNIT_NOT_AUTHORIZED, repr(op.unit))
        if cred.resource is not None:
            kind, _, path = str(cred.resource.get("ref")).partition(":")
            got = _lookup(op.request, path) if kind == "plan" else _MISSING
            if got is not _MISSING and not _same(got, cred.resource.get("value")):
                return block(C.RESOURCE_NOT_AUTHORIZED, f"{got!r}")
        if not _same(op.request, u["request"]):
            return block(C.ARGUMENTS_NOT_AUTHORIZED, f"{op.unit}: request differs from the unit's bound request")
        done = self._unit_records.get(cred.credential_id, {})
        if op.unit in done:
            return block(C.UNIT_CONSUMED, op.unit)
        waiting = [a for a in u.get("after", []) if done.get(a, {}).get("status") != EXEC_SUCCESS]
        if waiting:
            return block(C.UNIT_ORDER, f"{op.unit} after {waiting}")
        if cred.contract_id not in self._effectors:
            return block(C.NO_BOUNDARY, cred.contract_id)
        return None

    def _perform_unit(self, cred: ExecutionCredential, op: ProviderOperation) -> Invocation:
        records = self._unit_records.setdefault(cred.credential_id, {})
        eid, u = cred.execution_id, cred.unit(op.unit)
        self._consumed_executions.add(eid)
        state = u["state"]
        precondition, refusal = None, None
        if state == UNIT_STATE_AUTHORIZATION:
            precondition = cred.state_binding
        elif isinstance(state, dict):
            pred = records.get(state.get(UNIT_STATE_FROM), {}).get("result")
            precondition = _as_binding(getattr(pred, "established_state", None))
            if precondition is None:
                refusal = "intermediate state unavailable: the predecessor's effect exposed no version token"
            elif cred.state_binding is None or precondition.subject != cred.state_binding.subject:
                refusal = f"intermediate state is about {precondition.subject!r}, not the bound subject"
                precondition = None
        # consume BEFORE the effect: at most once even if the provider call fails or times out
        records[op.unit] = {"status": None, "result": None, "precondition": None}
        if refusal is not None:
            result = ExecutionResult(EXEC_PRECONDITION_FAILED, eid, None, copy.deepcopy(op.request), [], refusal)
        else:
            try:
                result = self._effectors[cred.contract_id].perform_unit(cred, copy.deepcopy(op), precondition)
                if not isinstance(result, ExecutionResult):
                    result = ExecutionResult(EXEC_FAILED, eid, None, copy.deepcopy(op.request), [], "effector returned no result")
            except ProviderTimeout as e:
                result = ExecutionResult(EXEC_UNKNOWN, eid, None, copy.deepcopy(op.request), [], f"timeout: {e}")
            except PreconditionFailed as e:
                result = ExecutionResult(EXEC_PRECONDITION_FAILED, eid, None, copy.deepcopy(op.request), [],
                                         f"stale state binding: {e}")
            except Exception as e:
                result = ExecutionResult(EXEC_FAILED, eid, None, copy.deepcopy(op.request), [], f"{type(e).__name__}: {e}")
        records[op.unit] = {"status": result.status, "result": result,
                            "precondition": precondition.to_dict() if precondition is not None else None}
        return Invocation(True, None, "", result)

    def _perform(self, cred: ExecutionCredential, op: ProviderOperation) -> Invocation:
        if cred.units:
            return self._perform_unit(cred, op)
        # consume BEFORE the effect: at most once even if the provider call fails or times out
        self._uses[cred.credential_id] += 1
        self._consumed_executions.add(cred.execution_id)
        eid = cred.execution_id
        try:
            result = self._effectors[cred.contract_id].perform(cred, copy.deepcopy(op))
            if not isinstance(result, ExecutionResult):
                result = ExecutionResult(EXEC_FAILED, eid, None, copy.deepcopy(op.request), [], "effector returned no result")
        except ProviderTimeout as e:
            result = ExecutionResult(EXEC_UNKNOWN, eid, None, copy.deepcopy(op.request), [], f"timeout: {e}")
        except PreconditionFailed as e:
            result = ExecutionResult(EXEC_PRECONDITION_FAILED, eid, None, copy.deepcopy(op.request), [],
                                     f"stale state binding: {e}")
        except Exception as e:
            result = ExecutionResult(EXEC_FAILED, eid, None, copy.deepcopy(op.request), [], f"{type(e).__name__}: {e}")
        self._results[cred.credential_id] = result
        return Invocation(True, None, "", result)

    # ------------------------------------------------------------- read-outs
    def result_of(self, credential_id: str) -> Optional[ExecutionResult]:
        """What the boundary itself observed the effector return for this credential's use.
        V0.4: for a unit credential, the composite outcome against the GRANT's required units."""
        if credential_id in self._unit_records:
            return self._composite_result(credential_id)
        return self._results.get(credential_id)

    def unit_records(self, credential_id: str) -> Optional[Dict[str, Dict[str, Any]]]:
        """V0.4: unit -> {status, precondition, established} as the boundary recorded it (None: no unit permits)."""
        recs = self._unit_records.get(credential_id)
        if recs is None:
            cred = self._creds.get(credential_id)
            return {} if cred is not None and cred.units else None
        return {uid: {"status": r["status"], "precondition": copy.deepcopy(r["precondition"]),
                      "established": copy.deepcopy(getattr(r["result"], "established_state", None))}
                for uid, r in recs.items()}

    def _composite_result(self, credential_id: str) -> ExecutionResult:
        cred = self._creds[credential_id]
        grant = self._verifier.grants.get(cred.grant_id)
        table = grant.execution_units if grant is not None else cred.units
        recs = self._unit_records[credential_id]
        status_of = {uid: r["status"] for uid, r in recs.items()}
        done = [u["unit_id"] for u in table if status_of.get(u["unit_id"]) == EXEC_SUCCESS]
        effects = [e for uid in done for e in (recs[uid]["result"].observed_effects or [])]
        if EXEC_UNKNOWN in status_of.values():
            status = EXEC_UNKNOWN
        elif all(status_of.get(u["unit_id"]) == EXEC_SUCCESS for u in table if u["required"]):
            status = EXEC_SUCCESS
        elif done:
            status = EXEC_PARTIAL
        elif EXEC_PRECONDITION_FAILED in status_of.values():
            status = EXEC_PRECONDITION_FAILED
        else:
            status = EXEC_FAILED
        detail = "; ".join(f"{uid}:{r['status']}" + (f":{r['result'].detail}" if r["result"] is not None and r["result"].detail else "")
                           for uid, r in recs.items())
        return ExecutionResult(status, cred.execution_id, cred.execution_id, copy.deepcopy(cred.request), effects, detail)

    def blocked_attempts(self, credential_id: str) -> List[Dict[str, Any]]:
        return [dict(e) for e in self.log if e["credential_id"] == credential_id and not e["allowed"]]

    # ----------------------------------------------------------- confinement
    def assess(self, contract_id: str, executor: Any, retains_provider_authority: bool,
               extra_handles: Iterable[Any] = ()) -> Confinement:
        """CONFINED only if (1) a boundary exists for the contract, (2) the deployer does not
        declare that the executor retains provider authority, and (3) none of the effector's
        authority handles (or `extra_handles`) is reachable from the executor's object graph.

        (3) is a MODELED check of an in-process object graph. It does not follow module
        globals or the runtime (gc, imports): real confinement needs process isolation."""
        effector = self._effectors.get(contract_id)
        if effector is None:
            return Confinement(NOT_CONFINED, MODE_C, (C.NO_BOUNDARY,), TCB_BY_MODE[MODE_C])
        if retains_provider_authority:
            return Confinement(NOT_CONFINED, MODE_C, ("declared_executor_retains_provider_authority",),
                               TCB_BY_MODE[MODE_C])
        handles = list(effector.authority_handles()) + list(extra_handles) + [effector, self, self._verifier]
        found = _reachable_handles(executor, handles)
        if found:
            return Confinement(NOT_CONFINED, MODE_C, tuple("bypass_authority_reachable:" + f for f in found),
                               TCB_BY_MODE[MODE_C])
        # V0.3: the mode and guarantee can never exceed declared infrastructure
        mode, reasons = effector.mode, []
        if mode == MODE_A and self._infra.get(INFRA_PROVIDER_ENFORCES) is False:
            # nobody but this gateway checks the credential: at best Mode B
            mode, reasons = MODE_B, ["mode_a_claimed_but_provider_does_not_enforce"]
        absent = [k for k in REQUIRED_INFRA[mode] if self._infra.get(k) is False]
        if absent:
            return Confinement(NOT_CONFINED, MODE_C, tuple(reasons + ["infrastructure_absent:" + k for k in absent]),
                               TCB_BY_MODE[MODE_C])
        assumptions = [a for a in CONFINEMENT_ASSUMPTIONS if self._infra.get(_ASSUMPTION_FACT.get(a, "")) is not True]
        if mode == MODE_A and self._infra.get(INFRA_PROVIDER_ENFORCES) is not True:
            assumptions.append(_MODE_A_ASSUMPTION)
        undeclared = [k for k in REQUIRED_INFRA[mode] if self._infra.get(k) is not True]
        return Confinement(CONFINED, mode, tuple(reasons), TCB_BY_MODE[mode], tuple(assumptions),
                           GUARANTEE_ASSUMED if undeclared else GUARANTEE_DECLARED)


# ===================================================================== helpers
_MISSING = object()


def _lookup(data: Any, path: str) -> Any:
    cur = data
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return _MISSING
        cur = cur[part]
    return cur


def _same(a: Any, b: Any) -> bool:
    try:
        return canonical.same(a, b)
    except Exception:
        return False


def _as_binding(v: Any) -> Optional[StateBinding]:
    """An opaque state token reported by an effector, if well formed."""
    keys = ("subject", "version_kind", "version_value")
    if not isinstance(v, dict) or set(v) != set(keys) or not all(isinstance(v[k], str) and v[k] for k in keys):
        return None
    return StateBinding(**{k: v[k] for k in keys})


def _digest(v: Any) -> Optional[str]:
    try:
        return canonical.digest(v)
    except Exception:
        return None


_ATOMS = (str, bytes, int, float, bool, type(None))


def _reachable_handles(root: Any, handles: List[Any], limit: int = 20000) -> List[str]:
    """Walk the executor's object graph (attributes, containers, closures, bound
    methods, class attributes of user classes). ExecutionPort is opaque: it is
    the sanctioned path. Returns a description of every reachable handle."""
    strings = {h for h in handles if isinstance(h, str)}
    ids = {id(h) for h in handles if not isinstance(h, str)}
    found: List[str] = []
    seen: set = set()
    stack = [root]
    while stack and len(seen) < limit:
        o = stack.pop()
        if isinstance(o, str):
            if o in strings:
                found.append("credential_string")
            continue
        if id(o) in seen:
            continue
        seen.add(id(o))
        if id(o) in ids and o is not root:
            found.append(type(o).__name__)
            continue
        if isinstance(o, _ATOMS) or isinstance(o, (types.ModuleType, ExecutionPort)):
            continue
        if isinstance(o, type):
            if o.__module__ != "builtins":
                stack.extend(v for k, v in vars(o).items() if not k.startswith("__"))
            continue
        if isinstance(o, dict):
            stack.extend(o.keys())
            stack.extend(o.values())
        elif isinstance(o, (list, tuple, set, frozenset)):
            stack.extend(o)
        elif isinstance(o, types.FunctionType):
            stack.extend(c.cell_contents for c in (o.__closure__ or ()) if _cell_full(c))
            stack.extend(o.__defaults__ or ())
        elif isinstance(o, types.MethodType):
            stack.extend((o.__self__, o.__func__))
        else:
            d = getattr(o, "__dict__", None)
            if isinstance(d, dict):
                stack.append(d)
            for slot in getattr(type(o), "__slots__", ()):
                if hasattr(o, slot):
                    stack.append(getattr(o, slot))
            stack.append(type(o))
    return sorted(set(found))


def _cell_full(cell: Any) -> bool:
    try:
        cell.cell_contents
        return True
    except ValueError:
        return False
