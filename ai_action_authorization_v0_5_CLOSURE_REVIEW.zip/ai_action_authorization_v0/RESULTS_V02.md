# RESULTS — AI Action Authorization Protocol V0.2 (execution-scoped authority / no-bypass)

Run: `python3 -m unittest discover -t . -s tests -v` on Python 3.9.6, macOS.
Earlier results are unchanged in [RESULTS_V0.md](RESULTS_V0.md) and [RESULTS_V01.md](RESULTS_V01.md). V0.3 results: [RESULTS_V03.md](RESULTS_V03.md). V0.4 (current): [RESULTS.md](RESULTS.md).

**Final verdict: `PARTIALLY_SURVIVED`** (reasoning in §19).

---

## 1. Totals

**152 tests run. 152 passed. 0 failed.**

| Group | Count | Notes |
|---|---|---|
| V0 tests | 57 | Byte-for-byte unchanged from V0.1 |
| V0.1 tests (`test_v01_f6_f7.py`) | 51 | Byte-for-byte unchanged |
| New V0.2 tests (`tests/test_v02_execution_authority.py`) | 44 | A1–A12, R1–R3, B1–B3b, T1–T7, H1–H4, D1–D5, G20–G21, 4 `test_FINDING_V02_*` |

`tests/harness.py` is also unchanged. `diff -r` against the V0.1 zip shows no differences under `tests/` except the new file.

`test_FINDING_*` tests pass because they assert that a weakness **exists**. They are reproductions, not evidence that something works.

**Mutation check (run once, not part of the suite).** 22 V0.2 protections were disabled one at a time. Each mutation made the suite fail:

| Disabled protection | Failing tests |
|---|---|
| boundary: holder check | 3 |
| boundary: expiry | 2 |
| boundary: grant standing | 3 |
| boundary: capability | 3 |
| boundary: execution_id | 2 |
| boundary: resource | 6 |
| boundary: request equality | 1 |
| boundary: use count | 3 |
| boundary: credential integrity | 1 |
| boundary: state binding passed to the provider | 8 |
| attenuation: capability | 3 |
| attenuation: resource | 2 |
| attenuation: uses | 2 |
| attenuation: lifetime ceiling | 2 |
| attenuation: state binding | 2 |
| attenuation: dependency gaps | 4 |
| attenuation: one credential per grant | 2 |
| confinement: reachability check | 3 |
| gateway: `require_confinement` | 2 |
| gateway: grant required | 1 |
| verifier: undeclared-read tracking | 2 |
| evaluators: dependency declarations | 23 |

---

## 2. Result of every A/B/T test

"3 domains" means the test runs as subtests in Matrix, Calendar and FakePay. "Effector calls 0" means the request never reached provider code.

### A — primary adversarial (confined Mode B, malicious executor really attempts Y)

| ID | Scenario | Observed | Result |
|---|---|---|---|
| **A1** | Matrix: authorized send to room A, then a send to room B with the same credential, then a send to B under a fresh txnId | X delivered. Both extra sends were blocked (`resource_not_authorized`, `execution_id_not_authorized`). Room B is empty. Homeserver `send_calls` = 1, effector calls = 1. Receipt is `VIOLATION` with `out_of_scope_attempt_blocked` ×2. | PASS |
| **A2** | Calendar: authorized reschedule of E1, then `delete_event(E1)` twice | Reschedule applied. Both deletes were blocked with `capability_not_authorized`. E1 still exists. Provider `delete_calls` = 0. | PASS |
| **A3** | Calendar: credential for E1 used to reschedule E2 | Blocked with `resource_not_authorized`. E2 unchanged. Patch calls 0. The receipt is not VERIFIED (FAILED: no in-scope invocation). | PASS |
| **A4** | FakePay: authorized 400 000 to An, then 100 000 to Binh (same execution_id), then a payment to Binh under a new execution_id | Both extras blocked (`resource_not_authorized`, `execution_id_not_authorized`). Balances are exactly Lam 600 000 / An 400 000 / Binh 0. Provider ledger has 1 entry and `transfer_calls` = 1. | PASS |
| **A5** | Credential for 400 000, request for 450 000 | Blocked with `arguments_not_authorized`. Lam's balance unchanged. `transfer_calls` = 0. | PASS |
| **A6** | Credential for An, request for Binh | Blocked with `resource_not_authorized`. No money moved. | PASS |
| **A7** | Credential for capability X used for Y (3 domains: `redact_event`, `delete_event`, `refund_money`). Also another contract_id, and a Matrix credential sent to the Calendar boundary of the same gateway. | All blocked with `capability_not_authorized`. Effector calls 0 everywhere. | PASS |
| **A8** | Resource substitution (3 domains: room B, evt-2, Binh) | All blocked with `resource_not_authorized`. Effector calls 0. | PASS |
| **A9** | Replay (3 domains): second use inside the execution, use after it finished, use through a fresh port, and re-minting from the same grant | `credential_exhausted` ×3 and `grant_already_attenuated`. Exactly 1 provider effect. | PASS |
| **A10** | Credential bound to agent-1, presented by agent-2 (3 domains). Also an executor registered as agent-2. | `credential_holder_mismatch` and 0 effects. The same credential then works for agent-1, so the block was the holder check. The agent-2 executor is never minted a credential (`holder_not_grantee`). | PASS (modeled identity, see V02-B) |
| **A11** | Clock passes the 5-minute credential lifetime (3 domains). Also an executor that "takes 10 minutes" before invoking. | `credential_expired`. 0 effects. Receipt `VIOLATION`. | PASS |
| **A12** | A valid credential, but state changes between minting and the call: Calendar location edit, FakePay external debit | Provider compare-and-swap refuses: `PRECONDITION_FAILED`, `UNVERIFIED state_precondition_failed_…`. No effect (FakePay ledger empty; Lam 950 000 from the external debit only). The spent credential then gives `credential_exhausted`. V0.1's TOCTOU protection holds. | PASS |

Additional boundary tests:

| ID | Scenario | Observed | Result |
|---|---|---|---|
| R1 | Delegation revoked after minting, before the call (3 domains) | `grant_no_longer_in_force: delegation_revoked`. 0 effects. | PASS |
| R2 | FakePay v2 contract published after minting | `grant_no_longer_in_force: contract_changed_…`. 0 transfers. | PASS |
| R3 | Credential altered (amount 900 000, max_uses 5) or a non-credential presented | `credential_not_issued_or_altered`, `malformed_invocation` | PASS |

### B — no bypass

| ID | Scenario | Observed | Result |
|---|---|---|---|
| **B1** | Confined Mode B executors in all 3 domains | `CONFINED`, `MODE_B`. None of the effector's authority handles (provider client, token map, token strings, effector, gateway, authority) are reachable from the executor or from anything it was handed or kept. The port's public API is exactly `holder` and `invoke`. Receipt `VERIFIED`. `assumptions` are stated, not hidden. | PASS |
| **B2a** | The executor keeps the homeserver client and token (deliberate bypass path); default `require_confinement=True` | Reported as `NOT_CONFINED` / `MODE_C` (`bypass_authority_reachable:…`). Fails closed with DENY `executor_not_confined`. No credential is minted. 0 messages. 0 boundary events. | PASS |
| **B2b** | The same executor with `require_confinement=False` | **The bypass works:** room B receives the extra message. The outcome says `NOT_CONFINED`, and the TCB list names the executor as trusted. The receipt is `VERIFIED` for its own execution and cannot see Y. **The ExecutionCredential does not solve a retained broad credential**, and the outcome does not claim it does. | PASS (as a demonstration) |
| B2c | Deployer declares retention; token hidden in a closure; an equal copy of the token string as a class attribute; executor holding the gateway; a V0.1 adapter registered as executor | All `NOT_CONFINED`. The adapter case is DENIED with 0 messages. | PASS |
| B2d | The V01-A scenario on the unchanged V0.1 `execute()` path | Outcome labelled `NOT_CONFINED` / `MODE_C`; the extra message still exists (this path is unchanged) | PASS |
| **B3** | The gateway effector holds broad authority | The TCB list contains "gateway effector (holds broad provider credential)" and no executor. Called directly with a forged credential, the effector deletes evt-2: it is **not** an authorization component and relies entirely on the boundary in front of it. | PASS (documented TCB) |
| B3b | A buggy trusted effector patches evt-2 instead of evt-1 | Wrong effect happened. This is outside the prevention guarantee. It is only **detected**: V0.1 evidence gives `VIOLATION evidence_subject_mismatch`. | PASS (documented) |

### T — attenuation (each refusal leaves the grant mintable once, which `tearDown` checks)

| ID | Attempt | Observed | Result |
|---|---|---|---|
| **T1** | Capability `refund_money`, `[transfer_money, refund_money]`, or another contract_id | `widens_capability` | PASS |
| **T2** | Resource Binh, `[An, Binh]`, or no resource | `widens_resource` | PASS |
| **T3** | Amount 500 000, or a request with the amount field removed | `widens_request` | PASS |
| **T4** | No state binding, or a different version value | `drops_or_changes_state_binding` | PASS |
| **T5** | max_uses 2, 1000, None, 0, True | `widens_max_uses` | PASS |
| **T6** | Expiry beyond the delegation's `valid_until`, expiry beyond the 5-minute ceiling, or backdated `not_before` | `widens_lifetime` / `malformed_lifetime` | PASS |
| T7 | Another holder; another execution_id; a grant forged with amount 500 000; several widenings at once | `holder_not_grantee`, `widens_execution_id`, `grant_not_issued_or_altered`, and all three codes together | PASS |

### H — honest path and V0.1 still first

| ID | Observed | Result |
|---|---|---|
| H1 | Honest confined execution is `VERIFIED` in all 3 domains, with `CONFINED`, holder agent-1, max_uses 1, request equal to the grant's request, one allowed boundary event, and 1 effect | PASS |
| H2 | `execute_confined` without a grant → DENY `grant_required_for_confined_execution`; 0 transfers | PASS |
| H3 | The confined path still returns `REQUIRE_CONFIRMATION`, `state_changed_…` and `delegation_revoked` **before** any credential exists | PASS |
| H4 | Replaying a finished confined execution returns the identical receipt with 1 transfer | PASS |

### D — state dependencies (V01-B / V01-C)

| ID | Observed | Result |
|---|---|---|
| **D1 (required test)** | Calendar: `core.resource_allowlist` authorizes on `fact:calendar_id` = work (V1). The grant and the credential carry `fact:calendar_id` and the etag binding. The event moves to `personal` (V2) between minting and the call. Result: `PRECONDITION_FAILED`, and the event time is unchanged. | PASS |
| D2 | Custom evaluator, no `fact:` in its spec, **declares** `fact:calendar_id`. (a) With a contract binding: carried into the credential, and a stale state gives PRECONDITION_FAILED. (b) Without a binding: V0.1's rule would not notice. Now the grant records a gap `unbound` and the decision warns `state_dependency_without_state_binding`. The confined path refuses (`attenuation_refused: state_dependency_gap`) with 0 patches. | PASS |
| D3 | Custom evaluator reads `ctx.facts["calendar_id"]` and declares **nothing** (with or without a binding). This is detected and classified as `undeclared_read` (warning `undeclared_state_read_by_evaluator`). The confined path refuses with 0 patches. | PASS |
| D4 | The V01-B scenario (FakePay contract without `state_binding`). `core.numeric_delta` now declares `fact:payer_balance`, which produces a gap `unbound` by `payer_debited_exactly`. The confined path refuses with 0 transfers. | PASS |
| D5 | V01-C: an incoming credit of 1 between minting and the call voids the credential (`PRECONDITION_FAILED`). Recorded as **`SAFE_BUT_OVERINVALIDATING`** (deferred). | PASS (as specified) |

---

## 3. Old V0/V0.1 regression results

**108/108 pass, and the test files are unchanged.** This includes every V0 test (M1–M4, C1–C4, P1–P7, X1, K1–K5, G1–G17, F1–F7) and every V0.1 test (E1–E6, S1–S6, X1–X4, U1–U5, G18–G19, FINDING_V01_A–F).

Two V0.1 finding tests deserve a note because V0.2 addresses their findings:

- `test_FINDING_V01_A` still passes. It runs the **legacy** `execute()` path, where the adapter holds provider credentials, so the extra effect still happens there. That path is now labelled `NOT_CONFINED` (B2d). V01-A is closed only on the new `execute_confined()` path.
- `test_FINDING_V01_B` still passes. The legacy `authorize()` call still returns ALLOW with no binding, which is what the test asserts. That decision now also carries a `state_dependency_without_state_binding` warning, and the confined path refuses it (D4).

I kept the legacy behaviour because the brief requires preserving every existing test. It is a deliberate choice, not an oversight.

---

## 4. Exact core files changed

Line counts are measured with `diff` against the unzipped V0.1.

| Core file | Change | +/− |
|---|---|---|
| `src/aaap/authority.py` | **New.** `ProviderOperation`, `ExecutionCredential`, `Attenuation`, `Invocation`, `Confinement`, `ProviderEffector` (interface), `ExecutionPort`, `ExecutionAuthority` (attenuate, attenuate_exact, the enforcement boundary `_invoke`/`_check`/`_perform`, assess), modes A/B/C, TCB table, confinement assumptions, object-graph reachability walk | +479 (new) |
| `src/aaap/verifier.py` | Reason codes. `GRANT_BOUND_FIELDS` extended. `now()`, `grants`, `grant_standing()`. Dependency aggregation and undeclared-read tracking (`_ReadTracker`) in steps 9–10, including post-only invariants. Gap classification as warnings. Grant built with V0.2 fields. `verify_execution(…, out_of_scope)` → `out_of_scope_attempt_blocked`. | +124 / −6 |
| `src/aaap/gateway.py` | `GatewayOutcome.confinement/credential/boundary_events`. `LEGACY_CONFINEMENT` label on `execute()`. `register_executor`, `assess_confinement`, `execute_confined`, `_refuse`, and an owned `ExecutionAuthority` | +107 / −5 |
| `src/aaap/evaluators.py` | `EvalOutcome.dependencies`. Core evaluators declare the `fact:` refs they relied on. `preserve_fields` and `numeric_delta` declare the facts their post-check compares against. | +27 / −8 |
| `src/aaap/objects.py` | `AuthorizationGrant` gains principal, agent, capability, resource, request, not_after, max_uses, state_dependencies, dependency_gaps (all with defaults, all in the digest) | +21 / −1 |
| `src/aaap/adapter.py` | `ConfinedExecutor` (untrusted executor interface; the generic default submits the plan) | +21 / −0 |
| `src/aaap/stores.py` | `GrantStore.get`, `claim_attenuation` (one credential per grant) | +14 / −0 |
| `src/aaap/__init__.py` | Exports | +7 / −3 |
| `src/aaap/canonical.py` | **Unchanged** | 0 |

## 5. Provider-specific files changed

All of these are outside `src/`. **No contract JSON, adapter or observer was changed.**

| File | Change |
|---|---|
| `fixtures/matrix/effector.py` (new) | `MatrixGatewayEffector` (Mode B). Holds the access token. `send_message` → `PUT /send` with txnId = execution_id. Refuses any state binding, because Matrix has no conditional send. |
| `fixtures/calendar/effector.py` (new) | `CalendarGatewayEffector` (Mode B). `reschedule_event` → PATCH with If-Match = the credential's binding. `delete_event` → DELETE. That is the broad authority the executor must not reach. 412 → `PreconditionFailed`. |
| `fixtures/fakepay/effector.py` (new) | `FakePayGatewayEffector` (Mode B). `transfer_money` → transfer with `if_match` = the credential's binding. |
| `fixtures/calendar/provider.py` | `delete_event` and a `delete_calls` counter (+10). These exist so that A2 can show that a broad token really can delete. |
| `fixtures/{matrix,calendar,fakepay}/world.py` | `build_confined()` (+13 each): the existing `build()` plus effector and executor registration |

## 6. Does core contain Matrix/Calendar/FakePay/capability branches?

**No.** The following tests check this:

- G1, G1b, G18, G19 (unchanged)
- **G20**: 24 domain words checked across every V0.2-touched core file, including `delete_event`, `transfer`, `room`, `recipient`, `amount`, `currency`
- **G21**: no `==`, `!=` or `in` comparison of issuer, capability, contract_id, identity, subject, version_kind, resource, holder, mode or request against a literal, in `authority.py`, `gateway.py` or `verifier.py`

The boundary compares capability, resource and request values with **opaque equality**. It finds the resource through the contract's own `verification.subject` reference (`plan:<field>`) and never knows what a room, event or recipient is. The effectors contain domain dispatch, as fixtures are allowed to.

## 7. Exact `ExecutionCredential` semantics

```yaml
credential_id:      "cred-" + sha256(body)[:24]       # content-addressed
grant_id, grant_digest:                              # the exact issued grant it came from
holder:             == grant.agent                    # the only identity that may present it
principal, intent_id                                  # whose authority; for provider metadata
contract_id, capability: == grant's                  # exactly one capability
resource:           == grant.resource                 # {"ref": verification.subject, "value": …}
request:            == grant.request (and digest == grant.plan_digest)   # the exact provider request
execution_id:       == grant.execution_id             # also the provider idempotency key
state_binding:      == grant.state_binding            # cannot be removed or changed
state_dependencies: == grant.state_dependencies       # opaque `fact:` refs (informational, carried)
not_before:         >= now
expires_at:         <= min(grant.not_after, now + 5 min)   # grant.not_after = delegation.valid_until
max_uses:           1                                 # 1 <= max_uses <= grant.max_uses (= 1)
```

It authorizes exactly one provider operation: the one whose contract_id, capability, execution_id, resource and full request are equal to the credential's. It may be used once, by its holder, inside its window, while its grant is still in force, under its state binding.

- **Integrity:** the in-memory `ExecutionAuthority` keeps `credential_id → digest`. An altered copy is `credential_not_issued_or_altered` (R3). There is no signature, by scope.
- **Not a bearer token:** a holder check is enforced on every call. It is a modeled identity, not proof-of-possession (§17 V02-B).

## 8. Exact attenuation algorithm

Code: `ExecutionAuthority.attenuate(grant, holder, contract_id, capability, resource, request, execution_id, state_binding, max_uses, not_before, expires_at)`.

1. The grant must be an `AuthorizationGrant` that `GrantStore` issued, unaltered. Otherwise `grant_not_issued_or_altered`.
2. `verifier.grant_standing(grant)`: the delegation exists, is unrevoked, is in its window, and its digest is unchanged; the contract's current digest equals the grant's. Otherwise `grant_no_longer_in_force:<code>`.
3. Collect **every** problem below; any problem refuses the mint. Nothing is clipped.
   - `grant.dependency_gaps` non-empty → `state_dependency_gap`
   - `holder != grant.agent` → `holder_not_grantee`
   - contract_id or capability ≠ grant's → `widens_capability`
   - resource ≠ grant's (canonical equality) → `widens_resource`
   - request ≠ grant.request, or digest(request) ≠ grant.plan_digest → `widens_request`
   - execution_id ≠ grant's → `widens_execution_id`
   - state_binding ≠ grant's → `drops_or_changes_state_binding`
   - max_uses not an int with 1 ≤ max_uses ≤ grant.max_uses → `widens_max_uses`
   - lifetime: `ceiling = min(grant.not_after, now + max_lifetime)`
     - `not_before ≥ now` and `not_before < expires_at`, else `malformed_lifetime`
     - `expires_at ≤ ceiling`, else `widens_lifetime`
4. `GrantStore.claim_attenuation(grant_id)`: at most **one** credential per grant, ever. Otherwise `grant_already_attenuated`. This is checked last, so refused attempts do not consume the grant.
5. Build the credential from the grant's values (not the caller's), content-address it, and record its digest and a use counter of 0.

Equality is the only relation used. Because the grant authorizes one exact request, any credential that differs from it is wider or different, and both are refused. No domain-specific ordering (such as "a smaller amount is narrower") is needed or used.

## 9. Exact enforcement-boundary algorithm

Code: `ExecutionPort.invoke(credential, operation)` → `ExecutionAuthority._invoke(port.holder, …)`.

Checks run in order, and the first failure blocks the call (`Invocation(allowed=False, reason)`). Nothing reaches provider code on a block.

1. Both arguments must be an `ExecutionCredential` and a `ProviderOperation` → `malformed_invocation`
2. The credential must be issued and unaltered (digest) → `credential_not_issued_or_altered`
3. `port.holder == credential.holder` → `credential_holder_mismatch`
4. `now ≥ not_before` → `credential_not_yet_valid`. `now < expires_at` → `credential_expired`
5. `grant_standing` (revocation, delegation window, contract change, grant integrity) → `grant_no_longer_in_force:<code>`
6. operation contract_id and capability == credential's → `capability_not_authorized`
7. operation execution_id == credential's → `execution_id_not_authorized`
8. Resource: resolve the credential's `plan:` reference inside `operation.request`. If it is missing → `resource_unverifiable`; if it differs → `resource_not_authorized`
9. `operation.request` must canonically equal the credential's request → `arguments_not_authorized`
10. uses < max_uses → `credential_exhausted`. The execution_id must not have been consumed by any credential → `execution_id_already_consumed`
11. An effector must be registered for the contract → `no_enforcement_boundary_for_contract`
12. **Consume before the effect:** uses += 1, and the execution_id is marked consumed.
13. `effector.perform(credential, operation)`. The effector must apply `credential.state_binding` as an atomic provider precondition or refuse.
    - `PreconditionFailed` → `PRECONDITION_FAILED`
    - `ProviderTimeout` → `UNKNOWN`
    - anything else → `FAILED`
14. Record the result. **The gateway takes the execution report from this record, not from the executor.** Every call, allowed or blocked, is appended to `authority.log`.

The gateway's `execute_confined()` wraps this:

1. Ledger replay.
2. Full V0.1 re-authorization with the grant.
3. Grant required.
4. Executor registered.
5. Confinement assessment. `NOT_CONFINED` with `require_confinement` → DENY `executor_not_confined`.
6. `attenuate_exact`. On refusal → DENY `attenuation_refused`.
7. Ledger claim.
8. `executor.execute_confined(intent copy, plan copy, credential, port)`.
9. Report = the boundary's record (or FAILED "no in-scope invocation"). Blocked attempts become `out_of_scope_attempt_blocked` violations in the receipt.
10. V0.1 evidence verification.

## 10. Is `AuthorizationGrant` now required?

**Yes, on the confined path.** `execute_confined()` without a grant is DENIED (H2). The credential can only be derived from an issued, unaltered, still-in-force grant, and every credential field is checked against it.

The legacy `execute()` keeps V0.1 semantics (grant optional) so that existing tests still pass. Its outcomes are labelled `NOT_CONFINED`.

## 11. Is V01-A prevented or merely detected?

**Prevented on the confined path, in the tested model.** The extra effect Y is refused at the boundary before any provider code runs: effector calls and provider call counters stay at the authorized count (A1, A2, A4, A7, A8).

The receipt additionally reports the blocked attempt (`out_of_scope_attempt_blocked`). That is secondary reporting, not the fix.

On the legacy path, V01-A still exists and is labelled `NOT_CONFINED`.

## 12. Can a malicious executor still cause extra effect Y?

| Configuration | Can it cause Y? |
|---|---|
| Confined (Mode B), executor uses its only sanctioned path | **No.** A1–A12, B1. |
| Executor retains a broad credential (Mode C) | **Yes.** B2b. It is labelled `NOT_CONFINED` and refused by default (B2a, B2c). |
| Executor assessed `CONFINED` but running in the same Python process | **Yes**, through runtime introspection: `gc.get_objects()` finds the gateway's provider client and token (FINDING V02-A). The in-process reachability check cannot see this. The `CONFINED` label therefore carries an explicit assumption that the executor runs outside the gateway's address space. |
| Executor with a port that reaches into the authority's internals | It can open a port in another holder's name and use a stolen credential (FINDING V02-B). |
| Trusted gateway effector is buggy or compromised | **Yes** (B3, B3b). This is outside the guarantee. It is only detected by V0.1 evidence. |

## 13. What happens when the executor retains broad provider authority?

The architecture reports it and refuses to call it confined:

- **Detection:** `assess()` returns `NOT_CONFINED` / `MODE_C` if any of these hold:
  - the deployer declares `retains_provider_authority`;
  - a V0.1 `ProviderAdapter` is registered as the executor;
  - any authority handle is reachable from the executor's object graph (attributes, containers, closures, bound methods, class attributes; string handles are matched by equality). Authority handles are the provider client, token map, token strings, effector, gateway, authority, ledger, adapters and evidence sources.
- **Default `require_confinement=True`:** DENY `executor_not_confined` before a credential exists, with 0 effects (B2a).
- **`require_confinement=False`:** execution proceeds. The outcome says `NOT_CONFINED`, and the TCB list names the executor as trusted. The bypass effect really happens (B2b). The V0.2 credential is **not** presented as a fix for this.
- **Legacy path:** always `NOT_CONFINED` / `MODE_C` (B2d).

## 14. Which components are now in the TCB?

The executor (the AI-side adapter) is **no longer** in the TCB for the absence of extra effects. That is the V0.2 change.

Confined Mode B (the only mode exercised), in addition to V0.1's TCB:

- `AuthorizationVerifier`, `GrantStore`, `ContractRegistry`, `DelegationStore`, `ExecutionLedger`, the core evaluators (as in V0.1)
- `ExecutionAuthority`: attenuation, the credential store and the enforcement boundary
- **The gateway effector**, which holds the broad provider credential and does no authorization of its own (B3)
- The gateway-side reader adapter (`resolve`/`plan`/`state_binding`/`read_back`; it also holds the token), as in V0.1
- Registered evidence sources (as in V0.1)
- The provider (its compare-and-swap and its records)
- **Deployment isolation:** the executor's process must not be able to reach the gateway's memory. This is stated as an assumption and is not enforced in-process.

## 15. How Mode A/B/C differ in guarantees

| | Mode A (provider-enforced scoped credential) | Mode B (trusted gateway holds broad credential) | Mode C (executor retains broad authority) |
|---|---|---|---|
| Who checks the credential | Provider | Gateway boundary (`ExecutionAuthority`) | Nobody, on the bypass path |
| Who holds broad authority | Nobody on the call path | Gateway effector | Executor |
| Extra effect Y by executor | Prevented by the provider | Prevented by the gateway, if the executor is isolated from the gateway | **Possible** |
| TCB | verifier, attenuation, provider | verifier, attenuation, boundary, effector, provider, isolation | Adds the executor |
| Status reported | `CONFINED` | `CONFINED` (with assumptions) | `NOT_CONFINED` |
| Exercised here | **No.** No fixture provider can verify a scoped credential (V02-D). The mode is represented, not implemented. | Yes, all three domains | Yes (B2, legacy) |

## 16. How state dependencies are declared and propagated

```
evaluator --EvalOutcome.dependencies ("fact:calendar_id", …)--> verifier aggregates StateDependencySet
   + _ReadTracker records the facts each evaluator actually read
   --> covered iff a StateBinding exists (V0.1 binding: versions all facts of resolve())
   --> AuthorizationGrant.state_dependencies / .dependency_gaps
   --> ExecutionCredential.state_binding (+ .state_dependencies)
   --> effector applies the binding as the provider precondition (If-Match / account revision)
```

- **Declaration:**
  - `core.allowed_values`, `core.resource_allowlist` and `core.max_numeric` declare their `fact:` target.
  - `core.time_window` declares its `fact:` targets.
  - `core.preserve_fields` and `core.numeric_delta` declare the facts their post-check compares against. This was the V01-B gap.
  - Post-only invariants are also run once in `pre` phase to collect declarations.
- **Opaque:** the core never interprets fact names or versions. It aggregates strings and requires a binding.
- **Gaps are classified, not assumed safe:**
  - `unbound`: declared, but there is no binding.
  - `undeclared_read`: the evaluator read a fact it did not declare.

  Both appear as decision warnings. Both make the grant impossible to attenuate, so the confined path fails closed (D2b, D3, D4).
- **Coarseness (V01-C, deferred):** one opaque token per resource, so any unrelated change invalidates the credential. **`SAFE_BUT_OVERINVALIDATING`** (D5, `test_FINDING_V01_C`).

## 17. New findings and classifications

| # | Finding | Test | Classification |
|---|---|---|---|
| V02-A | An executor assessed `CONFINED` reaches the gateway's FakePay client and token through `gc.get_objects()` and makes an extra transfer. The reachability check covers only the executor's object graph. Python provides no in-process isolation. | `test_FINDING_V02_A_…` | `ENFORCEMENT_BOUNDARY_DEFICIENCY` (of the in-process model; Mode B's guarantee needs process isolation) |
| V02-B | Holder binding is the identity of the port the call arrives on. A thief with any port can reach `port._authority` and open a port in the victim's name. | `test_FINDING_V02_B_…` | `ENFORCEMENT_BOUNDARY_DEFICIENCY` (modeled identity; proof-of-possession out of scope) |
| V02-C | Undeclared fact reads are detected only during authorization. An evaluator that reads facts only in its post phase, and declares nothing, leaves no dependency and no gap. This is the remaining part of V01-B. | `test_FINDING_V02_C_…` | `GENERIC_EVALUATOR_DEFICIENCY` |
| V02-D | None of the three providers accepts a scoped credential, so every confined configuration is Mode B: the gateway holds broad authority and is TCB. | `test_FINDING_V02_D_…` | `PROVIDER_LIMITATION` |
| V02-E | The gateway effector performs whatever it is handed. A buggy effector produces the wrong effect, which is detected by V0.1 evidence but not prevented. | B3, B3b | Not a protocol failure: gateway is TCB (as the brief's B3 directs). Recorded under `PROVIDER_LIMITATION` / TCB scope. |
| V02-F | To preserve the V0.1 tests, the legacy `execute()` and `authorize()` keep V0.1 behaviour. V01-A and V01-B remain on that path; it is labelled `NOT_CONFINED` and carries warnings. | B2d, D4, `test_FINDING_V01_A/B` | `CORE_ARCHITECTURE_DEFICIENCY` (compatibility path, not closed) |
| V02-G | Coarse whole-resource state binding over-invalidates (V01-C, deferred as instructed). | D5 | `STATE_BINDING_DEFICIENCY` — `SAFE_BUT_OVERINVALIDATING` |

Status of earlier findings:

- **V01-A:** closed on the confined path; still present on the legacy path.
- **V01-B:** mostly closed (declared and observed pre-phase reads; confined path fails closed). The V02-C residue remains.
- **V01-C:** deferred.
- **V01-D/E/F/G/H** and **F1–F5:** unchanged; their tests still reproduce them.

## 18. Known limitations

1. **In-process model.**
   - Confinement is a reachability check over an object graph plus a deployer declaration. It is not memory isolation (V02-A).
   - Holder identity is the port identity (V02-B).
   - Credential integrity comes from an in-memory store; there are no signatures.
2. **Mode A is not exercised.** No fixture provider verifies scoped credentials (V02-D).
3. **The gateway effector and the reader adapter are in the TCB** and hold the broad credential. A compromised gateway is outside the guarantee (B3).
4. **The credential is exact-match.** It cannot express "≤ 400 000" or "any time in this window". Narrower-than-exact delegation to the executor is not supported, and was not needed.
5. **Resource identity is the contract's single `verification.subject` reference.** Full request equality is what actually prevents a different resource; the resource check gives a clearer reason code.
6. **The receipt cannot see effects outside the boundary** (B2b). Detecting a bypass is not attempted. Bypass is prevented only by confinement.
7. **The legacy path is retained** for compatibility (V02-F).
8. **Post-only undeclared state reads are not detected** (V02-C). Coarse binding over-invalidates (V02-G).
9. **Designer bias:** the same author wrote the core, the fixtures and the tests with the brief in view. The fixture providers are fakes; no real Matrix, calendar or payment API was used.
10. **Not shown:**
    - containment of malicious providers or a compromised gateway;
    - cryptographic integrity or proof-of-possession;
    - OAuth or token-exchange interoperability;
    - universal provider support for scoped credentials;
    - atomic distributed execution;
    - enumerability of all side effects;
    - universal semantic equivalence.

## 19. Final verdict: **`PARTIALLY_SURVIVED`**

| Success criterion | Met? | Evidence |
|---|---|---|
| V0/V0.1 protections intact | Yes | 108/108 unchanged tests; H3 |
| Credential cannot exceed its grant | Yes | T1–T7, R3 |
| Extra effect Y prevented in confined mode | Yes, in the modeled configuration | A1, A2, A4, A7, A8 |
| Wrong capability/resource/arguments blocked before effect | Yes | A3, A5–A8 (effector calls 0) |
| Replay, expiry and wrong holder | Yes (holder is modeled) | A9–A11 |
| State binding still enforced | Yes | A12, D1 |
| No provider-specific branches in core | Yes | G1, G18–G21 |
| No bypass authority where confinement is claimed | Yes for the object graph; **not enforceable in-process** | B1, B2c vs V02-A |
| Bypass configurations identified, not overclaimed | Yes | B2a–B2d, `Confinement.assumptions` |
| V01-B dependencies propagate generically | Yes, except post-only reads | D1–D4, V02-C |

### Why not `SURVIVED`

The brief defines `PARTIALLY_SURVIVED` as "the generic model works but strong confinement depends on provider/gateway deployment assumptions that materially limit applicability". That is the result here:

- Every confined configuration is **Mode B**, so the gateway holds broad provider authority and is TCB. No provider supports Mode A (V02-D).
- The no-bypass property holds only if the executor is **isolated from the gateway's process**. The in-memory prototype cannot enforce that. A `CONFINED` executor escaped through `gc` (V02-A). The label therefore states its assumptions explicitly.

### Why not `FAILED`

- Preventing Y required **no** Matrix, Calendar or payment semantics in the core. Attenuation and enforcement compare opaque capability, resource, request, identity and time values, and find the resource through the contract's own reference.
- Within the model's stated trust boundary, no confined executor produced an unauthorized provider effect through any path the architecture grants it.
- The V02-A escape uses the Python runtime to read the TCB's memory. That violates the Mode B deployment premise ("the executor does not receive the broad credential"); the protocol logic is not wrong. This is why it is classified as a limit of the in-process model and why the verdict is PARTIALLY_SURVIVED rather than SURVIVED.
- If the `CONFINED` label were read as an in-process guarantee, V02-A would meet the brief's FAILED condition. The code does not make that claim (`Confinement.assumptions`), and neither does this report.
