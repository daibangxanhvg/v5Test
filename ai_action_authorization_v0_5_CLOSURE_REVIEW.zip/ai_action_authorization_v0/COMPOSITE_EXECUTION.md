# Composite Execution Binding (V0.4)

This document explains how one authorized action that causes several effects is bound, enforced and verified. Everything here is implemented and tested (`tests/test_v04_composite_execution.py`; test IDs below refer to it).

The approach in one sentence: a provider may declare **execution units**, which are opaque, effect-bound parts of one action. The unit table travels **inside the existing ExecutionBinding** (grant → credential → per-unit permit). Each unit is verified on its own.

There is no `ExecutionUnit`, `Effect`, `Step` or `Workflow` class. A unit is structured data (a dict) inside objects that already existed.

---

## 1. Why execution units are bindings, not a domain ontology

The core knows **five things** about a unit, and no more:

| The core knows | Example | The core never knows |
|---|---|---|
| an opaque identity | `"publish"`, `"u17"`, `"a1"` | what publishing is |
| which opaque effect labels it owns | `["document_published"]` | what a published document is |
| which fields of the authorized request it carries | `["document_ref", "audience"]` | what an audience is |
| an explicit order relation | `after: ["publish"]` | *why* the notification must follow the publish |
| an explicit state precondition and evidence requirement | `state: {"from_unit": "publish"}` | what a revision means |

Every comparison is exact string or canonical-JSON equality. A guard enforces this: G27 forbids comparing unit ids or effect labels against literals in any core file. G26 and G22 forbid newcomer vocabulary, and G28 forbids similarity or model inference.

- **B1:** renaming PubHub's units to `u17`/`u42` gives identical core behaviour across a 6-scenario battery.
- **B2:** a synthetic domain with three meaningless units (`a1`, `b2`, `c3`; labels `x.e1`–`x.e3`) works with no domain knowledge in the core.
- **B3:** lookalike ids (`Notify`, `notify `, `NOTIFY`, `notify#1`) are different units. A unit named `notify` in another contract on the same gateway is another unit.

What a unit id *means* exists in exactly one place: the provider's effector role table (`fixtures/pubhub_units/effector.py`: `roles = {"publish": "publish", "notify": "notify"}`). It lives with the provider, next to the contract.

## 2. Where units live (no sixth object)

```
CapabilityContract.execution_units      (provider declares; part of the security identity / binding digest)
        │  unit_table(contract, authorized plan)      deterministic binding generation
        ▼
AuthorizationGrant.execution_units      (exact unit table; in the grant digest; a GRANT_BOUND_FIELD)
        │  attenuate(..., units=subset?)  + independent re-derivation from the contract
        ▼
ExecutionCredential.units               (all units, or an explicit subset; in the credential digest)
        │  ProviderOperation(unit=...)   one permit per unit at the enforcement boundary
        ▼
ProviderEffector.perform_unit(credential, operation, precondition)   (provider-side; TCB)
        │
        ▼
ExecutionEvidence(covers_units, grant_id, unit_states)   → verifier → ActionReceipt.units
```

### Contract declaration (closed world; anything unknown → `malformed_contract`)

```jsonc
"execution_units": [
  {"unit_id": "publish", "required": true,  "effects": ["document_published"],
   "request_fields": ["document_ref", "audience"], "state": "authorization"},
  {"unit_id": "notify",  "required": true,  "effects": ["external_notification_sent"],
   "request_fields": ["document_ref", "audience"], "after": ["publish"],
   "state": {"from_unit": "publish"},
   "evidence": {"provenance": ["PROVIDER_AUTHORITY"], "joint_with": []},   // optional
   "post_invariants": [],                                                  // optional
   "subject": "plan:document_ref"}                                         // optional
]
```

Keys that must be stated explicitly (never defaulted): `unit_id`, `required`, `effects`, `request_fields`, `state`.

## 3. Unit identity and lineage

| Binding | Mechanism | Attack it stops |
|---|---|---|
| unit ↔ contract | units are part of the contract's binding digest; delegations pin it | changing units silently (E1–E5) |
| unit table ↔ grant | `grant.execution_units` is in the grant digest and in `GRANT_BOUND_FIELDS` | injecting, removing or mutating a unit in a grant (A2, A3, A4a); a grant from a faulty generator presented later (C8c2) |
| grant ↔ contract | before minting a credential, the boundary re-derives the table from the contract by digest, independently of binding generation | a binding generator that drops a unit (C8c) |
| unit ↔ credential | `credential.units` is in the credential digest | forging a credential with an extra unit (A2) |
| unit ↔ effect permit | `ProviderOperation.unit` must name a credential unit; request equals the unit's bound request; single use per unit | unit injection, argument mutation, duplication (C7a, A2, A3, A5) |
| evidence ↔ execution lineage | evidence must carry `execution_id`, `intent_id` **and** `grant_id`, and name the units it covers | replay across executions or actions (C5, C6, E3b) |

The provider records lineage itself. The effector writes `{intent_id, grant_id, unit}` as metadata on every provider write, and the observers return what the provider recorded.

## 4. Required vs optional

- `required` is mandatory and boolean. A missing or non-boolean value is malformed (C8b, C9).
- **Effects are partitioned over units.** Every contract effect belongs to exactly one unit:
  - An effect in no unit is malformed: "not assigned to any execution unit" (C8a, CT2).
  - An effect in two units is malformed (C9, C10c).
  - So once a contract opts into units, no effect can silently be "may happen". This is V03-A closed for unit contracts.
- **Every authorized request field is carried by some unit.** An argument cannot be dropped on the way to the provider.
- **A required unit cannot depend on an optional unit**, through `after` or `from_unit`.
- **At least one unit is required.** If `verification.required_effects` is also present, it must equal the effects of the required units.

An optional unit:

- does not block success when it is absent or fails (C10a);
- cannot widen authority: its request is bound exactly, and an unlisted "optional" unit cannot be invoked (C10b);
- cannot hide an effect: if it **executed**, it must be verified like any other unit, or the composite is UNVERIFIED with `executed_optional_unit_unverified` (C10c).

## 5. Authority coverage

- **Grant.** Covers the whole unit table authorized at decision time.
- **Credential.** Covers all units, or an explicit subset (`attenuate(..., units=(...))`). Its `effects` narrow to the subset's effects. Naming a unit outside the grant, an empty subset, or wider effects is refused: `widens_or_changes_units` / `widens_or_changes_effects` (A1b).
- **Permit, issued at the boundary immediately before each unit's effect.** All V0.2/V0.3 checks still run (holder, lifetime, grant standing, capability, execution id). Then:

| Check | Refusal code |
|---|---|
| the operation names a unit | `unit_not_specified` |
| the unit is in the credential | `unit_not_authorized` |
| the request equals the unit's bound request | `arguments_not_authorized` |
| the unit has not run before | `unit_already_performed` |
| every `after` predecessor completed with SUCCESS | `unit_predecessor_incomplete` |

- A unit operation on a V0.3 unit-less credential is refused (A2b).
- The composite outcome is aggregated against the **grant's required units**, not the credential's subset. A subset credential therefore yields PARTIAL, never SUCCESS (A1, A4c).

## 6. State continuity (V03-H)

A unit declares one of three preconditions explicitly:

| `state` | Precondition the boundary passes to the effector |
|---|---|
| `"authorization"` | the grant's authorization-time `StateBinding` (V1) |
| `{"from_unit": P}` | the state token P's effect **established**, as reported by the effector (`ExecutionResult.established_state`). P must be a declared predecessor (`after`). |
| `"unbound"` | none, by explicit provider declaration |

The **boundary**, not the executor, computes the precondition. `ProviderOperation` has no precondition field; an executor that tries to send one in the request is refused (S2c). The precondition is applied atomically by the provider (CAS):

- **S1a:** publish runs at rev 5 (V1) and establishes rev 6 (V2); notify is bound to rev 6.
- **S1b:** the document changes between the units → the provider refuses notify → PARTIAL, nothing sent.
- **S1c:** an effector that applies V1 to notify is refused by the provider.

This is **prevention**. V0.3 could only *detect* unchained calls (T4e).

Fail-closed cases:

- **The predecessor exposed no version token (S6a).** The dependent unit is **not attempted**. It is recorded as `PRECONDITION_FAILED: intermediate state unavailable`, the executor is not blamed, and the composite is PARTIAL. No state truth is invented.
- **The established token is about another subject (S2a).** The dependent unit is not attempted.

Verification cross-checks the continuity as well:

- the evidence for each unit must attest the precondition the provider *applied*;
- for `from_unit`, the predecessor's evidence must attest the state it *established*;
- that established state must equal what the boundary used.

Outcomes: an evidence mismatch is a VIOLATION (S2b, C4c). An unattested state is UNVERIFIED (S6b, S6c).

**Limit (FINDING_V04_C).** A grant carries **one** authorization-time `StateBinding`. A unit on another mutable resource can be evidence-bound to that resource (per-unit `subject`), but its precondition can only be `unbound` or a continuation of the bound subject. A second authorization-time binding is not expressible and fails closed.

## 7. Evidence coverage (V03-B)

For a unit contract, an evidence item counts for unit U only if every one of these holds:

1. **Source registration.** The source is registered for the contract address, and its provenance matches.
2. **Binding.** `execution_id`, `intent_id` and **`grant_id`** match.
3. **Unit claim.** The item names U in `covers_units` (no claim → `no_unit_claim`), and U is a unit of this contract (`unit_unknown`).
4. **Unit scope.** The deployer registered the source with a **unit scope** that contains U.
   - An unscoped source attests **no** unit (C12b).
   - Unscoped is never read as "everything". This is what closes V03-B.
5. **Effects inside the covered units.** Its observed effects lie inside the covered units' effects (`effect_outside_covered_units`). U's effects are actually observed (`effects_unobserved`, C15).
6. **Provenance accepted for U.** By default this is the contract-level list. A unit may demand a stronger one, e.g. `INDEPENDENT_READBACK` (C12c, E4).
7. **Joint coverage is explicit.** If the item covers several units, every pair must be declared `joint_with` **by both units**, and all covered units must be about the same subject (C11, C11b, C16).
8. **Subject and postconditions.** The subject matches the unit's subject. Postconditions are checked against the unit's **request projection**. Post invariants run only on evidence of the units that list them in `post_invariants`; this fixes V03-C (C14).
9. **Applied state.** For a unit that has a precondition, the applied state matches (§6).

Evidence that is about the contract but does not fit is handled this way:

- **Evidence of an effect outside the contract** from any registered source is a VIOLATION (`undeclared_effect_observed`), whatever units it claims (CT3).
- **Authoritative evidence of a unit the boundary never permitted or completed** is a VIOLATION (`unit_effect_observed_without_permit`, C5b, C7b).

**One evidence item may cover two units** only when the contract says so (C11). There is no hardcoded one-item-per-unit rule. There is also no implicit sharing (C4d, C11b).

## 8. Partial execution semantics

The composite status is aggregated from the boundary's own per-unit records. It is never taken from the executor or the effector's summary.

| Unit outcomes | Composite status | Ever VERIFIED? |
|---|---|---|
| every required unit SUCCESS (optional ones may be absent or failed) | SUCCESS | yes, if every required unit and every *executed* optional unit is verified |
| some unit SUCCESS, some required unit not | PARTIAL | never |
| any unit UNKNOWN (timeout) | UNKNOWN | never (settled IN_DOUBT) |
| none succeeded, a precondition refused | PRECONDITION_FAILED | never |
| none succeeded | FAILED | never |

The receipt carries a per-unit table: `ActionReceipt.units = [{unit_id, required, execution, verified, evidence, problems}]`.

- A partial outcome is settled and never retried. Replaying returns the same receipt, and no compensation is invented (C3).
- The legacy unconfined `execute()` path has no per-unit permits, so a unit contract executed there is UNVERIFIED with `unit_execution_unobserved` (C13).

## 9. Trust assumption: who is authoritative for the complete set of effects?

**The provider's authenticated CapabilityContract is authoritative for its domain semantics, including the complete set of security-relevant effects and units. The executor and adapter are not trusted for anything.** The protocol trusts the contract and distrusts the executor.

| Party | Behaviour | Outcome | Test |
|---|---|---|---|
| Honest, validated contract | declares every effect in a unit | strong guarantee: VERIFIED only with per-unit authoritative evidence | CT1, C1 |
| Incomplete contract that **still lists** the effect | effect not assigned to a unit | **fails closed** (`malformed_contract`) | CT2, C8a |
| Incomplete legacy contract **with no units** | several effects, no composition declared | V0.3 semantics: V03-A reproduces. A deployer may set `require_declared_composition` → DENY, but that also denies FakePay V2 (Calendar V2 has the same shape), so it is off by default | C8e, FINDING_V04_B |
| **Lying** contract | omits the effect entirely; the provider still causes it | detected **only** if an independently registered source observes the hidden effect (`undeclared_effect_observed`). Otherwise **VERIFIED**. | CT3, **FINDING_V04_A** |
| Malicious executor/adapter | injects, skips, reorders, repeats, mutates, widens | blocked at the boundary before any provider code runs, and reported (VIOLATION) | C7a, S3, S4, A2–A5, CT4 |
| Faulty binding generator (in the TCB) | drops a unit from the grant | refused at attenuation. Even if that check is bypassed, verification derives required units from the contract → never VERIFIED. | C8c, C8c2, C8d |
| Effector (TCB, Mode B) | causes an extra effect inside a permitted unit | detected only if a source observes it | C7b, **FINDING_V04_D** |
| Evidence source (TCB) | forges consistent evidence for a unit in its scope | VERIFIED; the damage is confined to that source's unit scope | **FINDING_V04_E** |

A lying contract makes strong verification impossible. This is a **contract/provider trust limitation**, and the protocol does not paper over it with effect discovery or an ontology. The mitigation is infrastructure: authenticated contract issuers (V03-D), contract review, and an independent observer of the effects the deployer cares about (CT3).

## 10. When fail-closed occurs

1. Any unknown key in a unit, its `state` or its `evidence`; an unknown state value (C9).
2. `required` or `state` not stated explicitly; `required` not boolean (C8b, C9).
3. A declared effect not assigned to any unit, or assigned to two (C8a, C9).
4. A request field carried by no unit; an unknown request field (C9).
5. `after` naming a unit not declared earlier (unknown, later or cyclic); `from_unit` not a declared predecessor (C9).
6. One-sided `joint_with` declarations (C9).
7. A required unit depending on an optional one; no required unit; `required_effects` contradicting the units (C9).
8. A post-phase invariant bound to no unit; `post_invariants` naming a pre-phase invariant (C9).
9. A unit with a state precondition when the contract declares no state binding (C9).
10. `execution_units` declared noncritical (C9).
11. A conditional or business-semantic dependency (`after_if`) (B4).
12. A grant unit table that differs from the contract's: at attenuation, re-authorization and verification (C8c, C8c2, C8d).
13. Any boundary refusal in §5.
14. A dependent unit whose intermediate state is unavailable or about another subject: not attempted (S6a, S2a).
15. Evidence failing any condition in §7.
16. Execution of a unit contract without boundary unit records: UNVERIFIED (C13).
17. A V0.3 core given a unit contract: `unsupported_critical_extension` (`tools/v04_probe.py`).
18. Deployer strict policy: a multi-effect contract without units (C8e).

## 11. Was a sixth primitive necessary?

**No.** The primitive-admission rule was applied to every candidate (RESULTS §10). None met all six conditions.

- **Units** are structured content of the existing ExecutionBinding (grant → credential → permit) and of the CapabilityContract. G25 checks that no class, module, object or binding was added.
- **Evidence** per unit is three fields on the existing `ExecutionEvidence` record.
- **Partial outcome** per unit is a field on the existing `ActionReceipt`.

The pressure that remains is **not** for a new object. It is for richer content inside the existing **StateBinding**: several authorization-time bindings when units act on different mutable resources (FINDING_V04_C). V0.4 does not add it: it fails closed (units on other resources must be `unbound`), and ordinary composites still execute, with a weaker guarantee for that unit. It is recorded as a proposal.

## 12. What this does not show

- Arbitrary workflows (loops, branches, conditional steps), long-running or human-in-the-loop sequences, distributed transactions or compensation.
- Real providers. All providers are in-memory fakes written by the same author as the core and tests.
- That providers will declare their units honestly and completely (§9).

## V0.5 interaction

Multi-subject `StateBinding` does not change V0.4 unit composition. Units can project different dependency subsets and share dependency identities. `from_unit` remains the explicit bridge when U1 establishes state required by U2. Partial execution remains legal and honestly reported; state consistency does not convert a composite into a transaction.
