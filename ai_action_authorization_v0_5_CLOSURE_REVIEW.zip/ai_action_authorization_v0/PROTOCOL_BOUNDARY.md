# Protocol Boundary (V0.4)

> Support what can be stated and enforced safely; identify the boundary; fail closed beyond it; do not grow into the world model.

This document states who owns what, as implemented and tested in V0.3 and extended by V0.4 (composite execution binding, [COMPOSITE_EXECUTION.md](COMPOSITE_EXECUTION.md)).

## 1. Protocol owns: the bounded action-authorization lifecycle and its bindings

### Lifecycle objects (unchanged count: 5)

| Object | Role | Code |
|---|---|---|
| `CapabilityContract` | The provider's statement of one action: inputs, effects (upper bound), required effects, constraints, invariants, verification, authority, confirmation, identity declaration. V0.4: optional `execution_units` (opaque units partitioning the effects) | `objects.py` |
| `Delegation` | The principal's bounded grant to an agent, pinned to contract addresses and security digests | `objects.py`, `stores.DelegationStore` |
| `ActionIntent` | The agent's proposal: one concrete action with arguments and an execution id | `objects.py` |
| `AuthorizationGrant` | "This exact execution is authorized under these conditions". V0.4: includes the exact unit table | `objects.py`; issued only by the verifier |
| `ActionReceipt` | What happened and how well it is proven: VERIFIED / UNVERIFIED / VIOLATION, with reasons and evidence records. V0.4: per-unit outcome table | `objects.py`; produced only by the verifier |

Supporting records from V0–V0.2 are unchanged in kind: `AuthorizationDecision`, `Confirmation`, `StateBinding`, `ExecutionEvidence`, and in `authority.py` `ExecutionCredential`, `ProviderOperation` and `Confinement`. V0.3 adds no class (G24); V0.4 adds no class, module or binding (G25). An execution unit is structured data, not an object.

### Bindings (unchanged count: 4)

| Binding | What it binds | V0.3 fields added | V0.4 fields added |
|---|---|---|---|
| **AuthorityBinding** | Delegation → contract (address + security digest), required authority, principal/agent, confirmation, credential holder | `binding_digest` (security identity); confirmation binds `contract_artifact_digest`; issuer-qualified contract address; per-(local id, issuer) trust | none (units are inside the security identity, so the V0.3 pinning covers them) |
| **StateBinding** | The authorization-time version of the state it relied on; the dependency set; the provider CAS precondition | none | none in the record. Per-unit *use*: `authorization` / `from_unit` (a predecessor's produced token, `ExecutionResult.established_state`) / `unbound`. Still one binding per grant (V04-C) |
| **EvidenceBinding** | Evidence ↔ execution, intent, subject, contract address, source provenance | source **effect scope**; `verification.required_effects`; consistency of evidence with a PARTIAL report | `covers_units`, `grant_id` (lineage), `unit_states`; source **unit scope**; per-unit provenance requirement, joint declaration, per-unit subject and post invariants |
| **ExecutionBinding** | Grant → credential → exact operation → effector; single use, lifetime, holder; confinement and guarantee | `effects` in grant and credential; report status `PARTIAL`; infrastructure facts and `Confinement.guarantee` | `grant.execution_units`, `credential.units` (subset allowed), `ProviderOperation.unit`, per-unit permit (order, single use, boundary-computed precondition), `ActionReceipt.units` |

### What the protocol standardizes

- **The action being authorized.** An address (`issuer::local_id` or legacy bare id), a capability, exact arguments and an exact provider request (the `maps_to` vocabulary).
- **Delegation.** Pins to security digests; constraints as data.
- **Exact intent/grant binding.** Digests and single use.
- **Security-relevant state dependencies.** Opaque version tokens and the dependency set.
- **Execution binding.** Credential ⊆ grant; the authorized effect set; partial outcomes; no invented rollback.
- **Evidence binding.** Provenance, effect scope, required effects.
- **Composite execution (V0.4).** The unit table, required vs optional, explicit order, per-unit permits, the per-unit state precondition and its continuation, per-unit evidence coverage and lineage. All of it is opaque ids and exact equality.
- **Deployment guarantee level.** Mode A/B/C, `CONFINED`/`NOT_CONFINED`, and the guarantee strength derived from declared infrastructure.
- **Schema closure.**
  - Every structure the verifier interprets has a closed key set.
  - An unknown top-level field is critical unless the issuer declares it noncritical.
  - An unknown modifier on a known evaluator is an unknown semantic.
- **Identity separation.** The issuer may declare only {description, human_metadata} non-security. Everything else, including the declaration itself, is security identity.

### What the protocol does NOT do

| It does not | Evidence |
|---|---|
| Understand any business concept: effect labels, fields, audiences, visibility, documents | G1, G18, G20, G22 |
| Decide semantic equivalence: lookalikes stay distinct; ambiguity is refused | P8 |
| Define a global ontology. Composite effects are opaque labels with a generic may/must distinction (`effects` / `required_effects`); V0.4 units are opaque ids whose meaning lives in the provider's effector role table | RESULTS_V03 §11; V0.4 B1–B4, G26–G28 |
| Infer missing effects, dependencies or equivalences: an undeclared effect is unknown to the core (V04-A); an undeclared dependency is not invented (B4); lookalike unit ids are different (B3) | V0.4 CT3, B3, B4, FINDING_V04_A |
| Define provider wire formats: Folio's nested body, integer revisions and `client_token` never reach the core | P7, G22 |
| Replace identity, token or isolation infrastructure: it consumes declared facts | §2 |
| Invent truth when authoritative observation does not exist: no evidence → no VERIFIED; partial → never success | T4, T5, T6c |
| Invent compensation | T4: no unpublish |

## 2. Infrastructure owns

These are modeled inputs here, never implemented:

| Concern | How it enters the protocol | What happens when it is absent |
|---|---|---|
| **Identity proof** of contract issuers | `ContractRegistry.publish(contract, authenticated_issuer=…)` | A forged contract can occupy an address. Digest pins turn this into DoS (V03-D). |
| **Identity proof** of holders (proof-of-possession) | `declare_infrastructure(holder_proof_of_possession=…)` | Holder = port identity (V02-B); stated as an assumption |
| **Cryptography** (signatures on contracts, grants, credentials, evidence) | Not modeled. Integrity comes from in-memory stores (`GrantStore`, credential digests). | Out of scope |
| **Token mechanics** (attenuation encoding, exchange: RAR / Token Exchange / GNAP / Macaroons / Biscuit / DPoP patterns) | `ExecutionCredential` is the semantic content, not an encoding | — |
| **Isolation** of the executor from the gateway (process, sandbox) | `declare_infrastructure(executor_isolated_from_gateway=…)` | Undeclared → `CONFINED_ASSUMING_UNDECLARED_INFRASTRUCTURE`; declared absent → `NOT_CONFINED` (E4b); V02-A unchanged |
| **Provider-side credential enforcement** (Mode A) | `declare_infrastructure(provider_enforces_scoped_credential=…)` | A Mode A claim is reported as Mode B (E4c) |
| **Transport security** | Not modeled | — |
| **Conditional-write implementation** (ETag/If-Match, revision CAS, step chaining) | The provider applies the opaque `StateBinding`; evidence reports `applied_precondition` | Unconditional writes are detected: `state_precondition_not_enforced` (T4e) |
| **Evidence-source integrity** | The deployer registers provenance, effect scope and (V0.4) unit scope | An unscoped lying source can attest any effect of a unit-less contract (V03-B). For a unit contract an unscoped source attests nothing, and a lying scoped source can attest only its own units (V04-E) |
| **Contract authenticity / completeness review** (V0.4) | `authenticated_issuer` (V0.3); independent observers registered by the deployer | A contract that hides an effect verifies unless an independent source observes the effect (V04-A) |

## 3. Provider / application contract owns

- **Domain semantics:** what `rename_document` or `publish_and_notify` means, expressed only through the contract fields above.
- **Effects:** the upper bound (`effects`) and what must happen (`verification.required_effects`). Omitting the latter weakens verification (V03-A).
- **Invariants and constraints:** with evaluators. Path or history rules are **provider evaluators** (e.g. `pubhub.no_public_within_hold`) with declared `fact:` dependencies (T3e). Without them the contract fails closed (T3d).
- **Risk, reversibility, confirmation policy.**
- **State dependencies:** which subject is version-bound (`verification.state_binding`).
- **Authoritative evidence sources:** which observers exist; the deployer registers them with provenance and effect scope.
- **Security-identity declaration:** which human metadata is non-security. This is the issuer's word (V03-E).
- **Representation mapping, at the newcomer boundary:** `fixtures/*/mapping.py`, adapter, effector, observer. For example:
  - protocol `doc-42` ↔ Folio `FD-0042`;
  - `"17"` ↔ `17`;
  - audience ↔ list, with ambiguity refused.
- **Splitting one authorized operation into several provider calls:** in V0.3 the trusted effector did this, honoured `credential.effects`, chained later calls to the bound state, and reported `PARTIAL`. It never compensates (V03-H, V03-J).
- **V0.4: the complete set of security-relevant effects and execution units.** The provider's authenticated contract is **authoritative** for this. The protocol trusts it for domain semantics and distrusts the executor and adapter.
  - Incomplete structure that the core can see fails closed.
  - A contract that hides an effect entirely is a stated trust limitation (V04-A).
  - The provider also owns:
    - what each unit id means (the effector's role table);
    - exposing the version token each write produces (else dependent units fail closed);
    - recording `{intent_id, grant_id, unit}` with each write;
    - emitting unit-labelled evidence.

## 4. AI owns

- **Semantic reasoning, planning and proposal:** choosing which contract, which arguments, and which delegation to use, and drafting the `ActionIntent`.
- **Never final authorization.**
  - The AI's executor is untrusted. It holds only a single-use, exact `ExecutionCredential` and an `ExecutionPort`.
  - What it reports is ignored; the boundary records what happened.
  - Splitting, widening, replay, holder substitution and relabelling all fail (T2, T3, T6; V0.2 A1–A12).
  - The core contains no LLM call and no learned equivalence.

## 5. The boundary, stated

| Inside (supported, enforced) | Edge (supported only with declarations; fails safe otherwise) | Outside (fails closed or unsupported) |
|---|---|---|
| Exact single actions in any domain whose provider exposes a version token and an idempotent record. **V0.4:** composite actions whose contract declares execution units over one bound subject, whose provider exposes produced versions and records lineage, and whose sources are unit-scoped | Composite actions **without** units: V0.3 semantics (V03-A/B unless declared; deployer strict policy denies them). Units on another mutable resource: evidence-bound, but only `unbound` (V04-C). The effect inside a unit is the effector's (V04-D). | Unknown critical structure (incl. any unknown unit structure); unknown path semantics; ambiguous mappings; lookalike contracts and unit ids; ambiguous bare ids; undeclared non-security fields; executor-side splitting outside units; skipped, reordered, repeated, injected or mutated units; dependent units without an exposed intermediate state; conditional dependencies; contract-claimed confinement |
| Metadata-only evolution with an explicit declaration | Confinement claims: assumed until infrastructure is declared | Mode C (refused by default); infrastructure declared absent |

## V0.5 state boundary

Generic core may know dependency IDs, issuer-qualified subject identity, requiredness, exact binding lineage, validation completeness, consistency level, and consistency-context coverage. It must not know provider token semantics. The provider/contract remains responsible for complete dependency declaration; the trusted validator remains responsible for token validation and truthful snapshot/atomic assertions. Unknown critical state semantics fail closed. State validation is authorization/execution-precondition evidence, not a promise of rollback or atomic business execution.
