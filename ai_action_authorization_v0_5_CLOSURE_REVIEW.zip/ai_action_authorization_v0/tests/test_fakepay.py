import dataclasses
import unittest

from aaap import ALLOW, DENY, REQUIRE_CONFIRMATION, UNVERIFIED, VERIFIED, VIOLATION, Confirmation, R

from fixtures.fakepay import world

NOW = "2026-10-13T09:31:00+07:00"


def confirm(decision):
    return Confirmation.from_decision(decision, principal="lam", confirmed_at=NOW)


class FakePayTests(unittest.TestCase):
    def setUp(self):
        self.core, self.pay, self.contract = world.build()
        self.gw = self.core.gateway

    def _confirmed(self, intent):
        d = self.gw.request_authorization(intent, "dlg-pay-1")
        self.assertEqual(d.decision, REQUIRE_CONFIRMATION, d.reasons)
        return confirm(d)

    def test_P1_confirm_allow_execute_verified(self):
        i = world.intent()
        d = self.gw.request_authorization(i, "dlg-pay-1")
        self.assertEqual(d.decision, REQUIRE_CONFIRMATION)
        self.assertEqual(self.pay.balances["lam"], 1_000_000)  # nothing moved yet
        c = confirm(d)
        self.assertEqual(self.gw.request_authorization(i, "dlg-pay-1", c).decision, ALLOW)
        out = self.gw.execute(i, "dlg-pay-1", c)
        self.assertEqual(out.decision.decision, ALLOW)
        self.assertEqual(out.receipt.verification_status, VERIFIED, out.receipt.verification_reasons)
        self.assertEqual(self.pay.balances["lam"], 600_000)
        self.assertEqual(self.pay.balances["an"], 400_000)

    def test_P1b_execute_without_confirmation_does_not_execute(self):
        out = self.gw.execute(world.intent(), "dlg-pay-1")
        self.assertEqual(out.decision.decision, REQUIRE_CONFIRMATION)
        self.assertIsNone(out.receipt)
        self.assertEqual(self.pay.transfer_calls, 0)

    def test_P2_over_limit_deny(self):
        out = self.gw.execute(world.intent(amount=700000), "dlg-pay-1")
        self.assertEqual(out.decision.decision, DENY)
        self.assertIn("max_amount", out.decision.reasons[0]["detail"])
        self.assertEqual(self.pay.transfer_calls, 0)

    def test_P3_confirm_400000_execute_450000_deny(self):
        c = self._confirmed(world.intent(amount=400000))
        out = self.gw.execute(world.intent(amount=450000), "dlg-pay-1", c)  # 450000 is under the 500000 limit
        self.assertEqual(out.decision.decision, DENY)
        self.assertEqual(out.decision.codes(), [R.CONFIRMATION_MISMATCH])
        self.assertEqual(out.decision.reasons[0]["detail"], "intent_digest")
        self.assertEqual(self.pay.transfer_calls, 0)

    def test_P3b_in_place_mutation_of_confirmed_intent_deny(self):
        i = world.intent()
        c = self._confirmed(i)
        i.arguments["amount"] = 450000   # frozen dataclass, but the dict is mutable
        out = self.gw.execute(i, "dlg-pay-1", c)
        self.assertEqual(out.decision.decision, DENY)
        self.assertEqual(self.pay.balances["lam"], 1_000_000)

    def test_P4_confirm_An_then_Binh_deny(self):
        c = self._confirmed(world.intent(recipient="an"))
        out = self.gw.execute(world.intent(recipient="binh"), "dlg-pay-1", c)
        self.assertEqual(out.decision.decision, DENY)
        self.assertIn(R.CONFIRMATION_MISMATCH, out.decision.codes())
        self.assertEqual(self.pay.balances["binh"], 0)

    def test_P4b_new_execution_id_needs_new_confirmation(self):
        c = self._confirmed(world.intent())
        out = self.gw.execute(world.intent(execution_id="exec-p-2"), "dlg-pay-1", c)
        self.assertEqual(out.decision.decision, DENY)

    def test_P5_same_execution_id_twice_effect_once(self):
        i = world.intent()
        c = self._confirmed(i)
        first = self.gw.execute(i, "dlg-pay-1", c)
        second = self.gw.execute(i, "dlg-pay-1", c)
        self.assertTrue(second.replayed)
        self.assertEqual(first.receipt.verification_status, VERIFIED)
        self.assertEqual(self.pay.balances["lam"], 600_000)
        self.assertEqual(len(self.pay.ledger), 1)
        self.assertEqual(self.pay.transfer_calls, 1)

    def test_P5b_timeout_then_retry_same_execution_id_effect_once(self):
        self.pay.timeout_after_commit_once = True
        i = world.intent()
        c = self._confirmed(i)
        first = self.gw.execute(i, "dlg-pay-1", c)
        self.assertEqual(first.receipt.execution_result["status"], "UNKNOWN")
        self.assertEqual(first.receipt.verification_status, UNVERIFIED)
        self.assertEqual(self.pay.balances["lam"], 600_000)   # it actually committed
        retry = self.gw.execute(i, "dlg-pay-1", c)
        self.assertTrue(retry.replayed)
        self.assertEqual(self.pay.transfer_calls, 1)          # provider execute never called again
        self.assertEqual(retry.receipt.verification_status, VERIFIED, retry.receipt.verification_reasons)
        self.assertEqual(self.pay.balances["lam"], 600_000)
        self.assertEqual(self.pay.balances["an"], 400_000)

    def test_P5c_core_guarantee_holds_even_if_provider_ignores_idempotency(self):
        self.pay.honor_idempotency = False
        self.pay.timeout_after_commit_once = True
        i = world.intent()
        c = self._confirmed(i)
        self.gw.execute(i, "dlg-pay-1", c)
        self.gw.execute(i, "dlg-pay-1", c)
        self.gw.execute(i, "dlg-pay-1", c)
        self.assertEqual(self.pay.balances["lam"], 600_000)

    def test_P6_unknown_security_critical_constraint_deny(self):
        core, pay, contract = world.build(contract_file="contract_v1_quantum.json")
        i = world.intent()
        out = core.gateway.execute(i, "dlg-pay-1")
        self.assertEqual(out.decision.decision, DENY)
        self.assertIn(R.UNSUPPORTED_CONSTRAINT, out.decision.codes())
        self.assertEqual(R.UNSUPPORTED_CONSTRAINT, "unsupported_security_constraint")
        self.assertEqual(pay.transfer_calls, 0)

    def test_P7_provider_reports_undeclared_effect_violation(self):
        self.pay.extra_effects = ["credit_line_may_be_used"]
        i = world.intent()
        out = self.gw.execute(i, "dlg-pay-1", self._confirmed(i))
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.UNDECLARED_EFFECT, out.receipt.codes())


if __name__ == "__main__":
    unittest.main()
