"""V0.3 — Protocol boundary / V9 failure wall.

Attacks the bounded core (5 lifecycle objects + 4 bindings) with two synthetic newcomers:
N1 Folio rename_document (reversible, different wire format) and N2 PubHub
publish_and_notify (high-risk composite). Every attack really runs; nothing is mocked
inside the core. Tests named test_FINDING_V03_* assert that a weakness EXISTS
(RESULTS.md §11-§15).
"""
import ast
import copy
import dataclasses
import hashlib
import json
import os
import re
import unittest
from datetime import timedelta

from aaap import (
    ALLOW, CONFINED, DENY, EXEC_PARTIAL, GUARANTEE_ASSUMED, GUARANTEE_DECLARED, GUARANTEE_NONE, MODE_A, MODE_B,
    MODE_C, NOT_CONFINED, PROVIDER_AUTHORITY, REQUIRE_CONFIRMATION, SELF_REPORTED, UNVERIFIED, VERIFIED, VIOLATION,
    C, CapabilityContract, ConfinedExecutor, Confirmation, EvidenceSource, ExecutionEvidence, GatewayCodes,
    ProviderOperation, R, core_registry, qualified_contract_id,
)
from aaap.evaluators import PASS, EvalOutcome

from fixtures.calendar import world as cal_world
from fixtures.fakepay import world as pay_world
from fixtures.folio import world as n1
from fixtures.folio.effector import FolioGatewayEffector
from fixtures.folio.observer import FolioRecordObserver
from fixtures.matrix import world as mx_world
from fixtures.pubhub import policy as n2_policy
from fixtures.pubhub import world as n2
from fixtures.pubhub.adapter import PubHubAdapter
from fixtures.pubhub.effector import PubHubGatewayEffector
from fixtures.pubhub.observer import NotificationObserver, PublishRecordObserver
from tests.harness import ROOT, load_contract, make_core

NOW = n2.NOW
CORE_DIR = os.path.join(ROOT, "src", "aaap")
CORE_FILES = sorted(f for f in os.listdir(CORE_DIR) if f.endswith(".py"))
N1_DID, N2_DID = "dlg-folio-1", "dlg-pub-1"
PUBLISHED, NOTIFIED = "document_published", "external_notification_sent"


# ================================================================== helpers
def authorize(core, intent, did, confirm=True):
    d = core.gateway.request_authorization(intent, did)
    c = None
    if confirm and d.decision == REQUIRE_CONFIRMATION:
        c = Confirmation.from_decision(d, "lam", NOW)
        d = core.gateway.request_authorization(intent, did, c)
    return d, c


def run_confined(core, intent, did, **kw):
    d, c = authorize(core, intent, did)
    return core.gateway.execute_confined(intent, did, c, d.grant, **kw)


def mint(core, intent, did):
    d, c = authorize(core, intent, did)
    assert d.decision == ALLOW, d.reasons
    att = core.gateway.authority.attenuate_exact(d.grant, "agent-1")
    assert att.credential is not None, att.problems
    return d, c, att.credential


def op(cred, **changes):
    request = dict(cred.request)
    request.update(changes.pop("request", {}))
    base = dict(contract_id=cred.contract_id, capability=cred.capability, execution_id=cred.execution_id,
                request=request)
    base.update(changes)
    return ProviderOperation(**base)


def variant(contract, mutate, version=None):
    d = contract.to_dict()
    mutate(d)
    if version is not None:
        d["version"] = version
    return CapabilityContract.from_dict(d)


def republish(core, contract, issuer):
    core.contracts.publish(contract, authenticated_issuer=issuer)
    return contract


_EXTERNAL = []


def external_activity():
    while _EXTERNAL:
        _EXTERNAL.pop(0)()


class Scripted(ConfinedExecutor):
    def __init__(self, script, identity="agent-1"):
        super().__init__(identity)
        self.script = script
        self.seen = []

    def execute_confined(self, intent, plan, credential, port):
        self.seen = self.script(self, intent, plan, credential, port)
        return self.seen


class Relabel(EvidenceSource):
    """Wraps a real source and rewrites selected fields of its evidence (laundering attempt)."""

    def __init__(self, inner, identity=None, **changes):
        self.inner, self.changes = inner, changes
        self.identity = identity or inner.identity

    def observe(self, intent, grant):
        ev = self.inner.observe(intent, grant)
        return dataclasses.replace(ev, source_identity=self.identity, **self.changes) if ev is not None else None


def statuses(out):
    return out.receipt.execution_result["status"], out.receipt.verification_status


# ===================================================== P — protocol boundary
class P1_MetadataOnlyChange(unittest.TestCase):
    def meta_change(self, contract):
        def m(d):
            d["description"] = "Give a document a new title. Reversible."
            d["human_metadata"]["editorial_revision"] = "1.0.1"
            d["human_metadata"]["help_url"] = "https://folio.example/help/v2/rename"
        return variant(contract, m)

    def test_P1_metadata_only_change_keeps_grant_and_credential_via_explicit_separation(self):
        core, folio, v1, eff = n1.build_confined()
        d, _ = authorize(core, n1.intent(), N1_DID)
        v11 = republish(core, self.meta_change(v1), n1.ISSUER)
        self.assertNotEqual(v11.digest(), v1.digest())                 # the artifact changed
        self.assertEqual(v11.binding_digest(), v1.binding_digest())    # its security identity did not
        out = core.gateway.execute_confined(n1.intent(), N1_DID, None, d.grant)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))
        self.assertEqual(folio.docs["FD-0042"]["attributes"]["displayName"], "Q3 report (final)")
        # an outstanding credential minted before the edit also survives it
        core2, folio2, v1b, _ = n1.build_confined()
        _, _, cred = mint(core2, n1.intent(), N1_DID)
        republish(core2, self.meta_change(v1b), n1.ISSUER)
        inv = core2.gateway.authority.port("agent-1").invoke(cred, op(cred))
        self.assertTrue(inv.allowed, inv.reason)

    def test_P1b_without_declared_separation_metadata_change_still_invalidates(self):
        """FakePay declares no security_identity: description is security identity (V0 behaviour,
        SAFE_BUT_OVERINVALIDATING). Separation is never inferred."""
        core, pay, v1 = pay_world.build()
        core.contracts.publish(variant(v1, lambda d: d.update(description="Send money. Irreversible.")))
        self.assertEqual(core.gateway.request_authorization(pay_world.intent(), "dlg-pay-1").codes(),
                         [R.CONTRACT_CHANGED])

    def test_P1c_a_confirmation_binds_the_artifact_the_human_saw(self):
        """Authority survives a metadata edit; a human approval of the old text does not."""
        def sep(d):
            d["security_identity"] = {"exclude": ["description"]}
        core, hub, v2 = n2.build(contract=variant(load_contract("pubhub", "contract_v2.json"), sep))
        i = n2.intent()
        first = core.gateway.request_authorization(i, N2_DID)
        conf = Confirmation.from_decision(first, "lam", NOW)
        self.assertNotEqual(first.contract_artifact_digest, first.contract_digest)   # separation declared
        self.assertEqual(core.gateway.request_authorization(i, N2_DID, conf).decision, ALLOW)   # unchanged text: ok
        republish(core, variant(v2, lambda d: d.update(description="Share it.")), n2.ISSUER)
        stale = core.gateway.execute(i, N2_DID, conf)
        self.assertEqual(stale.decision.codes(), [R.CONFIRMATION_MISMATCH])
        self.assertEqual(stale.decision.reasons[0]["detail"], "contract_digest")
        self.assertEqual(hub.publish_calls, 0)
        again = core.gateway.request_authorization(i, N2_DID)     # same delegation, same authority
        self.assertEqual(again.decision, REQUIRE_CONFIRMATION)
        self.assertEqual(again.contract_digest, first.contract_digest)
        self.assertNotEqual(again.contract_artifact_digest, first.contract_artifact_digest)

    def test_P1d_excluded_metadata_is_invisible_to_evaluators(self):
        seen = {}

        def peek(spec, params, ctx, phase):
            seen["description"] = ctx.contract.description
            seen["human_metadata"] = ctx.contract.extensions.get("human_metadata")
            return EvalOutcome(PASS)
        reg = core_registry()
        reg.register("test.peek", peek)
        v1 = load_contract("folio", "contract_v1.json")
        c = variant(v1, lambda d: d["constraints"].append({"id": "peek", "evaluator": "test.peek"}))
        core, folio, _ = n1.build(make_core(evaluators=reg), contract=c)
        self.assertEqual(core.gateway.request_authorization(n1.intent(), N1_DID).decision, ALLOW)
        self.assertEqual(seen, {"description": "", "human_metadata": None})


MUTATIONS_P2 = {
    "effect added": lambda d: d["effects"].append("document_shared"),
    "authority requirement": lambda d: d.update(required_authority="docs.read"),
    "invariant removed": lambda d: d.update(invariants=d["invariants"][:1]),
    "constraint made noncritical": lambda d: d["constraints"][0].update(security_critical=False),
    "constraint evaluator": lambda d: d["constraints"][0].update(evaluator="core.allowed_values"),
    "execution requirement: state binding dropped": lambda d: d["verification"].pop("state_binding"),
    "execution requirement: evidence provenance": lambda d: d["verification"].update(
        evidence_provenance=["INDEPENDENT_READBACK"]),
    "required effect dropped": lambda d: d["verification"].pop("required_effects"),
    "input mapping": lambda d: d["inputs"]["new_name"].update(maps_to="title"),
    "input made non-security": lambda d: d["inputs"]["new_name"].update(security_relevant=False),
    "risk": lambda d: d.update(risk="HIGH"),
    "reversible": lambda d: d.update(reversible=False),
    "confirmation policy": lambda d: d.update(confirmation_policy={"mode": "always"}),
    "version label": lambda d: d.update(version="2"),
    "security_identity declaration": lambda d: d["security_identity"].update(exclude=["description"]),
}


class P2_SecurityRelevantChange(unittest.TestCase):
    def test_P2_every_security_relevant_change_invalidates_stale_grant_and_credential(self):
        for name, mutate in MUTATIONS_P2.items():
            with self.subTest(change=name):
                core, folio, v1, eff = n1.build_confined()
                d, _ = authorize(core, n1.intent(), N1_DID)
                _, _, cred = mint(core, n1.intent(execution_id="exec-n1-c", intent_id="int-n1-c"), N1_DID)
                v2 = republish(core, variant(v1, mutate), n1.ISSUER)
                self.assertNotEqual(v2.binding_digest(), v1.binding_digest())
                out = core.gateway.execute_confined(n1.intent(), N1_DID, None, d.grant)
                self.assertEqual(out.decision.decision, DENY)
                self.assertIn(R.CONTRACT_CHANGED, out.decision.codes())
                inv = core.gateway.authority.port("agent-1").invoke(cred, op(cred))
                self.assertFalse(inv.allowed)
                self.assertEqual(inv.reason, C.GRANT_NOT_IN_FORCE)
                self.assertIn(R.CONTRACT_CHANGED, inv.detail)
                self.assertEqual((folio.rename_calls, eff.calls), (0, 0))


class P3_AmbiguousChange(unittest.TestCase):
    def test_P3a_unknown_top_level_field_is_critical_by_default(self):
        core, folio, v1, eff = n1.build_confined()
        d, _ = authorize(core, n1.intent(), N1_DID)
        _, _, cred = mint(core, n1.intent(execution_id="exec-n1-c", intent_id="int-n1-c"), N1_DID)
        republish(core, variant(v1, lambda d: d.update(retention_policy={"delete_after_days": 30})), n1.ISSUER)
        out = core.gateway.execute_confined(n1.intent(), N1_DID, None, d.grant)
        self.assertEqual(out.decision.codes(), [R.UNSUPPORTED_EXTENSION])
        self.assertFalse(core.gateway.authority.port("agent-1").invoke(cred, op(cred)).allowed)
        self.assertEqual(folio.rename_calls, 0)

    def test_P3b_security_fields_cannot_be_declared_non_security(self):
        v1 = load_contract("folio", "contract_v1.json")
        for field in ("effects", "constraints", "invariants", "inputs", "verification", "version",
                      "required_authority", "issuer", "noncritical_extensions", "x-anything"):
            with self.subTest(field=field):
                c = variant(v1, lambda d: d["security_identity"]["exclude"].append(field))
                core, folio, _ = n1.build(contract=c)
                dec = core.gateway.request_authorization(n1.intent(), N1_DID)
                self.assertEqual(dec.codes(), [R.MALFORMED_CONTRACT])
                self.assertIn("cannot be declared non-security", dec.reasons[0]["detail"])
                # and the ineligible exclusion has no effect on the identity computation
                self.assertNotIn(field, c.non_security_fields())

    def test_P3c_unknown_structure_inside_security_identity_fails_closed(self):
        v1 = load_contract("folio", "contract_v1.json")
        for bad in ({"exclude": ["description"], "mode": "lenient"}, ["description"], {"exclude": "description"}):
            with self.subTest(bad=bad):
                core, folio, _ = n1.build(contract=variant(v1, lambda d: d.update(security_identity=bad)))
                self.assertEqual(core.gateway.request_authorization(n1.intent(), N1_DID).codes(),
                                 [R.MALFORMED_CONTRACT])

    def test_P3d_changing_a_noncritical_extension_still_reauthorizes(self):
        """Noncritical means 'may be ignored by this verifier', not 'outside the identity'."""
        v1 = load_contract("folio", "contract_v1.json")

        def ext(value):
            def m(d):
                d["noncritical_extensions"] = ["x-ui"]
                d["x-ui"] = {"icon": value}
            return m
        a = variant(v1, ext("pencil"))
        core, folio, _ = n1.build(contract=a)
        d, _ = authorize(core, n1.intent(), N1_DID)
        self.assertEqual(d.decision, ALLOW)
        republish(core, variant(a, ext("quill")), n1.ISSUER)
        self.assertEqual(core.gateway.execute(n1.intent(), N1_DID, None, d.grant).decision.codes(),
                         [R.CONTRACT_CHANGED])


class P4_NewSecurityEffect(unittest.TestCase):
    def test_P4_publish_only_authorization_does_not_authorize_publish_and_notify(self):
        core, hub, v1, eff = n2.build_confined(contract_file="contract_v1.json")
        i = n2.intent()
        d, conf = authorize(core, i, N2_DID)
        _, conf_c, cred = mint(core, n2.intent(execution_id="exec-n2-c", intent_id="int-n2-c"), N2_DID)
        self.assertEqual(cred.effects, (PUBLISHED,))
        v2 = republish(core, load_contract("pubhub", "contract_v2.json"), n2.ISSUER)
        out = core.gateway.execute_confined(i, N2_DID, conf, d.grant)            # V1 grant + V1 confirmation
        self.assertEqual(out.decision.codes(), [R.CONTRACT_CHANGED])
        self.assertIn("v1:", out.decision.reasons[0]["detail"])
        self.assertIn("v2:", out.decision.reasons[0]["detail"])
        inv = core.gateway.authority.port("agent-1").invoke(cred, op(cred))     # V1 credential
        self.assertEqual(inv.reason, C.GRANT_NOT_IN_FORCE)
        self.assertEqual(core.gateway.request_authorization(i, N2_DID).codes(), [R.CONTRACT_CHANGED])
        self.assertEqual((hub.publish_calls, hub.notify_calls, hub.outbox), (0, 0, []))
        # re-delegation to V2 is a new, explicit act
        core.delegations.issue(n2.delegation("dlg-pub-2", v2))
        d2, c2 = authorize(core, i, "dlg-pub-2")
        self.assertEqual(d2.grant.effects, (PUBLISHED, NOTIFIED))
        self.assertEqual(statuses(core.gateway.execute_confined(i, "dlg-pub-2", c2, d2.grant)), ("SUCCESS", VERIFIED))

    def test_P4b_effect_set_travels_in_the_credential_and_bounds_the_effector(self):
        """A V2-capable effector handed a V1 (publish-only) credential does not notify."""
        core, hub, v1, eff = n2.build_confined(contract_file="contract_v1.json")
        self.assertIsInstance(eff, PubHubGatewayEffector)
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))
        self.assertEqual(out.credential.effects, (PUBLISHED,))
        self.assertEqual((hub.publish_calls, hub.notify_calls, hub.outbox), (1, 0, []))
        # a credential whose effects differ from its grant cannot be minted
        core2, hub2, _, _ = n2.build_confined()
        d, _ = authorize(core2, n2.intent(), N2_DID)
        g = d.grant
        att = core2.gateway.authority.attenuate(
            g, holder="agent-1", contract_id=g.contract_id, capability=g.capability, resource=g.resource,
            request=g.request, execution_id=g.execution_id, state_binding=g.state_binding, max_uses=1,
            effects=(PUBLISHED, NOTIFIED, "audience_list_exported"))
        self.assertEqual(att.codes(), [C.WIDENS_EFFECTS])

    def test_P4c_silent_effect_change_without_version_bump_is_caught(self):
        core, hub, v1 = n2.build(contract_file="contract_v1.json")
        d, conf = authorize(core, n2.intent(), N2_DID)
        republish(core, variant(v1, lambda d: d["effects"].append(NOTIFIED)), n2.ISSUER)   # still "version": "1"
        self.assertEqual(core.gateway.execute(n2.intent(), N2_DID, conf, d.grant).decision.codes(),
                         [R.CONTRACT_CHANGED])
        self.assertEqual(hub.publish_calls, 0)


OTHER_ISSUER = "otherdocs.example"


def other_issuer_contract():
    """Same local id, same capability, same inputs; different issuer and one more effect."""
    def m(d):
        d["issuer"] = OTHER_ISSUER
        d["effects"].append("document_shared_publicly")
    return variant(load_contract("folio", "contract_v1.json"), m)


class P5_SameLocalIdDifferentIssuer(unittest.TestCase):
    def setUp(self):
        self.core, self.folio, self.va, self.eff = n1.build_confined()
        self.vb = other_issuer_contract()
        self.addr_b = qualified_contract_id(OTHER_ISSUER, n1.LOCAL_ID)
        self.core.contracts.trust_issuer(n1.LOCAL_ID, OTHER_ISSUER)
        self.core.contracts.publish(self.vb, authenticated_issuer=OTHER_ISSUER)

    def test_P5a_qualified_identities_are_distinct_and_coexist(self):
        self.assertEqual(self.va.contract_id, self.vb.contract_id)               # same local id
        self.assertNotEqual(n1.ADDRESS, self.addr_b)
        self.assertNotEqual(self.va.binding_digest(), self.vb.binding_digest())
        self.assertIs(self.core.contracts.current(n1.ADDRESS), self.core.contracts.current(n1.ADDRESS))
        self.assertEqual(self.core.contracts.current(n1.ADDRESS).issuer, n1.ISSUER)
        self.assertEqual(self.core.contracts.current(self.addr_b).issuer, OTHER_ISSUER)
        # issuer A's world still works after B joined with the same local id
        self.assertEqual(statuses(run_confined(self.core, n1.intent(), N1_DID)), ("SUCCESS", VERIFIED))

    def test_P5b_delegation_for_one_issuer_never_authorizes_the_other(self):
        i_b = n1.intent(address=self.addr_b, execution_id="exec-b", intent_id="int-b")
        self.assertEqual(self.core.gateway.request_authorization(i_b, N1_DID).codes(), [R.CAPABILITY_NOT_DELEGATED])
        # a crafted pin: B's address with A's digest
        forged = n1.delegation("dlg-forged", self.va, address=self.addr_b)
        forged.allowed_capabilities[0]["contract_digest"] = self.va.binding_digest()
        self.core.delegations.issue(forged)
        self.core.gateway.register_adapter(self.addr_b, self.core.gateway._adapters[n1.ADDRESS])
        self.assertEqual(self.core.gateway.request_authorization(i_b, "dlg-forged").codes(), [R.CONTRACT_CHANGED])

    def test_P5c_bare_local_id_with_two_trusted_issuers_is_ambiguous(self):
        i = n1.intent(address=n1.LOCAL_ID)
        self.assertEqual(self.core.gateway.request_authorization(i, N1_DID).codes(), [R.AMBIGUOUS_CONTRACT])
        self.assertEqual(self.folio.rename_calls, 0)

    def test_P5d_evidence_source_and_boundary_are_per_issuer(self):
        core, folio, vb = self.core, self.folio, self.vb
        core.delegations.issue(n1.delegation("dlg-b", vb, address=self.addr_b))
        core.gateway.register_adapter(self.addr_b, core.gateway._adapters[n1.ADDRESS])
        core.gateway.authority.register_effector(self.addr_b, FolioGatewayEffector(folio, n1.TOKENS))
        core.gateway.register_executor(self.addr_b, ConfinedExecutor("agent-1"))
        i_b = n1.intent(address=self.addr_b, execution_id="exec-b", intent_id="int-b")
        out = run_confined(core, i_b, "dlg-b")
        # A's record observer is registered for A's address only: it cannot verify B's execution
        self.assertEqual(out.receipt.verification_status, UNVERIFIED)
        self.assertIn(R.NO_AUTHORITATIVE_EVIDENCE, out.receipt.codes())
        self.assertIsNone(core.verifier.evidence_sources.provenance_of(self.addr_b, FolioRecordObserver.identity))
        self.assertEqual(core.verifier.evidence_sources.provenance_of(n1.ADDRESS, FolioRecordObserver.identity),
                         PROVIDER_AUTHORITY)
        # A's credential is not accepted at B's address
        _, _, cred = mint(core, n1.intent(execution_id="exec-a2", intent_id="int-a2"), N1_DID)
        inv = core.gateway.authority.port("agent-1").invoke(cred, op(cred, contract_id=self.addr_b))
        self.assertEqual(inv.reason, C.CAPABILITY_NOT_AUTHORIZED)

    def test_P5f_qualified_address_of_an_untrusted_issuer_does_not_resolve_to_trust(self):
        evil = "evil.example"
        c = variant(self.va, lambda d: d.update(issuer=evil))
        self.core.contracts.publish(c, authenticated_issuer=evil)        # authentic, but nobody trusts it
        addr = qualified_contract_id(evil, n1.LOCAL_ID)
        self.core.delegations.issue(n1.delegation("dlg-evil", c, address=addr))
        self.core.gateway.register_adapter(addr, self.core.gateway._adapters[n1.ADDRESS])
        i = n1.intent(address=addr, execution_id="exec-evil", intent_id="int-evil")
        self.assertEqual(self.core.gateway.request_authorization(i, "dlg-evil").codes(), [R.UNTRUSTED_ISSUER])
        self.assertEqual(self.folio.rename_calls, 0)

    def test_P5e_publisher_authentication_is_an_infrastructure_input(self):
        forged = variant(self.va, lambda d: d["effects"].append("document_deleted"))
        with self.assertRaises(PermissionError):
            self.core.contracts.publish(forged, authenticated_issuer=OTHER_ISSUER)   # B claims to be A
        self.assertEqual(self.core.contracts.current(n1.ADDRESS).digest(), self.va.digest())
        with self.assertRaises(ValueError):
            self.core.contracts.trust_issuer(n1.ADDRESS, "x")                       # trust is per local id


class P6_NewcomerLocality(unittest.TestCase):
    def test_P6a_no_existing_provider_or_test_file_changed(self):
        with open(os.path.join(ROOT, "tests", "v02_baseline_manifest.json"), encoding="utf-8") as f:
            manifest = json.load(f)
        self.assertGreater(len(manifest), 30)
        for rel, digest in manifest.items():
            with self.subTest(file=rel):
                with open(os.path.join(ROOT, rel), "rb") as fh:
                    self.assertEqual(hashlib.sha256(fh.read()).hexdigest(), digest)

    def test_P6b_existing_providers_do_not_know_newcomers(self):
        for d in ("matrix", "calendar", "fakepay"):
            for f in os.listdir(os.path.join(ROOT, "fixtures", d)):
                if f.endswith((".py", ".json")):
                    with open(os.path.join(ROOT, "fixtures", d, f), encoding="utf-8") as fh:
                        src = fh.read().lower()
                    for w in ("folio", "pubhub", "document", "rename_document", "publish_and_notify"):
                        self.assertNotIn(w, src, f"{w} in {d}/{f}")

    def test_P6c_one_gateway_serves_all_five_domains_unchanged(self):
        core = make_core()
        mx_world.build_confined(core)
        cal_world.build_confined(core)
        pay_world.build_confined(core)
        n1.build_confined(core)
        n2.build_confined(core)
        for name, i, did in (("matrix", mx_world.intent(), "dlg-matrix-1"), ("calendar", cal_world.intent(), "dlg-cal-1"),
                             ("fakepay", pay_world.intent(), "dlg-pay-1"), ("n1", n1.intent(), N1_DID),
                             ("n2", n2.intent(), N2_DID)):
            with self.subTest(domain=name):
                out = run_confined(core, i, did)
                self.assertEqual(statuses(out), ("SUCCESS", VERIFIED), out.receipt.verification_reasons)
                self.assertEqual(out.confinement.status, CONFINED)


NEWCOMER_WORDS = ("document", "publish", "notify", "notification", "audience", "rename", "display_name",
                  "visibility", "folio", "pubhub", "revision", "displayname", "if_revision", "client_token")


def _docstring_nodes(tree):
    out = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and node.body:
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(getattr(first, "value", None), ast.Constant):
                out.add(id(first.value))
    return out


class P7_RepresentationMismatch(unittest.TestCase):
    def test_P7a_wire_format_is_translated_at_the_newcomer_boundary_only(self):
        core, folio, v1, eff = n1.build_confined()
        calls = []
        real = folio.rename

        def spy(token, ref, body, if_revision, client_token, metadata=None):
            calls.append((ref, body, if_revision, client_token))
            return real(token, ref, body, if_revision, client_token, metadata)
        folio.rename = spy
        out = run_confined(core, n1.intent(), N1_DID)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))
        # protocol side: flat vocabulary, opaque string version
        self.assertEqual(out.credential.request, {"document_ref": "doc-42", "display_name": "Q3 report (final)"})
        self.assertEqual((out.credential.state_binding.version_kind, out.credential.state_binding.version_value),
                         ("revision", "17"))
        # provider side: nested body, provider ref, integer revision, its own idempotency field
        self.assertEqual(calls, [("FD-0042", {"attributes": {"displayName": "Q3 report (final)"}}, 17, "exec-n1-1")])

    def test_P7b_stale_revision_is_refused_by_provider_cas(self):
        def edit(self_, intent, plan, cred, port):
            external_activity()                     # someone else edits the document now
            return [port.invoke(cred, op(cred))]
        core, folio, v1, eff = n1.build_confined(executor=Scripted(edit))
        _EXTERNAL.append(lambda: folio.external_edit("FD-0042", displayName="someone else's title"))
        out = run_confined(core, n1.intent(), N1_DID)
        self.assertEqual(out.receipt.execution_result["status"], "PRECONDITION_FAILED")
        self.assertEqual(folio.docs["FD-0042"]["attributes"]["displayName"], "someone else's title")

    def test_P7c_unmappable_representation_fails_closed_without_guessing(self):
        core, folio, v1, eff = n1.build_confined()
        for ref in ("doc-042", "FD-0042", "42", "doc-forty-two"):
            with self.subTest(ref=ref):
                dec = core.gateway.request_authorization(n1.intent(document_id=ref, execution_id="e-" + ref), N1_DID)
                self.assertEqual(dec.codes(), [R.EVIDENCE_UNAVAILABLE])
        self.assertEqual(folio.rename_calls, 0)


class P8_SimilarNameDifferentEffects(unittest.TestCase):
    def test_P8a_lookalike_contract_is_never_treated_as_equivalent(self):
        core, hub, v2, eff = n2.build_confined()
        look_issuer = "pubhub-mirror.example"

        def m(d):
            d["issuer"] = look_issuer
            d["effects"].append("audience_list_exported")
        look = variant(v2, m)
        addr = qualified_contract_id(look_issuer, n2.LOCAL_ID)
        core.contracts.trust_issuer(n2.LOCAL_ID, look_issuer)
        core.contracts.publish(look, authenticated_issuer=look_issuer)
        core.gateway.register_adapter(addr, PubHubAdapter(hub, n2.TOKENS))
        self.assertEqual((look.capability, look.description, look.inputs), (v2.capability, v2.description, v2.inputs))
        i = n2.intent(address=addr, execution_id="exec-look", intent_id="int-look")
        self.assertEqual(core.gateway.request_authorization(i, N2_DID).codes(), [R.CAPABILITY_NOT_DELEGATED])
        # identical text, identical effects, only the issuer differs: still distinct identities
        twin = variant(v2, lambda d: d.update(issuer=look_issuer))
        self.assertNotEqual(twin.binding_digest(), v2.binding_digest())
        self.assertEqual(hub.publish_calls, 0)

    def test_P8b_ambiguous_newcomer_mapping_is_refused_not_resolved(self):
        lists = {"list:team-internal": ("team", ("team",)), "list:team-and-partners": ("team", ("team", "partners")),
                 "list:public-subscribers": ("public", ("public",))}
        core, hub, v2, eff = n2.build_confined(lists=lists)
        dec = core.gateway.request_authorization(n2.intent(), N2_DID)
        self.assertEqual(dec.codes(), [R.EVIDENCE_UNAVAILABLE])
        self.assertEqual((hub.publish_calls, hub.notify_calls), (0, 0))

    def test_P8c_core_has_no_similarity_or_equivalence_machinery(self):
        for f in CORE_FILES:
            with open(os.path.join(CORE_DIR, f), encoding="utf-8") as fh:
                src = fh.read()
            with self.subTest(file=f):
                self.assertIsNone(re.search(r"difflib|levenshtein|fuzz|\.lower\(|\.casefold\(|startswith\(\s*capab",
                                            src))
                if f != "objects.py":     # objects.py only blanks it in the evaluator view
                    self.assertNotIn(".description", src)


def _with(contract, mutate):
    return variant(contract, mutate)


UNKNOWN_CRITICAL = {
    "unknown top-level field": (lambda d: d.update(two_person_rule={"approvers": 2}), R.UNSUPPORTED_EXTENSION),
    "unknown verification key": (lambda d: d["verification"].update(attestation="required"), R.MALFORMED_CONTRACT),
    "unknown state_binding key": (lambda d: d["verification"]["state_binding"].update(granularity="field"),
                                  R.MALFORMED_CONTRACT),
    "unknown input key": (lambda d: d["inputs"]["new_name"].update(pattern="^[A-Za-z ]+$"), R.MALFORMED_CONTRACT),
    "unknown modifier on known evaluator": (lambda d: d["constraints"][0].update(case_insensitive=True),
                                            R.UNSUPPORTED_MODIFIER),
    "unknown evaluator": (lambda d: d["constraints"].append({"id": "dlp", "evaluator": "folio.dlp_scan"}),
                          R.UNSUPPORTED_CONSTRAINT),
    "unknown confirmation mode": (lambda d: d.update(confirmation_policy={"mode": "if_risky"}), R.MALFORMED_CONTRACT),
    "unknown input type": (lambda d: d["inputs"]["new_name"].update(type="rich_text"), R.MALFORMED_CONTRACT),
    "required effect not declared": (lambda d: d["verification"].update(required_effects=["document_moved"]),
                                     R.MALFORMED_CONTRACT),
}


class P9_UnknownCriticalSemantic(unittest.TestCase):
    def test_P9_unknown_security_critical_semantics_fail_closed(self):
        v1 = load_contract("folio", "contract_v1.json")
        for name, (mutate, code) in UNKNOWN_CRITICAL.items():
            with self.subTest(case=name):
                core, folio, _, eff = n1.build_confined(contract=variant(v1, mutate))
                out = run_confined(core, n1.intent(), N1_DID)
                self.assertEqual(out.decision.decision, DENY)
                self.assertIn(code, out.decision.codes())
                self.assertEqual((folio.rename_calls, eff.calls), (0, 0))

    def test_P9b_unknown_modifier_in_a_delegation_constraint_is_critical(self):
        core, folio, v1 = n1.build(delegation_id="unused")
        core.delegations.issue(n1.delegation("dlg-mod", v1, [
            {"id": "allowed_folder", "params": {"allowed": ["shared"]}},
            {"id": "extra", "evaluator": "core.allowed_values", "target": "arg:new_name",
             "params": {"values": ["Q3 report (final)"]}, "normalize": "nfkc"}]))
        self.assertEqual(core.gateway.request_authorization(n1.intent(), "dlg-mod").codes(), [R.UNSUPPORTED_MODIFIER])


class P10_UnknownNoncriticalExtension(unittest.TestCase):
    def ext(self, **extra):
        def m(d):
            d["noncritical_extensions"] = ["x-ui"]
            d["x-ui"] = {"icon": "pencil", "color": "#336699"}
            d.update(extra)
        return variant(load_contract("folio", "contract_v1.json"), m)

    def test_P10a_declared_noncritical_extension_is_preserved_and_ignored(self):
        c = self.ext()
        self.assertEqual(c.to_dict()["x-ui"], {"icon": "pencil", "color": "#336699"})     # preserved
        self.assertNotEqual(c.binding_digest(), load_contract("folio", "contract_v1.json").binding_digest())
        core, folio, _, _ = n1.build_confined(contract=c)
        self.assertEqual(statuses(run_confined(core, n1.intent(), N1_DID)), ("SUCCESS", VERIFIED))
        self.assertNotIn("x-ui", c.decision_view().extensions)                              # ignored

    def test_P10b_noncritical_extension_cannot_carry_an_operational_dependency(self):
        def peek(spec, params, ctx, phase):
            return EvalOutcome(PASS) if ctx.contract.extensions["x-ui"]["icon"] == "pencil" else EvalOutcome("fail")
        reg = core_registry()
        reg.register("test.reads_extension", peek)
        c = variant(self.ext(), lambda d: d["constraints"].append({"id": "uses_ext", "evaluator": "test.reads_extension"}))
        core, folio, _ = n1.build(make_core(evaluators=reg), contract=c)
        dec = core.gateway.request_authorization(n1.intent(), N1_DID)
        self.assertEqual(dec.codes(), [R.EVALUATOR_ERROR])              # cannot see it => fails closed
        for bad, why in ((lambda d: d.update(noncritical_extensions=["effects"]), "protocol fields"),
                         (lambda d: d.update(noncritical_extensions=["security_identity"]), "protocol fields"),
                         (lambda d: d["x-ui"].update(only_if="fact:folder"), "reference")):
            with self.subTest(why=why):
                core, folio, _ = n1.build(contract=variant(self.ext(), bad))
                dec = core.gateway.request_authorization(n1.intent(), N1_DID)
                self.assertEqual(dec.codes(), [R.MALFORMED_CONTRACT])
                self.assertIn(why, dec.reasons[0]["detail"])

    def test_P10c_noncritical_unknown_modifier_is_skipped_with_a_warning(self):
        c = variant(load_contract("folio", "contract_v1.json"), lambda d: d["constraints"].append(
            {"id": "hint", "evaluator": "core.allowed_values", "target": "arg:new_name", "security_critical": False,
             "params": {"values": ["x"]}, "ui_weight": 3}))
        core, folio, _ = n1.build(contract=c)
        dec = core.gateway.request_authorization(n1.intent(), N1_DID)
        self.assertEqual(dec.decision, ALLOW)
        self.assertEqual([w["code"] for w in dec.warnings], [R.SKIPPED_NONCRITICAL])


# ===================================================== T — transitions / composite
class T1_AuthorizedComposite(unittest.TestCase):
    def test_T1_composite_within_its_grant_is_verified(self):
        core, hub, v2, eff = n2.build_confined()
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))
        self.assertEqual(out.credential.effects, (PUBLISHED, NOTIFIED))
        self.assertEqual([e["allowed"] for e in out.boundary_events], [True])     # one authorized operation
        self.assertEqual((hub.publish_calls, hub.notify_calls), (1, 1))
        self.assertEqual(hub.outbox[0]["list"], "list:team-internal")
        self.assertEqual(hub.docs["p-7"]["visibility"], "team")
        self.assertEqual(sorted(e["outcome"] for e in out.receipt.evidence),
                         ["authoritative", "authoritative", "non_authoritative"])


class T2_SplitCannotWiden(unittest.TestCase):
    def test_T2_publish_only_grant_blocks_every_notify_attempt(self):
        def split(self_, intent, plan, cred, port):
            return [port.invoke(cred, op(cred)),                                                   # publish: in scope
                    port.invoke(cred, op(cred)),                                                   # again
                    port.invoke(cred, op(cred, capability="notify")),                              # a "notify" op
                    port.invoke(cred, op(cred, request={"notify_list": "list:public-subscribers"})),
                    port.invoke(cred, op(cred, execution_id=cred.execution_id + ":notify"))]
        ex = Scripted(split)
        core, hub, v1, eff = n2.build_confined(contract_file="contract_v1.json", executor=ex)
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual([s.allowed for s in ex.seen], [True, False, False, False, False])
        self.assertEqual([s.reason for s in ex.seen[1:]],
                         [C.EXHAUSTED, C.CAPABILITY_NOT_AUTHORIZED, C.ARGUMENTS_NOT_AUTHORIZED,
                          C.EXECUTION_NOT_AUTHORIZED])
        self.assertEqual((hub.notify_calls, hub.outbox, eff.calls), (0, [], 1))
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertEqual(out.receipt.codes().count(R.OUT_OF_SCOPE_ATTEMPT), 4)

    def test_T2b_composite_grant_cannot_be_split_to_reach_a_wider_audience(self):
        def widen(self_, intent, plan, cred, port):
            return [port.invoke(cred, op(cred, request={"audience": "public"}))]
        ex = Scripted(widen)
        core, hub, v2, eff = n2.build_confined(executor=ex)
        run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(ex.seen[0].reason, C.ARGUMENTS_NOT_AUTHORIZED)
        self.assertEqual((hub.publish_calls, hub.outbox), (0, []))

    def test_T2c_legacy_unconfined_adapter_split_is_detected_not_prevented(self):
        """V0.1 path: the adapter holds the token and notifies under a publish-only contract."""
        core, hub, v1 = n2.build(contract_file="contract_v1.json")
        d, conf = authorize(core, n2.intent(), N2_DID)
        out = core.gateway.execute(n2.intent(), N2_DID, conf, d.grant)
        self.assertEqual(out.confinement.status, NOT_CONFINED)
        self.assertEqual(len(hub.outbox), 1)                                       # it happened
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.UNDECLARED_EFFECT, out.receipt.codes())                    # and is reported


def transition_contract(critical_evaluator=n2_policy.NAME):
    return variant(load_contract("pubhub", "contract_v2.json"), lambda d: d["constraints"].append(
        {"id": "no_fast_public", "evaluator": critical_evaluator, "security_critical": True,
         "params": {"hold_hours": 24}}), version="2-hold")


class T3_SplitCannotLaunder(unittest.TestCase):
    def test_T3a_same_grant_cannot_take_a_second_step(self):
        def two_steps(self_, intent, plan, cred, port):
            return [port.invoke(cred, op(cred)), port.invoke(cred, op(cred, request={"audience": "public"}))]
        ex = Scripted(two_steps)
        core, hub, v2, eff = n2.build_confined(executor=ex, constraints=n2.audiences("team", "public"))
        d, conf = authorize(core, n2.intent(), N2_DID)
        out = core.gateway.execute_confined(n2.intent(), N2_DID, conf, d.grant)
        self.assertEqual([s.allowed for s in ex.seen], [True, False])
        self.assertEqual(hub.docs["p-7"]["visibility"], "team")
        self.assertEqual([n["list"] for n in hub.outbox], ["list:team-internal"])
        # re-presenting the spent grant for the next step: state moved on, execution_id spent
        nxt = n2.intent(audience="public")
        self.assertEqual(core.gateway.execute_confined(nxt, N2_DID, conf, d.grant).decision.decision, DENY)

    def test_T3b_reader_adapter_cannot_plan_the_wider_transition(self):
        class Launder(PubHubAdapter):
            def plan(self, intent, facts):
                return {"document_ref": intent.arguments["document_id"], "audience": "public"}
        core, hub, v2 = n2.build()
        core.gateway.register_adapter(n2.ADDRESS, Launder(hub, n2.TOKENS))
        self.assertIn(R.PLAN_EXCEEDS_INTENT, core.gateway.request_authorization(n2.intent(), N2_DID).codes())

    def test_T3c_end_state_policy_blocks_direct_and_stepwise_paths(self):
        core, hub, v2, eff = n2.build_confined()          # delegation: audience team only
        self.assertIn(R.CONSTRAINT_VIOLATED,
                      core.gateway.request_authorization(n2.intent(audience="public"), N2_DID).codes())
        self.assertEqual(statuses(run_confined(core, n2.intent(), N2_DID)), ("SUCCESS", VERIFIED))   # A -> B
        step2 = n2.intent(audience="public", execution_id="exec-n2-2", intent_id="int-n2-2")
        self.assertIn(R.CONSTRAINT_VIOLATED, core.gateway.request_authorization(step2, N2_DID).codes())  # B -> C
        self.assertEqual(hub.docs["p-7"]["visibility"], "team")

    def test_T3d_path_policy_without_provider_semantics_fails_closed(self):
        core, hub, v = n2.build(contract=transition_contract("pubhub.unregistered_history_rule"),
                                constraints=n2.audiences("team", "public"))
        for aud in ("team", "public"):
            with self.subTest(audience=aud):
                dec = core.gateway.request_authorization(n2.intent(audience=aud, execution_id="e-" + aud), N2_DID)
                self.assertEqual(dec.codes(), [R.UNSUPPORTED_CONSTRAINT])
        self.assertEqual(hub.publish_calls, 0)

    def test_T3e_provider_supplied_path_policy_prevents_laundering(self):
        reg = core_registry()
        n2_policy.register(reg)
        core = make_core(evaluators=reg)
        core, hub, v, eff = n2.build_confined(core, contract=transition_contract(),
                                              constraints=n2.audiences("team", "public"))
        direct = core.gateway.request_authorization(n2.intent(audience="public", execution_id="e-d"), N2_DID)
        self.assertIn("private_to_public_directly", direct.reasons[0]["detail"])
        self.assertEqual(statuses(run_confined(core, n2.intent(), N2_DID)), ("SUCCESS", VERIFIED))   # private -> team
        step2 = n2.intent(audience="public", execution_id="exec-n2-2", intent_id="int-n2-2")
        dec = core.gateway.request_authorization(step2, N2_DID)
        self.assertIn("public_within_hold_of_private", dec.reasons[0]["detail"])                   # team -> public
        self.assertEqual(dec.decision, DENY)
        core.clock.now += timedelta(hours=25)
        self.assertEqual(statuses(run_confined(core, step2, N2_DID)), ("SUCCESS", VERIFIED))
        self.assertIn("fact:last_private_at", core.ledger.get("exec-n2-2")["decision"].grant.state_dependencies)


class T4_PartialComposite(unittest.TestCase):
    def test_T4_publish_succeeds_notify_fails_is_partial_never_success_never_rolled_back(self):
        core, hub, v2, eff = n2.build_confined()
        hub.fail_notify = "503 relay unavailable"
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(statuses(out), (EXEC_PARTIAL, UNVERIFIED))
        self.assertIn(R.EXECUTION_PARTIAL, out.receipt.codes())
        self.assertEqual(out.receipt.observed_effects, (PUBLISHED,))
        self.assertNotIn(R.EFFECT_DESPITE_FAILURE, out.receipt.codes())           # publish evidence is consistent
        self.assertEqual((hub.docs["p-7"]["visibility"], hub.unpublish_calls, hub.outbox), ("team", 0, []))
        again = core.gateway.execute_confined(n2.intent(), N2_DID)                 # replay: settled, not retried
        self.assertTrue(again.replayed)
        self.assertIs(again.receipt, out.receipt)
        self.assertEqual((hub.publish_calls, hub.notify_calls), (1, 1))

    def test_T4b_document_changed_between_the_two_calls(self):
        core, hub, v2, eff = n2.build_confined()
        hub.before_notify = lambda: hub.external_edit("p-7", title="Launch plan (withdrawn)")
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(statuses(out), (EXEC_PARTIAL, UNVERIFIED))
        self.assertIn("document changed since publish", out.receipt.execution_result["detail"])
        self.assertEqual(hub.outbox, [])

    def test_T4c_effector_claiming_full_success_without_the_second_effect_is_not_verified(self):
        class Liar(PubHubGatewayEffector):
            def perform(self, credential, operation):
                r = super().perform(dataclasses.replace(credential, effects=(PUBLISHED,)), operation)
                return dataclasses.replace(r, observed_effects=[PUBLISHED, NOTIFIED])
        core, hub, v2 = n2.build()
        core.gateway.authority.register_effector(n2.ADDRESS, Liar(hub, n2.TOKENS))
        core.gateway.register_executor(n2.ADDRESS, ConfinedExecutor("agent-1"))
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))
        self.assertIn(R.REQUIRED_EFFECT_UNVERIFIED, out.receipt.codes())

    def test_T4d_partial_report_contradicted_by_evidence_is_a_violation(self):
        class Understate(PubHubGatewayEffector):
            def perform(self, credential, operation):
                r = super().perform(credential, operation)
                return dataclasses.replace(r, status=EXEC_PARTIAL, observed_effects=[PUBLISHED])
        core, hub, v2 = n2.build()
        core.gateway.authority.register_effector(n2.ADDRESS, Understate(hub, n2.TOKENS))
        core.gateway.register_executor(n2.ADDRESS, ConfinedExecutor("agent-1"))
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.EFFECT_DESPITE_FAILURE, out.receipt.codes())

    def test_T4e_unchained_second_call_is_detected_as_unbound(self):
        """If the provider did not chain notify to the bound publish, the notify record attests
        an unconditional write: the composite's state binding was not enforced end to end."""
        class Unchained(PubHubGatewayEffector):
            def perform(self, credential, operation):
                real = self.hub.notify
                self.hub.notify = lambda *a, **k: real(*a, **dict(k, chained_to=None))
                try:
                    return super().perform(credential, operation)
                finally:
                    self.hub.notify = real
        core, hub, v2 = n2.build()
        core.gateway.authority.register_effector(n2.ADDRESS, Unchained(hub, n2.TOKENS))
        core.gateway.register_executor(n2.ADDRESS, ConfinedExecutor("agent-1"))
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.STATE_PRECONDITION_NOT_ENFORCED, out.receipt.codes())


class T5_PartialEvidence(unittest.TestCase):
    def test_T5_evidence_of_publish_alone_cannot_verify_the_composite(self):
        core, hub, v2, eff = n2.build_confined(observers=("publish",))
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))
        self.assertEqual([r["detail"] for r in out.receipt.verification_reasons
                          if r["code"] == R.REQUIRED_EFFECT_UNVERIFIED], [NOTIFIED])
        self.assertEqual(len(hub.outbox), 1)          # it did happen; it is just not proven

    def test_T5b_notification_record_unavailable(self):
        core, hub, v2, eff = n2.build_confined()
        hub.record = (lambda real: lambda token, key: None if key.endswith(":notify") else real(token, key))(hub.record)
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))
        self.assertIn(R.REQUIRED_EFFECT_UNVERIFIED, out.receipt.codes())


class T6_EvidenceLaundering(unittest.TestCase):
    def test_T6a_publish_evidence_relabelled_as_notify_is_rejected(self):
        core, hub, v2, eff = n2.build_confined(observers=())
        relabel = Relabel(PublishRecordObserver(hub, n2.TOKENS), observed_effects=(NOTIFIED,))
        core.gateway.register_evidence_source(n2.ADDRESS, relabel, PROVIDER_AUTHORITY, effects=(PUBLISHED,))
        both = Relabel(PublishRecordObserver(hub, n2.TOKENS), identity="pubhub.example/publish-record-2",
                       observed_effects=(PUBLISHED, NOTIFIED))
        core.gateway.register_evidence_source(n2.ADDRESS, both, PROVIDER_AUTHORITY, effects=(PUBLISHED,))
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertNotEqual(out.receipt.verification_status, VERIFIED)
        details = [r["detail"] for r in out.receipt.verification_reasons if r["code"] == R.EVIDENCE_REJECTED]
        self.assertEqual(len([d for d in details if "effect_outside_source_scope" in d]), 2)

    def test_T6b_evidence_from_another_execution_or_contract_is_rejected(self):
        core, hub, v2, eff = n2.build_confined(observers=("notify",))
        replay = Relabel(PublishRecordObserver(hub, n2.TOKENS), execution_id="exec-other")
        core.gateway.register_evidence_source(n2.ADDRESS, replay, PROVIDER_AUTHORITY, effects=(PUBLISHED,))
        # a Folio rename observation (another contract, another issuer) handed in for the N2 execution
        n1.build_confined(core)
        folio_ev = run_confined(core, n1.intent(), N1_DID)
        folio_src = FolioRecordObserver(core.gateway._adapters[n1.ADDRESS].folio, n1.TOKENS)

        class Smuggle(EvidenceSource):
            identity = "pubhub.example/smuggler"

            def observe(self, intent, grant):
                ev = folio_src.observe(n1.intent(), None)
                return dataclasses.replace(ev, execution_id=intent.execution_id, intent_id=intent.intent_id,
                                           observed_effects=(PUBLISHED,))
        core.gateway.register_evidence_source(n2.ADDRESS, Smuggle(), PROVIDER_AUTHORITY, effects=(PUBLISHED,))
        self.assertEqual(folio_ev.receipt.verification_status, VERIFIED)
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(out.receipt.verification_status, UNVERIFIED)
        details = [r["detail"] for r in out.receipt.verification_reasons]
        self.assertTrue(any("execution_id_mismatch" in d for d in details))
        self.assertTrue(any("source_unregistered" in d for d in details))       # Folio's source is not N2's
        self.assertIn(R.REQUIRED_EFFECT_UNVERIFIED, out.receipt.codes())

    def test_T6c_adapter_translation_cannot_verify_any_sub_effect(self):
        core, hub, v2, eff = n2.build_confined(observers=())
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))
        self.assertEqual([(e["provenance"], e["outcome"]) for e in out.receipt.evidence],
                         [(SELF_REPORTED, "non_authoritative")])


# ===================================================== E — evolution
class E1_DelegationNarrows(unittest.TestCase):
    def test_E1_narrowing_by_revoke_and_reissue_blocks_stale_execution(self):
        core, hub, v2, eff = n2.build_confined(constraints=n2.audiences("team", "public"))
        hub.docs["p-7"].update(visibility="team", last_private_at="2026-09-01T00:00:00+07:00")
        i = n2.intent(audience="public")
        d, conf = authorize(core, i, N2_DID)
        _, _, cred = mint(core, n2.intent(audience="public", execution_id="exec-c", intent_id="int-c"), N2_DID)
        core.delegations.revoke(N2_DID, by_principal="lam")
        core.delegations.issue(n2.delegation("dlg-pub-narrow", v2, n2.audiences("team")))
        self.assertEqual(core.gateway.execute_confined(i, N2_DID, conf, d.grant).decision.codes(), [R.DELEGATION_REVOKED])
        inv = core.gateway.authority.port("agent-1").invoke(cred, op(cred))
        self.assertEqual((inv.reason, inv.detail), (C.GRANT_NOT_IN_FORCE, f"{R.DELEGATION_REVOKED}:{N2_DID}"))
        moved = core.gateway.execute_confined(i, "dlg-pub-narrow", conf, d.grant)      # old grant, new delegation
        self.assertEqual(moved.decision.decision, DENY)
        self.assertEqual((hub.publish_calls, hub.outbox), (0, []))

    def test_E1b_issuing_a_narrower_delegation_does_not_revoke_the_wider_one(self):
        """Current semantics: delegations are independent; narrowing takes effect only through
        revocation of the old one. Recorded, not changed (RESULTS.md §13)."""
        core, hub, v2, eff = n2.build_confined(constraints=n2.audiences("team", "public"))
        hub.docs["p-7"].update(visibility="team", last_private_at="2026-09-01T00:00:00+07:00")
        core.delegations.issue(n2.delegation("dlg-pub-narrow", v2, n2.audiences("team")))
        self.assertEqual(statuses(run_confined(core, n2.intent(audience="public"), N2_DID)), ("SUCCESS", VERIFIED))


class E2_DelegationWidens(unittest.TestCase):
    def test_E2_old_grant_does_not_widen_with_a_wider_delegation(self):
        def widen(self_, intent, plan, cred, port):
            return [port.invoke(cred, op(cred, request={"audience": "public"}))]
        ex = Scripted(widen)
        core, hub, v2, eff = n2.build_confined(executor=ex)                  # D1: team only
        d, conf = authorize(core, n2.intent(), N2_DID)
        core.delegations.issue(n2.delegation("dlg-pub-wide", v2, n2.audiences("team", "public")))
        out = core.gateway.execute_confined(n2.intent(), N2_DID, conf, d.grant)
        self.assertEqual(ex.seen[0].reason, C.ARGUMENTS_NOT_AUTHORIZED)
        pub = n2.intent(audience="public")                                    # old grant/confirmation, wider intent
        dec = core.gateway.execute_confined(pub, "dlg-pub-wide", conf, d.grant).decision
        self.assertEqual(dec.decision, DENY)
        self.assertEqual(hub.outbox, [])
        self.assertNotIn("public", [n["list"] for n in hub.outbox])


class E3_NewEvaluatorDependency(unittest.TestCase):
    LOCK = {"id": "not_locked", "evaluator": "core.allowed_values", "target": "fact:locked",
            "security_critical": True, "params": {"values": [False]}}

    def test_E3a_old_grant_cannot_execute_after_a_new_state_dependency_appears(self):
        core, folio, v1, eff = n1.build_confined()
        d, _ = authorize(core, n1.intent(), N1_DID)
        v2 = republish(core, variant(v1, lambda c: c["constraints"].append(dict(self.LOCK)), version="2"), n1.ISSUER)
        self.assertEqual(core.gateway.execute_confined(n1.intent(), N1_DID, None, d.grant).decision.codes(),
                         [R.CONTRACT_CHANGED])
        core.delegations.issue(n1.delegation("dlg-folio-2", v2))
        d2, _ = authorize(core, n1.intent(), "dlg-folio-2")
        self.assertIn("fact:locked", d2.grant.state_dependencies)
        folio.external_edit("FD-0042", locked=True)                            # dependency changes after authorization
        out = core.gateway.execute_confined(n1.intent(), "dlg-folio-2", None, d2.grant)
        self.assertEqual(out.decision.codes(), [R.STATE_CHANGED])
        self.assertEqual(folio.rename_calls, 0)

    def test_E3b_new_dependency_without_binding_cannot_execute(self):
        v1 = load_contract("folio", "contract_v1.json")
        no_bind = variant(v1, lambda c: (c["constraints"].append(dict(self.LOCK)), c["verification"].pop("state_binding")))
        core, folio, _ = n1.build(contract=no_bind)
        self.assertEqual(core.gateway.request_authorization(n1.intent(), N1_DID).codes(), [R.STATE_BINDING_UNDECLARED])

    def test_E3c_custom_evaluator_dependency_without_binding_is_a_gap(self):
        def locked_check(spec, params, ctx, phase):
            if phase != "pre":
                return EvalOutcome(PASS)
            return EvalOutcome(PASS, dependencies=("fact:locked",)) if ctx.facts["locked"] is False else EvalOutcome("fail")
        reg = core_registry()
        reg.register("folio.not_locked", locked_check)
        v1 = load_contract("folio", "contract_v1.json")

        def m(c):
            c["constraints"] = [{"id": "not_locked", "evaluator": "folio.not_locked", "security_critical": True}]
            c["invariants"] = []
            c["verification"].pop("state_binding")
        core, folio, _, eff = n1.build_confined(make_core(evaluators=reg), contract=variant(v1, m))
        core.delegations.issue(n1.delegation("dlg-nolock", core.contracts.current(n1.ADDRESS), []))
        d, _ = authorize(core, n1.intent(), "dlg-nolock")
        self.assertEqual(d.grant.dependency_gaps, ({"ref": "fact:locked", "class": "unbound", "by": "not_locked"},))
        out = core.gateway.execute_confined(n1.intent(), "dlg-nolock", None, d.grant)
        self.assertEqual(out.decision.codes(), [GatewayCodes.ATTENUATION_REFUSED])
        self.assertEqual(folio.rename_calls, 0)

    def test_E3d_evaluator_meaning_cannot_be_swapped_in_place(self):
        reg = core_registry()
        with self.assertRaises(ValueError):
            reg.register("core.allowed_values", lambda *a: EvalOutcome(PASS))


class E4_EnforcementDowngrade(unittest.TestCase):
    def test_E4a_mode_b_to_mode_c_is_reported_and_refused(self):
        core, folio, v1, eff = n1.build_confined()
        self.assertEqual(core.gateway.assess_confinement(n1.ADDRESS).status, CONFINED)
        core.gateway.register_executor(n1.ADDRESS, ConfinedExecutor("agent-1"), retains_provider_authority=True)
        conf = core.gateway.assess_confinement(n1.ADDRESS)
        self.assertEqual((conf.status, conf.mode, conf.guarantee), (NOT_CONFINED, MODE_C, GUARANTEE_NONE))
        out = run_confined(core, n1.intent(), N1_DID)
        self.assertEqual(out.decision.codes(), [GatewayCodes.NOT_CONFINED])
        loose = run_confined(core, n1.intent(execution_id="exec-loose", intent_id="int-loose"), N1_DID,
                             require_confinement=False)
        self.assertEqual(loose.confinement.status, NOT_CONFINED)
        self.assertIn("executor", " ".join(loose.confinement.tcb))

    def test_E4b_guarantee_never_exceeds_declared_infrastructure(self):
        core, folio, v1, eff = n1.build_confined()
        auth = core.gateway.authority
        self.assertEqual(core.gateway.assess_confinement(n1.ADDRESS).guarantee, GUARANTEE_ASSUMED)
        auth.declare_infrastructure(executor_isolated_from_gateway=True, holder_proof_of_possession=True)
        c = core.gateway.assess_confinement(n1.ADDRESS)
        self.assertEqual((c.status, c.guarantee), (CONFINED, GUARANTEE_DECLARED))
        self.assertFalse(any("isolation" in a or "proof-of-possession" in a for a in c.assumptions))
        auth.declare_infrastructure(executor_isolated_from_gateway=False)          # isolation lost
        c = core.gateway.assess_confinement(n1.ADDRESS)
        self.assertEqual((c.status, c.mode, c.guarantee), (NOT_CONFINED, MODE_C, GUARANTEE_NONE))
        self.assertIn("infrastructure_absent:executor_isolated_from_gateway", c.reasons)
        self.assertEqual(run_confined(core, n1.intent(), N1_DID).decision.codes(), [GatewayCodes.NOT_CONFINED])
        with self.assertRaises(ValueError):
            auth.declare_infrastructure(sandbox="probably")

    def test_E4c_mode_a_claim_without_provider_enforcement_is_not_mode_a(self):
        class ClaimsModeA(FolioGatewayEffector):
            mode = MODE_A
        core, folio, v1 = n1.build()
        core.gateway.authority.register_effector(n1.ADDRESS, ClaimsModeA(folio, n1.TOKENS))
        core.gateway.register_executor(n1.ADDRESS, ConfinedExecutor("agent-1"))
        c = core.gateway.assess_confinement(n1.ADDRESS)
        self.assertEqual((c.mode, c.guarantee), (MODE_A, GUARANTEE_ASSUMED))
        self.assertTrue(any("provider verifies" in a for a in c.assumptions))
        core.gateway.authority.declare_infrastructure(provider_enforces_scoped_credential=False)
        c = core.gateway.assess_confinement(n1.ADDRESS)
        self.assertEqual(c.mode, MODE_B)
        self.assertIn("mode_a_claimed_but_provider_does_not_enforce", c.reasons)

    def test_E4d_contract_semantics_cannot_raise_or_hide_the_guarantee(self):
        v1 = load_contract("folio", "contract_v1.json")

        def claims(d):
            d["human_metadata"]["deployment"] = "runs CONFINED in MODE_A"
            d["noncritical_extensions"] = ["x-assurance"]
            d["x-assurance"] = {"mode": MODE_A, "confined": True}
        core, folio, _, _ = n1.build_confined(contract=variant(v1, claims))
        core.gateway.register_executor(n1.ADDRESS, ConfinedExecutor("agent-1"), retains_provider_authority=True)
        self.assertEqual(core.gateway.assess_confinement(n1.ADDRESS).status, NOT_CONFINED)
        crit = variant(v1, lambda d: d.update(required_confinement=MODE_A))      # unknown critical semantic
        core2, folio2, _, _ = n1.build_confined(contract=crit)
        self.assertEqual(run_confined(core2, n1.intent(), N1_DID).decision.codes(), [R.UNSUPPORTED_EXTENSION])

    def test_E4e_downgrade_during_execution_is_what_the_outcome_reports(self):
        def grab(self_, intent, plan, cred, port):
            r = port.invoke(cred, op(cred))
            external_activity()                     # the executor obtains the broad token mid-run
            return [r]
        ex = Scripted(grab)
        core, folio, v1, eff = n1.build_confined(executor=ex)
        _EXTERNAL.append(lambda: setattr(ex, "stash", "tok-lam-folio"))
        out = run_confined(core, n1.intent(), N1_DID)
        self.assertEqual(out.confinement.status, NOT_CONFINED)
        self.assertIn("downgraded_during_execution", out.confinement.reasons)


class W9_StaleBindings(unittest.TestCase):
    def test_W9a_confirmation_for_one_audience_does_not_cover_another(self):
        core, hub, v2, eff = n2.build_confined(constraints=n2.audiences("team", "public"))
        hub.docs["p-7"].update(visibility="team", last_private_at="2026-09-01T00:00:00+07:00")
        d = core.gateway.request_authorization(n2.intent(), N2_DID)
        conf = Confirmation.from_decision(d, "lam", NOW)
        dec = core.gateway.execute_confined(n2.intent(audience="public"), N2_DID, conf).decision
        self.assertEqual(dec.decision, DENY)
        self.assertIn(R.CONFIRMATION_MISMATCH, dec.codes())
        self.assertEqual(hub.publish_calls, 0)

    def test_W9b_authority_removed_from_delegation(self):
        core, folio, v1, eff = n1.build_confined()
        d, _ = authorize(core, n1.intent(), N1_DID)
        core.delegations.revoke(N1_DID, by_principal="lam")
        core.delegations.issue(n1.delegation("dlg-ro", v1, authority=("docs.read",)))
        self.assertEqual(core.gateway.request_authorization(n1.intent(), "dlg-ro").codes(), [R.AUTHORITY_NOT_DELEGATED])
        self.assertEqual(core.gateway.execute_confined(n1.intent(), N1_DID, None, d.grant).decision.codes(),
                         [R.DELEGATION_REVOKED])
        self.assertEqual(folio.rename_calls, 0)


# ===================================================== guards
class CoreStillBounded(unittest.TestCase):
    def test_G22_no_newcomer_identifiers_or_literals_in_core(self):
        for f in CORE_FILES:
            with open(os.path.join(CORE_DIR, f), encoding="utf-8") as fh:
                tree = ast.parse(fh.read())
            docs = _docstring_nodes(tree)
            for node in ast.walk(tree):
                with self.subTest(file=f):
                    if isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in docs:
                        low = node.value.lower()
                        for w in NEWCOMER_WORDS:
                            self.assertNotIn(w, low, f"string {node.value!r} in {f}")
                    name = getattr(node, "id", None) or getattr(node, "attr", None) or getattr(node, "name", None)
                    if isinstance(name, str):
                        for w in NEWCOMER_WORDS:
                            if w == "publish":     # ContractRegistry.publish is protocol vocabulary (V0)
                                continue
                            self.assertNotIn(w, name.lower(), f"identifier {name} in {f}")

    def test_G23_no_branch_on_provider_values_in_any_core_file(self):
        for f in CORE_FILES:
            with open(os.path.join(CORE_DIR, f), encoding="utf-8") as fh:
                src = fh.read()
            self.assertIsNone(re.search(
                r"(issuer|capability|contract_id|identity|subject|version_kind|resource|holder|request|effect|effects|"
                r"address|step)(\[[^\]]*\])?\s*(==|!=|in)\s*['\"(\[]", src), f)

    def test_G24_still_five_lifecycle_objects(self):
        import aaap.objects as o
        lifecycle = {"CapabilityContract", "Delegation", "ActionIntent", "AuthorizationGrant", "ActionReceipt"}
        classes = {n for n, v in vars(o).items() if isinstance(v, type) and v.__module__ == o.__name__}
        # V0-V0.2 supporting records; V0.3 adds none
        self.assertEqual(classes - lifecycle,
                         {"AuthorizationDecision", "Confirmation", "StateBinding", "ExecutionEvidence"})


# ===================================================== findings
class V03Findings(unittest.TestCase):
    def test_FINDING_V03_A_must_happen_effects_must_be_declared_by_the_contract(self):
        """A composite contract that omits verification.required_effects is VERIFIED on evidence of
        one sub-effect: `effects` is an upper bound ("may happen"), so the core cannot infer which
        effects must happen. CONTRACT_DEFICIENCY (provider declaration), not a core rule."""
        v2 = variant(load_contract("pubhub", "contract_v2.json"), lambda d: d["verification"].pop("required_effects"))
        core, hub, _, eff = n2.build_confined(contract=v2, observers=("publish",))
        self.assertEqual(statuses(run_confined(core, n2.intent(), N2_DID)), ("SUCCESS", VERIFIED))   # <-- weakness

    def test_FINDING_V03_B_an_unscoped_authoritative_source_can_attest_any_effect(self):
        """Effect scope is a deployer declaration. Registered without one, a relabelling source makes a
        publish-only observation count for the notification. INFRASTRUCTURE_DEPENDENCY (evidence
        integrity / source honesty is TCB)."""
        core, hub, v2, eff = n2.build_confined(observers=("publish",))
        relabel = Relabel(PublishRecordObserver(hub, n2.TOKENS), identity="pubhub.example/everything",
                          observed_effects=(PUBLISHED, NOTIFIED))
        core.gateway.register_evidence_source(n2.ADDRESS, relabel, PROVIDER_AUTHORITY)     # no scope
        orig = hub.notify
        hub.notify = lambda *a, **k: {"list": None}                                         # nothing is sent
        out = run_confined(core, n2.intent(), N2_DID)
        hub.notify = orig
        self.assertEqual(hub.outbox, [])                                                     # nothing was sent
        self.assertEqual(out.receipt.verification_status, VERIFIED)                          # <-- weakness exists

    def test_FINDING_V03_C_post_invariants_apply_to_every_sub_effect_observation(self):
        """A post-phase invariant over document state also runs on the notification record, which cannot
        observe it, so the composite can never be VERIFIED. Fails closed (over-strict).
        EVIDENCE_MODEL_DEFICIENCY."""
        v2 = variant(load_contract("pubhub", "contract_v2.json"),
                     lambda d: d["invariants"][0].update(phase="both"), version="2-post")
        core, hub, _, eff = n2.build_confined(contract=v2)
        out = run_confined(core, n2.intent(), N2_DID)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))                               # <-- limitation
        self.assertIn(R.INVARIANT_UNVERIFIABLE, out.receipt.codes())

    def test_FINDING_V03_D_unauthenticated_publish_can_occupy_a_qualified_address(self):
        """Without the infrastructure input (authenticated_issuer), the registry trusts the caller about
        the issuer. A forged 'folio.example' contract becomes current. Pinning still denies it: DoS, not
        authority. INFRASTRUCTURE_DEPENDENCY."""
        core, folio, v1, eff = n1.build_confined()
        forged = variant(v1, lambda d: d["effects"].append("document_deleted"))
        core.contracts.publish(forged)                                   # no authenticated publisher
        self.assertIs(core.contracts.current(n1.ADDRESS), forged)        # <-- weakness exists
        self.assertEqual(run_confined(core, n1.intent(), N1_DID).decision.codes(), [R.CONTRACT_CHANGED])
        self.assertEqual(folio.rename_calls, 0)

    def test_FINDING_V03_E_non_security_status_of_description_is_the_issuers_word(self):
        """An issuer that excludes `description` can change what the text claims without invalidating
        never-confirm grants. Enforcement cannot widen (effects/inputs/evaluators stay in the identity),
        but the human-readable meaning can drift. CONTRACT_DEFICIENCY risk, by design of P1."""
        core, folio, v1, eff = n1.build_confined()
        d, _ = authorize(core, n1.intent(), N1_DID)
        republish(core, variant(v1, lambda c: c.update(description="Rename and share publicly.")), n1.ISSUER)
        out = core.gateway.execute_confined(n1.intent(), N1_DID, None, d.grant)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))            # <-- accepted residual
        self.assertEqual(folio.move_calls, 0)                             # and nothing beyond the contract happened


if __name__ == "__main__":
    unittest.main()
