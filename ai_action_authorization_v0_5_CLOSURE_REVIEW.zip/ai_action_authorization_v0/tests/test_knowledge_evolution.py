import os
import unittest

from aaap import ALLOW, DENY, REQUIRE_CONFIRMATION, Confirmation, R

from fixtures.fakepay import world
from tests.harness import ROOT, delegation, load_contract


class KnowledgeEvolutionTests(unittest.TestCase):
    def test_K1_old_delegation_against_v2_denied(self):
        core, pay, v1 = world.build()
        self.assertEqual(core.gateway.request_authorization(world.intent(), "dlg-pay-1").decision, REQUIRE_CONFIRMATION)
        v2 = load_contract("fakepay", "contract_v2.json")
        core.contracts.publish(v2)
        d = core.gateway.request_authorization(world.intent(), "dlg-pay-1")
        self.assertEqual(d.decision, DENY)
        self.assertEqual(d.codes(), [R.CONTRACT_CHANGED])
        self.assertIn("v1:", d.reasons[0]["detail"])
        self.assertIn("v2:", d.reasons[0]["detail"])

    def test_K2_old_confirmation_against_v2_denied(self):
        core, pay, v1 = world.build()
        i = world.intent()
        c = Confirmation.from_decision(core.gateway.request_authorization(i, "dlg-pay-1"), "lam", "2026-10-13T09:31:00+07:00")
        core.contracts.publish(load_contract("fakepay", "contract_v2.json"))
        out = core.gateway.execute(i, "dlg-pay-1", c)
        self.assertEqual(out.decision.decision, DENY)
        self.assertEqual(pay.transfer_calls, 0)

    def test_K3_reauthorization_against_v2_works(self):
        core, pay, v1 = world.build()
        v2 = load_contract("fakepay", "contract_v2.json")
        core.contracts.publish(v2)
        core.delegations.issue(delegation("dlg-pay-2", "lam", "agent-1", ["financial.transfer"], [v2], world.LIMITS))
        i = world.intent()
        d = core.gateway.request_authorization(i, "dlg-pay-2")
        self.assertEqual(d.decision, REQUIRE_CONFIRMATION)
        c = Confirmation.from_decision(d, "lam", "2026-10-13T09:31:00+07:00")
        self.assertEqual(core.gateway.execute(i, "dlg-pay-2", c).decision.decision, ALLOW)

    def test_K4_same_version_string_silent_content_change_detected(self):
        """Provider changes effects but forgets to bump version: digest still catches it."""
        core, pay, v1 = world.build()
        d = v1.to_dict()
        d["effects"] = ["money_moved", "credit_line_may_be_used"]
        from aaap import CapabilityContract
        core.contracts.publish(CapabilityContract.from_dict(d))
        self.assertEqual(core.gateway.request_authorization(world.intent(), "dlg-pay-1").codes(), [R.CONTRACT_CHANGED])

    def test_K5_core_has_no_knowledge_of_new_effect(self):
        for f in os.listdir(os.path.join(ROOT, "src", "aaap")):
            if f.endswith(".py"):
                with open(os.path.join(ROOT, "src", "aaap", f), encoding="utf-8") as fh:
                    src = fh.read()
                self.assertNotIn("credit_line", src, f)


if __name__ == "__main__":
    unittest.main()
