"""Domain-agnostic test harness: wires one core instance. Fixtures plug into it."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from aaap import (
    ActionGateway, AuthorizationVerifier, CapabilityContract, ContractRegistry, Delegation, DelegationStore,
    ExecutionLedger, core_registry,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ICT = timezone(timedelta(hours=7))


def load_contract(domain: str, name: str) -> CapabilityContract:
    with open(os.path.join(ROOT, "fixtures", domain, name), encoding="utf-8") as f:
        return CapabilityContract.from_dict(json.load(f))


class Clock:
    def __init__(self, now: datetime):
        self.now = now

    def __call__(self) -> datetime:
        return self.now


@dataclass
class Core:
    clock: Clock
    evaluators: object
    contracts: ContractRegistry
    delegations: DelegationStore
    ledger: ExecutionLedger
    verifier: AuthorizationVerifier
    gateway: ActionGateway


def make_core(now: datetime = datetime(2026, 10, 13, 9, 30, tzinfo=ICT), evaluators=None) -> Core:
    clock = Clock(now)
    ev = evaluators or core_registry()
    contracts, delegations, ledger = ContractRegistry(), DelegationStore(), ExecutionLedger()
    verifier = AuthorizationVerifier(ev, contracts, delegations, ledger, clock)
    return Core(clock, ev, contracts, delegations, ledger, verifier, ActionGateway(verifier, contracts, ledger))


def grant(contract: CapabilityContract) -> dict:
    return {"contract_id": contract.contract_id, "capability": contract.capability,
            "contract_version": contract.version, "contract_digest": contract.digest()}


def delegation(did, principal, agent, authority, contracts, constraints,
               valid_from="2026-10-01T00:00:00+07:00", valid_until="2026-11-01T00:00:00+07:00") -> Delegation:
    return Delegation(delegation_id=did, principal=principal, agent=agent, allowed_authority=list(authority),
                      allowed_capabilities=[grant(c) for c in contracts], constraints=list(constraints),
                      valid_from=valid_from, valid_until=valid_until)
