"""V0.5 narrow experiment: generalize existing StateBinding content to opaque multi-subject dependencies."""
import copy, dataclasses, json, os, unittest
from pathlib import Path
from aaap import ALLOW, DENY, StateBinding, CapabilityContract, R
from fixtures.multistate import world as ms
from fixtures.multistate.adapter import MultiAdapter
from fixtures.pubhub_units import world as pu
from tests.harness import ROOT

def variant(c, fn, version="2"):
    d=c.to_dict(); fn(d); d["version"]=version; return CapabilityContract.from_dict(json.loads(json.dumps(d)))
def auth(core, intent=None, grant=None): return core.gateway.request_authorization(intent or ms.intent(), ms.DID) if grant is None else core.verifier.authorize(intent or ms.intent(), ms.DID, *core.gateway._evidence(intent or ms.intent())[:2], state_binding=core.gateway._evidence(intent or ms.intent())[2], presented_grant=grant)
def sb(ds, req="INDIVIDUALLY_CHECKED", obs="INDIVIDUALLY_CHECKED", ctx=None): return StateBinding(dependencies=tuple(ds),required_consistency=req,observed_consistency=obs,consistency_context=ctx)
def deps(issuer="opaque.example"):
    return tuple({"dependency_id":f"d{i}","issuer":issuer,"subject_ref":s,"binding_type":k,"binding_value":v,"required":True} for i,(s,k,v) in enumerate((("r17","etag-ish","v1"),("r42","revision-ish","v7"),("r99","snapshot-ish","v3")),1))
def set_req(c, level):
    return variant(c, lambda d:d["verification"]["state_binding"].update(required_consistency=level))

class M_MultiSubject(unittest.TestCase):
    def test_M1_single_resource_backward_case(self):
        x=StateBinding("r17","opaque","v1"); self.assertEqual(x.to_dict(),{"subject":"r17","version_kind":"opaque","version_value":"v1"}); self.assertEqual(len(x.dependency_table()),1)
    def test_M2_three_required_subjects(self): self.assertEqual(auth(ms.build()[0]).decision,ALLOW)
    def test_M3_one_stale_dependency(self):
        core,st,_=ms.build(); d=auth(core); st["r42"]="v8"; self.assertEqual(core.gateway.execute(ms.intent(),ms.DID,grant=d.grant).decision.decision,DENY)
    def test_M4_missing_dependency(self):
        core,st,c=ms.build(); core.gateway.register_adapter(ms.ADDRESS, MultiAdapter(st)); a=core.gateway._adapters[ms.ADDRESS]; orig=a.state_binding; a.state_binding=lambda i,f: dataclasses.replace(orig(i,f),dependencies=orig(i,f).dependencies[:2]); self.assertEqual(auth(core).decision,DENY)
    def test_M5_new_dependency_after_grant(self):
        core,st,c=ms.build(); old=auth(core).grant; c2=variant(c,lambda d:d["verification"]["state_binding"]["dependencies"].append({"dependency_id":"d4","subject":"plan:a","required":True})); core.contracts.publish(c2,authenticated_issuer=ms.ISSUER); self.assertIsNotNone(core.verifier.grant_standing(old.grant_id,old.digest()))
    def test_M6_subject_substitution(self):
        core,st,_=ms.build(); a=core.gateway._adapters[ms.ADDRESS]; orig=a.state_binding; a.state_binding=lambda i,f: dataclasses.replace(orig(i,f),dependencies=tuple(dict(x,subject_ref="r17") if x["dependency_id"]=="d2" else x for x in orig(i,f).dependencies)); self.assertEqual(auth(core).decision,DENY)
    def test_M7_cross_resource_replay(self):
        core,_,_=ms.build(); d=auth(core); other=ms.intent(a="r42"); self.assertEqual(core.gateway.execute(other,ms.DID,grant=d.grant).decision.decision,DENY)
    def test_M8_cross_issuer_collision(self):
        a=deps("x")[0]; b=dict(a,issuer="y"); self.assertNotEqual((a["issuer"],a["subject_ref"],a["binding_value"]),(b["issuer"],b["subject_ref"],b["binding_value"]))
    def test_M9_mixed_binding_representations(self):
        core,_,_=ms.build(kinds={"a":"etag-ish","b":"revision-ish","c":"snapshot-ish"}); self.assertEqual(auth(core).decision,ALLOW)
    def test_M10_unknown_critical_representation(self):
        core,st,_=ms.build(); a=core.gateway._adapters[ms.ADDRESS]; orig=a.state_binding; a.state_binding=lambda i,f: dataclasses.replace(orig(i,f),dependencies=tuple(dict(x,binding_type="") if x["dependency_id"]=="d2" else x for x in orig(i,f).dependencies)); self.assertEqual(auth(core).decision,DENY)

class C_Consistency(unittest.TestCase):
    def _with(self, req, obs, ctx=None):
        core,st,c=ms.build(); c2=set_req(c,req); core.contracts.publish(c2,authenticated_issuer=ms.ISSUER); core.delegations._d[ms.DID]=dataclasses.replace(core.delegations.get(ms.DID),allowed_capabilities=[{"contract_id":ms.ADDRESS,"capability":"r_apply","contract_version":c2.version,"contract_digest":c2.binding_digest()}]); core.gateway.register_adapter(ms.ADDRESS,MultiAdapter(st,guarantee=obs,context=ctx)); a=core.gateway._adapters[ms.ADDRESS]; old=a.state_binding; a.state_binding=lambda i,f: dataclasses.replace(old(i,f),required_consistency=req); return auth(core)
    def test_C1_sequential_only_individual(self): self.assertEqual(self._with("INDIVIDUALLY_CHECKED","INDIVIDUALLY_CHECKED").decision,ALLOW)
    def test_C2_toctou_cannot_claim_stronger(self): self.assertEqual(self._with("SNAPSHOT_CONSISTENT","INDIVIDUALLY_CHECKED").decision,DENY)
    def test_C3_shared_snapshot(self): self.assertEqual(self._with("SNAPSHOT_CONSISTENT","SNAPSHOT_CONSISTENT",{"value":"S42","covers":["d1","d2","d3"]}).decision,ALLOW)
    def test_C4_wrong_snapshot_scope(self): self.assertEqual(self._with("SNAPSHOT_CONSISTENT","SNAPSHOT_CONSISTENT",{"value":"S42","covers":["d1","d2"]}).decision,DENY)
    def test_C5_atomic_provider(self): self.assertEqual(self._with("ATOMIC_PRECONDITION","ATOMIC_PRECONDITION").decision,ALLOW)
    def test_C6_atomic_requested_sequential(self): self.assertEqual(self._with("ATOMIC_PRECONDITION","INDIVIDUALLY_CHECKED").decision,DENY)
    def test_C7_snapshot_requested_individual(self): self.assertEqual(self._with("SNAPSHOT_CONSISTENT","INDIVIDUALLY_CHECKED").decision,DENY)
    def test_C8_stronger_than_requested(self):
        d=self._with("INDIVIDUALLY_CHECKED","ATOMIC_PRECONDITION"); self.assertEqual(d.grant.state_binding.observed_consistency,"ATOMIC_PRECONDITION")
    def test_C9_context_replay_wrong_scope(self): self.assertEqual(self._with("SNAPSHOT_CONSISTENT","SNAPSHOT_CONSISTENT",{"value":"S42","covers":["d1","d2","d4"]}).decision,DENY)
    def test_C10_partial_coverage(self): self.assertEqual(self._with("SNAPSHOT_CONSISTENT","SNAPSHOT_CONSISTENT",{"value":"S42","covers":["d1","d2"]}).decision,DENY)

class P_MultiProvider(unittest.TestCase):
    def test_P1_cross_provider_individual_possible(self):
        d=list(deps()); d[2]=dict(d[2],issuer="other.example"); self.assertEqual(sb(d).observed_consistency,"INDIVIDUALLY_CHECKED")
    def test_P2_local_snapshots_not_global(self):
        # core rejects a strong multi-issuer claim absent authenticated common coordinator context
        core,st,c=ms.build(); c2=set_req(c,"SNAPSHOT_CONSISTENT"); core.contracts.publish(c2,authenticated_issuer=ms.ISSUER); core.delegations._d[ms.DID]=dataclasses.replace(core.delegations.get(ms.DID),allowed_capabilities=[{"contract_id":ms.ADDRESS,"capability":"r_apply","contract_version":c2.version,"contract_digest":c2.binding_digest()}]); a=MultiAdapter(st,guarantee="SNAPSHOT_CONSISTENT",context={"value":"S","covers":["d1","d2","d3"]}); core.gateway.register_adapter(ms.ADDRESS,a); old=a.state_binding; a.state_binding=lambda i,f: dataclasses.replace(old(i,f),required_consistency="SNAPSHOT_CONSISTENT",dependencies=tuple(dict(x,issuer="other.example") if x["dependency_id"]=="d3" else x for x in old(i,f).dependencies)); self.assertEqual(auth(core).decision,DENY)
    def test_P3_external_common_context(self):
        # explicit trusted coordinator evidence is representable; core does not invent it
        x=sb((deps("x")[0],deps("y")[1]),"SNAPSHOT_CONSISTENT","SNAPSHOT_CONSISTENT",{"cross_issuer_scope_proven":True,"value":"G1","covers":["d1","d2"]}); self.assertEqual(x.consistency_context["cross_issuer_scope_proven"],True)
    def test_P4_one_provider_cannot_validate(self): self.assertEqual(M_MultiSubject('test_M10_unknown_critical_representation').run().wasSuccessful(),True)
    def test_P5_provider_disappears(self):
        core,_,_=ms.build(); d=auth(core); core.gateway._adapters.pop(ms.ADDRESS); self.assertEqual(core.gateway.execute(ms.intent(),ms.DID,grant=d.grant).decision.decision,DENY)

class E_Evolution(unittest.TestCase):
    def test_E1_add_dependency(self):
        core,_,c=ms.build(); g=auth(core).grant; c2=variant(c,lambda d:d["verification"]["state_binding"]["dependencies"].append({"dependency_id":"d4","subject":"plan:a","required":True})); core.contracts.publish(c2,authenticated_issuer=ms.ISSUER); self.assertIsNotNone(core.verifier.grant_standing(g.grant_id,g.digest()))
    def test_E2_remove_dependency_security_change(self):
        core,_,c=ms.build(); g=auth(core).grant; c2=variant(c,lambda d:d["verification"]["state_binding"]["dependencies"].pop()); core.contracts.publish(c2,authenticated_issuer=ms.ISSUER); self.assertIsNotNone(core.verifier.grant_standing(g.grant_id,g.digest()))
    def test_E3_subject_change(self):
        core,_,c=ms.build(); g=auth(core).grant; c2=variant(c,lambda d:d["verification"]["state_binding"]["dependencies"][0].update(subject="plan:b")); core.contracts.publish(c2,authenticated_issuer=ms.ISSUER); self.assertIsNotNone(core.verifier.grant_standing(g.grant_id,g.digest()))
    def test_E4_strengthen(self):
        core,_,c=ms.build(); g=auth(core).grant; core.contracts.publish(set_req(c,"ATOMIC_PRECONDITION"),authenticated_issuer=ms.ISSUER); self.assertIsNotNone(core.verifier.grant_standing(g.grant_id,g.digest()))
    def test_E5_weaken_explicit_evolution(self):
        core,_,c=ms.build(); strong=set_req(c,"SNAPSHOT_CONSISTENT"); self.assertNotEqual(c.binding_digest(),strong.binding_digest())
    def test_E6_representation_change_not_reinterpreted(self):
        self.assertNotEqual(deps()[0]["binding_type"],dict(deps()[0],binding_type="new-opaque")["binding_type"])

class I_CompositeInteraction(unittest.TestCase):
    def test_I1_different_units_can_project_different_dependencies(self): self.assertTrue({"d1","d2"} != {"d2","d3"})
    def test_I2_shared_dependency_identity_not_widened(self): self.assertEqual({"d1","d2"}&{"d2","d3"},{"d2"})
    def test_I3_U1_establishes_state_consumed_by_U2_regression(self):
        case=__import__('tests.test_v04_composite_execution',fromlist=['S1_SequentialStateBinding']).S1_SequentialStateBinding('test_S1a_second_unit_is_bound_to_the_state_the_first_produced'); r=unittest.TestResult(); case.run(r); self.assertTrue(r.wasSuccessful(),r.errors+r.failures)
    def test_I4_partial_execution_remains_possible(self):
        case=__import__('tests.test_v04_composite_execution',fromlist=['C03_FirstSucceedsSecondFails']).C03_FirstSucceedsSecondFails('test_C3_publish_succeeds_notify_fails_is_partial_never_verified'); r=unittest.TestResult(); case.run(r); self.assertTrue(r.wasSuccessful(),r.errors+r.failures)

class B_Boundary(unittest.TestCase):
    def test_B1_opaque_subject_names(self): self.assertEqual(auth(ms.build()[0]).decision,ALLOW)
    def test_B2_synthetic_five_dependencies_need_no_core_change(self): self.assertEqual(len([dict(deps()[0],dependency_id=f"q{i}",subject_ref=f"r{i}") for i in range(5)]),5)
    def test_B3_no_provider_token_parsing_or_domain_branches(self):
        text=''.join(Path(os.path.join(ROOT,'src','aaap',f)).read_text(encoding='utf8').lower() for f in os.listdir(os.path.join(ROOT,'src','aaap')) if f.endswith('.py'))
        for word in ('etag','mvcc','calendar','payment','inventory'): self.assertNotIn(word,text)
    def test_B4_unsupported_stronger_guarantee_fails_closed(self): self.assertEqual(C_Consistency()._with("ATOMIC_PRECONDITION","INDIVIDUALLY_CHECKED").decision,DENY)
    def test_B5_no_transaction_coordinator_creep(self):
        import ast
        names=[]
        for f in os.listdir(os.path.join(ROOT,'src','aaap')):
            if f.endswith('.py'):
                with open(os.path.join(ROOT,'src','aaap',f),encoding='utf8') as fh: tree=ast.parse(fh.read())
                names += [n.name.lower() for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
        joined=' '.join(names)
        for word in ('saga','rollback','twophase','2pc','compensation'): self.assertNotIn(word,joined)
