"""Independent closure review. Security expectation failures are deliberately retained.
Fixtures are test-only; production code and all baseline tests remain untouched.
"""
import copy
import dataclasses as dc
import unittest
from aaap import ALLOW, DENY, StateBinding, ConfinedExecutor, CapabilityContract
from aaap.adapter import ExecutionResult, PreconditionFailed
from aaap.authority import ProviderEffector, MODE_B
from fixtures.multistate import world as ms
from fixtures.multistate.adapter import MultiAdapter
from tests.test_v05_multi_state_binding import set_req, variant
from tests.test_v04_composite_execution import uop


def setup(req='INDIVIDUALLY_CHECKED', obs='INDIVIDUALLY_CHECKED', ctx=None):
    core, st, c = ms.build()
    c = set_req(c, req)
    core.contracts.publish(c, authenticated_issuer=ms.ISSUER)
    core.delegations._d[ms.DID] = dc.replace(core.delegations.get(ms.DID), allowed_capabilities=[{
        'contract_id':ms.ADDRESS,'capability':'r_apply','contract_version':c.version,'contract_digest':c.binding_digest()}])
    a = MultiAdapter(st, guarantee=obs, context=ctx)
    orig = a.state_binding
    a.state_binding = lambda i,f: dc.replace(orig(i,f),required_consistency=req)
    core.gateway.register_adapter(ms.ADDRESS,a)
    return core, st, c, a


def alter(a, fn):
    orig = a.state_binding
    a.state_binding = lambda i,f: fn(orig(i,f))


def execute(core, intent=None):
    i=intent or ms.intent()
    d=core.gateway.request_authorization(i,ms.DID)
    if d.decision != ALLOW: return d, None
    return d, core.gateway.execute(i,ms.DID,grant=d.grant)


class DependencyAttacks(unittest.TestCase):
    def test_missing_stale_substitution_and_malformed(self):
        attacks={
            'missing':lambda b:dc.replace(b,dependencies=b.dependencies[:2]),
            'wrong_subject':lambda b:dc.replace(b,dependencies=tuple(dict(d,subject_ref='other') if d['dependency_id']=='d2' else d for d in b.dependencies)),
            'duplicate_identity':lambda b:dc.replace(b,dependencies=b.dependencies+(dict(b.dependencies[0],binding_value='evil'),)),
            'empty':lambda b:dc.replace(b,dependencies=()),
            'missing_observed':lambda b:dc.replace(b,observed_consistency=None),
        }
        for name,fn in attacks.items():
            with self.subTest(attack=name):
                core,st,c,a=setup(); alter(a,fn); d,o=execute(core)
                self.assertEqual(d.decision,DENY); self.assertEqual(a.effects,[])
        core,st,c,a=setup(); d=core.gateway.request_authorization(ms.intent(),ms.DID)
        st['r42']='v8'; o=core.gateway.execute(ms.intent(),ms.DID,grant=d.grant)
        self.assertEqual(o.decision.decision,DENY); self.assertEqual(a.effects,[])

    def test_required_flag_cannot_disable_contract_precondition(self):
        core,st,c,a=setup()
        alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,required=False) if d['dependency_id']=='d2' else d for d in b.dependencies)))
        original=a.execute_conditional
        def race(i,p,b):
            st['r42']='v8'
            return original(i,p,b)
        a.execute_conditional=race
        d,o=execute(core)
        self.assertEqual(a.effects,[], 'contract-required B was skipped using offered required=False')

    def test_duplicate_id_different_subject_rejected(self):
        core,st,c,a=setup()
        alter(a,lambda b:dc.replace(b,dependencies=b.dependencies+(dict(b.dependencies[0],subject_ref='other',binding_value='other'),)))
        d,o=execute(core)
        self.assertEqual(d.decision,DENY)

    def test_unknown_critical_consistency_context_rejected(self):
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT',{'value':'s','covers':['d1','d2','d3'],'critical':{'unrecognized':True}})
        d,o=execute(core); self.assertEqual(d.decision,DENY)

    def test_representation_and_contract_requirement_change_pin_grant(self):
        core,st,c,a=setup(); i=ms.intent(); g=core.gateway.request_authorization(i,ms.DID).grant
        alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,binding_type='different') for d in b.dependencies)))
        self.assertEqual(core.gateway.execute(i,ms.DID,grant=g).decision.decision,DENY)
        core,st,c,a=setup(); g=core.gateway.request_authorization(i,ms.DID).grant
        core.contracts.publish(set_req(c,'ATOMIC_PRECONDITION'),authenticated_issuer=ms.ISSUER)
        self.assertEqual(core.gateway.execute(i,ms.DID,grant=g).decision.decision,DENY)


class ConsistencyAttacks(unittest.TestCase):
    def test_independent_snapshots_and_sequential_strong_request_block(self):
        for req,obs,ctx in [('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT',{'value':'S1/S2','covers':['d1','d2','d3']}),('ATOMIC_PRECONDITION','INDIVIDUALLY_CHECKED',None)]:
            with self.subTest(req=req,obs=obs):
                core,st,c,a=setup(req,obs,ctx)
                alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,issuer='P2') if d['dependency_id']=='d3' else d for d in b.dependencies)))
                d,o=execute(core); self.assertEqual(d.decision,DENY); self.assertEqual(a.effects,[])

    def test_coordinator_missing_coverage_block(self):
        for covers in (['d1','d2'],['d1','d2','d3','absent'],None):
            with self.subTest(covers=covers):
                core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT',{'value':'S','covers':covers,'cross_issuer_scope_proven':True})
                # A malformed context must produce DENY, not throw out of authorize.
                try: d,o=execute(core)
                except Exception as e: self.fail('malformed coverage crashed verifier: '+repr(e))
                self.assertEqual(d.decision,DENY)

    def test_context_replay_scope_lineage_not_enforced(self):
        ctx={'value':'S','covers':['d1','d2','d3'],'cross_issuer_scope_proven':True,
             'execution_id':'exec-ms','intent_id':'int-ms','grant_id':'old-grant',
             'subjects':['r17','r42','r99'],'issuers':['opaque.example']}
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT',ctx)
        first,out=execute(core); self.assertEqual(first.decision,ALLOW)
        cases={'execution':dc.replace(ms.intent(),execution_id='new-exec'),
               'intent':dc.replace(ms.intent(),intent_id='new-intent',execution_id='new-exec'),
               'subject':dc.replace(ms.intent(a='r42'),execution_id='new-exec')}
        for name,i in cases.items():
            with self.subTest(replay=name):
                fresh,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT',ctx)
                d,o=execute(fresh,i); self.assertEqual(d.decision,DENY,'context lineage/scope not checked')
        fresh,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT',ctx)
        alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,issuer='different') for d in b.dependencies)))
        d,o=execute(fresh); self.assertEqual(d.decision,DENY,'context issuer scope not checked')

    def test_atomic_does_not_imply_snapshot(self):
        # Legitimate opaque predicates: A is true at t0, then A becomes false and B true.
        # Reads A@t0+B@t1 never form a snapshot; both remain valid predicates at write time
        # when provider later makes A true. Atomic application does not validate read provenance.
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','ATOMIC_PRECONDITION')
        d,o=execute(core)
        self.assertEqual(d.decision,DENY,'atomic declaration was upgraded to snapshot with no snapshot context')

    def test_sequential_individual_has_no_execution_time_freshness_claim(self):
        core,st,c,a=setup(); original=a.execute_conditional
        def race(i,p,b): st['r17']='v2'; return original(i,p,b)
        a.execute_conditional=race
        d,o=execute(core); self.assertEqual(d.decision,ALLOW)
        self.assertEqual(o.receipt.execution_result['status'],'PRECONDITION_FAILED'); self.assertEqual(a.effects,[])


class HandoffEffector(ProviderEffector):
    mode=MODE_B
    def __init__(self,state,attack='valid'):
        self.state=state; self.attack=attack; self.calls=[]; self.validations=[]
    def authority_handles(self): return [self.state]
    def perform_unit(self,cred,op,pre):
        # This fixture validates complete unit dependencies against authoritative state.
        ids=('d1','d2') if op.unit=='U1' else ('d2','d3')
        table={d['dependency_id']:d for d in pre.dependencies} if pre else {}
        for did in ids:
            d=table.get(did)
            if d is None or d['issuer']!=ms.ISSUER or d['binding_value']!=self.state.get(d['subject_ref']):
                raise PreconditionFailed('missing/stale/wrong-issuer '+did)
            self.validations.append((op.unit,did,d['binding_value']))
        self.calls.append(op.unit)
        if op.unit=='U1':
            self.state['r42']='v8'
            deps=tuple(dict(d,binding_value='v8') if d['dependency_id']=='d2' else dict(d) for d in pre.dependencies)
            est=dc.replace(pre,dependencies=deps).to_dict()
            if self.attack=='stale': est=pre.to_dict()
            if self.attack=='substitution': est['dependencies'][1]['subject_ref']='r17'
            if self.attack=='issuer': est['dependencies'][1]['issuer']='other'
            if self.attack=='wrong_lineage': est['execution_id']='other-execution'
            if self.attack=='missing': est=None
            if self.attack=='false_state': est['dependencies'][1]['binding_value']='v999'
            if self.attack=='upgrade': est['observed_consistency']='ATOMIC_PRECONDITION'
            status='PARTIAL' if self.attack=='partial' else 'SUCCESS'
            return ExecutionResult(status,cred.execution_id,'U1',op.request,['r.u1'],established_state=est)
        return ExecutionResult('SUCCESS',cred.execution_id,'U2',op.request,['r.u2'])


def composite(attack='valid'):
    core,st,c,a=setup()
    d=c.to_dict(); d['version']='composite-review'; d['effects']=['r.u1','r.u2']
    d['execution_units']=[
        {'unit_id':'U1','required':True,'effects':['r.u1'],'request_fields':['a','b'],'state':'authorization'},
        {'unit_id':'U2','required':True,'effects':['r.u2'],'request_fields':['b','c'],'after':['U1'],'state':{'from_unit':'U1'}}]
    c=CapabilityContract.from_dict(d)
    core.contracts.publish(c,authenticated_issuer=ms.ISSUER)
    core.delegations._d[ms.DID]=dc.replace(core.delegations.get(ms.DID),allowed_capabilities=[{'contract_id':ms.ADDRESS,'capability':'r_apply','contract_version':c.version,'contract_digest':c.binding_digest()}])
    eff=HandoffEffector(st,attack); core.gateway.authority.register_effector(ms.ADDRESS,eff)
    core.gateway.register_executor(ms.ADDRESS,ConfinedExecutor('agent-1'))
    return core,st,eff


class CompositeAttacks(unittest.TestCase):
    def test_valid_multistate_handoff_must_execute_and_validate_B2_C(self):
        core,st,eff=composite(); i=ms.intent(); d=core.gateway.request_authorization(i,ms.DID)
        self.assertEqual(d.decision,ALLOW,d.reasons)
        o=core.gateway.execute_confined(i,ms.DID,grant=d.grant)
        self.assertEqual(eff.calls,['U1','U2'],'core cannot consume a multi-state established binding')
        self.assertIn(('U2','d2','v8'),eff.validations); self.assertIn(('U2','d3','v3'),eff.validations)

    def test_invalid_handoffs_block_without_rollback(self):
        for attack in ('stale','substitution','issuer','wrong_lineage','missing','false_state','partial','upgrade'):
            with self.subTest(attack=attack):
                core,st,eff=composite(attack); i=ms.intent(); d=core.gateway.request_authorization(i,ms.DID)
                self.assertEqual(d.decision,ALLOW,d.reasons)
                o=core.gateway.execute_confined(i,ms.DID,grant=d.grant)
                self.assertEqual(eff.calls,['U1']); self.assertEqual(st['r42'],'v8')
                self.assertNotIn(('U2','d2','v8'),eff.validations)

    def test_reordering_injection_and_wrong_execution_block_at_port(self):
        core,st,eff=composite(); d=core.gateway.request_authorization(ms.intent(),ms.DID)
        cred=core.gateway.authority.attenuate_exact(d.grant,'agent-1').credential
        port=core.gateway.authority.port('agent-1')
        for op in (uop(cred,'U2'),uop(cred,'U3'),uop(cred,'U1',execution_id='other')):
            with self.subTest(op=op):
                r=port.invoke(cred,op); self.assertFalse(r.allowed)
        self.assertEqual(eff.calls,[])

    def test_required_unit_removal_blocks_old_grant(self):
        core,st,eff=composite(); i=ms.intent(); d=core.gateway.request_authorization(i,ms.DID)
        c=core.contracts.by_digest(d.grant.contract_digest)
        newer=variant(c,lambda x:x['execution_units'].pop(),'removed')
        core.contracts.publish(newer,authenticated_issuer=ms.ISSUER)
        o=core.gateway.execute_confined(i,ms.DID,grant=d.grant)
        self.assertEqual(o.decision.decision,DENY); self.assertEqual(eff.calls,[])

class AdditionalBoundaryAttacks(unittest.TestCase):
    def test_duplicate_subject_conflicting_tokens_cannot_execute(self):
        core,st,c,a=setup()
        c2=variant(c,lambda d:d['verification']['state_binding']['dependencies'][1].update(subject='plan:a'),'same-subject')
        core.contracts.publish(c2,authenticated_issuer=ms.ISSUER)
        core.delegations._d[ms.DID]=dc.replace(core.delegations.get(ms.DID),allowed_capabilities=[{'contract_id':ms.ADDRESS,'capability':'r_apply','contract_version':c2.version,'contract_digest':c2.binding_digest()}])
        alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,subject_ref='r17',binding_value='conflict') if d['dependency_id']=='d2' else d for d in b.dependencies)))
        d,o=execute(core)
        self.assertEqual(a.effects,[])
        # Core itself accepts contradictory subject bindings; provider conditional check blocks.
        self.assertEqual(d.decision,ALLOW)
        self.assertEqual(o.receipt.execution_result['status'],'PRECONDITION_FAILED')

    def test_provider_omission_and_lying_validator_are_trust_limits(self):
        core,st,c,a=setup()
        c2=variant(c,lambda d:d['verification']['state_binding']['dependencies'].pop(),'omit-C')
        core.contracts.publish(c2,authenticated_issuer=ms.ISSUER)
        core.delegations._d[ms.DID]=dc.replace(core.delegations.get(ms.DID),allowed_capabilities=[{'contract_id':ms.ADDRESS,'capability':'r_apply','contract_version':c2.version,'contract_digest':c2.binding_digest()}])
        alter(a,lambda b:dc.replace(b,dependencies=b.dependencies[:2]))
        old=a.execute_conditional
        def hidden(i,p,b): st['r99']='changed'; return old(i,p,b)
        a.execute_conditional=hidden
        d,o=execute(core); self.assertEqual(d.decision,ALLOW); self.assertEqual(a.effects,['exec-ms'])
        core,st,c,a=setup('ATOMIC_PRECONDITION','ATOMIC_PRECONDITION')
        def lie(i,p,b):
            st['r42']='changed'; a.effects.append(i.execution_id)
            return ExecutionResult('SUCCESS',i.execution_id,'lie',p,['r.effect'])
        a.execute_conditional=lie
        d,o=execute(core); self.assertEqual(a.effects,['exec-ms'])
        self.assertEqual(o.receipt.state_consistency['observed'],'ATOMIC_PRECONDITION')
        self.assertNotEqual(o.receipt.verification_status,'VERIFIED')

    def test_four_subject_two_local_snapshots_not_global(self):
        for flag in (False,True):
            with self.subTest(unsubstantiated_coordinator_boolean=flag):
                ctx={'value':'S1+S2','covers':['d1','d2','d3','d4']}
                if flag: ctx['cross_issuer_scope_proven']=True
                core,st,c,a=setup('SNAPSHOT_CONSISTENT','SNAPSHOT_CONSISTENT',ctx)
                st['r100']='v4'
                def addfour(d):
                    d['inputs']['d']={'type':'string','required':True,'security_relevant':True,'maps_to':'d'}
                    d['verification']['state_binding']['dependencies'].append({'dependency_id':'d4','subject':'plan:d','required':True})
                c2=variant(c,addfour,'four')
                core.contracts.publish(c2,authenticated_issuer=ms.ISSUER)
                core.delegations._d[ms.DID]=dc.replace(core.delegations.get(ms.DID),allowed_capabilities=[{'contract_id':ms.ADDRESS,'capability':'r_apply','contract_version':c2.version,'contract_digest':c2.binding_digest()}])
                old=a.plan; a.plan=lambda i,f:dict(old(i,f),d='r100')
                def four(b):
                    ds=tuple(dict(d,issuer='P1' if d['dependency_id'] in ('d1','d2') else 'P2') for d in b.dependencies)
                    return dc.replace(b,dependencies=ds+(dict(ds[-1],dependency_id='d4',subject_ref='r100',binding_value='v4'),))
                alter(a,four)
                d,o=execute(core,ms.intent(d='r100'))
                # No deployer-registered common coordinator is present in either case.
                self.assertEqual(d.decision,DENY,'a Boolean is not authenticated common-snapshot evidence')

    def test_mixed_local_atomic_individual_not_global_atomic(self):
        core,st,c,a=setup('ATOMIC_PRECONDITION','INDIVIDUALLY_CHECKED')
        alter(a,lambda b:dc.replace(b,dependencies=tuple(dict(d,local_guarantee='ATOMIC_PRECONDITION' if d['dependency_id']=='d1' else 'INDIVIDUALLY_CHECKED') for d in b.dependencies)))
        d,o=execute(core); self.assertEqual(d.decision,DENY)

    def test_atomic_predicates_with_no_read_snapshot_must_not_satisfy_snapshot(self):
        # Tokens are stable opaque predicates, not injective versions. A@on is read
        # at (on,off); B@on at (off,on). There was no (on,on) during collection.
        history=[('on','off'),('off','on')]
        observed=(history[0][0],history[1][1])
        self.assertNotIn(observed,history)
        core,st,c,a=setup('SNAPSHOT_CONSISTENT','ATOMIC_PRECONDITION')
        st.update(r17='on',r42='on')
        old=a.state_binding
        def read_skew(i,f):
            # Adapter collected predicates over history, then the provider reaches
            # (on,on) before the protected write and atomically validates all of them.
            b=old(i,f)
            return dc.replace(b,dependencies=tuple(dict(d,binding_value=observed[int(d['dependency_id'][1:])-1]) if d['dependency_id'] in ('d1','d2') else d for d in b.dependencies))
        a.state_binding=read_skew
        d,o=execute(core)
        self.assertEqual(a.effects,[],'atomic predicate check executed despite absent read snapshot')
        self.assertEqual(d.decision,DENY)
