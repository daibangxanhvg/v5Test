"""V0.4 — Composite execution binding.

Question: can the V0.3 composite failures (V03-A must-happen effects, V03-B evidence scope,
V03-H inter-step state) be solved by opaque, effect-bound execution units structured INSIDE
the existing ExecutionBinding, with no sixth object, no new binding category, no effect
ontology and no provider branch in the core?

Fixtures: fixtures/pubhub_units (PubHub publish_and_notify V3, two units, sequential state),
fixtures/triad (synthetic, three opaque units). The V0.3 PubHub provider/adapter/mapping are
reused unchanged. Tests named test_FINDING_V04_* assert that a weakness EXISTS.
"""
import copy
import dataclasses
import hashlib
import json
import os
import re
import unittest

from aaap import (
    ALLOW, CONFINED, DENY, EXEC_PARTIAL, INDEPENDENT_READBACK, PROVIDER_AUTHORITY, REQUIRE_CONFIRMATION,
    SELF_REPORTED, UNVERIFIED, VERIFIED, VIOLATION, C, CapabilityContract, ConfinedExecutor, Confirmation,
    EvidenceSource, ExecutionEvidence, ExecutionResult, GatewayCodes, ProviderOperation, ProviderTimeout, R,
    AuthorizationGrant,
)
from aaap.verifier import unit_table

from fixtures.calendar import world as cal_world
from fixtures.fakepay import world as pay_world
from fixtures.folio import world as n1
from fixtures.matrix import world as mx_world
from fixtures.pubhub import world as n2
from fixtures.pubhub.observer import NotificationObserver
from fixtures.pubhub_units import world as pu
from fixtures.pubhub_units.effector import NOTIFIED, PUBLISHED, UnitPubHubEffector, rev_token, unit_key
from fixtures.pubhub_units.observer import CompositeActivityObserver, UnitRecordObserver
from fixtures.triad import world as tri
from tests.harness import ROOT, load_contract, make_core

NOW = pu.NOW
DID = pu.DID
CORE_DIR = os.path.join(ROOT, "src", "aaap")
CORE_FILES = sorted(f for f in os.listdir(CORE_DIR) if f.endswith(".py"))
V03_CORE_FILES = ["__init__.py", "adapter.py", "authority.py", "canonical.py", "evaluators.py", "gateway.py",
                  "objects.py", "stores.py", "verifier.py"]


# ================================================================== helpers
def authorize(core, intent, did=DID, confirm=True):
    d = core.gateway.request_authorization(intent, did)
    c = None
    if confirm and d.decision == REQUIRE_CONFIRMATION:
        c = Confirmation.from_decision(d, "lam", NOW)
        d = core.gateway.request_authorization(intent, did, c)
    return d, c


def run(core, intent=None, did=DID, **kw):
    intent = intent or pu.intent()
    d, c = authorize(core, intent, did)
    return core.gateway.execute_confined(intent, did, c, d.grant, **kw)


def mint(core, intent=None, did=DID, **att):
    intent = intent or pu.intent()
    d, c = authorize(core, intent, did)
    assert d.decision == ALLOW, d.reasons
    if att:
        g = d.grant
        a = core.gateway.authority.attenuate(g, holder="agent-1", contract_id=g.contract_id, capability=g.capability,
                                             resource=copy.deepcopy(g.resource), request=copy.deepcopy(g.request),
                                             execution_id=g.execution_id, state_binding=g.state_binding, max_uses=1,
                                             **att)
    else:
        a = core.gateway.authority.attenuate_exact(d.grant, "agent-1")
    return d, c, a


def uop(cred, unit, **changes):
    u = cred.unit(unit)
    request = dict(u["request"]) if u else dict(cred.request)
    request.update(changes.pop("request", {}))
    base = dict(contract_id=cred.contract_id, capability=cred.capability, execution_id=cred.execution_id,
                request=request, unit=unit)
    base.update(changes)
    return ProviderOperation(**base)


def variant(contract, mutate, version=None):
    d = contract.to_dict()
    mutate(d)
    if version is not None:
        d["version"] = version
    return CapabilityContract.from_dict(json.loads(json.dumps(d)))


def v3(mutate=None, version=None):
    c = load_contract("pubhub_units", "contract_v3.json")
    return variant(c, mutate, version) if mutate else c


def unit(d, uid):
    return next(u for u in d["execution_units"] if u["unit_id"] == uid)


class Scripted(ConfinedExecutor):
    def __init__(self, script, identity="agent-1"):
        super().__init__(identity)
        self.script = script
        self.seen = []

    def execute_confined(self, intent, plan, credential, port):
        self.seen = self.script(self, intent, plan, credential, port)
        return self.seen


class Rewrite(EvidenceSource):
    """Wraps a real source and rewrites fields of its evidence (laundering / replay attempts)."""

    def __init__(self, inner, identity, fn=None, **changes):
        self.inner, self.identity, self.fn, self.changes = inner, identity, fn, changes

    def observe(self, intent, grant):
        ev = self.fn(intent) if self.fn else self.inner.observe(intent, grant)
        if ev is None:
            return None
        return dataclasses.replace(ev, source_identity=self.identity, **self.changes)


def statuses(out):
    return out.receipt.execution_result["status"], out.receipt.verification_status


def rows(out):
    return {u["unit_id"]: (u["execution"], u["verified"]) for u in out.receipt.units}


def details(out, code):
    return [r["detail"] for r in out.receipt.verification_reasons if r["code"] == code]


def rejected(out):
    return [r["detail"] for r in out.receipt.verification_reasons if r["code"] == R.EVIDENCE_REJECTED]


def calls(hub):
    return hub.publish_calls, hub.notify_calls


# ============================================================ C — composite
class C01_CompleteComposite(unittest.TestCase):
    def test_C1_both_units_executed_and_evidenced_is_verified(self):
        core, hub, contract, eff = pu.build_confined()
        out = run(core)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED), out.receipt.verification_reasons)
        self.assertEqual(rows(out), {"publish": ("SUCCESS", True), "notify": ("SUCCESS", True)})
        self.assertEqual(out.credential.units and tuple(u["unit_id"] for u in out.credential.units),
                         ("publish", "notify"))
        self.assertEqual(out.decision.grant.unit_ids(), ("publish", "notify"))
        # one boundary permit per unit, nothing else
        self.assertEqual([(e["allowed"], e["operation"].split("#")[1].split(":")[0]) for e in out.boundary_events],
                         [(True, "publish"), (True, "notify")])
        self.assertEqual(calls(hub), (1, 1))
        self.assertEqual(hub.outbox[0]["list"], "list:team-internal")
        self.assertEqual(out.confinement.status, CONFINED)


class C02_MissingSecondUnitEvidence(unittest.TestCase):
    def test_C2_evidence_for_publish_only_cannot_verify_the_composite(self):
        core, hub, contract, eff = pu.build_confined(observers=("publish",))
        out = run(core)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))
        self.assertEqual(rows(out), {"publish": ("SUCCESS", True), "notify": ("SUCCESS", False)})
        self.assertEqual(details(out, R.REQUIRED_UNIT_UNVERIFIED), ["notify:no_accepted_evidence"])
        self.assertEqual(len(hub.outbox), 1)          # it happened; it is not proven

    def test_C2b_notification_record_unavailable(self):
        core, hub, contract, eff = pu.build_confined()
        real = hub.record
        hub.record = lambda token, key: None if key.endswith("#notify") else real(token, key)
        out = run(core)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))
        self.assertIn(R.REQUIRED_UNIT_UNVERIFIED, out.receipt.codes())


class C03_FirstSucceedsSecondFails(unittest.TestCase):
    def test_C3_publish_succeeds_notify_fails_is_partial_never_verified(self):
        core, hub, contract, eff = pu.build_confined()
        hub.fail_notify = "503 relay unavailable"
        out = run(core)
        self.assertEqual(statuses(out), (EXEC_PARTIAL, UNVERIFIED))
        self.assertEqual(rows(out), {"publish": ("SUCCESS", True), "notify": ("FAILED", False)})
        self.assertIn(R.EXECUTION_PARTIAL, out.receipt.codes())
        self.assertEqual(details(out, R.REQUIRED_UNIT_NOT_EXECUTED), ["notify:FAILED"])
        self.assertEqual(out.receipt.observed_effects, (PUBLISHED,))
        self.assertEqual((hub.docs["p-7"]["visibility"], hub.unpublish_calls, hub.outbox), ("team", 0, []))
        again = core.gateway.execute_confined(pu.intent(), DID)             # settled, never retried
        self.assertTrue(again.replayed)
        self.assertIs(again.receipt, out.receipt)
        self.assertEqual(calls(hub), (1, 1))

    def test_C3b_second_unit_outcome_unknown_is_never_verified(self):
        class Timeout(UnitPubHubEffector):
            def perform_unit(self, credential, operation, precondition):
                if operation.unit == "notify":
                    raise ProviderTimeout("relay did not answer")
                return super().perform_unit(credential, operation, precondition)
        core, hub, contract, eff = pu.build_confined(effector=Timeout)
        out = run(core)
        self.assertEqual(statuses(out), ("UNKNOWN", UNVERIFIED))
        self.assertIn(R.OUTCOME_UNKNOWN, out.receipt.codes())


class C04_EvidenceLaundering(unittest.TestCase):
    """notify really executes, but its own evidence is missing; publish evidence is laundered."""

    def setUp(self):
        self.core, self.hub, self.contract, self.eff = pu.build_confined(observers=("publish",))
        self.pub = UnitRecordObserver(self.hub, pu.TOKENS, "publish")

    def relabel(self, ev_fn=None, **changes):
        return Rewrite(self.pub, "pubhub.example/launder-" + str(len(changes)), **changes)

    def test_C4a_relabelled_unit_claim_from_a_publish_scoped_source_is_rejected(self):
        src = self.relabel(covers_units=("notify",))
        self.core.gateway.register_evidence_source(pu.ADDRESS, src, PROVIDER_AUTHORITY, units=("publish",))
        out = run(self.core)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))
        self.assertTrue(any("unit_outside_source_scope:notify" in d for d in rejected(out)))
        self.assertEqual(rows(out)["notify"], ("SUCCESS", False))

    def test_C4b_publish_record_presented_as_notify_by_a_notify_scoped_source_is_rejected(self):
        # the deployer scoped the laundering source to notify; the content is still publish's
        src = self.relabel(covers_units=("notify",), unit_states=None)
        self.core.gateway.register_evidence_source(pu.ADDRESS, src, PROVIDER_AUTHORITY, units=("notify",))
        out = run(self.core)
        self.assertTrue(any("effect_outside_covered_units" in d for d in rejected(out)))
        self.assertNotEqual(out.receipt.verification_status, VERIFIED)

    def test_C4c_full_relabel_still_carries_publishs_state_and_breaks_continuity(self):
        def launder(intent):
            ev = self.pub.observe(intent, None)
            st = ev.unit_states["publish"]
            return dataclasses.replace(ev, covers_units=("notify",), observed_effects=(NOTIFIED,),
                                       unit_states={"notify": st})
        src = Rewrite(None, "pubhub.example/launder-full", fn=launder)
        self.core.gateway.register_evidence_source(pu.ADDRESS, src, PROVIDER_AUTHORITY, units=("notify",))
        out = run(self.core)
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.UNIT_STATE_MISMATCH, out.receipt.codes())          # applied rev 5, bound rev 6

    def test_C4d_one_item_claiming_both_units_needs_a_contract_joint_declaration(self):
        src = self.relabel(covers_units=("publish", "notify"))
        self.core.gateway.register_evidence_source(pu.ADDRESS, src, PROVIDER_AUTHORITY, units=("publish", "notify"))
        out = run(self.core)
        self.assertTrue(any("joint_evidence_undeclared" in d for d in rejected(out)))
        self.assertEqual(out.receipt.verification_status, UNVERIFIED)


class C05_CrossExecutionReplay(unittest.TestCase):
    def test_C5_notify_evidence_of_E1_cannot_verify_notify_of_E2(self):
        core, hub, contract, eff = pu.build_confined(observers=("publish",))
        notify_src = UnitRecordObserver(hub, pu.TOKENS, "notify")
        e1 = pu.intent()
        core.gateway.register_evidence_source(pu.ADDRESS, notify_src, PROVIDER_AUTHORITY, units=("notify",))
        self.assertEqual(statuses(run(core, e1)), ("SUCCESS", VERIFIED))
        e2 = pu.intent(execution_id="exec-n2-2", intent_id="int-n2-2")
        hub.fail_notify = "503"                                             # E2's notify really fails
        old = lambda intent: notify_src.observe(e1, None)
        cases = {
            "as-is": Rewrite(None, "pubhub.example/replay-1", fn=old),
            "ids rewritten": Rewrite(None, "pubhub.example/replay-2", fn=old, execution_id=e2.execution_id,
                                     intent_id=e2.intent_id),
        }
        for src in cases.values():
            core.gateway.register_evidence_source(pu.ADDRESS, src, PROVIDER_AUTHORITY, units=("notify",))
        out = run(core, e2)
        rj = rejected(out)
        self.assertTrue(any("execution_id_mismatch" in d for d in rj))
        self.assertTrue(any("lineage_mismatch" in d for d in rj))
        self.assertEqual(statuses(out), (EXEC_PARTIAL, UNVERIFIED))
        self.assertEqual(rows(out)["notify"], ("FAILED", False))

    def test_C5b_fully_forged_replay_contradicts_the_boundary_record(self):
        core, hub, contract, eff = pu.build_confined()
        e1 = pu.intent()
        run(core, e1)
        notify_src = UnitRecordObserver(hub, pu.TOKENS, "notify")
        e2 = pu.intent(execution_id="exec-n2-2", intent_id="int-n2-2")
        d, c = authorize(core, e2)
        forged = Rewrite(None, "pubhub.example/replay-3", fn=lambda i: notify_src.observe(e1, None),
                         execution_id=e2.execution_id, intent_id=e2.intent_id, grant_id=d.grant.grant_id)
        core.gateway.register_evidence_source(pu.ADDRESS, forged, PROVIDER_AUTHORITY, units=("notify",))
        hub.fail_notify = "503"
        out = core.gateway.execute_confined(e2, DID, c, d.grant)
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.UNIT_EFFECT_WITHOUT_PERMIT, out.receipt.codes())


class C06_CrossActionReplay(unittest.TestCase):
    def test_C6_evidence_from_another_intent_and_grant_is_rejected(self):
        core, hub, contract, eff = pu.build_confined(observers=("publish",))
        hub.add("p-8", "Other plan", visibility="private")
        notify_src = UnitRecordObserver(hub, pu.TOKENS, "notify")
        a = pu.intent()
        run(core, a)                                                        # action A completes
        b = pu.intent(document_id="p-8", execution_id="exec-b", intent_id="int-b")
        d, c = authorize(core, b)
        hub.fail_notify = "503"
        from_a = lambda i: notify_src.observe(a, None)
        core.gateway.register_evidence_source(pu.ADDRESS, Rewrite(None, "pubhub.example/xa-1", fn=from_a,
                                                                  execution_id=b.execution_id, intent_id=b.intent_id),
                                              PROVIDER_AUTHORITY, units=("notify",))
        core.gateway.register_evidence_source(pu.ADDRESS, Rewrite(None, "pubhub.example/xa-2", fn=from_a,
                                                                  execution_id=b.execution_id, intent_id=b.intent_id,
                                                                  grant_id=d.grant.grant_id),
                                              PROVIDER_AUTHORITY, units=("notify",))
        out = core.gateway.execute_confined(b, DID, c, d.grant)
        self.assertTrue(any("lineage_mismatch" in x for x in rejected(out)))
        self.assertIn(R.EVIDENCE_SUBJECT_MISMATCH, out.receipt.codes())     # p-7 evidence for a p-8 action
        self.assertNotEqual(out.receipt.verification_status, VERIFIED)

    def test_C6b_evidence_in_the_V03_shape_from_the_V03_contract_carries_no_unit_claim(self):
        core, hub, contract, eff = pu.build_confined(observers=("publish",))
        core.gateway.register_evidence_source(pu.ADDRESS, NotificationObserver(hub, pu.TOKENS), PROVIDER_AUTHORITY,
                                              units=("notify",))
        out = run(core)
        self.assertEqual(rows(out)["notify"], ("SUCCESS", False))           # V0.3 record key differs: nothing seen
        legacy = Rewrite(None, "pubhub.example/legacy-shape", fn=lambda i: ExecutionEvidence(
            evidence_id="x", execution_id=i.execution_id, intent_id=i.intent_id, source_identity="x",
            provenance=PROVIDER_AUTHORITY, observed_subject="p-7", observed_state={}, observed_effects=(NOTIFIED,)))
        core2, hub2, _, _ = pu.build_confined(observers=("publish",))
        core2.gateway.register_evidence_source(pu.ADDRESS, legacy, PROVIDER_AUTHORITY, units=("notify",))
        out2 = run(core2)
        self.assertTrue(any("no_unit_claim" in d for d in rejected(out2)))
        self.assertEqual(out2.receipt.verification_status, UNVERIFIED)


class C07_UndeclaredUnit(unittest.TestCase):
    def test_C7a_executor_cannot_perform_a_unit_outside_the_binding(self):
        def extra(self_, intent, plan, cred, port):
            return [port.invoke(cred, uop(cred, "publish")),
                    port.invoke(cred, uop(cred, "unpublish_other")),                       # undeclared unit
                    port.invoke(cred, uop(cred, None, request=dict(cred.request))),          # whole op, no unit
                    port.invoke(cred, uop(cred, "notify"))]
        ex = Scripted(extra)
        core, hub, contract, eff = pu.build_confined(executor=ex)
        out = run(core)
        self.assertEqual([(s.allowed, s.reason) for s in ex.seen],
                         [(True, None), (False, C.UNIT_NOT_AUTHORIZED), (False, C.UNIT_UNSPECIFIED), (True, None)])
        self.assertEqual((hub.unpublish_calls, eff.calls), (0, 2))
        self.assertEqual(out.receipt.verification_status, VIOLATION)        # prevented, and reported
        self.assertEqual(out.receipt.codes().count(R.OUT_OF_SCOPE_ATTEMPT), 2)

    def test_C7b_effector_performing_an_unpermitted_unit_effect_is_detected(self):
        """Provider side (TCB) does more than the permitted unit: not preventable by the boundary,
        but the composite cannot claim VERIFIED when an authoritative source sees the effect."""
        class Eager(UnitPubHubEffector):
            def perform_unit(self, credential, operation, precondition):
                r = super().perform_unit(credential, operation, precondition)
                if operation.unit == "publish":
                    self.hub.notify_if(self.tokens[credential.principal], "list:team-internal", "p-7",
                                       unit_key(credential.execution_id, "notify"), None,
                                       {"intent_id": credential.intent_id, "grant_id": credential.grant_id,
                                        "unit": "notify"})
                return r
        core, hub, contract, eff = pu.build_confined(effector=Eager)
        d, c, a = mint(core, units=("publish",))                            # credential covers publish only
        port = core.gateway.authority.port("agent-1")
        self.assertTrue(port.invoke(a.credential, uop(a.credential, "publish")).allowed)
        self.assertEqual(port.invoke(a.credential, uop(a.credential, "notify")).reason, C.UNIT_NOT_AUTHORIZED)
        self.assertEqual(len(hub.outbox), 1)                                 # the effector did it anyway
        result = core.gateway.authority.result_of(a.credential.credential_id)
        evidence = [s.observe(pu.intent(), d.grant) for s in core.gateway._sources[pu.ADDRESS]]
        receipt = core.verifier.verify_execution(pu.intent(), d, core.gateway._evidence(pu.intent())[0],
                                                 d.grant.request, result, [e for e in evidence if e],
                                                 (), core.gateway.authority.unit_records(a.credential.credential_id))
        self.assertEqual(receipt.verification_status, VIOLATION)
        self.assertIn(R.UNIT_EFFECT_WITHOUT_PERMIT, receipt.codes())


class C08_MissingRequiredUnitDeclaration(unittest.TestCase):
    def test_C8a_effect_not_assigned_to_any_unit_fails_closed(self):
        c = v3(lambda d: d["execution_units"].pop(1), version="3-incomplete")
        core, hub, _, eff = pu.build_confined(contract=c)
        out = run(core)
        self.assertEqual(out.decision.decision, DENY)
        self.assertIn("not assigned to any execution unit", out.decision.reasons[0]["detail"])
        self.assertEqual((calls(hub), eff.calls), ((0, 0), 0))

    def test_C8b_unit_without_explicit_required_flag_is_not_defaulted(self):
        c = v3(lambda d: unit(d, "notify").pop("required"), version="3-noflag")
        core, hub, _, eff = pu.build_confined(contract=c)
        self.assertEqual(run(core).decision.codes(), [R.MALFORMED_CONTRACT])

    def test_C8c_binding_generation_that_omits_a_unit_is_refused_before_any_effect(self):
        core, hub, contract, eff = pu.build_confined()
        core.verifier._execution_units = lambda c, p: (unit_table(c, p)[0][:1], None)     # buggy generator
        d, c = authorize(core, pu.intent())
        self.assertEqual(d.grant.unit_ids(), ("publish",))                                 # grant was issued
        out = core.gateway.execute_confined(pu.intent(), DID, c, d.grant)
        self.assertEqual(out.decision.codes(), [GatewayCodes.ATTENUATION_REFUSED])
        self.assertIn(C.EXECUTION_BINDING_INCONSISTENT, out.decision.reasons[0]["detail"])
        self.assertEqual((calls(hub), eff.calls), ((0, 0), 0))

    def test_C8c2_a_grant_from_a_faulty_generator_is_refused_at_reauthorization(self):
        core, hub, contract, eff = pu.build_confined()
        core.verifier._execution_units = lambda c, p: (unit_table(c, p)[0][:1], None)
        d, c = authorize(core, pu.intent())
        del core.verifier._execution_units                                                 # generator fixed
        out = core.gateway.execute_confined(pu.intent(), DID, c, d.grant)
        self.assertEqual(out.decision.decision, DENY)
        self.assertEqual([r["detail"] for r in out.decision.reasons if r["code"] == R.GRANT_MISMATCH], ["execution_units"])
        self.assertEqual(calls(hub), (0, 0))

    def test_C8d_even_past_the_boundary_check_an_incomplete_binding_never_verifies(self):
        core, hub, contract, eff = pu.build_confined()
        core.verifier._execution_units = lambda c, p: (unit_table(c, p)[0][:1], None)
        core.verifier.execution_binding_problem = lambda g: None                           # check disabled too
        out = run(core)
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.EXECUTION_BINDING_MISMATCH, out.receipt.codes())
        self.assertEqual(details(out, R.REQUIRED_UNIT_NOT_EXECUTED), ["notify:NOT_EXECUTED"])

    def test_C8e_legacy_multi_effect_contract_without_units_is_denied_under_deployer_strict_policy(self):
        legacy = variant(load_contract("pubhub", "contract_v2.json"), lambda d: d["verification"].pop("required_effects"))
        core, hub, _, eff = n2.build_confined(contract=legacy, observers=("publish",))
        core.verifier.require_declared_composition = True
        out = run(core, n2.intent(), "dlg-pub-1")
        self.assertEqual(out.decision.codes(), [R.COMPOSITION_UNDECLARED])
        self.assertEqual(calls(hub), (0, 0))


class C09_UnknownCriticalUnitStructure(unittest.TestCase):
    CASES = {
        "unknown unit key": lambda d: unit(d, "notify").update(compensation={"undo": "retract"}),
        "unknown state value": lambda d: unit(d, "notify").update(state="eventual"),
        "unknown state structure": lambda d: unit(d, "notify").update(state={"from_unit": "publish", "lag": 2}),
        "unknown evidence key": lambda d: unit(d, "notify").update(evidence={"quorum": 2}),
        "self-reported evidence requirement": lambda d: unit(d, "notify").update(evidence={"provenance": [SELF_REPORTED]}),
        "required not bool": lambda d: unit(d, "notify").update(required="yes"),
        "unit effect not declared": lambda d: unit(d, "notify").update(effects=["sms_sent"]),
        "effect in two units": lambda d: unit(d, "notify").update(effects=[NOTIFIED, PUBLISHED]),
        "duplicate unit id": lambda d: unit(d, "notify").update(unit_id="publish", after=[], state="unbound"),
        "after names a later unit": lambda d: unit(d, "publish").update(after=["notify"]),
        "after names an unknown unit": lambda d: unit(d, "notify").update(after=["review"]),
        "state from a non-predecessor": lambda d: unit(d, "notify").update(after=[]),
        "joint evidence one-sided": lambda d: unit(d, "notify").update(evidence={"joint_with": ["publish"]}),
        "unknown request field": lambda d: unit(d, "notify").update(request_fields=["document_ref", "cc"]),
        "request field carried by no unit": lambda d: [unit(d, u).update(request_fields=["document_ref"])
                                                       for u in ("publish", "notify")],
        "subject not a plan ref of the unit": lambda d: unit(d, "notify").update(subject="fact:owner"),
        "post invariant names a pre invariant": lambda d: unit(d, "notify").update(post_invariants=["preserve_title"]),
        "required depends on optional": lambda d: unit(d, "publish").update(required=False),
        "no required unit": lambda d: [unit(d, u).update(required=False) for u in ("publish", "notify")],
        "units not a list": lambda d: d.update(execution_units={"publish": {}}),
        "empty unit list": lambda d: d.update(execution_units=[]),
        "required_effects contradicts units": lambda d: d["verification"].update(required_effects=[PUBLISHED]),
        "state without a declared state binding": lambda d: d["verification"].pop("state_binding"),
        "units declared noncritical": lambda d: d.update(noncritical_extensions=["execution_units"]),
        "unbound post invariant": lambda d: d["invariants"].append(
            {"id": "post_check", "evaluator": "core.preserve_fields", "phase": "post", "params": {"fields": ["title"]}}),
    }

    def test_C9_every_unknown_or_malformed_unit_structure_fails_closed(self):
        for name, mutate in self.CASES.items():
            with self.subTest(case=name):
                core, hub, _, eff = pu.build_confined(contract=v3(mutate, version="3-x"))
                out = run(core)
                self.assertEqual(out.decision.decision, DENY)
                self.assertEqual(out.decision.codes(), [R.MALFORMED_CONTRACT])
                self.assertEqual((calls(hub), eff.calls), ((0, 0), 0))


def optional_notify(d):
    unit(d, "notify")["required"] = False


class C10_ExplicitOptionalUnit(unittest.TestCase):
    def test_C10a_absent_optional_unit_does_not_prevent_required_success(self):
        core, hub, _, eff = pu.build_confined(contract=v3(optional_notify, "3-opt"))
        hub.fail_notify = "503"
        out = run(core)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED), out.receipt.verification_reasons)
        self.assertEqual(rows(out), {"publish": ("SUCCESS", True), "notify": ("FAILED", False)})
        core2, hub2, _, _ = pu.build_confined(contract=v3(optional_notify, "3-opt"))
        d, c, a = mint(core2, units=("publish",))                           # credential without the optional unit
        self.assertEqual(a.credential.effects, (PUBLISHED,))
        port = core2.gateway.authority.port("agent-1")
        port.invoke(a.credential, uop(a.credential, "publish"))
        self.assertEqual(core2.gateway.authority.result_of(a.credential.credential_id).status, "SUCCESS")

    def test_C10b_optional_unit_cannot_widen_authority(self):
        def widen(self_, intent, plan, cred, port):
            return [port.invoke(cred, uop(cred, "publish")),
                    port.invoke(cred, uop(cred, "notify", request={"audience": "public"})),
                    port.invoke(cred, uop(cred, "notify_public"))]
        ex = Scripted(widen)
        core, hub, _, eff = pu.build_confined(contract=v3(optional_notify, "3-opt"), executor=ex)
        run(core)
        self.assertEqual([s.reason for s in ex.seen[1:]], [C.ARGUMENTS_NOT_AUTHORIZED, C.UNIT_NOT_AUTHORIZED])
        self.assertEqual(hub.outbox, [])

    def test_C10c_optional_unit_cannot_hide_a_required_or_unproven_effect(self):
        # same effect in a required and an optional unit; a required unit after an optional one
        bad = [v3(lambda d: d["execution_units"].append({"unit_id": "shadow", "required": False, "effects": [PUBLISHED],
                                                         "request_fields": ["document_ref"], "state": "unbound"}), "3-s"),
               v3(lambda d: (unit(d, "publish").update(required=False)), "3-s2")]
        for c in bad:
            core, hub, _, eff = pu.build_confined(contract=c)
            self.assertEqual(run(core).decision.codes(), [R.MALFORMED_CONTRACT])
        # an optional effect that HAPPENED without proof keeps the composite UNVERIFIED
        core, hub, _, eff = pu.build_confined(contract=v3(optional_notify, "3-opt"), observers=("publish",))
        out = run(core)
        self.assertEqual(len(hub.outbox), 1)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))
        self.assertEqual(details(out, R.EXECUTED_UNIT_UNVERIFIED), ["notify:no_accepted_evidence"])


def joint(d):
    unit(d, "publish")["evidence"] = {"joint_with": ["notify"]}
    unit(d, "notify")["evidence"] = {"joint_with": ["publish"]}


class C11_OneEvidenceCoversTwoUnits(unittest.TestCase):
    def test_C11_declared_joint_evidence_verifies_both_units(self):
        core, hub, _, eff = pu.build_confined(contract=v3(joint, "3-joint"), observers=())
        core.gateway.register_evidence_source(pu.ADDRESS, CompositeActivityObserver(hub, pu.TOKENS, ("publish", "notify")),
                                              PROVIDER_AUTHORITY, units=("publish", "notify"))
        out = run(core)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED), out.receipt.verification_reasons)
        ids = {u["unit_id"]: u["evidence"] for u in out.receipt.units}
        self.assertEqual(ids["publish"], ids["notify"])                      # one item, two units
        self.assertEqual(len(ids["publish"]), 1)

    def test_C11b_same_item_without_the_contract_declaration_is_rejected(self):
        core, hub, _, eff = pu.build_confined(observers=())
        core.gateway.register_evidence_source(pu.ADDRESS, CompositeActivityObserver(hub, pu.TOKENS, ("publish", "notify")),
                                              PROVIDER_AUTHORITY, units=("publish", "notify"))
        out = run(core)
        self.assertTrue(any("joint_evidence_undeclared" in d for d in rejected(out)))
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))

    def test_C11c_joint_item_from_a_source_scoped_to_one_unit_is_rejected(self):
        core, hub, _, eff = pu.build_confined(contract=v3(joint, "3-joint"), observers=())
        core.gateway.register_evidence_source(pu.ADDRESS, CompositeActivityObserver(hub, pu.TOKENS, ("publish", "notify")),
                                              PROVIDER_AUTHORITY, units=("publish",))
        out = run(core)
        self.assertTrue(any("unit_outside_source_scope:notify" in d for d in rejected(out)))


class C12_WrongEvidenceAuthority(unittest.TestCase):
    def test_C12a_authentic_source_not_scoped_to_the_unit_cannot_verify_it(self):
        core, hub, _, eff = pu.build_confined(observers=("publish",))
        core.gateway.register_evidence_source(pu.ADDRESS, UnitRecordObserver(hub, pu.TOKENS, "notify"),
                                              PROVIDER_AUTHORITY, units=("publish",))
        out = run(core)
        self.assertTrue(any("unit_outside_source_scope:notify" in d for d in rejected(out)))
        self.assertEqual(rows(out)["notify"], ("SUCCESS", False))

    def test_C12b_unscoped_authoritative_source_attests_no_unit(self):
        core, hub, _, eff = pu.build_confined(observers=("publish",))
        core.gateway.register_evidence_source(pu.ADDRESS, UnitRecordObserver(hub, pu.TOKENS, "notify"),
                                              PROVIDER_AUTHORITY)                    # no unit scope (V0.3 style)
        out = run(core)
        self.assertTrue(any("unit_outside_source_scope" in d for d in rejected(out)))
        self.assertEqual(out.receipt.verification_status, UNVERIFIED)

    def test_C12c_unit_evidence_requirement_names_the_authoritative_provenance(self):
        stronger = v3(lambda d: unit(d, "notify").update(evidence={"provenance": [INDEPENDENT_READBACK]}), "3-ir")
        core, hub, _, eff = pu.build_confined(contract=stronger)
        out = run(core)
        self.assertEqual(rows(out)["notify"], ("SUCCESS", False))           # provider record is not enough here
        self.assertEqual(out.receipt.verification_status, UNVERIFIED)
        core2, hub2, _, _ = pu.build_confined(contract=stronger, observers=("publish",))
        reader = UnitRecordObserver(hub2, pu.TOKENS, "notify", identity="reader.example/inbox-probe")
        core2.gateway.register_evidence_source(pu.ADDRESS, reader, INDEPENDENT_READBACK, units=("notify",))
        reader_ev = lambda real: (lambda i, g: dataclasses.replace(real(i, g), provenance=INDEPENDENT_READBACK))
        reader.observe = reader_ev(reader.observe)
        self.assertEqual(statuses(run(core2)), ("SUCCESS", VERIFIED))


class C13_LegacyPathCannotVerifyUnits(unittest.TestCase):
    def test_C13_unconfined_adapter_execution_of_a_unit_contract_is_unverified(self):
        core, hub, contract = pu.build()
        d, c = authorize(core, pu.intent())
        out = core.gateway.execute(pu.intent(), DID, c, d.grant)
        self.assertEqual(out.receipt.verification_status, UNVERIFIED)
        self.assertIn(R.UNIT_EXECUTION_UNOBSERVED, out.receipt.codes())


class C14_PerUnitPostInvariant(unittest.TestCase):
    """V03-C: a post invariant over the document ran on every sub-effect observation (over-strict).
    With units it runs only on evidence of the units the contract binds it to."""

    def bound(self, d):
        d["invariants"][0]["phase"] = "both"
        unit(d, "publish")["post_invariants"] = ["preserve_title"]

    def test_C14_post_invariant_bound_to_its_unit_is_verifiable(self):
        core, hub, _, eff = pu.build_confined(contract=v3(self.bound, "3-post"))
        out = run(core)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED), out.receipt.verification_reasons)

    def test_C14b_and_still_catches_a_violation_on_that_unit(self):
        class Retitle(UnitPubHubEffector):
            def perform_unit(self, credential, operation, precondition):
                r = super().perform_unit(credential, operation, precondition)
                if operation.unit == "publish":
                    rec = self.hub._records[unit_key(credential.execution_id, "publish")]
                    rec["result"]["title"] = "Launch plan (edited)"
                return r
        core, hub, _, eff = pu.build_confined(contract=v3(self.bound, "3-post"), effector=Retitle)
        out = run(core)
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.INVARIANT_VIOLATED, out.receipt.codes())


class C15_EvidenceMustShowTheUnitsEffect(unittest.TestCase):
    def test_C15_unit_claim_without_the_units_effect_does_not_verify_it(self):
        core, hub, _, eff = pu.build_confined(observers=("publish",))
        inner = UnitRecordObserver(hub, pu.TOKENS, "notify")
        core.gateway.register_evidence_source(pu.ADDRESS, Rewrite(inner, inner.identity, observed_effects=()),
                                              PROVIDER_AUTHORITY, units=("notify",))
        out = run(core)
        self.assertEqual(rows(out)["notify"], ("SUCCESS", False))
        self.assertTrue(any("effects_unobserved" in d for d in details(out, R.REQUIRED_UNIT_UNVERIFIED)))


class C16_JointEvidenceAcrossSubjects(unittest.TestCase):
    def test_C16_one_item_cannot_cover_units_about_different_resources(self):
        from fixtures.triad.observer import TriRecordObserver

        def j(d):
            unit(d, "a1")["evidence"] = {"joint_with": ["c3"]}
            unit(d, "c3")["evidence"] = {"joint_with": ["a1"]}
        core, store, _, _ = tri.build_confined(contract=variant(load_contract("triad", "contract_v1.json"), j, "1-j"),
                                               observers=("a1", "b2"))
        a1 = TriRecordObserver(store, tri.TOKENS, "a1")

        def both(intent):
            ev = a1.observe(intent, None)
            return dataclasses.replace(ev, covers_units=("a1", "c3"), observed_effects=("x.e1", "x.e3"),
                                       unit_states={"a1": ev.unit_states["a1"], "c3": {"applied": None, "established": None}})
        core.gateway.register_evidence_source(tri.ADDRESS, Rewrite(None, "triad.example/joint", fn=both),
                                              PROVIDER_AUTHORITY, units=("a1", "c3"))
        out = run(core, tri.intent(), tri.DID)
        self.assertTrue(any("joint_evidence_spans_subjects" in d for d in rejected(out)))
        self.assertEqual(rows(out)["c3"], ("SUCCESS", False))


# ============================================================ S — state continuity
class S1_SequentialStateBinding(unittest.TestCase):
    def test_S1a_second_unit_is_bound_to_the_state_the_first_produced(self):
        core, hub, _, eff = pu.build_confined()
        out = run(core)
        recs = core.gateway.authority.unit_records(out.credential.credential_id)
        self.assertEqual(out.decision.grant.state_binding.version_value, "5")         # V1
        self.assertEqual(recs["publish"]["precondition"], rev_token("p-7", 5))
        self.assertEqual(recs["publish"]["established"], rev_token("p-7", 6))         # V2
        self.assertEqual(recs["notify"]["precondition"], rev_token("p-7", 6))         # bound to V2
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))

    def test_S1b_state_changed_between_units_the_second_unit_cannot_execute(self):
        core, hub, _, eff = pu.build_confined()
        hub.before_notify = lambda: hub.external_edit("p-7", title="Launch plan (withdrawn)")
        out = run(core)
        self.assertEqual(statuses(out), (EXEC_PARTIAL, UNVERIFIED))
        self.assertEqual(rows(out)["notify"], ("PRECONDITION_FAILED", False))
        self.assertEqual(hub.outbox, [])

    def test_S1c_second_unit_cannot_run_against_the_stale_authorization_state(self):
        class Stale(UnitPubHubEffector):
            def perform_unit(self, credential, operation, precondition):
                return super().perform_unit(credential, operation, credential.state_binding)   # V1 for both
        core, hub, _, eff = pu.build_confined(effector=Stale)
        out = run(core)
        self.assertEqual(rows(out)["notify"], ("PRECONDITION_FAILED", False))
        self.assertEqual(hub.outbox, [])


class S1d_PredecessorFails(unittest.TestCase):
    def test_S1d_failed_first_unit_stops_the_dependent_one_without_blaming_the_executor(self):
        core, hub, _, eff = pu.build_confined()
        d, c = authorize(core, pu.intent())
        hub.external_edit("p-7", title="Launch plan v2")                   # state moves after authorization
        g = d.grant
        # re-authorization would now refuse; drive the boundary directly with the minted credential
        att = core.gateway.authority.attenuate_exact(g, "agent-1")
        port = core.gateway.authority.port("agent-1")
        ConfinedExecutor("agent-1").execute_confined(pu.intent(), g.request, att.credential, port)
        recs = core.gateway.authority.unit_records(att.credential.credential_id)
        self.assertEqual(list(recs), ["publish"])                          # notify never attempted
        self.assertEqual(recs["publish"]["status"], "PRECONDITION_FAILED")
        self.assertEqual(core.gateway.authority.blocked_attempts(att.credential.credential_id), [])
        self.assertEqual(core.gateway.authority.result_of(att.credential.credential_id).status, "PRECONDITION_FAILED")
        self.assertEqual(calls(hub), (1, 0))


class S2_StateSubstitution(unittest.TestCase):
    def test_S2a_established_state_of_another_resource_is_not_used(self):
        class Other(UnitPubHubEffector):
            def perform_unit(self, credential, operation, precondition):
                r = super().perform_unit(credential, operation, precondition)
                return dataclasses.replace(r, established_state=rev_token("p-9", 1)) if operation.unit == "publish" else r
        core, hub, _, eff = pu.build_confined(effector=Other)
        out = run(core)
        self.assertEqual(rows(out)["notify"], ("PRECONDITION_FAILED", False))
        self.assertIn("not the bound subject", out.receipt.execution_result["detail"])
        self.assertEqual(hub.notify_calls, 0)                               # never attempted

    def test_S2b_evidence_attesting_another_units_state_is_a_violation(self):
        core, hub, _, eff = pu.build_confined(observers=("publish",))
        inner = UnitRecordObserver(hub, pu.TOKENS, "notify")

        def swapped(intent):
            ev = inner.observe(intent, None)
            return dataclasses.replace(ev, unit_states={"notify": {"applied": rev_token("p-7", 5),
                                                                   "established": rev_token("p-7", 6)}})
        core.gateway.register_evidence_source(pu.ADDRESS, Rewrite(None, inner.identity, fn=swapped),
                                              PROVIDER_AUTHORITY, units=("notify",))
        out = run(core)
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.UNIT_STATE_MISMATCH, out.receipt.codes())

    def test_S2c_the_executor_cannot_supply_a_precondition(self):
        def supply(self_, intent, plan, cred, port):
            return [port.invoke(cred, uop(cred, "publish", request={"if_rev": 99}))]
        ex = Scripted(supply)
        core, hub, _, eff = pu.build_confined(executor=ex)
        run(core)
        self.assertEqual(ex.seen[0].reason, C.ARGUMENTS_NOT_AUTHORIZED)
        self.assertNotIn("precondition", {f.name for f in dataclasses.fields(ProviderOperation)})


class S3_SkipPredecessor(unittest.TestCase):
    def test_S3_dependent_unit_without_its_predecessor_is_blocked(self):
        ex = Scripted(lambda s, i, p, cred, port: [port.invoke(cred, uop(cred, "notify"))])
        core, hub, _, eff = pu.build_confined(executor=ex)
        out = run(core)
        self.assertEqual((ex.seen[0].allowed, ex.seen[0].reason), (False, C.UNIT_ORDER))
        self.assertEqual((calls(hub), hub.outbox), ((0, 0), []))
        self.assertEqual(out.receipt.verification_status, VIOLATION)


class S4_ReorderDependentUnits(unittest.TestCase):
    def test_S4_dependent_unit_first_is_blocked_and_never_precedes_its_predecessor(self):
        ex = Scripted(lambda s, i, p, cred, port: [port.invoke(cred, uop(cred, "notify")),
                                                   port.invoke(cred, uop(cred, "publish"))])
        core, hub, _, eff = pu.build_confined(executor=ex)
        out = run(core)
        self.assertEqual([(s.allowed, s.reason) for s in ex.seen], [(False, C.UNIT_ORDER), (True, None)])
        self.assertEqual(hub.outbox, [])
        self.assertEqual(statuses(out), (EXEC_PARTIAL, VIOLATION))


def independent(d):
    n = unit(d, "notify")
    n["after"], n["state"] = [], "unbound"


class S5_IndependentUnits(unittest.TestCase):
    def test_S5_core_does_not_invent_an_order(self):
        ex = Scripted(lambda s, i, p, cred, port: [port.invoke(cred, uop(cred, "notify")),
                                                   port.invoke(cred, uop(cred, "publish"))])
        core, hub, _, eff = pu.build_confined(contract=v3(independent, "3-ind"), executor=ex)
        out = run(core)
        self.assertEqual([s.allowed for s in ex.seen], [True, True])
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED), out.receipt.verification_reasons)

    def test_S5b_synthetic_independent_unit_may_run_first(self):
        ex = Scripted(lambda s, i, p, cred, port: [port.invoke(cred, uop(cred, u)) for u in ("c3", "a1", "b2")])
        core, store, _, eff = tri.build_confined(executor=ex)
        out = run(core, tri.intent(), tri.DID)
        self.assertEqual([s.allowed for s in ex.seen], [True, True, True])
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))


class S6_IntermediateStateUnavailable(unittest.TestCase):
    def test_S6a_provider_not_exposing_intermediate_state_blocks_the_dependent_unit(self):
        core, hub, _, eff = pu.build_confined()
        hub.expose_versions = False
        out = run(core)
        self.assertEqual(statuses(out), (EXEC_PARTIAL, UNVERIFIED))
        self.assertEqual(rows(out)["notify"], ("PRECONDITION_FAILED", False))
        self.assertIn("intermediate state unavailable", out.receipt.execution_result["detail"])
        self.assertEqual((hub.notify_calls, hub.outbox), (0, []))
        self.assertNotEqual(out.receipt.verification_status, VIOLATION)    # the honest executor is not blamed

    def test_S6b_produced_state_not_attested_by_evidence_is_not_invented(self):
        core, hub, _, eff = pu.build_confined(observers=("notify",))
        inner = UnitRecordObserver(hub, pu.TOKENS, "publish")

        def blind(intent):
            ev = inner.observe(intent, None)
            return dataclasses.replace(ev, unit_states={"publish": {"applied": rev_token("p-7", 5), "established": None}})
        core.gateway.register_evidence_source(pu.ADDRESS, Rewrite(None, inner.identity, fn=blind),
                                              PROVIDER_AUTHORITY, units=("publish",))
        out = run(core)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))
        self.assertTrue(any("notify" in d for d in details(out, R.UNIT_STATE_UNATTESTED)))


class S6c_PreconditionInvisibleToTheSource(unittest.TestCase):
    def test_S6c_a_source_that_cannot_see_the_applied_state_leaves_the_unit_unattested(self):
        core, hub, _, eff = pu.build_confined(observers=("publish",))
        inner = UnitRecordObserver(hub, pu.TOKENS, "notify")
        core.gateway.register_evidence_source(pu.ADDRESS, Rewrite(inner, inner.identity, unit_states=None),
                                              PROVIDER_AUTHORITY, units=("notify",))
        out = run(core)
        self.assertEqual(statuses(out), ("SUCCESS", UNVERIFIED))           # not proven, not a breach
        self.assertTrue(any(R.UNIT_STATE_UNATTESTED in d for d in details(out, R.REQUIRED_UNIT_UNVERIFIED)))


class S6d_ContinuityAttestedOnlyByAnAuthoritativeSource(unittest.TestCase):
    def test_S6d_a_non_authoritative_source_cannot_supply_the_produced_state(self):
        stronger = v3(lambda d: unit(d, "publish").update(evidence={"provenance": [INDEPENDENT_READBACK]}), "3-irp")
        core, hub, _, eff = pu.build_confined(contract=stronger)
        out = run(core)                       # the publish record is PROVIDER_AUTHORITY: not enough for publish
        self.assertEqual(rows(out)["publish"], ("SUCCESS", False))
        self.assertTrue(any("notify" in d for d in details(out, R.UNIT_STATE_UNATTESTED)))
        self.assertEqual(rows(out)["notify"], ("SUCCESS", False))


# ============================================================ A — authority
class A1_UnitLevelNarrowing(unittest.TestCase):
    def test_A1_credential_for_one_unit_does_not_authorize_the_other(self):
        core, hub, _, eff = pu.build_confined()
        d, c, a = mint(core, units=("publish",))
        cred = a.credential
        self.assertEqual(([u["unit_id"] for u in cred.units], cred.effects), (["publish"], (PUBLISHED,)))
        port = core.gateway.authority.port("agent-1")
        self.assertTrue(port.invoke(cred, uop(cred, "publish")).allowed)
        self.assertEqual(port.invoke(cred, uop(cred, "notify")).reason, C.UNIT_NOT_AUTHORIZED)
        self.assertEqual(hub.outbox, [])
        self.assertEqual(core.gateway.authority.result_of(cred.credential_id).status, EXEC_PARTIAL)

    def test_A1b_unit_subsets_cannot_widen(self):
        core, hub, _, eff = pu.build_confined()
        for units, effects, code in ((("publish", "archive"), None, C.WIDENS_UNITS), ((), None, C.WIDENS_UNITS),
                                     (("publish",), (PUBLISHED, NOTIFIED), C.WIDENS_EFFECTS)):
            core2, _, _, _ = pu.build_confined()
            att = {"units": units} if effects is None else {"units": units, "effects": effects}
            d, c, a = mint(core2, **att)
            self.assertIn(code, a.codes())
        core3, _, _, _ = n2.build_confined()
        d, c, a = mint(core3, n2.intent(), "dlg-pub-1", units=("publish",))            # V0.3 grant: no units
        self.assertIn(C.WIDENS_UNITS, a.codes())


class A2_UnitInjection(unittest.TestCase):
    def test_A2_injected_unit_in_operation_credential_or_grant_is_refused(self):
        core, hub, _, eff = pu.build_confined()
        d, c, a = mint(core)
        port = core.gateway.authority.port("agent-1")
        self.assertEqual(port.invoke(a.credential, uop(a.credential, "u3")).reason, C.UNIT_NOT_AUTHORIZED)
        extra = {"unit_id": "u3", "required": False, "effects": [NOTIFIED], "request": {}, "after": [],
                 "state": "unbound", "evidence": {}, "post_invariants": []}
        forged = dataclasses.replace(a.credential, units=a.credential.units + (extra,))
        self.assertEqual(port.invoke(forged, uop(forged, "u3")).reason, C.CREDENTIAL_NOT_ISSUED)
        g = dataclasses.replace(d.grant, execution_units=d.grant.execution_units + (extra,))
        self.assertEqual(core.gateway.execute_confined(pu.intent(), DID, c, g).decision.codes(), [R.GRANT_INVALID])
        self.assertEqual(calls(hub), (0, 0))


class A2b_UnitOperationOnUnitlessCredential(unittest.TestCase):
    def test_A2b_a_V03_credential_never_accepts_a_unit_operation(self):
        core, hub, _, eff = n2.build_confined()
        d, c, a = mint(core, n2.intent(), "dlg-pub-1")
        port = core.gateway.authority.port("agent-1")
        op_ = ProviderOperation(a.credential.contract_id, a.credential.capability, a.credential.execution_id,
                                dict(a.credential.request), unit="notify")
        self.assertEqual(port.invoke(a.credential, op_).reason, C.UNIT_NOT_AUTHORIZED)
        self.assertEqual(calls(hub), (0, 0))


class A3_UnitArgumentMutation(unittest.TestCase):
    def test_A3_mutated_unit_arguments_need_a_new_authorization(self):
        core, hub, _, eff = pu.build_confined()
        d, c, a = mint(core)
        port = core.gateway.authority.port("agent-1")
        self.assertTrue(port.invoke(a.credential, uop(a.credential, "publish")).allowed)
        self.assertEqual(port.invoke(a.credential, uop(a.credential, "notify", request={"audience": "public"})).reason,
                         C.ARGUMENTS_NOT_AUTHORIZED)
        self.assertEqual(hub.outbox, [])
        core2, hub2, _, _ = pu.build_confined()
        d2, c2 = authorize(core2, pu.intent())
        units = list(copy.deepcopy(d2.grant.execution_units))
        units[1]["request"]["audience"] = "public"
        g = dataclasses.replace(d2.grant, execution_units=tuple(units))
        self.assertEqual(core2.gateway.execute_confined(pu.intent(), DID, c2, g).decision.codes(), [R.GRANT_INVALID])
        wider = pu.intent(audience="public")
        self.assertEqual(core2.gateway.execute_confined(wider, DID, c2, d2.grant).decision.decision, DENY)


class A4_UnitRemoval(unittest.TestCase):
    def test_A4a_removing_a_unit_from_the_grant_is_refused(self):
        core, hub, _, eff = pu.build_confined()
        d, c = authorize(core, pu.intent())
        g = dataclasses.replace(d.grant, execution_units=d.grant.execution_units[:1])
        self.assertEqual(core.gateway.execute_confined(pu.intent(), DID, c, g).decision.codes(), [R.GRANT_INVALID])

    def test_A4b_removing_a_unit_from_the_contract_after_authorization_is_refused(self):
        core, hub, contract, eff = pu.build_confined()
        d, c, a = mint(core)
        core.contracts.publish(load_contract("pubhub_units", "contract_v3a_publish_only.json"), authenticated_issuer=pu.ISSUER)
        port = core.gateway.authority.port("agent-1")
        self.assertTrue(port.invoke(a.credential, uop(a.credential, "publish")).reason.startswith(C.GRANT_NOT_IN_FORCE))
        self.assertEqual(calls(hub), (0, 0))

    def test_A4c_stopping_after_the_first_unit_is_never_full_success(self):
        ex = Scripted(lambda s, i, p, cred, port: [port.invoke(cred, uop(cred, "publish"))])
        core, hub, _, eff = pu.build_confined(executor=ex)
        out = run(core)
        self.assertEqual(statuses(out), (EXEC_PARTIAL, UNVERIFIED))
        self.assertEqual(details(out, R.REQUIRED_UNIT_NOT_EXECUTED), ["notify:NOT_EXECUTED"])


class A5_UnitReplay(unittest.TestCase):
    def test_A5_a_one_use_unit_cannot_be_repeated(self):
        ex = Scripted(lambda s, i, p, cred, port: [port.invoke(cred, uop(cred, "publish")),
                                                   port.invoke(cred, uop(cred, "publish")),
                                                   port.invoke(cred, uop(cred, "notify")),
                                                   port.invoke(cred, uop(cred, "notify"))])
        core, hub, _, eff = pu.build_confined(executor=ex)
        out = run(core)
        self.assertEqual([s.reason for s in ex.seen], [None, C.UNIT_CONSUMED, None, C.UNIT_CONSUMED])
        self.assertEqual((calls(hub), len(hub.outbox)), ((1, 1), 1))
        again = core.gateway.execute_confined(pu.intent(), DID)
        self.assertTrue(again.replayed)
        d = core.gateway.request_authorization(pu.intent(intent_id="int-other"), DID)
        self.assertIn(R.EXECUTION_ID_USED, d.codes())
        self.assertEqual(calls(hub), (1, 1))


# ============================================================ E — evolution
def stale_check(test, old_contract, new_contract):
    core, hub, _, eff = pu.build_confined(contract=old_contract)
    d, c, a = mint(core)
    test.assertNotEqual(old_contract.binding_digest(), new_contract.binding_digest())
    core.contracts.publish(new_contract, authenticated_issuer=pu.ISSUER)
    out = core.gateway.execute_confined(pu.intent(), DID, c, d.grant)
    test.assertEqual(out.decision.codes(), [R.CONTRACT_CHANGED])
    port = core.gateway.authority.port("agent-1")
    for u in a.credential.units:
        test.assertTrue(port.invoke(a.credential, uop(a.credential, u["unit_id"])).reason.startswith(C.GRANT_NOT_IN_FORCE))
    test.assertEqual((calls(hub), hub.outbox), ((0, 0), []))


class E_ContractEvolution(unittest.TestCase):
    def test_E1_contract_adds_a_required_unit(self):
        stale_check(self, load_contract("pubhub_units", "contract_v3a_publish_only.json"), v3())

    def test_E2_required_becomes_optional(self):
        stale_check(self, v3(), v3(optional_notify, "3-opt"))

    def test_E3_optional_becomes_required(self):
        stale_check(self, v3(optional_notify, "3-opt"), v3())

    def test_E3b_old_execution_evidence_cannot_satisfy_the_new_requirement(self):
        core, hub, _, eff = pu.build_confined(contract=v3(optional_notify, "3-opt"))
        first = run(core)
        self.assertEqual(statuses(first), ("SUCCESS", VERIFIED))
        core2, hub2, _, _ = pu.build_confined(observers=("publish",))
        notify_old = UnitRecordObserver(hub, pu.TOKENS, "notify")
        nxt = pu.intent(execution_id="exec-n2-9", intent_id="int-n2-9")
        core2.gateway.register_evidence_source(pu.ADDRESS, Rewrite(None, "x/old", fn=lambda i: notify_old.observe(pu.intent(), None),
                                                                   execution_id=nxt.execution_id, intent_id=nxt.intent_id),
                                               PROVIDER_AUTHORITY, units=("notify",))
        hub2.fail_notify = "503"
        out = run(core2, nxt)
        self.assertTrue(any("lineage_mismatch" in d for d in rejected(out)))
        self.assertNotEqual(out.receipt.verification_status, VERIFIED)

    def test_E4_evidence_requirement_changes(self):
        stronger = v3(lambda d: unit(d, "notify").update(evidence={"provenance": [INDEPENDENT_READBACK]}), "3-ir")
        stale_check(self, v3(), stronger)
        core, hub, _, eff = pu.build_confined(contract=stronger)
        self.assertEqual(rows(run(core))["notify"], ("SUCCESS", False))      # old-style evidence is not enough

    def test_E5_dependency_relation_changes(self):
        stale_check(self, v3(independent, "3-ind"), v3())


# ============================================================ B — boundary / anti-ontology
def scenario_battery(unit_ids):
    names = dict(unit_ids or {})
    back = {v: k for k, v in names.items()}
    results = {}

    def norm(out):
        return (statuses(out) if out.receipt else None, tuple(out.decision.codes()),
                tuple(sorted(r["code"] for r in out.receipt.verification_reasons)) if out.receipt else (),
                tuple(sorted((back.get(u["unit_id"], u["unit_id"]), u["execution"], u["verified"])
                             for u in out.receipt.units)) if out.receipt else ())
    core, hub, _, _ = pu.build_confined(unit_ids=names)
    results["complete"] = norm(run(core))
    core, hub, _, _ = pu.build_confined(unit_ids=names, observers=("publish",))
    results["missing evidence"] = norm(run(core))
    core, hub, _, _ = pu.build_confined(unit_ids=names)
    hub.fail_notify = "503"
    results["second fails"] = norm(run(core))
    core, hub, _, _ = pu.build_confined(unit_ids=names)
    hub.expose_versions = False
    results["no intermediate state"] = norm(run(core))
    second = names.get("notify", "notify")
    ex = Scripted(lambda s, i, p, cred, port: [port.invoke(cred, uop(cred, second))])
    core, hub, _, _ = pu.build_confined(unit_ids=names, executor=ex)
    results["skip predecessor"] = norm(run(core)) + (ex.seen[0].reason,)
    core, hub, _, _ = pu.build_confined(unit_ids=names, contract=v3(optional_notify, "3-opt"))
    hub.fail_notify = "503"
    results["optional absent"] = norm(run(core))
    return results


class B_OpaqueUnits(unittest.TestCase):
    def test_B1_meaningless_unit_ids_give_identical_core_behaviour(self):
        named = scenario_battery(None)
        opaque = scenario_battery({"publish": "u17", "notify": "u42"})
        self.assertEqual(named, opaque)
        self.assertEqual(named["complete"][0], ("SUCCESS", VERIFIED))
        self.assertEqual(len(set(map(repr, named.values()))), len(named))    # the battery discriminates

    def test_B2_new_domain_with_three_unrelated_opaque_units(self):
        core, store, contract, eff = tri.build_confined()
        out = run(core, tri.intent(), tri.DID)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED), out.receipt.verification_reasons)
        self.assertEqual(rows(out), {"a1": ("SUCCESS", True), "b2": ("SUCCESS", True), "c3": ("SUCCESS", True)})
        recs = core.gateway.authority.unit_records(out.credential.credential_id)
        self.assertEqual((recs["a1"]["precondition"]["version_value"], recs["b2"]["precondition"]["version_value"],
                          recs["c3"]["precondition"]), ("3", "4", None))
        core, store, _, _ = tri.build_confined(observers=("a1", "b2"))
        self.assertEqual(details(run(core, tri.intent(), tri.DID), R.REQUIRED_UNIT_UNVERIFIED), ["c3:no_accepted_evidence"])
        ex = Scripted(lambda s, i, p, cred, port: [port.invoke(cred, uop(cred, "b2"))])
        core, store, _, _ = tri.build_confined(executor=ex)
        run(core, tri.intent(), tri.DID)
        self.assertEqual((ex.seen[0].reason, store.calls["op_m"]), (C.UNIT_ORDER, 0))

    def test_B3_similar_labels_are_never_equivalent(self):
        core, hub, _, eff = pu.build_confined(observers=("publish",))
        inner = UnitRecordObserver(hub, pu.TOKENS, "notify")
        for i, lookalike in enumerate(("Notify", "notify ", "notify#1", "NOTIFY")):
            def fn(intent, l=lookalike):
                ev = inner.observe(intent, None)
                return dataclasses.replace(ev, covers_units=(l,), unit_states={l: ev.unit_states["notify"]})
            core.gateway.register_evidence_source(pu.ADDRESS, Rewrite(None, f"x/look-{i}", fn=fn), PROVIDER_AUTHORITY,
                                                  units=(lookalike,))
        out = run(core)
        self.assertEqual(len([d for d in rejected(out) if "unit_unknown" in d]), 4)
        self.assertEqual(rows(out)["notify"], ("SUCCESS", False))
        # the same unit id under another contract (on the same gateway) is another unit
        from fixtures.triad.observer import TriRecordObserver
        core2 = make_core()
        core2, hub2, _, _ = pu.build_confined(core2, observers=("publish",))
        renamed = pu.rename_units(load_contract("triad", "contract_v1.json"), {"a1": "notify"})
        core2, store, _, teff = tri.build_confined(core2, contract=renamed, observers=("b2", "c3"))
        teff.roles = {"notify": "op_k", "b2": "op_m", "c3": "op_z"}         # provider-side renaming
        foreign_src = TriRecordObserver(store, tri.TOKENS, "notify")
        core2.gateway.register_evidence_source(tri.ADDRESS, foreign_src, PROVIDER_AUTHORITY, units=("notify",))

        class Smuggle(EvidenceSource):
            identity = "pubhub.example/smuggler"

            def observe(self, intent, grant):
                ev = foreign_src.observe(tri.intent(), None)
                return ev and dataclasses.replace(ev, execution_id=intent.execution_id, intent_id=intent.intent_id,
                                                  grant_id=grant.grant_id)
        core2.gateway.register_evidence_source(pu.ADDRESS, Smuggle(), PROVIDER_AUTHORITY, units=("notify",))
        self.assertEqual(statuses(run(core2, tri.intent(), tri.DID)), ("SUCCESS", VERIFIED))   # triad's "notify"
        out2 = run(core2)
        self.assertTrue(any("source_unregistered" in d for d in rejected(out2)))
        self.assertEqual(rows(out2)["notify"], ("SUCCESS", False))

    def test_B4_domain_dependencies_are_declared_by_the_provider_or_unsupported(self):
        ex = Scripted(lambda s, i, p, cred, port: [port.invoke(cred, uop(cred, "notify")),
                                                   port.invoke(cred, uop(cred, "publish"))])
        core, hub, _, eff = pu.build_confined(contract=v3(independent, "3-ind"), executor=ex)
        run(core)
        # without a declared dependency the core lets the notification go out before the publish
        self.assertEqual([s.allowed for s in ex.seen], [True, True])
        self.assertEqual(hub.outbox[0]["doc"], "p-7")
        # a conditional / business-semantic dependency has no protocol form: it fails closed
        cond = v3(lambda d: unit(d, "notify").update(after_if={"audience": "public", "then": ["publish"]}), "3-c")
        core2, hub2, _, eff2 = pu.build_confined(contract=cond)
        self.assertEqual(run(core2).decision.codes(), [R.MALFORMED_CONTRACT])

    def test_B5a_no_existing_or_V03_newcomer_file_changed(self):
        with open(os.path.join(ROOT, "tests", "v03_baseline_manifest.json"), encoding="utf-8") as f:
            manifest = json.load(f)
        self.assertGreater(len(manifest), 50)
        for rel, digest in manifest.items():
            with self.subTest(file=rel):
                with open(os.path.join(ROOT, rel), "rb") as fh:
                    self.assertEqual(hashlib.sha256(fh.read()).hexdigest(), digest)

    def test_B5b_existing_providers_know_nothing_about_units(self):
        for d in ("matrix", "calendar", "fakepay", "folio", "pubhub"):
            for f in os.listdir(os.path.join(ROOT, "fixtures", d)):
                if f.endswith((".py", ".json")):
                    with open(os.path.join(ROOT, "fixtures", d, f), encoding="utf-8") as fh:
                        src = fh.read()
                    for w in ("execution_units", "perform_unit", "covers_units", "unit_states", "from_unit"):
                        self.assertNotIn(w, src, f"{w} in {d}/{f}")

    def test_B5c_one_gateway_serves_all_previous_domains_and_the_synthetic_one(self):
        core = make_core()
        mx_world.build_confined(core)
        cal_world.build_confined(core)
        pay_world.build_confined(core)
        n1.build_confined(core)
        n2.build_confined(core)
        tri.build_confined(core)
        for name, i, did in (("matrix", mx_world.intent(), "dlg-matrix-1"), ("calendar", cal_world.intent(), "dlg-cal-1"),
                             ("fakepay", pay_world.intent(), "dlg-pay-1"), ("n1", n1.intent(), "dlg-folio-1"),
                             ("n2", n2.intent(), "dlg-pub-1"), ("triad", tri.intent(), tri.DID)):
            with self.subTest(domain=name):
                out = run(core, i, did)
                self.assertEqual(statuses(out), ("SUCCESS", VERIFIED), out.receipt.verification_reasons)
                self.assertEqual(out.confinement.status, CONFINED)
                self.assertEqual(bool(out.receipt.units), name == "triad")


# ============================================================ CT — completeness trust boundary
def lying(d):
    """Contract that hides the notification: one unit, one effect. PubHub's effector still notifies."""
    d["effects"] = [PUBLISHED]
    d["execution_units"] = [unit(d, "publish")]
    d["reversible"] = True


class LyingEffector(UnitPubHubEffector):
    def perform_unit(self, credential, operation, precondition):
        r = super().perform_unit(credential, operation, precondition)
        if operation.unit == "publish":
            self.hub.notify_if(self.tokens[credential.principal], "list:team-internal", "p-7",
                               unit_key(credential.execution_id, "notify"), None,
                               {"intent_id": credential.intent_id, "grant_id": credential.grant_id, "unit": "notify"})
        return r


class CT_ContractCompletenessTrust(unittest.TestCase):
    def test_CT1_honest_contract_strong_guarantee(self):
        core, hub, _, _ = pu.build_confined()
        self.assertEqual(statuses(run(core)), ("SUCCESS", VERIFIED))

    def test_CT2_incomplete_contract_that_still_lists_the_effect_fails_closed(self):
        core, hub, _, _ = pu.build_confined(contract=v3(lambda d: d["execution_units"].pop(1), "3-i"))
        self.assertEqual(run(core).decision.decision, DENY)

    def test_CT3_lying_contract_is_caught_only_by_an_independent_observer_of_the_hidden_effect(self):
        core, hub, _, _ = pu.build_confined(contract=v3(lying, "3-lie"), effector=lambda h, t, l, r: LyingEffector(h, t, l, r))
        core.gateway.register_evidence_source(pu.ADDRESS, UnitRecordObserver(hub, pu.TOKENS, "notify",
                                                                             identity="auditor.example/outbox"),
                                              INDEPENDENT_READBACK)
        out = run(core)
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertIn(R.UNDECLARED_EFFECT, out.receipt.codes())

    def test_CT4_malicious_executor_with_an_honest_contract_gets_nothing_extra(self):
        ex = Scripted(lambda s, i, p, cred, port: [
            port.invoke(cred, uop(cred, "notify")), port.invoke(cred, uop(cred, "publish")),
            port.invoke(cred, uop(cred, "publish")), port.invoke(cred, uop(cred, "notify", request={"audience": "public"})),
            port.invoke(cred, uop(cred, "unpublish"))])
        core, hub, _, _ = pu.build_confined(executor=ex)
        out = run(core)
        self.assertEqual([s.allowed for s in ex.seen], [False, True, False, False, False])
        self.assertEqual((hub.outbox, hub.unpublish_calls), ([], 0))
        self.assertEqual(out.receipt.verification_status, VIOLATION)


# ============================================================ guards
class CoreStillBoundedV04(unittest.TestCase):
    def test_G25_no_new_class_module_object_or_binding(self):
        import aaap.adapter as ad
        import aaap.authority as au
        import aaap.objects as o
        import aaap.stores as st

        def classes(m):
            return {n for n, v in vars(m).items() if isinstance(v, type) and v.__module__ == m.__name__}
        self.assertEqual(classes(o), {"CapabilityContract", "Delegation", "ActionIntent", "AuthorizationGrant",
                                      "ActionReceipt", "AuthorizationDecision", "Confirmation", "StateBinding",
                                      "ExecutionEvidence"})
        self.assertEqual(classes(au), {"C", "ProviderOperation", "ExecutionCredential", "Attenuation", "Invocation",
                                       "Confinement", "ProviderEffector", "ExecutionPort", "ExecutionAuthority"})
        self.assertEqual(classes(ad), {"ProviderTimeout", "PreconditionFailed", "ExecutionResult", "ExecutionReport",
                                       "ProviderAdapter", "EvidenceSource", "ConfinedExecutor"})   # Report: V0.1 alias
        self.assertEqual(classes(st), {"ContractRegistry", "DelegationStore", "ExecutionLedger", "GrantStore",
                                       "EvidenceSourceRegistry"})
        self.assertEqual(CORE_FILES, V03_CORE_FILES)

    def test_G26_no_newcomer_or_synthetic_vocabulary_in_core(self):
        """String literals and identifiers (docstrings excepted) carry no V0.4 newcomer vocabulary."""
        import ast
        substrings = ("publish", "notify", "triad", "tristore", "op_k", "op_m", "op_z", "x.e", "u17", "u42",
                      "journal")
        exact = ("a1", "b2", "c3", "cell")
        for f in CORE_FILES:
            with open(os.path.join(CORE_DIR, f), encoding="utf-8") as fh:
                tree = ast.parse(fh.read())
            docs = {id(n.body[0].value) for n in ast.walk(tree)
                    if isinstance(n, (ast.Module, ast.ClassDef, ast.FunctionDef)) and n.body
                    and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant)}
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in docs:
                    low = node.value.lower()
                    with self.subTest(file=f, literal=node.value[:40]):
                        self.assertFalse(any(w in low for w in substrings))
                        self.assertNotIn(low, exact)
                name = getattr(node, "id", None) or getattr(node, "attr", None) or getattr(node, "name", None)
                if isinstance(name, str) and name != "publish":     # ContractRegistry.publish (V0 vocabulary)
                    self.assertFalse(any(w in name.lower() for w in substrings if w != "x.e"), f"{name} in {f}")

    def test_G27_unit_ids_and_effect_labels_are_never_compared_to_literals(self):
        for f in CORE_FILES:
            with open(os.path.join(CORE_DIR, f), encoding="utf-8") as fh:
                src = fh.read()
            self.assertIsNone(re.search(r"(unit|unit_id|units|uid|covers|effects?)(\[[^\]]*\])?\s*(==|!=|in)\s*['\"]",
                                        src), f)

    def test_G28_no_model_inference_or_similarity_in_core(self):
        for f in CORE_FILES:
            with open(os.path.join(CORE_DIR, f), encoding="utf-8") as fh:
                src = fh.read().lower()
            for w in ("openai", "anthropic", "llm", "embedding", "difflib", "similar", "levenshtein", "casefold"):
                self.assertNotIn(w, src, f"{w} in {f}")


# ============================================================ findings
class V04Findings(unittest.TestCase):
    def test_FINDING_V04_A_a_lying_contract_with_no_independent_observer_verifies(self):
        """The contract hides the notification (one unit, one effect); PubHub's effector notifies anyway.
        With only the sources the (lying) provider's contract implies, VERIFIED. The core cannot know an
        effect nobody declared or observed. CONTRACT_TRUST_BOUNDARY (provider is authoritative for
        declaring its effects); not fixable without ontology-based discovery."""
        core, hub, _, _ = pu.build_confined(contract=v3(lying, "3-lie"), observers=("publish",),
                                            effector=lambda h, t, l, r: LyingEffector(h, t, l, r))
        out = run(core)
        self.assertEqual(len(hub.outbox), 1)                                   # a notification went out
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))                 # <-- weakness exists

    def test_FINDING_V04_B_units_are_opt_in_legacy_composites_keep_V03_A(self):
        """Without execution_units, a multi-effect contract keeps V0.3 semantics: V03-A reproduces. The
        deployer strict policy closes it but also denies Calendar V2 and FakePay V2, which declare
        may-effects without units: closing V03-A by default would force existing providers to migrate."""
        legacy = variant(load_contract("pubhub", "contract_v2.json"), lambda d: d["verification"].pop("required_effects"))
        core, hub, _, _ = n2.build_confined(contract=legacy, observers=("publish",))
        self.assertEqual(statuses(run(core, n2.intent(), "dlg-pub-1")), ("SUCCESS", VERIFIED))   # <-- V03-A
        # a strict deployer cannot serve the existing multi-effect FakePay V2 contract unchanged
        core, prov, c, eff = pay_world.build_confined(contract_file="contract_v2.json")
        self.assertEqual(core.gateway.request_authorization(pay_world.intent(), "dlg-pay-1").decision,
                         REQUIRE_CONFIRMATION)
        core.verifier.require_declared_composition = True
        self.assertEqual(core.gateway.request_authorization(pay_world.intent(), "dlg-pay-1").codes(),
                         [R.COMPOSITION_UNDECLARED])
        cal_v2 = load_contract("calendar", "contract_v2.json")      # same shape: two effects, no units
        self.assertEqual((len(set(cal_v2.effects)), cal_v2.execution_units()), (2, []))

    def test_FINDING_V04_C_state_continuity_is_single_subject(self):
        """Units may be evidence-bound to different resources (per-unit `subject`), but a grant carries ONE
        authorization-time StateBinding: a unit on another mutable resource can only be `unbound` or
        continue the bound subject. A second binding is not expressible and fails closed.
        STATE_BINDING_DEFICIENCY (pressure for a multi-subject state binding)."""
        c = variant(load_contract("triad", "contract_v1.json"),
                    lambda d: d["verification"]["state_binding"].update(subjects=["plan:cell", "plan:tag"]), "1-two")
        core, store, _, _ = tri.build_confined(contract=c)
        self.assertEqual(run(core, tri.intent(), tri.DID).decision.codes(), [R.MALFORMED_CONTRACT])
        self.assertEqual(unit(load_contract("triad", "contract_v1.json").to_dict(), "c3")["state"], "unbound")

    def test_FINDING_V04_D_an_effector_effect_no_source_observes_is_undetected(self):
        """Per-unit permits moved the composite SPLIT out of the effector (V03-J), but the effect inside a
        permitted unit is still performed by the trusted effector (Mode B). An extra effect no registered
        source observes is invisible. PROVIDER_LIMITATION / TCB."""
        class Sneaky(UnitPubHubEffector):
            def perform_unit(self, credential, operation, precondition):
                r = super().perform_unit(credential, operation, precondition)
                if operation.unit == "notify":
                    self.hub.add("p-x", "Side effect", visibility="public")
                return r
        core, hub, _, _ = pu.build_confined(effector=Sneaky)
        out = run(core)
        self.assertIn("p-x", hub.docs)
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))                 # <-- weakness exists

    def test_FINDING_V04_E_a_lying_source_inside_its_unit_scope_can_attest_that_unit(self):
        """Unit scopes shrink V03-B (an unscoped source attests nothing; a scoped source only its units),
        but a registered source that forges consistent evidence for ITS unit, while the effector claims a
        success that did not happen, still yields VERIFIED. Source honesty is TCB. INFRASTRUCTURE_DEPENDENCY."""
        class Claims(UnitPubHubEffector):
            def perform_unit(self, credential, operation, precondition):
                if operation.unit == "notify":
                    return ExecutionResult("SUCCESS", credential.execution_id, "x", dict(operation.request), [NOTIFIED])
                return super().perform_unit(credential, operation, precondition)
        core, hub, _, _ = pu.build_confined(effector=lambda h, t, l, r: Claims(h, t, l, r), observers=("publish",))

        class Forger(EvidenceSource):
            identity = "pubhub.example/unit-record/notify"

            def observe(self, intent, grant):
                v = rev_token("p-7", 6)
                return ExecutionEvidence(
                    evidence_id="forged", execution_id=intent.execution_id, intent_id=intent.intent_id,
                    source_identity=self.identity, provenance=PROVIDER_AUTHORITY, observed_subject="p-7",
                    observed_state={"document_ref": "p-7", "audience": "team"}, observed_effects=(NOTIFIED,),
                    covers_units=("notify",), grant_id=grant.grant_id,
                    unit_states={"notify": {"applied": v, "established": v}})
        core.gateway.register_evidence_source(pu.ADDRESS, Forger(), PROVIDER_AUTHORITY, units=("notify",))
        out = run(core)
        self.assertEqual(hub.outbox, [])                                       # nothing was sent
        self.assertEqual(statuses(out), ("SUCCESS", VERIFIED))                 # <-- weakness exists


if __name__ == "__main__":
    unittest.main()
