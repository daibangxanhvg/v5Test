"""X1 — revocation, run identically against all three domains."""
import unittest

from aaap import ALLOW, DENY, REQUIRE_CONFIRMATION, Confirmation, R

from fixtures.calendar import world as cal_world
from fixtures.fakepay import world as pay_world
from fixtures.matrix import world as mx_world

DOMAINS = [
    ("matrix", mx_world, "dlg-matrix-1", lambda p: len(p.timeline(mx_world.ALLOWED_ROOM))),
    ("calendar", cal_world, "dlg-cal-1", lambda p: p.patch_calls),
    ("fakepay", pay_world, "dlg-pay-1", lambda p: len(p.ledger)),
]


class RevocationTests(unittest.TestCase):
    def test_X1_revocation_beats_prior_authorization_and_confirmation(self):
        for name, w, did, effects in DOMAINS:
            with self.subTest(domain=name):
                core, provider, _ = w.build()
                intent = w.intent()
                d = core.gateway.request_authorization(intent, did)
                confirmation = None
                if d.decision == REQUIRE_CONFIRMATION:
                    confirmation = Confirmation.from_decision(d, "lam", "2026-10-13T09:31:00+07:00")
                    d = core.gateway.request_authorization(intent, did, confirmation)
                self.assertEqual(d.decision, ALLOW)
                core.delegations.revoke(did, by_principal="lam")
                out = core.gateway.execute(intent, did, confirmation)
                self.assertEqual(out.decision.decision, DENY)
                self.assertEqual(out.decision.codes(), [R.DELEGATION_REVOKED])
                self.assertIsNone(out.receipt)
                self.assertEqual(effects(provider), 0)

    def test_X1b_agent_cannot_revoke_or_unrevoke(self):
        core, _, _ = pay_world.build()
        with self.assertRaises(PermissionError):
            core.delegations.revoke("dlg-pay-1", by_principal="agent-1")


if __name__ == "__main__":
    unittest.main()
