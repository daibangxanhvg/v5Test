import unittest

from aaap import ALLOW, DENY, VERIFIED, VIOLATION, R

from fixtures.calendar import world
from fixtures.calendar.adapter import FullReplaceCalendarAdapter
from tests.harness import load_contract


class CalendarTests(unittest.TestCase):
    def setUp(self):
        self.core, self.cal, self.v1 = world.build()
        self.gw = self.core.gateway

    def test_C1_valid_reschedule_allow_verified(self):
        self.assertEqual(self.gw.request_authorization(world.intent(), "dlg-cal-1").decision, ALLOW)
        out = self.gw.execute(world.intent(), "dlg-cal-1")
        self.assertEqual(out.decision.decision, ALLOW)
        self.assertEqual(out.receipt.verification_status, VERIFIED, out.receipt.verification_reasons)
        ev = self.cal.events["evt-1"]
        self.assertEqual((ev["start"], ev["end"]), ("2026-10-14T14:00:00+07:00", "2026-10-14T15:00:00+07:00"))
        self.assertEqual(ev["attendees"], world.ORIGINAL["attendees"])

    def test_C2_outside_working_hours_deny(self):
        out = self.gw.execute(world.intent(new_start="2026-10-14T18:00:00+07:00",
                                           new_end="2026-10-14T19:00:00+07:00"), "dlg-cal-1")
        self.assertEqual(out.decision.decision, DENY)
        self.assertIn(R.CONSTRAINT_VIOLATED, out.decision.codes())
        self.assertIn("working_hours", out.decision.reasons[0]["detail"])
        self.assertEqual(self.cal.patch_calls, 0)

    def test_C2b_same_wall_clock_in_other_offset_is_still_checked(self):
        # 10:00Z = 17:00 ICT start, 11:00Z = 18:00 ICT end -> outside
        out = self.gw.execute(world.intent(new_start="2026-10-14T10:00:00Z", new_end="2026-10-14T11:00:00Z"),
                              "dlg-cal-1")
        self.assertEqual(out.decision.decision, DENY)

    def test_C2c_event_in_non_delegated_calendar_deny(self):
        out = self.gw.execute(world.intent(event_id="evt-2"), "dlg-cal-1")
        self.assertEqual(out.decision.decision, DENY)
        self.assertIn("allowed_calendar", out.decision.reasons[0]["detail"])

    def test_C3a_plan_removes_attendee_denied_pre_execution(self):
        core, cal, _ = world.build(adapter_cls=FullReplaceCalendarAdapter)
        out = core.gateway.execute(world.intent(), "dlg-cal-1")
        self.assertEqual(out.decision.decision, DENY)
        codes = out.decision.codes()
        self.assertIn(R.INVARIANT_VIOLATED, codes)      # preserve_attendees on the plan
        self.assertIn(R.PLAN_EXCEEDS_INTENT, codes)     # plan field not derived from intent
        self.assertEqual(cal.patch_calls, 0)

    def test_C3b_provider_unexpectedly_drops_attendee_violation(self):
        self.cal.drop_attendee_on_update = "binh@example.com"
        out = self.gw.execute(world.intent(), "dlg-cal-1")
        self.assertEqual(out.decision.decision, ALLOW)
        self.assertEqual(out.receipt.execution_result["status"], "SUCCESS")
        self.assertEqual(out.receipt.verification_status, VIOLATION)
        self.assertTrue(any("preserve_attendees" in r["detail"] for r in out.receipt.verification_reasons))

    def test_C4_contract_v2_new_effect_requires_reauthorization(self):
        d1 = self.gw.request_authorization(world.intent(), "dlg-cal-1")
        self.assertEqual(d1.decision, ALLOW)
        self.core.contracts.publish(load_contract("calendar", "contract_v2.json"))
        out = self.gw.execute(world.intent(), "dlg-cal-1")
        self.assertEqual(out.decision.decision, DENY)
        self.assertEqual(out.decision.codes(), [R.CONTRACT_CHANGED])
        self.assertEqual(self.cal.patch_calls, 0)


if __name__ == "__main__":
    unittest.main()
