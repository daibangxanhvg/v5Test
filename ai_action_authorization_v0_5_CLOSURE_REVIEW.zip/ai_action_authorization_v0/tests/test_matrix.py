import unittest

from aaap import ALLOW, DENY, UNVERIFIED, VERIFIED, R

from fixtures.matrix import world


class MatrixTests(unittest.TestCase):
    def setUp(self):
        self.core, self.hs, self.contract = world.build()
        self.gw = self.core.gateway

    def test_M1_allowed_room_allow(self):
        d = self.gw.request_authorization(world.intent(), "dlg-matrix-1")
        self.assertEqual(d.decision, ALLOW, d.reasons)
        out = self.gw.execute(world.intent(), "dlg-matrix-1")
        self.assertEqual(out.receipt.verification_status, VERIFIED, out.receipt.verification_reasons)
        self.assertEqual(len(self.hs.timeline(world.ALLOWED_ROOM)), 1)

    def test_M2_unauthorized_room_deny(self):
        out = self.gw.execute(world.intent(room_id=world.OTHER_ROOM), "dlg-matrix-1")
        self.assertEqual(out.decision.decision, DENY)
        self.assertIn(R.CONSTRAINT_VIOLATED, out.decision.codes())
        self.assertIn("allowed_rooms", out.decision.reasons[0]["detail"])
        self.assertIsNone(out.receipt)
        self.assertEqual(self.hs.timeline(world.OTHER_ROOM), [])  # room is joinable: only the verifier stopped it

    def test_M3_same_execution_id_twice_one_message(self):
        first = self.gw.execute(world.intent(), "dlg-matrix-1")
        second = self.gw.execute(world.intent(), "dlg-matrix-1")
        self.assertTrue(second.replayed)
        self.assertIs(second.receipt, first.receipt)
        self.assertEqual(len(self.hs.timeline(world.ALLOWED_ROOM)), 1)
        self.assertEqual(self.hs.send_calls, 1)

    def test_M3b_same_execution_id_different_content_denied(self):
        self.gw.execute(world.intent(), "dlg-matrix-1")
        out = self.gw.execute(world.intent(content="something else", intent_id="int-m-2"), "dlg-matrix-1")
        self.assertEqual(out.decision.decision, DENY)
        self.assertIn(R.EXECUTION_ID_USED, out.decision.codes())
        self.assertEqual(len(self.hs.timeline(world.ALLOWED_ROOM)), 1)

    def test_M3c_ledger_lost_provider_txnid_dedupes(self):
        """A second gateway (fresh, empty ledger) retries the same execution_id:
        the core cannot help, Matrix txnId idempotency does."""
        self.gw.execute(world.intent(), "dlg-matrix-1")
        from tests.harness import make_core
        core2, _, _ = world.build(make_core())
        # point core2 at the SAME homeserver
        from fixtures.matrix.adapter import MatrixAdapter
        core2.gateway.register_adapter("matrix.send_message", MatrixAdapter(self.hs, {"lam": "tok-lam"}))
        out = core2.gateway.execute(world.intent(), "dlg-matrix-1")
        self.assertEqual(out.decision.decision, ALLOW)
        self.assertEqual(len(self.hs.timeline(world.ALLOWED_ROOM)), 1)

    def test_M4_success_without_readback_is_unverified(self):
        self.hs.readback_available = False
        out = self.gw.execute(world.intent(), "dlg-matrix-1")
        self.assertEqual(out.receipt.execution_result["status"], "SUCCESS")
        self.assertEqual(out.receipt.verification_status, UNVERIFIED)
        self.assertNotEqual(out.receipt.verification_status, VERIFIED)
        self.assertIn(R.READ_BACK_UNAVAILABLE, out.receipt.codes())


if __name__ == "__main__":
    unittest.main()
